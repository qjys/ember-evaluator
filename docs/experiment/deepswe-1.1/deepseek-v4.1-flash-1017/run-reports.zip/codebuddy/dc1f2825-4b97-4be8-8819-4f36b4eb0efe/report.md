<!-- snapshotDigest: 6e9aeb7e9078e6bb96b4fd6037f6303e52448d337d0336b6e45ee90e13e94097 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 50.00%（10/20）**

Run: dc1f2825-4b97-4be8-8819-4f36b4eb0efe · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T10:42:50.137Z / 2026-11-16T04:06:47.646Z |
| 总耗时 | 65 小时 23 分 58 秒 |
| 答对 / 答错 / 解题超时 | 10 / 4 / 6 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 6 / 0 |

已选择 20 题；已保存 20 条记录；待运行 0 题。
有效评分覆盖率：20/20（100.00%）。
执行失败 0；超时 6；取消 0；不支持 0。
Agent 解题超时 6（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 20 |
| 计分题数 | 20 |
| 正常评分题数 | 14 |
| 答对题数 | 10 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 50.00% |
| 平均奖励 | 0.5 |
| 奖励 f2p | 0.6479 |
| 奖励 p2p | 0.6977 |
| 奖励 partial | 0.6567 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 65 小时 23 分 58 秒 |
| 环境准备耗时 | 1 小时 19 分 0 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 41 分 25 秒 | 12 分 52 秒 | 1 小时 0 分 4 秒 | 20 |
| 任务准备 | 0.21 毫秒 | 0.12 毫秒 | 0.37 毫秒 | 20 |
| 环境启动 | 3 秒 | 2 秒 | 4 秒 | 20 |
| 解题 | 40 分 56 秒 | 12 分 35 秒 | 59 分 58 秒 | 20 |
| 产物传输 | 2 秒 | 653.61 毫秒 | 3 秒 | 20 |
| 证据收集 | 748.95 毫秒 | 106.44 毫秒 | 3 秒 | 20 |
| 资源清理 | 1 秒 | 836.96 毫秒 | 3 秒 | 20 |
| 评分 | 31 秒 | 2 秒 | 2 分 52 秒 | 14 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 07e7c988-6c2b-469d-a331-715e8b606ed3 | 1,800 | 1800 | 4 | 4 | 7200 |
| 0782883e-7696-4cd0-b6c0-20cd6406c262 | 1,800 | 1800 | 4 | 4 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 214,097,643 | 3,213,641 | 217,311,284 | 14 / 20 | — |
| 运行累计 | 214,097,643 | 3,213,641 | 217,311,284 | 14 / 24 | 10 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| abs-module-cache-flags | completed | 1 | 1675.19 | 15.71 | complete / complete | — | [result](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/33a6a6a9-aa97-4df7-bc41-3d14e5c2c996/result.json) · [文件清单](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/33a6a6a9-aa97-4df7-bc41-3d14e5c2c996/files.json) · [轨迹](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/33a6a6a9-aa97-4df7-bc41-3d14e5c2c996/agent/trajectory.jsonl) |
| anko-typed-variable-bindings | completed | 1 | 2429.24 | 15.91 | complete / complete | — | [result](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/dd9b7ddb-8da9-43f2-a294-f7585d772eb3/result.json) · [文件清单](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/dd9b7ddb-8da9-43f2-a294-f7585d772eb3/files.json) · [轨迹](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/dd9b7ddb-8da9-43f2-a294-f7585d772eb3/agent/trajectory.jsonl) |
| bandit-structured-nosec-directives | completed | 0 | 2365.16 | 8.10 | complete / complete | — | [result](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/2513eab5-4347-4bd9-8b83-7f166059d458/result.json) · [文件清单](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/2513eab5-4347-4bd9-8b83-7f166059d458/files.json) · [轨迹](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/2513eab5-4347-4bd9-8b83-7f166059d458/agent/trajectory.jsonl) |
| csstree-shorthand-expansion-compression | completed | 1 | 1799.14 | 1.94 | complete / complete | — | [result](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/2822cb75-0f30-4f38-acc9-0eefb331b21e/result.json) · [文件清单](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/2822cb75-0f30-4f38-acc9-0eefb331b21e/files.json) · [轨迹](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/2822cb75-0f30-4f38-acc9-0eefb331b21e/agent/trajectory.jsonl) |
| effect-sse-httpapi-streaming | completed | 0 | 2947.37 | 13.42 | complete / complete | — | [result](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/cf8ad18a-8d3e-430b-a571-680d483de45b/result.json) · [文件清单](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/cf8ad18a-8d3e-430b-a571-680d483de45b/files.json) · [轨迹](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/cf8ad18a-8d3e-430b-a571-680d483de45b/agent/trajectory.jsonl) |
| fastapi-implicit-head-options | completed | 1 | 3132.37 | 42.33 | complete / complete | — | [result](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/b9cb0eaa-ca02-4af6-a1d8-911dacb52db1/result.json) · [文件清单](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/b9cb0eaa-ca02-4af6-a1d8-911dacb52db1/files.json) · [轨迹](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/b9cb0eaa-ca02-4af6-a1d8-911dacb52db1/agent/trajectory.jsonl) |
| goreleaser-retry-publish-auditing | completed | 1 | 2088.96 | 65.48 | complete / complete | — | [result](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/34508876-9ce7-49d5-9614-e3bbb94244e3/result.json) · [文件清单](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/34508876-9ce7-49d5-9614-e3bbb94244e3/files.json) · [轨迹](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/34508876-9ce7-49d5-9614-e3bbb94244e3/agent/trajectory.jsonl) |
| httpx-deterministic-cookie-store | completed | 0 | 1251.52 | 11.88 | complete / complete | — | [result](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/4e56de94-834c-46eb-9af7-4a616d0d2c73/result.json) · [文件清单](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/4e56de94-834c-46eb-9af7-4a616d0d2c73/files.json) · [轨迹](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/4e56de94-834c-46eb-9af7-4a616d0d2c73/agent/trajectory.jsonl) |
| katex-multicolumn-array-spans | timeout (agent) | 0 | 3597.32 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/ee0bdb2f-ca87-4436-9e84-a6675595635c/result.json) · [文件清单](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/ee0bdb2f-ca87-4436-9e84-a6675595635c/files.json) · [轨迹](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/ee0bdb2f-ca87-4436-9e84-a6675595635c/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | timeout (agent) | 0 | 3597.35 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/ca8d1314-3fe3-40b2-b126-e47691e9cad0/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/ca8d1314-3fe3-40b2-b126-e47691e9cad0/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/ca8d1314-3fe3-40b2-b126-e47691e9cad0/agent/trajectory.jsonl) |
| langchain-request-coalescing | timeout (agent) | 0 | 3597.30 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/2c0ab2af-9c88-4838-b023-7cb085084cd5/result.json) · [文件清单](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/2c0ab2af-9c88-4838-b023-7cb085084cd5/files.json) · [轨迹](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/2c0ab2af-9c88-4838-b023-7cb085084cd5/agent/trajectory.jsonl) |
| numba-stencil-boundary-modes | timeout (agent) | 0 | 3596.76 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/f9d467e6-d9a0-4a50-b7c8-47cb65067a8b/result.json) · [文件清单](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/f9d467e6-d9a0-4a50-b7c8-47cb65067a8b/files.json) · [轨迹](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/f9d467e6-d9a0-4a50-b7c8-47cb65067a8b/agent/trajectory.jsonl) |
| opa-rego-rule-profiling | completed | 0 | 2782.49 | 29.53 | complete / complete | — | [result](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/aff7a846-bcbe-45cf-a5b9-5d3f08ff3c2d/result.json) · [文件清单](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/aff7a846-bcbe-45cf-a5b9-5d3f08ff3c2d/files.json) · [轨迹](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/aff7a846-bcbe-45cf-a5b9-5d3f08ff3c2d/agent/trajectory.jsonl) |
| pest-character-class-coalescing | completed | 1 | 1830.87 | 9.04 | complete / complete | — | [result](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/7b228b8b-ad2c-4303-9ed3-3aee64a96062/result.json) · [文件清单](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/7b228b8b-ad2c-4303-9ed3-3aee64a96062/files.json) · [轨迹](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/7b228b8b-ad2c-4303-9ed3-3aee64a96062/agent/trajectory.jsonl) |
| query-persist-restored-query-state | completed | 1 | 1897.84 | 8.22 | complete / complete | — | [result](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/5dcf4420-c78f-4f86-b2a7-47a242a47f3b/result.json) · [文件清单](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/5dcf4420-c78f-4f86-b2a7-47a242a47f3b/files.json) · [轨迹](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/5dcf4420-c78f-4f86-b2a7-47a242a47f3b/agent/trajectory.jsonl) |
| skrub-duration-encoding | completed | 1 | 1570.32 | 171.76 | complete / complete | — | [result](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/056b53ec-5ccf-495f-923b-456b622a8a3f/result.json) · [文件清单](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/056b53ec-5ccf-495f-923b-456b622a8a3f/files.json) · [轨迹](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/056b53ec-5ccf-495f-923b-456b622a8a3f/agent/trajectory.jsonl) |
| tengo-callable-instance-isolation | timeout (agent) | 0 | 3597.93 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/6c81e41a-ff78-4c02-832e-9505c0421f32/result.json) · [文件清单](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/6c81e41a-ff78-4c02-832e-9505c0421f32/files.json) · [轨迹](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/6c81e41a-ff78-4c02-832e-9505c0421f32/agent/trajectory.jsonl) |
| textual-richlog-follow-state | timeout (agent) | 0 | 3597.88 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/282e5c19-5d09-48a9-badd-c5670117b17a/result.json) · [文件清单](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/282e5c19-5d09-48a9-badd-c5670117b17a/files.json) · [轨迹](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/282e5c19-5d09-48a9-badd-c5670117b17a/agent/trajectory.jsonl) |
| vitest-duration-sharding | completed | 1 | 1014.86 | 30.03 | complete / complete | — | [result](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/fcfe3b4e-ee85-4268-bca1-b180176d8245/result.json) · [文件清单](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/fcfe3b4e-ee85-4268-bca1-b180176d8245/files.json) · [轨迹](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/fcfe3b4e-ee85-4268-bca1-b180176d8245/agent/trajectory.jsonl) |
| ytt-jsonpath-query-api | completed | 1 | 755.33 | 10.61 | complete / complete | — | [result](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/d067cb89-dfee-449c-aebf-8d1d62882280/result.json) · [文件清单](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/d067cb89-dfee-449c-aebf-8d1d62882280/files.json) · [轨迹](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/d067cb89-dfee-449c-aebf-8d1d62882280/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 6；错误记录 6（主流程 6；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 6 | 6 |

## 警告

警告涉及 6 个任务，共 6 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| katex-multicolumn-array-spans | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| koota-composite-trait-aspects | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| langchain-request-coalescing | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| numba-stencil-boundary-modes | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| tengo-callable-instance-isolation | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| textual-richlog-follow-state | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

