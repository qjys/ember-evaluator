<!-- snapshotDigest: 32c9960247c51f63bc4f4baf47f4339600f3f47e74370fbcbd07fb98fda11884 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 66.67%（4/6）**

Run: 294fd52a-9919-4e24-ac18-b175bcdeaf4d · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-16T11:16:52.038Z / 2026-11-16T11:53:15.466Z |
| 总耗时 | 36 分 23 秒 |
| 答对 / 答错 / 解题超时 | 4 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 6 题；已保存 6 条记录；待运行 0 题。
有效评分覆盖率：6/6（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 6 |
| 计分题数 | 6 |
| 正常评分题数 | 6 |
| 答对题数 | 4 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 66.67% |
| 平均奖励 | 0.6667 |
| 奖励 f2p | 0.9894 |
| 奖励 p2p | 0.9994 |
| 奖励 partial | 0.9953 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 36 分 23 秒 |
| 环境准备耗时 | 3 分 2 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 14 分 28 秒 | 9 分 21 秒 | 20 分 26 秒 | 6 |
| 任务准备 | 0.19 毫秒 | 0.12 毫秒 | 0.3 毫秒 | 6 |
| 环境启动 | 4 秒 | 3 秒 | 4 秒 | 6 |
| 解题 | 14 分 8 秒 | 9 分 12 秒 | 20 分 12 秒 | 6 |
| 产物传输 | 2 秒 | 1 秒 | 2 秒 | 6 |
| 证据收集 | 127.51 毫秒 | 111.74 毫秒 | 143.83 毫秒 | 6 |
| 资源清理 | 1 秒 | 1 秒 | 2 秒 | 6 |
| 评分 | 14 秒 | 2 秒 | 42 秒 | 6 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| d24f1652-d846-4564-9a87-520f3885ac06 | 1,800 | 1800 | 3 | 3 | 5400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 90,733,742 | 494,926 | 91,228,668 | 6 / 6 | — |
| 运行累计 | 90,733,742 | 494,926 | 91,228,668 | 6 / 6 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| bandit-structured-nosec-directives | completed | 0 | 615.03 | 8.42 | complete / complete | — | [result](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/c7cde726-4b05-496c-82a5-b4fbd8c180b5/result.json) · [文件清单](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/c7cde726-4b05-496c-82a5-b4fbd8c180b5/files.json) · [轨迹](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/c7cde726-4b05-496c-82a5-b4fbd8c180b5/agent/trajectory.jsonl) |
| csstree-shorthand-expansion-compression | completed | 1 | 551.52 | 1.83 | complete / complete | — | [result](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/0b0d00b9-10a8-4d65-a36c-f5fc4202f693/result.json) · [文件清单](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/0b0d00b9-10a8-4d65-a36c-f5fc4202f693/files.json) · [轨迹](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/0b0d00b9-10a8-4d65-a36c-f5fc4202f693/agent/trajectory.jsonl) |
| effect-sse-httpapi-streaming | completed | 0 | 1084.72 | 13.68 | complete / complete | — | [result](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/b7666fb0-3d3e-4a36-b6fd-c66b85350e02/result.json) · [文件清单](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/b7666fb0-3d3e-4a36-b6fd-c66b85350e02/files.json) · [轨迹](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/b7666fb0-3d3e-4a36-b6fd-c66b85350e02/agent/trajectory.jsonl) |
| fastapi-implicit-head-options | completed | 1 | 777.68 | 42.37 | complete / complete | — | [result](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/a1a0b0b0-4cd9-468c-86ec-8e7c3053c7e8/result.json) · [文件清单](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/a1a0b0b0-4cd9-468c-86ec-8e7c3053c7e8/files.json) · [轨迹](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/a1a0b0b0-4cd9-468c-86ec-8e7c3053c7e8/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | completed | 1 | 1211.85 | 7.68 | complete / complete | — | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/f3038d2d-b9c1-44e8-8c0a-a9816ae26b12/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/f3038d2d-b9c1-44e8-8c0a-a9816ae26b12/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/f3038d2d-b9c1-44e8-8c0a-a9816ae26b12/agent/trajectory.jsonl) |
| query-persist-restored-query-state | completed | 1 | 845.60 | 7.82 | complete / complete | — | [result](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/520d139b-d971-435e-bbd6-12bd93887290/result.json) · [文件清单](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/520d139b-d971-435e-bbd6-12bd93887290/files.json) · [轨迹](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/520d139b-d971-435e-bbd6-12bd93887290/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

