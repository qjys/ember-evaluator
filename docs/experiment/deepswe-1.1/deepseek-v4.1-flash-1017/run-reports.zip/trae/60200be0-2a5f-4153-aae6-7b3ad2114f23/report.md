<!-- snapshotDigest: d691f7c404eac02561f7562b2232bf8652fdb02f948b0b53604fb94ecb41f9d0 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 78.57%（11/14）**

Run: 60200be0-2a5f-4153-aae6-7b3ad2114f23 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T09:03:16.177Z / 2026-11-13T10:42:47.804Z |
| 总耗时 | 1 小时 39 分 32 秒 |
| 答对 / 答错 / 解题超时 | 11 / 3 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 6 / 0 |

已选择 20 题；已保存 20 条记录；待运行 0 题。
有效评分覆盖率：14/20（70.00%）。
执行失败 6；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 6。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 20 |
| 计分题数 | 14 |
| 正常评分题数 | 14 |
| 答对题数 | 11 |
| 无效评测 | 6 |
| 待运行 | 0 |
| 正确率 | 78.57% |
| 平均奖励 | 0.7857 |
| 奖励 f2p | 0.935 |
| 奖励 p2p | 0.997 |
| 奖励 partial | 0.9915 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 39 分 32 秒 |
| 环境准备耗时 | 34 分 32 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 17 分 44 秒 | 5 分 45 秒 | 42 分 25 秒 | 20 |
| 任务准备 | 0.2 毫秒 | 0.12 毫秒 | 0.57 毫秒 | 20 |
| 环境启动 | 3 秒 | 2 秒 | 5 秒 | 20 |
| 解题 | 17 分 6 秒 | 5 分 28 秒 | 42 分 21 秒 | 20 |
| 产物传输 | 1 秒 | 625.13 毫秒 | 2 秒 | 20 |
| 证据收集 | 527.71 毫秒 | 101.87 毫秒 | 2 秒 | 20 |
| 资源清理 | 1 秒 | 778.17 毫秒 | 2 秒 | 20 |
| 评分 | 45 秒 | 5 秒 | 3 分 50 秒 | 14 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 35afa5a6-f850-4226-a9e5-b0a85b7f5540 | 1,800 | 1800 | 4 | 4 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 157,612,276 | 987,028 | 158,599,304 | 14 / 20 | — |
| 运行累计 | 157,612,276 | 987,028 | 158,599,304 | 14 / 20 | 6 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| abs-module-cache-flags | completed | 1 | 649.93 | 16.48 | complete / complete | — | [result](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/031a5eed-7b6f-4b63-af72-f4c3e984943f/result.json) · [文件清单](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/031a5eed-7b6f-4b63-af72-f4c3e984943f/files.json) · [轨迹](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/031a5eed-7b6f-4b63-af72-f4c3e984943f/agent/trajectory.jsonl) |
| anko-typed-variable-bindings | completed | 0 | 364.46 | 14.60 | complete / complete | — | [result](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/91d3af22-f0fb-42ae-9c4c-737af0753186/result.json) · [文件清单](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/91d3af22-f0fb-42ae-9c4c-737af0753186/files.json) · [轨迹](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/91d3af22-f0fb-42ae-9c4c-737af0753186/agent/trajectory.jsonl) |
| bandit-structured-nosec-directives | invalid | — | 855.24 | — | partial / complete | SOLVER\_PROTOCOL\_INVALID; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/7822a0dd-7bf4-4569-a183-586908d26b65/result.json) · [文件清单](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/7822a0dd-7bf4-4569-a183-586908d26b65/files.json) · [轨迹](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/7822a0dd-7bf4-4569-a183-586908d26b65/agent/trajectory.jsonl) |
| csstree-shorthand-expansion-compression | invalid | — | 616.78 | — | partial / complete | SOLVER\_PROTOCOL\_INVALID; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/3cc4025d-2b04-4fa3-b08a-6e9e19764c1e/result.json) · [文件清单](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/3cc4025d-2b04-4fa3-b08a-6e9e19764c1e/files.json) · [轨迹](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/3cc4025d-2b04-4fa3-b08a-6e9e19764c1e/agent/trajectory.jsonl) |
| effect-sse-httpapi-streaming | invalid | — | 2540.72 | — | partial / complete | SOLVER\_PROTOCOL\_INVALID; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/68288da6-1ab2-434a-a0da-0cc2ff646a8a/result.json) · [文件清单](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/68288da6-1ab2-434a-a0da-0cc2ff646a8a/files.json) · [轨迹](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/68288da6-1ab2-434a-a0da-0cc2ff646a8a/agent/trajectory.jsonl) |
| fastapi-implicit-head-options | invalid | — | 762.71 | — | partial / complete | SOLVER\_PROTOCOL\_INVALID; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/670c1748-cca6-4077-8a76-6501d9bed322/result.json) · [文件清单](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/670c1748-cca6-4077-8a76-6501d9bed322/files.json) · [轨迹](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/670c1748-cca6-4077-8a76-6501d9bed322/agent/trajectory.jsonl) |
| goreleaser-retry-publish-auditing | completed | 1 | 997.81 | 64.70 | complete / complete | — | [result](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/63ee59ac-5bc6-481c-9c7c-ee570cc80b41/result.json) · [文件清单](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/63ee59ac-5bc6-481c-9c7c-ee570cc80b41/files.json) · [轨迹](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/63ee59ac-5bc6-481c-9c7c-ee570cc80b41/agent/trajectory.jsonl) |
| httpx-deterministic-cookie-store | completed | 0 | 532.97 | 11.96 | complete / complete | — | [result](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/f80cf6b5-f744-4e43-be62-409f0fa4664d/result.json) · [文件清单](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/f80cf6b5-f744-4e43-be62-409f0fa4664d/files.json) · [轨迹](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/f80cf6b5-f744-4e43-be62-409f0fa4664d/agent/trajectory.jsonl) |
| katex-multicolumn-array-spans | completed | 0 | 1677.56 | 5.11 | complete / complete | — | [result](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/26ea9043-0420-4666-ab50-91d74336e2ae/result.json) · [文件清单](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/26ea9043-0420-4666-ab50-91d74336e2ae/files.json) · [轨迹](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/26ea9043-0420-4666-ab50-91d74336e2ae/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | invalid | — | 2274.50 | — | partial / complete | SOLVER\_PROTOCOL\_INVALID; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/e5f3420b-f168-4f18-bc94-c47c68271167/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/e5f3420b-f168-4f18-bc94-c47c68271167/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/e5f3420b-f168-4f18-bc94-c47c68271167/agent/trajectory.jsonl) |
| langchain-request-coalescing | completed | 1 | 2111.55 | 26.69 | complete / complete | — | [result](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/37957b22-1588-4d0c-a523-94f5900fb14a/result.json) · [文件清单](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/37957b22-1588-4d0c-a523-94f5900fb14a/files.json) · [轨迹](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/37957b22-1588-4d0c-a523-94f5900fb14a/agent/trajectory.jsonl) |
| numba-stencil-boundary-modes | completed | 1 | 1809.10 | 230.42 | complete / complete | — | [result](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/1788d37c-fe0d-4541-93d9-a58941ddf136/result.json) · [文件清单](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/1788d37c-fe0d-4541-93d9-a58941ddf136/files.json) · [轨迹](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/1788d37c-fe0d-4541-93d9-a58941ddf136/agent/trajectory.jsonl) |
| opa-rego-rule-profiling | completed | 1 | 710.15 | 29.36 | complete / complete | — | [result](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/bffbc189-7b6f-49fa-8d16-09a236b5acfa/result.json) · [文件清单](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/bffbc189-7b6f-49fa-8d16-09a236b5acfa/files.json) · [轨迹](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/bffbc189-7b6f-49fa-8d16-09a236b5acfa/agent/trajectory.jsonl) |
| pest-character-class-coalescing | completed | 1 | 635.44 | 8.98 | complete / complete | — | [result](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/77b6c098-7299-4178-af72-421dda9b118a/result.json) · [文件清单](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/77b6c098-7299-4178-af72-421dda9b118a/files.json) · [轨迹](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/77b6c098-7299-4178-af72-421dda9b118a/agent/trajectory.jsonl) |
| query-persist-restored-query-state | invalid | — | 566.30 | — | partial / complete | SOLVER\_PROTOCOL\_INVALID; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/588565cf-f64f-4852-84ae-d9cb9efbd1c2/result.json) · [文件清单](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/588565cf-f64f-4852-84ae-d9cb9efbd1c2/files.json) · [轨迹](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/588565cf-f64f-4852-84ae-d9cb9efbd1c2/agent/trajectory.jsonl) |
| skrub-duration-encoding | completed | 1 | 617.20 | 171.67 | complete / complete | — | [result](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/b7f818ca-1635-4d6c-98ad-ae60787a7d04/result.json) · [文件清单](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/b7f818ca-1635-4d6c-98ad-ae60787a7d04/files.json) · [轨迹](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/b7f818ca-1635-4d6c-98ad-ae60787a7d04/agent/trajectory.jsonl) |
| tengo-callable-instance-isolation | completed | 1 | 698.33 | 9.42 | complete / complete | — | [result](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/1689a69e-73f9-44fa-962e-62cfcd91e877/result.json) · [文件清单](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/1689a69e-73f9-44fa-962e-62cfcd91e877/files.json) · [轨迹](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/1689a69e-73f9-44fa-962e-62cfcd91e877/agent/trajectory.jsonl) |
| textual-richlog-follow-state | completed | 1 | 860.05 | 6.80 | complete / complete | — | [result](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/ed2499c7-e3c2-4c52-90cc-1659bf2507ce/result.json) · [文件清单](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/ed2499c7-e3c2-4c52-90cc-1659bf2507ce/files.json) · [轨迹](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/ed2499c7-e3c2-4c52-90cc-1659bf2507ce/agent/trajectory.jsonl) |
| vitest-duration-sharding | completed | 1 | 917.19 | 29.52 | complete / complete | — | [result](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/339544d5-366c-49af-a6f8-73b7f5aff4ac/result.json) · [文件清单](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/339544d5-366c-49af-a6f8-73b7f5aff4ac/files.json) · [轨迹](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/339544d5-366c-49af-a6f8-73b7f5aff4ac/agent/trajectory.jsonl) |
| ytt-jsonpath-query-api | completed | 1 | 327.87 | 10.95 | complete / complete | — | [result](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/a9868b4e-fe15-458d-a5c0-39ebd3399586/result.json) · [文件清单](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/a9868b4e-fe15-458d-a5c0-39ebd3399586/files.json) · [轨迹](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/a9868b4e-fe15-458d-a5c0-39ebd3399586/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 6；错误记录 12（主流程 6；证据收集 6；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_PROTOCOL_INVALID | 6 | 6 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 6 | 6 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

