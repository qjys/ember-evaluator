<!-- snapshotDigest: f3a2f9efe13940b665c62a8d498f5a736fae1690fcb46bce58037b05912a7afb -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 73.68%（14/19）**

Run: 31e49d91-5189-4cbe-a9e5-b1521a6c1650 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T03:55:22.507Z / 2026-11-13T05:05:15.333Z |
| 总耗时 | 1 小时 9 分 53 秒 |
| 答对 / 答错 / 解题超时 | 14 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 20 题；已保存 20 条记录；待运行 0 题。
有效评分覆盖率：19/20（95.00%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 20 |
| 计分题数 | 19 |
| 正常评分题数 | 19 |
| 答对题数 | 14 |
| 无效评测 | 1 |
| 待运行 | 0 |
| 正确率 | 73.68% |
| 平均奖励 | 0.7368 |
| 奖励 f2p | 0.9914 |
| 奖励 p2p | 0.9974 |
| 奖励 partial | 0.9917 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 9 分 53 秒 |
| 环境准备耗时 | 26 分 32 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 12 分 47 秒 | 5 分 27 秒 | 42 分 55 秒 | 20 |
| 任务准备 | 0.19 毫秒 | 0.11 毫秒 | 0.48 毫秒 | 20 |
| 环境启动 | 8 秒 | 7 秒 | 9 秒 | 20 |
| 解题 | 10 分 30 秒 | 4 分 46 秒 | 20 分 58 秒 | 20 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 20 |
| 证据收集 | 127.45 毫秒 | 97.15 毫秒 | 145.76 毫秒 | 20 |
| 资源清理 | 1 秒 | 1 秒 | 2 秒 | 20 |
| 评分 | 2 分 6 秒 | 2 秒 | 30 分 0 秒 | 20 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| eaddf836-2282-4e17-b6ca-0c878d35136e | 1,800 | 1800 | 4 | 4 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 1,259,212 | 133,509,708 | 20 / 20 | — |
| 运行累计 | — | 1,259,212 | 133,509,708 | 20 / 20 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| abs-module-cache-flags | completed | 1 | 358.37 | 17.03 | complete / complete | — | [result](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/0e4546d0-9cfa-425e-bc97-b64d1eea9d56/result.json) · [文件清单](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/0e4546d0-9cfa-425e-bc97-b64d1eea9d56/files.json) · [轨迹](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/0e4546d0-9cfa-425e-bc97-b64d1eea9d56/agent/trajectory.jsonl) |
| anko-typed-variable-bindings | completed | 1 | 343.79 | 15.74 | complete / complete | — | [result](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/a88db420-6c4c-45a8-864e-7f880f905732/result.json) · [文件清单](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/a88db420-6c4c-45a8-864e-7f880f905732/files.json) · [轨迹](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/a88db420-6c4c-45a8-864e-7f880f905732/agent/trajectory.jsonl) |
| bandit-structured-nosec-directives | completed | 0 | 497.23 | 8.51 | complete / complete | — | [result](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/c912ff92-9a43-4508-9398-51dbabb04a37/result.json) · [文件清单](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/c912ff92-9a43-4508-9398-51dbabb04a37/files.json) · [轨迹](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/c912ff92-9a43-4508-9398-51dbabb04a37/agent/trajectory.jsonl) |
| csstree-shorthand-expansion-compression | completed | 1 | 731.80 | 1.87 | complete / complete | — | [result](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/ec859e7f-cc01-4998-9ded-5ad2e06a639b/result.json) · [文件清单](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/ec859e7f-cc01-4998-9ded-5ad2e06a639b/files.json) · [轨迹](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/ec859e7f-cc01-4998-9ded-5ad2e06a639b/agent/trajectory.jsonl) |
| effect-sse-httpapi-streaming | completed | 0 | 1258.14 | 14.22 | complete / complete | — | [result](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/0a3266fa-3df1-424f-8e36-f6f29880fda9/result.json) · [文件清单](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/0a3266fa-3df1-424f-8e36-f6f29880fda9/files.json) · [轨迹](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/0a3266fa-3df1-424f-8e36-f6f29880fda9/agent/trajectory.jsonl) |
| fastapi-implicit-head-options | completed | 1 | 529.94 | 46.05 | complete / complete | — | [result](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/3570e058-2f58-404c-b10a-48663f6a9895/result.json) · [文件清单](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/3570e058-2f58-404c-b10a-48663f6a9895/files.json) · [轨迹](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/3570e058-2f58-404c-b10a-48663f6a9895/agent/trajectory.jsonl) |
| goreleaser-retry-publish-auditing | completed | 1 | 642.63 | 62.76 | complete / complete | — | [result](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/358739b2-b1f5-4136-8d94-c2cb7967256b/result.json) · [文件清单](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/358739b2-b1f5-4136-8d94-c2cb7967256b/files.json) · [轨迹](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/358739b2-b1f5-4136-8d94-c2cb7967256b/agent/trajectory.jsonl) |
| httpx-deterministic-cookie-store | completed | 0 | 479.21 | 11.86 | complete / complete | — | [result](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/4c773150-4cbd-4bfe-9828-838cc0ae1f53/result.json) · [文件清单](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/4c773150-4cbd-4bfe-9828-838cc0ae1f53/files.json) · [轨迹](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/4c773150-4cbd-4bfe-9828-838cc0ae1f53/agent/trajectory.jsonl) |
| katex-multicolumn-array-spans | completed | 1 | 552.45 | 4.81 | complete / complete | — | [result](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/1c27a347-20e4-4184-93aa-ed7e588f530e/result.json) · [文件清单](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/1c27a347-20e4-4184-93aa-ed7e588f530e/files.json) · [轨迹](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/1c27a347-20e4-4184-93aa-ed7e588f530e/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | invalid (infrastructure) | — | 764.43 | 1800.01 | complete / complete | VERIFY\_TIMEOUT | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/f8f146d8-f1d1-4ec5-9ef1-6e0360640068/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/f8f146d8-f1d1-4ec5-9ef1-6e0360640068/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/f8f146d8-f1d1-4ec5-9ef1-6e0360640068/agent/trajectory.jsonl) |
| langchain-request-coalescing | completed | 1 | 575.18 | 26.67 | complete / complete | — | [result](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/f66b546d-26da-421b-890b-3a747b1e4050/result.json) · [文件清单](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/f66b546d-26da-421b-890b-3a747b1e4050/files.json) · [轨迹](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/f66b546d-26da-421b-890b-3a747b1e4050/agent/trajectory.jsonl) |
| numba-stencil-boundary-modes | completed | 1 | 859.69 | 232.05 | complete / complete | — | [result](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/60149ca3-9476-4000-b232-dac97f1f45ff/result.json) · [文件清单](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/60149ca3-9476-4000-b232-dac97f1f45ff/files.json) · [轨迹](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/60149ca3-9476-4000-b232-dac97f1f45ff/agent/trajectory.jsonl) |
| opa-rego-rule-profiling | completed | 0 | 286.42 | 30.59 | complete / complete | — | [result](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/0f701183-fe53-4c15-af34-704ac033f5e0/result.json) · [文件清单](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/0f701183-fe53-4c15-af34-704ac033f5e0/files.json) · [轨迹](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/0f701183-fe53-4c15-af34-704ac033f5e0/agent/trajectory.jsonl) |
| pest-character-class-coalescing | completed | 0 | 455.15 | 9.48 | complete / complete | — | [result](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/888f6bb8-c759-4af9-90f8-2368074ab010/result.json) · [文件清单](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/888f6bb8-c759-4af9-90f8-2368074ab010/files.json) · [轨迹](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/888f6bb8-c759-4af9-90f8-2368074ab010/agent/trajectory.jsonl) |
| query-persist-restored-query-state | completed | 1 | 804.92 | 8.64 | complete / complete | — | [result](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/0fcf6a51-0ba6-4566-956a-c3f5621c1de6/result.json) · [文件清单](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/0fcf6a51-0ba6-4566-956a-c3f5621c1de6/files.json) · [轨迹](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/0fcf6a51-0ba6-4566-956a-c3f5621c1de6/agent/trajectory.jsonl) |
| skrub-duration-encoding | completed | 1 | 650.58 | 172.93 | complete / complete | — | [result](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/2ed8016e-e019-46a3-92df-1f1290cb8c45/result.json) · [文件清单](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/2ed8016e-e019-46a3-92df-1f1290cb8c45/files.json) · [轨迹](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/2ed8016e-e019-46a3-92df-1f1290cb8c45/agent/trajectory.jsonl) |
| tengo-callable-instance-isolation | completed | 1 | 1068.66 | 10.89 | complete / complete | — | [result](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/daf9dc44-645f-42b4-b993-37eb5bc9f760/result.json) · [文件清单](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/daf9dc44-645f-42b4-b993-37eb5bc9f760/files.json) · [轨迹](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/daf9dc44-645f-42b4-b993-37eb5bc9f760/agent/trajectory.jsonl) |
| textual-richlog-follow-state | completed | 1 | 554.16 | 6.28 | complete / complete | — | [result](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/2ffb26f5-b5ad-456b-b45e-cac55c413ca3/result.json) · [文件清单](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/2ffb26f5-b5ad-456b-b45e-cac55c413ca3/files.json) · [轨迹](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/2ffb26f5-b5ad-456b-b45e-cac55c413ca3/agent/trajectory.jsonl) |
| vitest-duration-sharding | completed | 1 | 702.33 | 30.32 | complete / complete | — | [result](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/47bbf896-3a84-4744-8964-dbb8d140d883/result.json) · [文件清单](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/47bbf896-3a84-4744-8964-dbb8d140d883/files.json) · [轨迹](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/47bbf896-3a84-4744-8964-dbb8d140d883/agent/trajectory.jsonl) |
| ytt-jsonpath-query-api | completed | 1 | 486.25 | 10.56 | complete / complete | — | [result](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/6168ac4d-5d8e-4ed8-991f-3270afc6f1f3/result.json) · [文件清单](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/6168ac4d-5d8e-4ed8-991f-3270afc6f1f3/files.json) · [轨迹](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/6168ac4d-5d8e-4ed8-991f-3270afc6f1f3/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 1（主流程 1；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| verify | VERIFY_TIMEOUT | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

