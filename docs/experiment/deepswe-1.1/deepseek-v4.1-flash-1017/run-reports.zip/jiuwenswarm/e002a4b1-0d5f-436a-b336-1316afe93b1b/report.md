<!-- snapshotDigest: 9c061906aba7378c0dff44807fe3f78fda261a046c1b1cf3efd978210530bc72 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 30.00%（6/20）**

Run: e002a4b1-0d5f-436a-b336-1316afe93b1b · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-16T12:31:24.445Z / 2026-11-16T13:25:47.713Z |
| 总耗时 | 54 分 24 秒 |
| 答对 / 答错 / 解题超时 | 6 / 14 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 12 / 0 |

已选择 20 题；已保存 20 条记录；待运行 0 题。
有效评分覆盖率：20/20（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 20 |
| 计分题数 | 20 |
| 正常评分题数 | 20 |
| 答对题数 | 6 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 30.00% |
| 平均奖励 | 0.3 |
| 奖励 f2p | 0.3889 |
| 奖励 p2p | 0.9993 |
| 奖励 partial | 0.8593 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 54 分 24 秒 |
| 环境准备耗时 | 22 分 52 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 10 分 3 秒 | 6 分 14 秒 | 14 分 15 秒 | 20 |
| 任务准备 | 0.2 毫秒 | 0.12 毫秒 | 0.42 毫秒 | 20 |
| 环境启动 | 12 秒 | 10 秒 | 15 秒 | 20 |
| 解题 | 9 分 10 秒 | 5 分 32 秒 | 10 分 10 秒 | 20 |
| 产物传输 | 2 秒 | 2 秒 | 4 秒 | 20 |
| 证据收集 | 125.59 毫秒 | 100.84 毫秒 | 206.49 毫秒 | 20 |
| 资源清理 | 2 秒 | 1 秒 | 3 秒 | 20 |
| 评分 | 37 秒 | 2 秒 | 3 分 55 秒 | 20 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 6d285336-4c0d-4d38-91a1-f34d3d4d29c8 | 未设置 | 1800 | 4 | 4 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 54,187,643 | 401,649 | 54,589,292 | 8 / 20 | — |
| 运行累计 | 54,187,643 | 401,649 | 54,589,292 | 8 / 20 | 12 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| abs-module-cache-flags | completed | 1 | 367.84 | 21.96 | complete / complete | — | [result](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/12c293da-a7fe-4482-aa5f-7f3c05ed7134/result.json) · [文件清单](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/12c293da-a7fe-4482-aa5f-7f3c05ed7134/files.json) · [轨迹](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/12c293da-a7fe-4482-aa5f-7f3c05ed7134/agent/trajectory.jsonl) |
| anko-typed-variable-bindings | completed | 0 | 331.69 | 19.94 | complete / complete | — | [result](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/e9d4ee0e-4eaf-4752-9681-6f119085fa1d/result.json) · [文件清单](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/e9d4ee0e-4eaf-4752-9681-6f119085fa1d/files.json) · [轨迹](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/e9d4ee0e-4eaf-4752-9681-6f119085fa1d/agent/trajectory.jsonl) |
| bandit-structured-nosec-directives | completed | 0 | 609.42 | 10.25 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/f0f6563d-d7d8-4e57-8d9c-451b677bf88b/result.json) · [文件清单](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/f0f6563d-d7d8-4e57-8d9c-451b677bf88b/files.json) · [轨迹](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/f0f6563d-d7d8-4e57-8d9c-451b677bf88b/agent/trajectory.jsonl) |
| csstree-shorthand-expansion-compression | completed | 0 | 607.12 | 2.05 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/240542c9-9744-49c3-ab02-27de1d843e95/result.json) · [文件清单](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/240542c9-9744-49c3-ab02-27de1d843e95/files.json) · [轨迹](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/240542c9-9744-49c3-ab02-27de1d843e95/agent/trajectory.jsonl) |
| effect-sse-httpapi-streaming | completed | 0 | 609.99 | 15.75 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/4dea9d0d-506b-448f-a808-839a9543d233/result.json) · [文件清单](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/4dea9d0d-506b-448f-a808-839a9543d233/files.json) · [轨迹](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/4dea9d0d-506b-448f-a808-839a9543d233/agent/trajectory.jsonl) |
| fastapi-implicit-head-options | completed | 0 | 605.78 | 45.41 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/f757b91a-9bc2-4811-93e1-4e4711c85453/result.json) · [文件清单](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/f757b91a-9bc2-4811-93e1-4e4711c85453/files.json) · [轨迹](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/f757b91a-9bc2-4811-93e1-4e4711c85453/agent/trajectory.jsonl) |
| goreleaser-retry-publish-auditing | completed | 0 | 606.21 | 54.82 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/2749029b-2834-4b82-9d58-ebfd0066e64d/result.json) · [文件清单](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/2749029b-2834-4b82-9d58-ebfd0066e64d/files.json) · [轨迹](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/2749029b-2834-4b82-9d58-ebfd0066e64d/agent/trajectory.jsonl) |
| httpx-deterministic-cookie-store | completed | 0 | 465.12 | 7.34 | complete / complete | — | [result](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/a6af8380-f2fb-4bb8-ba00-39dd7b7df0ee/result.json) · [文件清单](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/a6af8380-f2fb-4bb8-ba00-39dd7b7df0ee/files.json) · [轨迹](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/a6af8380-f2fb-4bb8-ba00-39dd7b7df0ee/agent/trajectory.jsonl) |
| katex-multicolumn-array-spans | completed | 0 | 606.04 | 6.51 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/e2a004c5-5699-4a30-8664-b4a8425bae1c/result.json) · [文件清单](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/e2a004c5-5699-4a30-8664-b4a8425bae1c/files.json) · [轨迹](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/e2a004c5-5699-4a30-8664-b4a8425bae1c/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | completed | 0 | 605.47 | 7.25 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/ea8cd23c-27b9-4c51-abaa-64cce944e2a6/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/ea8cd23c-27b9-4c51-abaa-64cce944e2a6/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/ea8cd23c-27b9-4c51-abaa-64cce944e2a6/agent/trajectory.jsonl) |
| langchain-request-coalescing | completed | 1 | 502.02 | 27.14 | complete / complete | — | [result](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/65ca5291-389e-4997-bd30-0c0fc7a1c681/result.json) · [文件清单](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/65ca5291-389e-4997-bd30-0c0fc7a1c681/files.json) · [轨迹](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/65ca5291-389e-4997-bd30-0c0fc7a1c681/agent/trajectory.jsonl) |
| numba-stencil-boundary-modes | completed | 0 | 604.70 | 234.91 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/ea2b750f-bd24-4873-b7ec-0e8090ce1267/result.json) · [文件清单](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/ea2b750f-bd24-4873-b7ec-0e8090ce1267/files.json) · [轨迹](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/ea2b750f-bd24-4873-b7ec-0e8090ce1267/agent/trajectory.jsonl) |
| opa-rego-rule-profiling | completed | 1 | 568.29 | 31.20 | complete / complete | — | [result](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/09acb37b-de94-44e4-aa67-84e634bdec21/result.json) · [文件清单](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/09acb37b-de94-44e4-aa67-84e634bdec21/files.json) · [轨迹](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/09acb37b-de94-44e4-aa67-84e634bdec21/agent/trajectory.jsonl) |
| pest-character-class-coalescing | completed | 0 | 604.79 | 7.83 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/68dc4519-3dba-49aa-b998-c85310f6d277/result.json) · [文件清单](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/68dc4519-3dba-49aa-b998-c85310f6d277/files.json) · [轨迹](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/68dc4519-3dba-49aa-b998-c85310f6d277/agent/trajectory.jsonl) |
| query-persist-restored-query-state | completed | 1 | 574.51 | 8.26 | complete / complete | — | [result](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/38959f0c-061d-4005-b2e9-75448bf9d6dd/result.json) · [文件清单](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/38959f0c-061d-4005-b2e9-75448bf9d6dd/files.json) · [轨迹](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/38959f0c-061d-4005-b2e9-75448bf9d6dd/agent/trajectory.jsonl) |
| skrub-duration-encoding | completed | 0 | 604.49 | 169.70 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/cb0e6e29-f8bd-4a93-ab61-abca79e261e6/result.json) · [文件清单](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/cb0e6e29-f8bd-4a93-ab61-abca79e261e6/files.json) · [轨迹](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/cb0e6e29-f8bd-4a93-ab61-abca79e261e6/agent/trajectory.jsonl) |
| tengo-callable-instance-isolation | completed | 0 | 604.89 | 9.80 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/f109d3c3-c6b6-4a4d-82bf-e5aad9ec1c34/result.json) · [文件清单](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/f109d3c3-c6b6-4a4d-82bf-e5aad9ec1c34/files.json) · [轨迹](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/f109d3c3-c6b6-4a4d-82bf-e5aad9ec1c34/agent/trajectory.jsonl) |
| textual-richlog-follow-state | completed | 0 | 604.96 | 25.72 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/15387f68-d1d9-4cb6-bffd-74fd73efc526/result.json) · [文件清单](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/15387f68-d1d9-4cb6-bffd-74fd73efc526/files.json) · [轨迹](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/15387f68-d1d9-4cb6-bffd-74fd73efc526/agent/trajectory.jsonl) |
| vitest-duration-sharding | completed | 1 | 552.36 | 28.98 | complete / complete | — | [result](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/1105415f-8f82-4c42-a6b9-329abc474130/result.json) · [文件清单](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/1105415f-8f82-4c42-a6b9-329abc474130/files.json) · [轨迹](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/1105415f-8f82-4c42-a6b9-329abc474130/agent/trajectory.jsonl) |
| ytt-jsonpath-query-api | completed | 1 | 361.92 | 10.82 | complete / complete | — | [result](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/33fcf845-532f-4390-b148-76bb431a3d49/result.json) · [文件清单](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/33fcf845-532f-4390-b148-76bb431a3d49/files.json) · [轨迹](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/33fcf845-532f-4390-b148-76bb431a3d49/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 12；错误记录 12（主流程 12；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 12 | 12 |

## 警告

警告涉及 12 个任务，共 12 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| bandit-structured-nosec-directives | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| csstree-shorthand-expansion-compression | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| effect-sse-httpapi-streaming | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| fastapi-implicit-head-options | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| goreleaser-retry-publish-auditing | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| katex-multicolumn-array-spans | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| koota-composite-trait-aspects | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| numba-stencil-boundary-modes | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| pest-character-class-coalescing | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| skrub-duration-encoding | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| tengo-callable-instance-isolation | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| textual-richlog-follow-state | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

