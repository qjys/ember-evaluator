<!-- snapshotDigest: 6ce2efd9175b1aacbddaf0a197c73bb8ee019f95130985fdad8590a66d3dbb46 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 37.50%（3/8）**

Run: c301fbe5-27b8-49de-94d0-e41a667e4044 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-17T02:11:04.387Z / 2026-11-17T02:49:21.282Z |
| 总耗时 | 38 分 18 秒 |
| 答对 / 答错 / 解题超时 | 3 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 4 / 0 |

已选择 12 题；已保存 12 条记录；待运行 0 题。
有效评分覆盖率：8/12（66.67%）。
执行失败 4；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 4。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 12 |
| 计分题数 | 8 |
| 正常评分题数 | 8 |
| 答对题数 | 3 |
| 无效评测 | 4 |
| 待运行 | 0 |
| 正确率 | 37.50% |
| 平均奖励 | 0.375 |
| 奖励 f2p | 0.9808 |
| 奖励 p2p | 0.9996 |
| 奖励 partial | 0.9967 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 38 分 18 秒 |
| 环境准备耗时 | 28 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 11 分 16 秒 | 2 分 37 秒 | 22 分 14 秒 | 12 |
| 任务准备 | 0.2 毫秒 | 0.12 毫秒 | 0.48 毫秒 | 12 |
| 环境启动 | 12 秒 | 10 秒 | 16 秒 | 12 |
| 解题 | 10 分 39 秒 | 2 分 24 秒 | 19 分 16 秒 | 12 |
| 产物传输 | 1 秒 | 730.5 毫秒 | 3 秒 | 12 |
| 证据收集 | 612.65 毫秒 | 114.79 毫秒 | 2 秒 | 12 |
| 资源清理 | 2 秒 | 1 秒 | 4 秒 | 12 |
| 评分 | 32 秒 | 2 秒 | 2 分 44 秒 | 8 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| c19370ca-b7e8-4655-8575-91cef540da11 | 未设置 | 1800 | 4 | 4 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 83,470,103 | 531,453 | 84,001,556 | 8 / 12 | — |
| 运行累计 | 83,470,103 | 531,453 | 84,001,556 | 8 / 12 | 4 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| bandit-structured-nosec-directives | completed | 0 | 546.36 | 8.44 | complete / complete | — | [result](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/2ae1f039-b5f7-4db1-aff0-78fae044db86/result.json) · [文件清单](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/2ae1f039-b5f7-4db1-aff0-78fae044db86/files.json) · [轨迹](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/2ae1f039-b5f7-4db1-aff0-78fae044db86/agent/trajectory.jsonl) |
| csstree-shorthand-expansion-compression | completed | 0 | 451.67 | 1.94 | complete / complete | — | [result](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/4d0fd594-f5f9-4b36-9b3b-96609b5f368b/result.json) · [文件清单](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/4d0fd594-f5f9-4b36-9b3b-96609b5f368b/files.json) · [轨迹](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/4d0fd594-f5f9-4b36-9b3b-96609b5f368b/agent/trajectory.jsonl) |
| effect-sse-httpapi-streaming | completed | 0 | 754.94 | 13.55 | complete / complete | — | [result](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/d21ba7c8-4c05-4ede-a687-c5a435573763/result.json) · [文件清单](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/d21ba7c8-4c05-4ede-a687-c5a435573763/files.json) · [轨迹](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/d21ba7c8-4c05-4ede-a687-c5a435573763/agent/trajectory.jsonl) |
| fastapi-implicit-head-options | completed | 0 | 619.96 | 44.18 | complete / complete | — | [result](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/47e3f79d-564f-4b75-97e3-1713ac103348/result.json) · [文件清单](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/47e3f79d-564f-4b75-97e3-1713ac103348/files.json) · [轨迹](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/47e3f79d-564f-4b75-97e3-1713ac103348/agent/trajectory.jsonl) |
| goreleaser-retry-publish-auditing | invalid | — | 144.23 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/2d4e6dee-96e7-41e6-a96a-9e90e9aa0f33/result.json) · [文件清单](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/2d4e6dee-96e7-41e6-a96a-9e90e9aa0f33/files.json) · [轨迹](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/2d4e6dee-96e7-41e6-a96a-9e90e9aa0f33/agent/trajectory.jsonl) |
| katex-multicolumn-array-spans | invalid | — | 250.78 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/2cd91a6b-bc69-4bf0-819a-959ef82911c5/result.json) · [文件清单](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/2cd91a6b-bc69-4bf0-819a-959ef82911c5/files.json) · [轨迹](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/2cd91a6b-bc69-4bf0-819a-959ef82911c5/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | invalid | — | 360.04 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/b1c988d6-93c4-409f-8437-9545458249e8/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/b1c988d6-93c4-409f-8437-9545458249e8/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/b1c988d6-93c4-409f-8437-9545458249e8/agent/trajectory.jsonl) |
| numba-stencil-boundary-modes | invalid | — | 461.48 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/e14273a4-7147-4bb2-bd3d-f2963ffd3531/result.json) · [文件清单](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/e14273a4-7147-4bb2-bd3d-f2963ffd3531/files.json) · [轨迹](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/e14273a4-7147-4bb2-bd3d-f2963ffd3531/agent/trajectory.jsonl) |
| pest-character-class-coalescing | completed | 0 | 945.29 | 8.89 | complete / complete | — | [result](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/697eb9fe-1130-40d3-9a5c-a449ebd540dc/result.json) · [文件清单](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/697eb9fe-1130-40d3-9a5c-a449ebd540dc/files.json) · [轨迹](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/697eb9fe-1130-40d3-9a5c-a449ebd540dc/agent/trajectory.jsonl) |
| skrub-duration-encoding | completed | 1 | 1156.27 | 163.89 | complete / complete | — | [result](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/badd729f-074d-436f-a6bb-351065c2bb9d/result.json) · [文件清单](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/badd729f-074d-436f-a6bb-351065c2bb9d/files.json) · [轨迹](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/badd729f-074d-436f-a6bb-351065c2bb9d/agent/trajectory.jsonl) |
| tengo-callable-instance-isolation | completed | 1 | 1047.73 | 9.56 | complete / complete | — | [result](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/0d352c81-f532-4e4b-977a-b5068a48055f/result.json) · [文件清单](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/0d352c81-f532-4e4b-977a-b5068a48055f/files.json) · [轨迹](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/0d352c81-f532-4e4b-977a-b5068a48055f/agent/trajectory.jsonl) |
| textual-richlog-follow-state | completed | 1 | 933.28 | 6.39 | complete / complete | — | [result](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/b604423e-83c0-4e00-b86b-b40a422829a9/result.json) · [文件清单](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/b604423e-83c0-4e00-b86b-b40a422829a9/files.json) · [轨迹](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/b604423e-83c0-4e00-b86b-b40a422829a9/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 4；错误记录 4（主流程 4；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | NETWORK_FAILURE | 4 | 4 |

## 警告

警告涉及 4 个任务，共 4 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| goreleaser-retry-publish-auditing | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| katex-multicolumn-array-spans | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| koota-composite-trait-aspects | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| numba-stencil-boundary-modes | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

