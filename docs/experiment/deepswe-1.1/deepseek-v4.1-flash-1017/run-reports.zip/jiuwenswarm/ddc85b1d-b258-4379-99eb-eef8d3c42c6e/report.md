<!-- snapshotDigest: c722a5af0f6560ae74caf52648df3410cd4fbbee7a1ede2fb37b54c001bc5497 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 75.00%（3/4）**

Run: ddc85b1d-b258-4379-99eb-eef8d3c42c6e · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-17T11:25:33.076Z / 2026-11-17T12:37:52.806Z |
| 总耗时 | 1 小时 12 分 21 秒 |
| 答对 / 答错 / 解题超时 | 3 / 0 / 1 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 4 题；已保存 4 条记录；待运行 0 题。
有效评分覆盖率：4/4（100.00%）。
执行失败 0；超时 1；取消 0；不支持 0。
Agent 解题超时 1（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 4 |
| 计分题数 | 4 |
| 正常评分题数 | 3 |
| 答对题数 | 3 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 75.00% |
| 平均奖励 | 0.75 |
| 奖励 f2p | 0.75 |
| 奖励 p2p | 0.75 |
| 奖励 partial | 0.75 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 12 分 21 秒 |
| 环境准备耗时 | 43 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 28 分 32 秒 | 11 分 49 秒 | 1 小时 0 分 3 秒 | 4 |
| 任务准备 | 0.27 毫秒 | 0.17 毫秒 | 0.39 毫秒 | 4 |
| 环境启动 | 14 秒 | 10 秒 | 17 秒 | 4 |
| 解题 | 26 分 49 秒 | 11 分 25 秒 | 59 分 50 秒 | 4 |
| 产物传输 | 2 秒 | 670.45 毫秒 | 2 秒 | 4 |
| 证据收集 | 607.57 毫秒 | 117.3 毫秒 | 2 秒 | 4 |
| 资源清理 | 2 秒 | 1 秒 | 4 秒 | 4 |
| 评分 | 1 分 54 秒 | 5 秒 | 4 分 6 秒 | 3 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| ae98a783-3c19-4caf-9cfe-83f1b5c9b471 | 未设置 | 1800 | 2 | 2 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 41,677,375 | 211,603 | 41,888,978 | 3 / 4 | — |
| 运行累计 | 41,677,375 | 211,603 | 41,888,978 | 3 / 4 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| goreleaser-retry-publish-auditing | completed | 1 | 927.66 | 90.08 | complete / complete | — | [result](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/5bc0b3dc-01ee-4809-a882-2d473a0fe1bb/result.json) · [文件清单](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/5bc0b3dc-01ee-4809-a882-2d473a0fe1bb/files.json) · [轨迹](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/5bc0b3dc-01ee-4809-a882-2d473a0fe1bb/agent/trajectory.jsonl) |
| katex-multicolumn-array-spans | completed | 1 | 685.40 | 5.40 | complete / complete | — | [result](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/98fa5b74-1aef-49f8-a263-270f88f96f29/result.json) · [文件清单](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/98fa5b74-1aef-49f8-a263-270f88f96f29/files.json) · [轨迹](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/98fa5b74-1aef-49f8-a263-270f88f96f29/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | timeout (agent) | 0 | 3590.30 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/16beca2e-90a0-44c8-aaa7-2904ffe79cd5/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/16beca2e-90a0-44c8-aaa7-2904ffe79cd5/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/16beca2e-90a0-44c8-aaa7-2904ffe79cd5/agent/trajectory.jsonl) |
| numba-stencil-boundary-modes | completed | 1 | 1231.20 | 245.85 | complete / complete | — | [result](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/ff0f653f-8027-4956-ba1e-251ff99a296b/result.json) · [文件清单](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/ff0f653f-8027-4956-ba1e-251ff99a296b/files.json) · [轨迹](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/ff0f653f-8027-4956-ba1e-251ff99a296b/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 1（主流程 1；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| koota-composite-trait-aspects | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

