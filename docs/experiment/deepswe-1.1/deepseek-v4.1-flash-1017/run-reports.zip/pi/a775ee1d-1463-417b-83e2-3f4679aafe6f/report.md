<!-- snapshotDigest: 1a8f7d9459aa1bfad26c286f2f1884a2986cc97bc2bca28a8b3f0ee5a094886f -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 73.68%（14/19）**

Run: a775ee1d-1463-417b-83e2-3f4679aafe6f · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T12:17:23.600Z / 2026-11-16T05:14:20.696Z |
| 总耗时 | 64 小时 56 分 57 秒 |
| 答对 / 答错 / 解题超时 | 14 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 20 题；已保存 20 条记录；待运行 0 题。
有效评分覆盖率：19/20（95.00%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 20 |
| 计分题数 | 19 |
| 正常评分题数 | 19 |
| 答对题数 | 14 |
| 无效评测 | 1 |
| 待运行 | 0 |
| 正确率 | 73.68% |
| 平均奖励 | 0.7368 |
| 奖励 f2p | 0.9926 |
| 奖励 p2p | 0.9974 |
| 奖励 partial | 0.9924 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 64 小时 56 分 57 秒 |
| 环境准备耗时 | 21 分 10 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 12 分 29 秒 | 5 分 9 秒 | 48 分 23 秒 | 20 |
| 任务准备 | 0.17 毫秒 | 0.12 毫秒 | 0.38 毫秒 | 20 |
| 环境启动 | 4 秒 | 4 秒 | 5 秒 | 20 |
| 解题 | 10 分 15 秒 | 4 分 46 秒 | 18 分 19 秒 | 20 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 20 |
| 证据收集 | 124.68 毫秒 | 102.69 毫秒 | 145.29 毫秒 | 20 |
| 资源清理 | 2 秒 | 1 秒 | 3 秒 | 20 |
| 评分 | 2 分 6 秒 | 2 秒 | 30 分 0 秒 | 20 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 2cabd843-bf64-44d4-8992-e86ba0ffa324 | 1,800 | 1800 | 4 | 4 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 104,252,725 | 1,321,193 | 105,573,918 | 20 / 20 | — |
| 运行累计 | 104,252,725 | 1,321,193 | 105,573,918 | 20 / 24 | 4 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| abs-module-cache-flags | completed | 1 | 328.47 | 15.62 | complete / complete | — | [result](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/02ae93ac-dbfc-42ad-b18b-22a11161f8f9/result.json) · [文件清单](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/02ae93ac-dbfc-42ad-b18b-22a11161f8f9/files.json) · [轨迹](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/02ae93ac-dbfc-42ad-b18b-22a11161f8f9/agent/trajectory.jsonl) |
| anko-typed-variable-bindings | completed | 1 | 286.31 | 14.99 | complete / complete | — | [result](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/b5e2fb92-db56-4da2-9ade-093244f29751/result.json) · [文件清单](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/b5e2fb92-db56-4da2-9ade-093244f29751/files.json) · [轨迹](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/b5e2fb92-db56-4da2-9ade-093244f29751/agent/trajectory.jsonl) |
| bandit-structured-nosec-directives | completed | 0 | 368.29 | 8.83 | complete / complete | — | [result](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/f157cdc8-1c04-4055-ae53-97d4f1061364/result.json) · [文件清单](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/f157cdc8-1c04-4055-ae53-97d4f1061364/files.json) · [轨迹](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/f157cdc8-1c04-4055-ae53-97d4f1061364/agent/trajectory.jsonl) |
| csstree-shorthand-expansion-compression | completed | 1 | 526.09 | 2.06 | complete / complete | — | [result](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/799a0d49-02a4-4a1b-819b-ba046e25dd2c/result.json) · [文件清单](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/799a0d49-02a4-4a1b-819b-ba046e25dd2c/files.json) · [轨迹](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/799a0d49-02a4-4a1b-819b-ba046e25dd2c/agent/trajectory.jsonl) |
| effect-sse-httpapi-streaming | completed | 1 | 1098.58 | 13.80 | complete / complete | — | [result](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/ff5afb4c-777c-4649-ab87-15b68a08c796/result.json) · [文件清单](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/ff5afb4c-777c-4649-ab87-15b68a08c796/files.json) · [轨迹](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/ff5afb4c-777c-4649-ab87-15b68a08c796/agent/trajectory.jsonl) |
| fastapi-implicit-head-options | completed | 1 | 904.85 | 43.54 | complete / complete | — | [result](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/ffd21412-0594-4c4b-a9e7-2ccff39c2b61/result.json) · [文件清单](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/ffd21412-0594-4c4b-a9e7-2ccff39c2b61/files.json) · [轨迹](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/ffd21412-0594-4c4b-a9e7-2ccff39c2b61/agent/trajectory.jsonl) |
| goreleaser-retry-publish-auditing | completed | 1 | 377.86 | 59.58 | complete / complete | — | [result](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/9d29d3cc-c6e1-4835-926f-bfd8bd74cc1a/result.json) · [文件清单](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/9d29d3cc-c6e1-4835-926f-bfd8bd74cc1a/files.json) · [轨迹](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/9d29d3cc-c6e1-4835-926f-bfd8bd74cc1a/agent/trajectory.jsonl) |
| httpx-deterministic-cookie-store | completed | 0 | 368.55 | 11.86 | complete / complete | — | [result](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/d731a3c5-0f83-4496-9989-d8bdb90c3c36/result.json) · [文件清单](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/d731a3c5-0f83-4496-9989-d8bdb90c3c36/files.json) · [轨迹](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/d731a3c5-0f83-4496-9989-d8bdb90c3c36/agent/trajectory.jsonl) |
| katex-multicolumn-array-spans | completed | 0 | 720.43 | 6.22 | complete / complete | — | [result](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/0b2920ea-6765-4ad2-9eb0-da50586df8dd/result.json) · [文件清单](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/0b2920ea-6765-4ad2-9eb0-da50586df8dd/files.json) · [轨迹](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/0b2920ea-6765-4ad2-9eb0-da50586df8dd/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | invalid (infrastructure) | — | 1095.49 | 1800.01 | complete / complete | VERIFY\_TIMEOUT | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/5789c55a-2fe8-4b25-902f-b22ac5593f6a/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/5789c55a-2fe8-4b25-902f-b22ac5593f6a/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/5789c55a-2fe8-4b25-902f-b22ac5593f6a/agent/trajectory.jsonl) |
| langchain-request-coalescing | completed | 1 | 404.53 | 26.70 | complete / complete | — | [result](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/4ef2d764-0d4f-4320-810f-ee27018df21e/result.json) · [文件清单](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/4ef2d764-0d4f-4320-810f-ee27018df21e/files.json) · [轨迹](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/4ef2d764-0d4f-4320-810f-ee27018df21e/agent/trajectory.jsonl) |
| numba-stencil-boundary-modes | completed | 1 | 817.36 | 234.46 | complete / complete | — | [result](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/c5ce39c6-01c6-45f8-af46-9a4d348f402c/result.json) · [文件清单](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/c5ce39c6-01c6-45f8-af46-9a4d348f402c/files.json) · [轨迹](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/c5ce39c6-01c6-45f8-af46-9a4d348f402c/agent/trajectory.jsonl) |
| opa-rego-rule-profiling | completed | 0 | 817.04 | 29.92 | complete / complete | — | [result](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/932f2a78-b2da-4477-a99f-01e82d05a4fa/result.json) · [文件清单](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/932f2a78-b2da-4477-a99f-01e82d05a4fa/files.json) · [轨迹](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/932f2a78-b2da-4477-a99f-01e82d05a4fa/agent/trajectory.jsonl) |
| pest-character-class-coalescing | completed | 0 | 458.82 | 9.44 | complete / complete | — | [result](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/1786840e-25b6-4273-8295-1c777c91816c/result.json) · [文件清单](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/1786840e-25b6-4273-8295-1c777c91816c/files.json) · [轨迹](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/1786840e-25b6-4273-8295-1c777c91816c/agent/trajectory.jsonl) |
| query-persist-restored-query-state | completed | 1 | 421.97 | 8.19 | complete / complete | — | [result](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/94608824-122d-4992-9da1-2a734689ceb9/result.json) · [文件清单](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/94608824-122d-4992-9da1-2a734689ceb9/files.json) · [轨迹](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/94608824-122d-4992-9da1-2a734689ceb9/agent/trajectory.jsonl) |
| skrub-duration-encoding | completed | 1 | 905.05 | 170.14 | complete / complete | — | [result](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/ed0fbf44-f5ac-4fe2-8ac3-63bf5f046683/result.json) · [文件清单](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/ed0fbf44-f5ac-4fe2-8ac3-63bf5f046683/files.json) · [轨迹](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/ed0fbf44-f5ac-4fe2-8ac3-63bf5f046683/agent/trajectory.jsonl) |
| tengo-callable-instance-isolation | completed | 1 | 587.44 | 9.23 | complete / complete | — | [result](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/58423f76-1c3c-48a6-b202-35da59a24d27/result.json) · [文件清单](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/58423f76-1c3c-48a6-b202-35da59a24d27/files.json) · [轨迹](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/58423f76-1c3c-48a6-b202-35da59a24d27/agent/trajectory.jsonl) |
| textual-richlog-follow-state | completed | 1 | 640.54 | 6.60 | complete / complete | — | [result](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/85db5299-2e4f-4d79-b115-98496855e29c/result.json) · [文件清单](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/85db5299-2e4f-4d79-b115-98496855e29c/files.json) · [轨迹](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/85db5299-2e4f-4d79-b115-98496855e29c/agent/trajectory.jsonl) |
| vitest-duration-sharding | completed | 1 | 865.91 | 29.73 | complete / complete | — | [result](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/73a661d1-8475-4831-9486-0dacf871d0f1/result.json) · [文件清单](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/73a661d1-8475-4831-9486-0dacf871d0f1/files.json) · [轨迹](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/73a661d1-8475-4831-9486-0dacf871d0f1/agent/trajectory.jsonl) |
| ytt-jsonpath-query-api | completed | 1 | 315.92 | 10.91 | complete / complete | — | [result](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/dd35a596-a4c3-4f26-af1f-ebfffa280174/result.json) · [文件清单](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/dd35a596-a4c3-4f26-af1f-ebfffa280174/files.json) · [轨迹](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/dd35a596-a4c3-4f26-af1f-ebfffa280174/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 1（主流程 1；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| verify | VERIFY_TIMEOUT | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

