<!-- snapshotDigest: b4090f24004478698ff09da69e78bde30627b63e10ce3c208b8cac9603762b5a -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 75.00%（15/20）**

Run: 1e3ddec6-6032-4576-9fa0-bc1932783298 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T06:06:22.282Z / 2026-11-13T07:23:10.373Z |
| 总耗时 | 1 小时 16 分 48 秒 |
| 答对 / 答错 / 解题超时 | 15 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 20 题；已保存 20 条记录；待运行 0 题。
有效评分覆盖率：20/20（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 20 |
| 计分题数 | 20 |
| 正常评分题数 | 20 |
| 答对题数 | 15 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 75.00% |
| 平均奖励 | 0.75 |
| 奖励 f2p | 0.9914 |
| 奖励 p2p | 0.9977 |
| 奖励 partial | 0.9921 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 16 分 48 秒 |
| 环境准备耗时 | 24 分 26 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 14 分 5 秒 | 7 分 2 秒 | 44 分 40 秒 | 20 |
| 任务准备 | 0.21 毫秒 | 0.12 毫秒 | 0.54 毫秒 | 20 |
| 环境启动 | 3 秒 | 3 秒 | 4 秒 | 20 |
| 解题 | 13 分 19 秒 | 6 分 38 秒 | 44 分 25 秒 | 20 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 20 |
| 证据收集 | 122.24 毫秒 | 104.94 毫秒 | 144.75 毫秒 | 20 |
| 资源清理 | 1 秒 | 1 秒 | 2 秒 | 20 |
| 评分 | 39 秒 | 2 秒 | 4 分 17 秒 | 20 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| b8cbac04-cbdf-4163-a646-cc37091de4e6 | 1,800 | 1800 | 4 | 4 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 198,309,964 | 1,729,961 | 200,039,925 | 20 / 20 | — |
| 运行累计 | 198,309,964 | 1,729,961 | 200,039,925 | 20 / 20 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| abs-module-cache-flags | completed | 1 | 399.54 | 22.85 | complete / complete | — | [result](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/063eceb0-f6af-4d1b-967c-aba53ecc4e07/result.json) · [文件清单](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/063eceb0-f6af-4d1b-967c-aba53ecc4e07/files.json) · [轨迹](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/063eceb0-f6af-4d1b-967c-aba53ecc4e07/agent/trajectory.jsonl) |
| anko-typed-variable-bindings | completed | 1 | 398.30 | 16.54 | complete / complete | — | [result](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/50cbd762-b1a5-4d3c-81f3-ecc99fe3590c/result.json) · [文件清单](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/50cbd762-b1a5-4d3c-81f3-ecc99fe3590c/files.json) · [轨迹](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/50cbd762-b1a5-4d3c-81f3-ecc99fe3590c/agent/trajectory.jsonl) |
| bandit-structured-nosec-directives | completed | 0 | 533.33 | 7.90 | complete / complete | — | [result](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/06e1dac4-bddf-4dee-b0a8-edca33d6ad13/result.json) · [文件清单](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/06e1dac4-bddf-4dee-b0a8-edca33d6ad13/files.json) · [轨迹](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/06e1dac4-bddf-4dee-b0a8-edca33d6ad13/agent/trajectory.jsonl) |
| csstree-shorthand-expansion-compression | completed | 1 | 554.75 | 2.00 | complete / complete | — | [result](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/973e1aa0-42e8-4373-abb9-e5742c334d6f/result.json) · [文件清单](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/973e1aa0-42e8-4373-abb9-e5742c334d6f/files.json) · [轨迹](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/973e1aa0-42e8-4373-abb9-e5742c334d6f/agent/trajectory.jsonl) |
| effect-sse-httpapi-streaming | completed | 0 | 1653.66 | 13.69 | complete / complete | — | [result](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/21d818ef-6030-4647-b257-49d7b7fbd73b/result.json) · [文件清单](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/21d818ef-6030-4647-b257-49d7b7fbd73b/files.json) · [轨迹](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/21d818ef-6030-4647-b257-49d7b7fbd73b/agent/trajectory.jsonl) |
| fastapi-implicit-head-options | completed | 1 | 726.87 | 45.65 | complete / complete | — | [result](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/e957361a-ee12-406a-ac56-e8c4b29f925c/result.json) · [文件清单](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/e957361a-ee12-406a-ac56-e8c4b29f925c/files.json) · [轨迹](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/e957361a-ee12-406a-ac56-e8c4b29f925c/agent/trajectory.jsonl) |
| goreleaser-retry-publish-auditing | completed | 1 | 762.68 | 58.50 | complete / complete | — | [result](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/a0e3b7b0-6c92-4a81-8d57-1a6b5241d9be/result.json) · [文件清单](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/a0e3b7b0-6c92-4a81-8d57-1a6b5241d9be/files.json) · [轨迹](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/a0e3b7b0-6c92-4a81-8d57-1a6b5241d9be/agent/trajectory.jsonl) |
| httpx-deterministic-cookie-store | completed | 0 | 624.68 | 13.48 | complete / complete | — | [result](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/d7d6f770-9556-43e7-81c5-35c790953eae/result.json) · [文件清单](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/d7d6f770-9556-43e7-81c5-35c790953eae/files.json) · [轨迹](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/d7d6f770-9556-43e7-81c5-35c790953eae/agent/trajectory.jsonl) |
| katex-multicolumn-array-spans | completed | 1 | 523.92 | 4.98 | complete / complete | — | [result](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/8992263b-13e3-4dab-87cd-2de5613ea7ba/result.json) · [文件清单](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/8992263b-13e3-4dab-87cd-2de5613ea7ba/files.json) · [轨迹](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/8992263b-13e3-4dab-87cd-2de5613ea7ba/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | completed | 1 | 2665.36 | 7.73 | complete / complete | — | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/2ca6c841-dc3f-423c-8527-ecdfd31063e3/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/2ca6c841-dc3f-423c-8527-ecdfd31063e3/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/2ca6c841-dc3f-423c-8527-ecdfd31063e3/agent/trajectory.jsonl) |
| langchain-request-coalescing | completed | 1 | 732.27 | 26.91 | complete / complete | — | [result](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/0290d61f-c170-43fe-91c5-58f975485b81/result.json) · [文件清单](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/0290d61f-c170-43fe-91c5-58f975485b81/files.json) · [轨迹](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/0290d61f-c170-43fe-91c5-58f975485b81/agent/trajectory.jsonl) |
| numba-stencil-boundary-modes | completed | 1 | 1022.01 | 256.90 | complete / complete | — | [result](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/a0312087-dc85-4b2d-aa6e-22510dd05d6f/result.json) · [文件清单](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/a0312087-dc85-4b2d-aa6e-22510dd05d6f/files.json) · [轨迹](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/a0312087-dc85-4b2d-aa6e-22510dd05d6f/agent/trajectory.jsonl) |
| opa-rego-rule-profiling | completed | 0 | 547.24 | 43.31 | complete / complete | — | [result](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/feecb3c1-4ede-42b2-b21d-3f7543522d56/result.json) · [文件清单](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/feecb3c1-4ede-42b2-b21d-3f7543522d56/files.json) · [轨迹](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/feecb3c1-4ede-42b2-b21d-3f7543522d56/agent/trajectory.jsonl) |
| pest-character-class-coalescing | completed | 0 | 648.44 | 8.46 | complete / complete | — | [result](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/d945eabb-4b42-493f-942d-756409b88945/result.json) · [文件清单](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/d945eabb-4b42-493f-942d-756409b88945/files.json) · [轨迹](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/d945eabb-4b42-493f-942d-756409b88945/agent/trajectory.jsonl) |
| query-persist-restored-query-state | completed | 1 | 459.25 | 9.32 | complete / complete | — | [result](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/db7833ee-15dd-4a35-80bf-ea1d87215696/result.json) · [文件清单](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/db7833ee-15dd-4a35-80bf-ea1d87215696/files.json) · [轨迹](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/db7833ee-15dd-4a35-80bf-ea1d87215696/agent/trajectory.jsonl) |
| skrub-duration-encoding | completed | 1 | 1180.65 | 178.79 | complete / complete | — | [result](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/27d2b0bc-a6ee-466d-999f-0c8f866f2ce9/result.json) · [文件清单](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/27d2b0bc-a6ee-466d-999f-0c8f866f2ce9/files.json) · [轨迹](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/27d2b0bc-a6ee-466d-999f-0c8f866f2ce9/agent/trajectory.jsonl) |
| tengo-callable-instance-isolation | completed | 1 | 684.85 | 9.66 | complete / complete | — | [result](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/b95b715e-52a8-4fa0-a123-130c09d157ae/result.json) · [文件清单](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/b95b715e-52a8-4fa0-a123-130c09d157ae/files.json) · [轨迹](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/b95b715e-52a8-4fa0-a123-130c09d157ae/agent/trajectory.jsonl) |
| textual-richlog-follow-state | completed | 1 | 726.28 | 6.58 | complete / complete | — | [result](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/c11fda0b-22ee-48a4-8886-f7fff38b3ee6/result.json) · [文件清单](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/c11fda0b-22ee-48a4-8886-f7fff38b3ee6/files.json) · [轨迹](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/c11fda0b-22ee-48a4-8886-f7fff38b3ee6/agent/trajectory.jsonl) |
| vitest-duration-sharding | completed | 1 | 738.77 | 36.47 | complete / complete | — | [result](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/8ff312ec-e1e4-43a0-929f-d034c9823535/result.json) · [文件清单](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/8ff312ec-e1e4-43a0-929f-d034c9823535/files.json) · [轨迹](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/8ff312ec-e1e4-43a0-929f-d034c9823535/agent/trajectory.jsonl) |
| ytt-jsonpath-query-api | completed | 1 | 407.13 | 12.69 | complete / complete | — | [result](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/efb67c65-c60c-4782-91eb-69f1b0cf55c8/result.json) · [文件清单](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/efb67c65-c60c-4782-91eb-69f1b0cf55c8/files.json) · [轨迹](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/efb67c65-c60c-4782-91eb-69f1b0cf55c8/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

