<!-- snapshotDigest: 6e7459cfccefcc621ff16c8ec1518dfdc4301993b4aa234602ea3af0e90acaa2 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 60.00%（12/20）**

Run: 635de06f-b902-401d-bbdf-5baab6bf89a8 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T02:53:44.363Z / 2026-11-13T03:55:20.432Z |
| 总耗时 | 1 小时 1 分 55 秒 |
| 答对 / 答错 / 解题超时 | 12 / 8 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 20 题；已保存 20 条记录；待运行 0 题。
有效评分覆盖率：20/20（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 20 |
| 计分题数 | 20 |
| 正常评分题数 | 20 |
| 答对题数 | 12 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 60.00% |
| 平均奖励 | 0.6 |
| 奖励 f2p | 0.9819 |
| 奖励 p2p | 0.9975 |
| 奖励 partial | 0.9908 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 1 分 55 秒 |
| 环境准备耗时 | 22 分 25 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 11 分 36 秒 | 4 分 57 秒 | 21 分 2 秒 | 20 |
| 任务准备 | 0.18 毫秒 | 0.11 毫秒 | 0.35 毫秒 | 20 |
| 环境启动 | 3 秒 | 3 秒 | 4 秒 | 20 |
| 解题 | 10 分 51 秒 | 4 分 39 秒 | 20 分 48 秒 | 20 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 20 |
| 证据收集 | 124.8 毫秒 | 96.7 毫秒 | 155.63 毫秒 | 20 |
| 资源清理 | 1 秒 | 1 秒 | 2 秒 | 20 |
| 评分 | 39 秒 | 2 秒 | 4 分 13 秒 | 20 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| afe3901f-9774-4ca5-b89a-c5eee152ebb6 | 未设置 | 1800 | 4 | 4 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 101,857,656 | 1,196,735 | 103,054,391 | 20 / 20 | — |
| 运行累计 | 101,857,656 | 1,196,735 | 103,054,391 | 20 / 20 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| abs-module-cache-flags | completed | 1 | 374.37 | 17.25 | complete / complete | — | [result](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/8dda108e-ad35-431a-af55-21f3d0f807cf/result.json) · [文件清单](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/8dda108e-ad35-431a-af55-21f3d0f807cf/files.json) · [轨迹](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/8dda108e-ad35-431a-af55-21f3d0f807cf/agent/trajectory.jsonl) |
| anko-typed-variable-bindings | completed | 1 | 388.75 | 17.39 | complete / complete | — | [result](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/4b690340-bdfa-426d-9915-fd243da9e79b/result.json) · [文件清单](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/4b690340-bdfa-426d-9915-fd243da9e79b/files.json) · [轨迹](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/4b690340-bdfa-426d-9915-fd243da9e79b/agent/trajectory.jsonl) |
| bandit-structured-nosec-directives | completed | 0 | 381.88 | 9.23 | complete / complete | — | [result](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/fc5740d5-fab6-47b9-8ef2-730e5ad0e3eb/result.json) · [文件清单](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/fc5740d5-fab6-47b9-8ef2-730e5ad0e3eb/files.json) · [轨迹](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/fc5740d5-fab6-47b9-8ef2-730e5ad0e3eb/agent/trajectory.jsonl) |
| csstree-shorthand-expansion-compression | completed | 1 | 561.67 | 1.94 | complete / complete | — | [result](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/f5ccee7f-cd0d-4480-9875-57b1d6dcaae9/result.json) · [文件清单](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/f5ccee7f-cd0d-4480-9875-57b1d6dcaae9/files.json) · [轨迹](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/f5ccee7f-cd0d-4480-9875-57b1d6dcaae9/agent/trajectory.jsonl) |
| effect-sse-httpapi-streaming | completed | 1 | 1143.48 | 14.13 | complete / complete | — | [result](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/98906318-8858-4bc4-b24b-ba26f12e81d7/result.json) · [文件清单](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/98906318-8858-4bc4-b24b-ba26f12e81d7/files.json) · [轨迹](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/98906318-8858-4bc4-b24b-ba26f12e81d7/agent/trajectory.jsonl) |
| fastapi-implicit-head-options | completed | 0 | 912.12 | 44.63 | complete / complete | — | [result](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/647878f6-9152-410d-a793-48a4f3f86f40/result.json) · [文件清单](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/647878f6-9152-410d-a793-48a4f3f86f40/files.json) · [轨迹](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/647878f6-9152-410d-a793-48a4f3f86f40/agent/trajectory.jsonl) |
| goreleaser-retry-publish-auditing | completed | 1 | 702.16 | 55.05 | complete / complete | — | [result](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/4f831870-83ea-46f5-bab5-4293664f07b2/result.json) · [文件清单](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/4f831870-83ea-46f5-bab5-4293664f07b2/files.json) · [轨迹](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/4f831870-83ea-46f5-bab5-4293664f07b2/agent/trajectory.jsonl) |
| httpx-deterministic-cookie-store | completed | 0 | 398.00 | 12.06 | complete / complete | — | [result](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/157d3f70-2092-445e-a9ee-033a65bd318a/result.json) · [文件清单](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/157d3f70-2092-445e-a9ee-033a65bd318a/files.json) · [轨迹](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/157d3f70-2092-445e-a9ee-033a65bd318a/agent/trajectory.jsonl) |
| katex-multicolumn-array-spans | completed | 0 | 444.92 | 5.00 | complete / complete | — | [result](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/c63727b4-f087-444d-b727-cd6b4ad3d04e/result.json) · [文件清单](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/c63727b4-f087-444d-b727-cd6b4ad3d04e/files.json) · [轨迹](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/c63727b4-f087-444d-b727-cd6b4ad3d04e/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | completed | 0 | 1248.34 | 7.44 | complete / complete | — | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/bdfe8966-4efc-407e-a078-4747d571d771/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/bdfe8966-4efc-407e-a078-4747d571d771/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/bdfe8966-4efc-407e-a078-4747d571d771/agent/trajectory.jsonl) |
| langchain-request-coalescing | completed | 0 | 705.53 | 27.03 | complete / complete | — | [result](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/5e3126bf-be05-489f-817e-8cbd9f294323/result.json) · [文件清单](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/5e3126bf-be05-489f-817e-8cbd9f294323/files.json) · [轨迹](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/5e3126bf-be05-489f-817e-8cbd9f294323/agent/trajectory.jsonl) |
| numba-stencil-boundary-modes | completed | 1 | 789.76 | 252.98 | complete / complete | — | [result](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/5e3e2e20-9b0d-4bf9-8a27-cdff789087a8/result.json) · [文件清单](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/5e3e2e20-9b0d-4bf9-8a27-cdff789087a8/files.json) · [轨迹](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/5e3e2e20-9b0d-4bf9-8a27-cdff789087a8/agent/trajectory.jsonl) |
| opa-rego-rule-profiling | completed | 1 | 532.41 | 31.52 | complete / complete | — | [result](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/d598baee-f4fe-498a-80fd-79d2d158c769/result.json) · [文件清单](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/d598baee-f4fe-498a-80fd-79d2d158c769/files.json) · [轨迹](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/d598baee-f4fe-498a-80fd-79d2d158c769/agent/trajectory.jsonl) |
| pest-character-class-coalescing | completed | 0 | 511.10 | 9.26 | complete / complete | — | [result](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/1a82da8d-c811-4c19-a011-a05b2674cf7f/result.json) · [文件清单](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/1a82da8d-c811-4c19-a011-a05b2674cf7f/files.json) · [轨迹](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/1a82da8d-c811-4c19-a011-a05b2674cf7f/agent/trajectory.jsonl) |
| query-persist-restored-query-state | completed | 1 | 526.99 | 8.23 | complete / complete | — | [result](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/4859dc77-2dea-47fb-95d9-cc68e031c542/result.json) · [文件清单](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/4859dc77-2dea-47fb-95d9-cc68e031c542/files.json) · [轨迹](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/4859dc77-2dea-47fb-95d9-cc68e031c542/agent/trajectory.jsonl) |
| skrub-duration-encoding | completed | 1 | 949.03 | 203.88 | complete / complete | — | [result](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/d1beeb4a-f5de-4efc-8b52-5e0d233980b3/result.json) · [文件清单](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/d1beeb4a-f5de-4efc-8b52-5e0d233980b3/files.json) · [轨迹](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/d1beeb4a-f5de-4efc-8b52-5e0d233980b3/agent/trajectory.jsonl) |
| tengo-callable-instance-isolation | completed | 1 | 464.90 | 9.48 | complete / complete | — | [result](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/95946dc0-e99b-493d-8783-885d8f449f13/result.json) · [文件清单](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/95946dc0-e99b-493d-8783-885d8f449f13/files.json) · [轨迹](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/95946dc0-e99b-493d-8783-885d8f449f13/agent/trajectory.jsonl) |
| textual-richlog-follow-state | completed | 1 | 760.98 | 6.59 | complete / complete | — | [result](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/578a97e4-d613-4b7e-8780-1bf722241c43/result.json) · [文件清单](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/578a97e4-d613-4b7e-8780-1bf722241c43/files.json) · [轨迹](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/578a97e4-d613-4b7e-8780-1bf722241c43/agent/trajectory.jsonl) |
| vitest-duration-sharding | completed | 0 | 948.08 | 29.69 | complete / complete | — | [result](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/50327a3b-4f07-441b-955e-0265b3fccd28/result.json) · [文件清单](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/50327a3b-4f07-441b-955e-0265b3fccd28/files.json) · [轨迹](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/50327a3b-4f07-441b-955e-0265b3fccd28/agent/trajectory.jsonl) |
| ytt-jsonpath-query-api | completed | 1 | 278.86 | 12.36 | complete / complete | — | [result](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/1fd6fe6b-2de0-4574-99d4-dc5c483560f7/result.json) · [文件清单](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/1fd6fe6b-2de0-4574-99d4-dc5c483560f7/files.json) · [轨迹](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/1fd6fe6b-2de0-4574-99d4-dc5c483560f7/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

