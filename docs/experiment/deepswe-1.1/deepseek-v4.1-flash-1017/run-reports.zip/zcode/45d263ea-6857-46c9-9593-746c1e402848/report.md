<!-- snapshotDigest: ecda5415f34b5c83650e47954d576eac420d0d2a4bbec0e4d9a26173167c2ff0 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 65.00%（13/20）**

Run: 45d263ea-6857-46c9-9593-746c1e402848 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T07:23:13.672Z / 2026-11-13T09:03:12.009Z |
| 总耗时 | 1 小时 39 分 58 秒 |
| 答对 / 答错 / 解题超时 | 13 / 7 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 20 题；已保存 20 条记录；待运行 0 题。
有效评分覆盖率：20/20（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 20 |
| 计分题数 | 20 |
| 正常评分题数 | 20 |
| 答对题数 | 13 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 65.00% |
| 平均奖励 | 0.65 |
| 奖励 f2p | 0.9913 |
| 奖励 p2p | 0.9975 |
| 奖励 partial | 0.9961 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 39 分 58 秒 |
| 环境准备耗时 | 41 分 8 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 17 分 38 秒 | 9 分 31 秒 | 31 分 6 秒 | 20 |
| 任务准备 | 0.2 毫秒 | 0.13 毫秒 | 0.34 毫秒 | 20 |
| 环境启动 | 4 秒 | 3 秒 | 6 秒 | 20 |
| 解题 | 16 分 54 秒 | 9 分 4 秒 | 26 分 59 秒 | 20 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 20 |
| 证据收集 | 262.4 毫秒 | 191.5 毫秒 | 343.52 毫秒 | 20 |
| 资源清理 | 1 秒 | 1 秒 | 2 秒 | 20 |
| 评分 | 37 秒 | 2 秒 | 4 分 0 秒 | 20 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 6176068e-2732-471a-a126-01cac38dd146 | 1,800 | 1800 | 4 | 4 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 271,353,296 | 1,974,598 | 273,327,894 | 20 / 20 | — |
| 运行累计 | 271,353,296 | 1,974,598 | 273,327,894 | 20 / 20 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| abs-module-cache-flags | completed | 1 | 633.35 | 15.92 | complete / complete | — | [result](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/9d55fe0d-dad3-4c80-b807-96acbe2a84ae/result.json) · [文件清单](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/9d55fe0d-dad3-4c80-b807-96acbe2a84ae/files.json) · [轨迹](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/9d55fe0d-dad3-4c80-b807-96acbe2a84ae/agent/trajectory.jsonl) |
| anko-typed-variable-bindings | completed | 1 | 544.12 | 16.99 | complete / complete | — | [result](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/a4bf56e9-bf7e-4154-9c2a-41614d51da28/result.json) · [文件清单](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/a4bf56e9-bf7e-4154-9c2a-41614d51da28/files.json) · [轨迹](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/a4bf56e9-bf7e-4154-9c2a-41614d51da28/agent/trajectory.jsonl) |
| bandit-structured-nosec-directives | completed | 0 | 979.88 | 8.48 | complete / complete | — | [result](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/1bf4bf7c-58e7-4c7a-b999-d358889a44b1/result.json) · [文件清单](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/1bf4bf7c-58e7-4c7a-b999-d358889a44b1/files.json) · [轨迹](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/1bf4bf7c-58e7-4c7a-b999-d358889a44b1/agent/trajectory.jsonl) |
| csstree-shorthand-expansion-compression | completed | 1 | 920.78 | 1.93 | complete / complete | — | [result](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/fa8c0c24-4367-46e5-a168-31f6827a9e55/result.json) · [文件清单](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/fa8c0c24-4367-46e5-a168-31f6827a9e55/files.json) · [轨迹](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/fa8c0c24-4367-46e5-a168-31f6827a9e55/agent/trajectory.jsonl) |
| effect-sse-httpapi-streaming | completed | 0 | 1212.43 | 14.17 | complete / complete | — | [result](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/70d7c2ca-3d9e-40e3-abd8-b6e2c1885369/result.json) · [文件清单](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/70d7c2ca-3d9e-40e3-abd8-b6e2c1885369/files.json) · [轨迹](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/70d7c2ca-3d9e-40e3-abd8-b6e2c1885369/agent/trajectory.jsonl) |
| fastapi-implicit-head-options | completed | 0 | 1027.81 | 43.60 | complete / complete | — | [result](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/56bc44bf-0fb3-414b-8498-832a3b4058d2/result.json) · [文件清单](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/56bc44bf-0fb3-414b-8498-832a3b4058d2/files.json) · [轨迹](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/56bc44bf-0fb3-414b-8498-832a3b4058d2/agent/trajectory.jsonl) |
| goreleaser-retry-publish-auditing | completed | 1 | 1158.24 | 58.37 | complete / complete | — | [result](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/50ecbcf0-2ba8-4364-bfe3-68a57b614a38/result.json) · [文件清单](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/50ecbcf0-2ba8-4364-bfe3-68a57b614a38/files.json) · [轨迹](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/50ecbcf0-2ba8-4364-bfe3-68a57b614a38/agent/trajectory.jsonl) |
| httpx-deterministic-cookie-store | completed | 0 | 964.61 | 12.18 | complete / complete | — | [result](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/e20af3fd-549d-470d-943f-9c2978bf66d6/result.json) · [文件清单](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/e20af3fd-549d-470d-943f-9c2978bf66d6/files.json) · [轨迹](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/e20af3fd-549d-470d-943f-9c2978bf66d6/agent/trajectory.jsonl) |
| katex-multicolumn-array-spans | completed | 1 | 1074.96 | 5.05 | complete / complete | — | [result](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/1643c8db-e581-4357-83aa-475f98f1dc8d/result.json) · [文件清单](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/1643c8db-e581-4357-83aa-475f98f1dc8d/files.json) · [轨迹](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/1643c8db-e581-4357-83aa-475f98f1dc8d/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | completed | 0 | 1606.67 | 7.46 | complete / complete | — | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/f62c3d94-15d6-4c44-8ac3-e48d3cf37558/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/f62c3d94-15d6-4c44-8ac3-e48d3cf37558/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/f62c3d94-15d6-4c44-8ac3-e48d3cf37558/agent/trajectory.jsonl) |
| langchain-request-coalescing | completed | 0 | 1468.64 | 27.50 | complete / complete | — | [result](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/a65b35ee-47b3-4f96-add6-b23d5603c05f/result.json) · [文件清单](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/a65b35ee-47b3-4f96-add6-b23d5603c05f/files.json) · [轨迹](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/a65b35ee-47b3-4f96-add6-b23d5603c05f/agent/trajectory.jsonl) |
| numba-stencil-boundary-modes | completed | 1 | 1619.22 | 240.35 | complete / complete | — | [result](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/59e9adc4-e6ed-4421-82f6-451687622a49/result.json) · [文件清单](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/59e9adc4-e6ed-4421-82f6-451687622a49/files.json) · [轨迹](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/59e9adc4-e6ed-4421-82f6-451687622a49/agent/trajectory.jsonl) |
| opa-rego-rule-profiling | completed | 1 | 829.87 | 32.94 | complete / complete | — | [result](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/f9c7a0e5-4da8-4a85-9176-51b38bb4d717/result.json) · [文件清单](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/f9c7a0e5-4da8-4a85-9176-51b38bb4d717/files.json) · [轨迹](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/f9c7a0e5-4da8-4a85-9176-51b38bb4d717/agent/trajectory.jsonl) |
| pest-character-class-coalescing | completed | 0 | 623.31 | 9.17 | complete / complete | — | [result](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/1d9d32ce-a55f-4e9f-9bb9-aa0669377ba1/result.json) · [文件清单](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/1d9d32ce-a55f-4e9f-9bb9-aa0669377ba1/files.json) · [轨迹](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/1d9d32ce-a55f-4e9f-9bb9-aa0669377ba1/agent/trajectory.jsonl) |
| query-persist-restored-query-state | completed | 1 | 768.47 | 8.45 | complete / complete | — | [result](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/425767b8-4384-458e-ac02-739b472c4c6c/result.json) · [文件清单](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/425767b8-4384-458e-ac02-739b472c4c6c/files.json) · [轨迹](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/425767b8-4384-458e-ac02-739b472c4c6c/agent/trajectory.jsonl) |
| skrub-duration-encoding | completed | 1 | 906.08 | 172.48 | complete / complete | — | [result](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/2d9ecd97-2225-4bae-97c8-bb259a3eeb26/result.json) · [文件清单](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/2d9ecd97-2225-4bae-97c8-bb259a3eeb26/files.json) · [轨迹](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/2d9ecd97-2225-4bae-97c8-bb259a3eeb26/agent/trajectory.jsonl) |
| tengo-callable-instance-isolation | completed | 1 | 1017.72 | 10.03 | complete / complete | — | [result](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/d3f41074-8e53-4f6e-810c-3c3732f2e5ce/result.json) · [文件清单](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/d3f41074-8e53-4f6e-810c-3c3732f2e5ce/files.json) · [轨迹](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/d3f41074-8e53-4f6e-810c-3c3732f2e5ce/agent/trajectory.jsonl) |
| textual-richlog-follow-state | completed | 1 | 1073.72 | 7.23 | complete / complete | — | [result](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/6e2c1d60-1204-42d1-85ec-9cc3a5964655/result.json) · [文件清单](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/6e2c1d60-1204-42d1-85ec-9cc3a5964655/files.json) · [轨迹](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/6e2c1d60-1204-42d1-85ec-9cc3a5964655/agent/trajectory.jsonl) |
| vitest-duration-sharding | completed | 1 | 1196.41 | 30.66 | complete / complete | — | [result](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/f0856838-18e1-4c91-8cab-ce9c0e872544/result.json) · [文件清单](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/f0856838-18e1-4c91-8cab-ce9c0e872544/files.json) · [轨迹](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/f0856838-18e1-4c91-8cab-ce9c0e872544/agent/trajectory.jsonl) |
| ytt-jsonpath-query-api | completed | 1 | 647.56 | 10.91 | complete / complete | — | [result](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/fc4b396e-a0ef-48c3-b66c-18d1f0c134d4/result.json) · [文件清单](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/fc4b396e-a0ef-48c3-b66c-18d1f0c134d4/files.json) · [轨迹](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/fc4b396e-a0ef-48c3-b66c-18d1f0c134d4/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

