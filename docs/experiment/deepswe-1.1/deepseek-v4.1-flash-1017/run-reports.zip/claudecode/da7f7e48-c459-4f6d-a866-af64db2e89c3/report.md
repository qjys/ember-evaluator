<!-- snapshotDigest: 7832e01ccadea035a532eb1eea30e4c83724acf77d9a77106feafba7ee97a729 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 75.00%（15/20）**

Run: da7f7e48-c459-4f6d-a866-af64db2e89c3 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | harbor |
| 模型 | claude-sonnet-4-5-20250929 |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T05:05:18.906Z / 2026-11-13T06:06:19.441Z |
| 总耗时 | 1 小时 1 分 1 秒 |
| 答对 / 答错 / 解题超时 | 15 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 20 题；已保存 20 条记录；待运行 0 题。
有效评分覆盖率：20/20（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 20 |
| 计分题数 | 20 |
| 正常评分题数 | 20 |
| 答对题数 | 15 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 75.00% |
| 平均奖励 | 0.75 |
| 奖励 f2p | 0.9821 |
| 奖励 p2p | 0.9977 |
| 奖励 partial | 0.9944 |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 1 分 1 秒 |
| 环境准备耗时 | 23 分 40 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 11 分 27 秒 | 4 分 54 秒 | 21 分 21 秒 | 20 |
| 任务准备 | 0.19 毫秒 | 0.13 毫秒 | 0.31 毫秒 | 20 |
| 环境启动 | 3 秒 | 3 秒 | 4 秒 | 20 |
| 解题 | 10 分 43 秒 | 4 分 35 秒 | 18 分 16 秒 | 20 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 20 |
| 证据收集 | 162.08 毫秒 | 130.17 毫秒 | 202.16 毫秒 | 20 |
| 资源清理 | 1 秒 | 1 秒 | 2 秒 | 20 |
| 评分 | 38 秒 | 2 秒 | 4 分 13 秒 | 20 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 0c80fe55-86ab-4bc4-9309-3daab0ef9b59 | 1,800 | 1800 | 4 | 4 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 142,966,082 | 1,252,616 | 144,218,698 | 20 / 20 | — |
| 运行累计 | 142,966,082 | 1,252,616 | 144,218,698 | 20 / 20 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| abs-module-cache-flags | completed | 1 | 422.84 | 16.14 | complete / complete | — | [result](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/3ce72c32-66bd-4a93-86f7-e876b7ab5622/result.json) · [文件清单](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/3ce72c32-66bd-4a93-86f7-e876b7ab5622/files.json) · [轨迹](tasks/dd0d22e9aa7725471f5b2dcac23943247d8877661c49541da66bc6c19efb063d/attempts/3ce72c32-66bd-4a93-86f7-e876b7ab5622/agent/trajectory.jsonl) |
| anko-typed-variable-bindings | completed | 0 | 352.45 | 15.80 | complete / complete | — | [result](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/5e02e41b-303c-4768-aead-9ebac8da8dec/result.json) · [文件清单](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/5e02e41b-303c-4768-aead-9ebac8da8dec/files.json) · [轨迹](tasks/6e90ecbe05619fb8b6d0ad9ae3349530f9d0e537d097a9d46f18a59cd299ace8/attempts/5e02e41b-303c-4768-aead-9ebac8da8dec/agent/trajectory.jsonl) |
| bandit-structured-nosec-directives | completed | 0 | 507.32 | 8.40 | complete / complete | — | [result](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/7949a963-9192-4540-bba8-d428c2640787/result.json) · [文件清单](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/7949a963-9192-4540-bba8-d428c2640787/files.json) · [轨迹](tasks/c297f4024fa21eb87af97b2c4edf5a9b234a1c93c7a231cf76dc407ac18c7bf8/attempts/7949a963-9192-4540-bba8-d428c2640787/agent/trajectory.jsonl) |
| csstree-shorthand-expansion-compression | completed | 1 | 708.25 | 1.94 | complete / complete | — | [result](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/d5a13579-de05-4dd4-909e-cc167028e961/result.json) · [文件清单](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/d5a13579-de05-4dd4-909e-cc167028e961/files.json) · [轨迹](tasks/df41ea9422188075adb5965ce905b05e681aa45928e6abf802f1256f02bb3c10/attempts/d5a13579-de05-4dd4-909e-cc167028e961/agent/trajectory.jsonl) |
| effect-sse-httpapi-streaming | completed | 0 | 914.90 | 20.04 | complete / complete | — | [result](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/c2562e71-b7cd-429d-8f1c-088840177c7d/result.json) · [文件清单](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/c2562e71-b7cd-429d-8f1c-088840177c7d/files.json) · [轨迹](tasks/ea37cc43c5a609deb1ac2aa376b232ea44a659a4fb4a5c058df31ce615342c21/attempts/c2562e71-b7cd-429d-8f1c-088840177c7d/agent/trajectory.jsonl) |
| fastapi-implicit-head-options | completed | 1 | 542.40 | 45.58 | complete / complete | — | [result](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/f28f7b6e-266a-47ea-840f-deba45276964/result.json) · [文件清单](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/f28f7b6e-266a-47ea-840f-deba45276964/files.json) · [轨迹](tasks/1d0122b138288d750b9f439538b1050b745e64a3aaa6088d68dd1e33d78eac8d/attempts/f28f7b6e-266a-47ea-840f-deba45276964/agent/trajectory.jsonl) |
| goreleaser-retry-publish-auditing | completed | 1 | 743.76 | 58.61 | complete / complete | — | [result](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/bd7ffcfd-e5d6-4b5f-b02d-6f381646dd69/result.json) · [文件清单](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/bd7ffcfd-e5d6-4b5f-b02d-6f381646dd69/files.json) · [轨迹](tasks/527e43c496c9ea07db57e564e9001aaf17faa43bec45730f5a106f0dd7dcc344/attempts/bd7ffcfd-e5d6-4b5f-b02d-6f381646dd69/agent/trajectory.jsonl) |
| httpx-deterministic-cookie-store | completed | 0 | 351.50 | 11.94 | complete / complete | — | [result](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/024c4270-83cf-4022-97c4-210d954f5a2b/result.json) · [文件清单](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/024c4270-83cf-4022-97c4-210d954f5a2b/files.json) · [轨迹](tasks/6c4a6f69aeb18c567a5726d875e69d8d9282227994440956480d26c324c74a30/attempts/024c4270-83cf-4022-97c4-210d954f5a2b/agent/trajectory.jsonl) |
| katex-multicolumn-array-spans | completed | 1 | 609.19 | 4.98 | complete / complete | — | [result](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/a580b8e6-de4e-4bdb-a992-624e199f86f6/result.json) · [文件清单](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/a580b8e6-de4e-4bdb-a992-624e199f86f6/files.json) · [轨迹](tasks/90f5931e629ca2a37460868a13460630bf043406a94d9a39b2dc64cdc4b00783/attempts/a580b8e6-de4e-4bdb-a992-624e199f86f6/agent/trajectory.jsonl) |
| koota-composite-trait-aspects | completed | 1 | 1019.13 | 7.46 | complete / complete | — | [result](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/2fb1418c-3bb0-4ef3-afe9-972c6a45793d/result.json) · [文件清单](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/2fb1418c-3bb0-4ef3-afe9-972c6a45793d/files.json) · [轨迹](tasks/673160b608f73618f8f15a608114c5435832c26b9f34b7038fcfbfa863d3d013/attempts/2fb1418c-3bb0-4ef3-afe9-972c6a45793d/agent/trajectory.jsonl) |
| langchain-request-coalescing | completed | 1 | 704.35 | 27.47 | complete / complete | — | [result](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/6927a134-ca22-4113-b957-4db6f40917ba/result.json) · [文件清单](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/6927a134-ca22-4113-b957-4db6f40917ba/files.json) · [轨迹](tasks/60024d70d052bbf3030dfb6ec9b0d98d3847bdfe23960ec91210439e8a2f668a/attempts/6927a134-ca22-4113-b957-4db6f40917ba/agent/trajectory.jsonl) |
| numba-stencil-boundary-modes | completed | 1 | 858.25 | 252.67 | complete / complete | — | [result](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/c06030bd-ee6a-4c13-90db-feeb9b29aad8/result.json) · [文件清单](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/c06030bd-ee6a-4c13-90db-feeb9b29aad8/files.json) · [轨迹](tasks/0645798f7445f51e09501680cae1d07b9f31e8263ef4385a298ef30faa0d4f3d/attempts/c06030bd-ee6a-4c13-90db-feeb9b29aad8/agent/trajectory.jsonl) |
| opa-rego-rule-profiling | completed | 1 | 382.35 | 32.79 | complete / complete | — | [result](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/d7786979-f604-4eec-b42b-282178ef3079/result.json) · [文件清单](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/d7786979-f604-4eec-b42b-282178ef3079/files.json) · [轨迹](tasks/91d52b781975194b33beb7332e384c2592d3108946e65304b2e94d1556f5c47d/attempts/d7786979-f604-4eec-b42b-282178ef3079/agent/trajectory.jsonl) |
| pest-character-class-coalescing | completed | 0 | 722.42 | 9.77 | complete / complete | — | [result](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/a40263ca-1921-4c1f-9487-c9923a1edaf8/result.json) · [文件清单](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/a40263ca-1921-4c1f-9487-c9923a1edaf8/files.json) · [轨迹](tasks/544c03073f9876ea683b24ec2e581be2958cebac21633fd31a36f44044f71cbd/attempts/a40263ca-1921-4c1f-9487-c9923a1edaf8/agent/trajectory.jsonl) |
| query-persist-restored-query-state | completed | 1 | 476.05 | 8.52 | complete / complete | — | [result](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/91d8f868-98f5-4370-a33c-3ac03cf970a9/result.json) · [文件清单](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/91d8f868-98f5-4370-a33c-3ac03cf970a9/files.json) · [轨迹](tasks/e3f5ee6f5d427ca3bce2bf8923090d21eb1f839feabcab0a95bc66950521e926/attempts/91d8f868-98f5-4370-a33c-3ac03cf970a9/agent/trajectory.jsonl) |
| skrub-duration-encoding | completed | 1 | 1096.34 | 178.63 | complete / complete | — | [result](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/dac5bc26-9a3a-4171-9f04-bf14f47a2065/result.json) · [文件清单](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/dac5bc26-9a3a-4171-9f04-bf14f47a2065/files.json) · [轨迹](tasks/64ceeade91bf0dade299469a91f9bab2066939989f3dd30f7f1bb61d514242b7/attempts/dac5bc26-9a3a-4171-9f04-bf14f47a2065/agent/trajectory.jsonl) |
| tengo-callable-instance-isolation | completed | 1 | 675.27 | 10.33 | complete / complete | — | [result](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/06107189-2b0e-4228-915c-a9d3a9175934/result.json) · [文件清单](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/06107189-2b0e-4228-915c-a9d3a9175934/files.json) · [轨迹](tasks/b870b6373995a4b6adf83174e12c9feae50e6692ad2476223a751beaac1614d4/attempts/06107189-2b0e-4228-915c-a9d3a9175934/agent/trajectory.jsonl) |
| textual-richlog-follow-state | completed | 1 | 668.44 | 6.71 | complete / complete | — | [result](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/61c2e3b0-57e0-4dfc-99d7-c8451359f569/result.json) · [文件清单](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/61c2e3b0-57e0-4dfc-99d7-c8451359f569/files.json) · [轨迹](tasks/b803295c6797f07ca973a1c5783ac7534656fa7605102a5a180a5ff8bc2a1a34/attempts/61c2e3b0-57e0-4dfc-99d7-c8451359f569/agent/trajectory.jsonl) |
| vitest-duration-sharding | completed | 1 | 821.37 | 34.19 | complete / complete | — | [result](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/660ed009-8b8f-4a84-9cc9-f89a75f5f7f3/result.json) · [文件清单](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/660ed009-8b8f-4a84-9cc9-f89a75f5f7f3/files.json) · [轨迹](tasks/2ac2fd85369ed8eac608c02e4b08973ff251495b805c426179eb080fc6b88399/attempts/660ed009-8b8f-4a84-9cc9-f89a75f5f7f3/agent/trajectory.jsonl) |
| ytt-jsonpath-query-api | completed | 1 | 275.16 | 12.68 | complete / complete | — | [result](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/d08651d1-01fd-450c-bb37-4951d9acbd54/result.json) · [文件清单](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/d08651d1-01fd-450c-bb37-4951d9acbd54/files.json) · [轨迹](tasks/55913d0441394ad17ced0858fb37a561f55c3efbc84883088091a707d1fe8fa3/attempts/d08651d1-01fd-450c-bb37-4951d9acbd54/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：harbor @ 5eb09ad30cc7354769f53b3e019d20dda8e20f7f0795bde0012f6fe304ca0e88

