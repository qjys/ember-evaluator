<!-- snapshotDigest: bfff16a15f37351cd984e71673e8fbcca2f9ffac3f05ea1a7f922545bf6c8633 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 83.33%（20/24）**

Run: 340281df-009b-4119-a01b-af50ad082b55 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:56:48.518Z / 2026-11-12T08:01:03.205Z |
| 总耗时 | 4 分 6 秒 |
| 答对 / 答错 / 解题超时 | 20 / 4 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 20 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 83.33% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 4 分 6 秒 |
| 环境准备耗时 | 3 分 14 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 30 秒 | 16 秒 | 1 分 25 秒 | 24 |
| 任务准备 | 0.61 毫秒 | 0.29 毫秒 | 2.92 毫秒 | 24 |
| 环境启动 | 14 秒 | 8 秒 | 21 秒 | 24 |
| 解题 | 9 秒 | 3 秒 | 1 分 9 秒 | 24 |
| 产物传输 | 2 秒 | 908.32 毫秒 | 3 秒 | 24 |
| 资源清理 | 5 秒 | 3 秒 | 8 秒 | 24 |
| 评分 | 0.56 毫秒 | 0.25 毫秒 | 4.87 毫秒 | 24 |
| 证据收集 | 10.83 毫秒 | 4.11 毫秒 | 37.08 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| ada4e371-8317-4ad9-99fc-d646123c09fe | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 34,558 | 17,364 | 51,922 | 24 / 24 | — |
| 运行累计 | 34,558 | 17,364 | 51,922 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4625 | completed | 1 | 3.47 | 0.00 | complete / not-produced | — | [result](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/e65e69f2-c7b3-437c-8daa-3ecb6b81df3d/result.json) · [文件清单](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/e65e69f2-c7b3-437c-8daa-3ecb6b81df3d/files.json) · [轨迹](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/e65e69f2-c7b3-437c-8daa-3ecb6b81df3d/agent/trajectory.jsonl) |
| test:4651 | completed | 1 | 4.35 | 0.00 | complete / not-produced | — | [result](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/07341562-a8f2-4b11-b972-1cfc599ad5ea/result.json) · [文件清单](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/07341562-a8f2-4b11-b972-1cfc599ad5ea/files.json) · [轨迹](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/07341562-a8f2-4b11-b972-1cfc599ad5ea/agent/trajectory.jsonl) |
| test:4670 | completed | 1 | 14.11 | 0.00 | complete / not-produced | — | [result](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/2a6b8ab7-1a9f-4f92-a1b4-945423790f15/result.json) · [文件清单](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/2a6b8ab7-1a9f-4f92-a1b4-945423790f15/files.json) · [轨迹](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/2a6b8ab7-1a9f-4f92-a1b4-945423790f15/agent/trajectory.jsonl) |
| test:4700 | completed | 1 | 5.09 | 0.00 | complete / not-produced | — | [result](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/d63a7add-48d6-4228-92e1-81ac9f80c185/result.json) · [文件清单](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/d63a7add-48d6-4228-92e1-81ac9f80c185/files.json) · [轨迹](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/d63a7add-48d6-4228-92e1-81ac9f80c185/agent/trajectory.jsonl) |
| test:4709 | completed | 0 | 6.63 | 0.00 | complete / not-produced | — | [result](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/64d316ce-a0ac-41db-8018-43e395af623a/result.json) · [文件清单](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/64d316ce-a0ac-41db-8018-43e395af623a/files.json) · [轨迹](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/64d316ce-a0ac-41db-8018-43e395af623a/agent/trajectory.jsonl) |
| test:4763 | completed | 0 | 14.22 | 0.00 | complete / not-produced | — | [result](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/71f1d576-d980-4968-8056-c321a67634d1/result.json) · [文件清单](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/71f1d576-d980-4968-8056-c321a67634d1/files.json) · [轨迹](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/71f1d576-d980-4968-8056-c321a67634d1/agent/trajectory.jsonl) |
| test:4770 | completed | 1 | 5.28 | 0.00 | complete / not-produced | — | [result](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/cd805aad-1925-4709-aeed-3e1c7948df2d/result.json) · [文件清单](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/cd805aad-1925-4709-aeed-3e1c7948df2d/files.json) · [轨迹](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/cd805aad-1925-4709-aeed-3e1c7948df2d/agent/trajectory.jsonl) |
| test:4786 | completed | 1 | 7.33 | 0.00 | complete / not-produced | — | [result](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/774872e3-1f9f-4f20-8f20-d4b895fdd90c/result.json) · [文件清单](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/774872e3-1f9f-4f20-8f20-d4b895fdd90c/files.json) · [轨迹](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/774872e3-1f9f-4f20-8f20-d4b895fdd90c/agent/trajectory.jsonl) |
| test:4879 | completed | 1 | 10.56 | 0.00 | complete / not-produced | — | [result](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/3514f37e-c0fb-4f11-8cf9-fd013ee16ece/result.json) · [文件清单](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/3514f37e-c0fb-4f11-8cf9-fd013ee16ece/files.json) · [轨迹](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/3514f37e-c0fb-4f11-8cf9-fd013ee16ece/agent/trajectory.jsonl) |
| test:5078 | completed | 1 | 13.76 | 0.00 | complete / not-produced | — | [result](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/9cf332b4-3cd8-4724-a883-65e02486ef5c/result.json) · [文件清单](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/9cf332b4-3cd8-4724-a883-65e02486ef5c/files.json) · [轨迹](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/9cf332b4-3cd8-4724-a883-65e02486ef5c/agent/trajectory.jsonl) |
| test:5123 | completed | 1 | 4.59 | 0.00 | complete / not-produced | — | [result](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/319932a1-623a-442f-a8c5-656927b146cd/result.json) · [文件清单](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/319932a1-623a-442f-a8c5-656927b146cd/files.json) · [轨迹](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/319932a1-623a-442f-a8c5-656927b146cd/agent/trajectory.jsonl) |
| test:5174 | completed | 1 | 3.86 | 0.00 | complete / not-produced | — | [result](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/427b8d86-8d89-49ea-8188-e749089805a9/result.json) · [文件清单](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/427b8d86-8d89-49ea-8188-e749089805a9/files.json) · [轨迹](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/427b8d86-8d89-49ea-8188-e749089805a9/agent/trajectory.jsonl) |
| test:5198 | completed | 1 | 3.88 | 0.00 | complete / not-produced | — | [result](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/e917ffc5-99cd-4726-b968-0f49dffb7e49/result.json) · [文件清单](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/e917ffc5-99cd-4726-b968-0f49dffb7e49/files.json) · [轨迹](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/e917ffc5-99cd-4726-b968-0f49dffb7e49/agent/trajectory.jsonl) |
| test:5243 | completed | 1 | 4.71 | 0.00 | complete / not-produced | — | [result](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/108befd0-199d-43a1-b4b7-2b20cde2c8b4/result.json) · [文件清单](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/108befd0-199d-43a1-b4b7-2b20cde2c8b4/files.json) · [轨迹](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/108befd0-199d-43a1-b4b7-2b20cde2c8b4/agent/trajectory.jsonl) |
| test:5309 | completed | 1 | 4.76 | 0.00 | complete / not-produced | — | [result](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/1ce4b40b-6c43-40c9-96c6-f1248439739b/result.json) · [文件清单](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/1ce4b40b-6c43-40c9-96c6-f1248439739b/files.json) · [轨迹](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/1ce4b40b-6c43-40c9-96c6-f1248439739b/agent/trajectory.jsonl) |
| test:5319 | completed | 1 | 6.11 | 0.00 | complete / not-produced | — | [result](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/a08005c7-67d1-4b44-ac82-b2ef4ebe3ebc/result.json) · [文件清单](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/a08005c7-67d1-4b44-ac82-b2ef4ebe3ebc/files.json) · [轨迹](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/a08005c7-67d1-4b44-ac82-b2ef4ebe3ebc/agent/trajectory.jsonl) |
| test:5328 | completed | 0 | 6.19 | 0.00 | complete / not-produced | — | [result](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/31fca564-5071-46aa-ad13-71c6e15e2b83/result.json) · [文件清单](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/31fca564-5071-46aa-ad13-71c6e15e2b83/files.json) · [轨迹](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/31fca564-5071-46aa-ad13-71c6e15e2b83/agent/trajectory.jsonl) |
| test:5361 | completed | 0 | 69.19 | 0.00 | complete / not-produced | — | [result](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/fb5f241b-86cc-40e9-8c8e-679d85398b77/result.json) · [文件清单](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/fb5f241b-86cc-40e9-8c8e-679d85398b77/files.json) · [轨迹](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/fb5f241b-86cc-40e9-8c8e-679d85398b77/agent/trajectory.jsonl) |
| test:5457 | completed | 1 | 5.17 | 0.00 | complete / not-produced | — | [result](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/b479a0f5-d954-42f7-8e74-a849f7f26db9/result.json) · [文件清单](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/b479a0f5-d954-42f7-8e74-a849f7f26db9/files.json) · [轨迹](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/b479a0f5-d954-42f7-8e74-a849f7f26db9/agent/trajectory.jsonl) |
| test:5461 | completed | 1 | 4.75 | 0.00 | complete / not-produced | — | [result](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/65655839-cd4b-4f1f-bb40-fa1f50e0c05d/result.json) · [文件清单](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/65655839-cd4b-4f1f-bb40-fa1f50e0c05d/files.json) · [轨迹](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/65655839-cd4b-4f1f-bb40-fa1f50e0c05d/agent/trajectory.jsonl) |
| test:5530 | completed | 1 | 6.83 | 0.00 | complete / not-produced | — | [result](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/acaf6e54-6961-471a-9679-406ad0e419df/result.json) · [文件清单](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/acaf6e54-6961-471a-9679-406ad0e419df/files.json) · [轨迹](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/acaf6e54-6961-471a-9679-406ad0e419df/agent/trajectory.jsonl) |
| test:5578 | completed | 1 | 3.62 | 0.00 | complete / not-produced | — | [result](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/c39c5f17-6067-49a2-8ac4-e9ca0ceabe7e/result.json) · [文件清单](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/c39c5f17-6067-49a2-8ac4-e9ca0ceabe7e/files.json) · [轨迹](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/c39c5f17-6067-49a2-8ac4-e9ca0ceabe7e/agent/trajectory.jsonl) |
| test:5580 | completed | 1 | 5.52 | 0.00 | complete / not-produced | — | [result](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/dd548bbb-75dc-402a-8e21-add93d12525a/result.json) · [文件清单](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/dd548bbb-75dc-402a-8e21-add93d12525a/files.json) · [轨迹](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/dd548bbb-75dc-402a-8e21-add93d12525a/agent/trajectory.jsonl) |
| test:5795 | completed | 1 | 3.10 | 0.00 | complete / not-produced | — | [result](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/d140e89b-42e8-4a47-9797-e0becc61af5e/result.json) · [文件清单](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/d140e89b-42e8-4a47-9797-e0becc61af5e/files.json) · [轨迹](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/d140e89b-42e8-4a47-9797-e0becc61af5e/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

