<!-- snapshotDigest: e09324ea251d18a17018c54212b4f95149eae4790739bb1de07d2d0a033ecd5b -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 79.17%（19/24）**

Run: 812e4bd0-a2f7-40a5-bfe1-5d683735cff4 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:01:08.579Z / 2026-11-12T08:04:44.581Z |
| 总耗时 | 3 分 29 秒 |
| 答对 / 答错 / 解题超时 | 19 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 19 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 79.17% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 3 分 29 秒 |
| 环境准备耗时 | 2 分 14 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 27 秒 | 17 秒 | 1 分 32 秒 | 24 |
| 任务准备 | 0.6 毫秒 | 0.3 毫秒 | 3.14 毫秒 | 24 |
| 环境启动 | 9 秒 | 6 秒 | 11 秒 | 24 |
| 解题 | 13 秒 | 3 秒 | 1 分 18 秒 | 24 |
| 产物传输 | 1 秒 | 906.81 毫秒 | 2 秒 | 24 |
| 资源清理 | 4 秒 | 3 秒 | 5 秒 | 24 |
| 评分 | 0.41 毫秒 | 0.19 毫秒 | 2.08 毫秒 | 24 |
| 证据收集 | 8.18 毫秒 | 3.66 毫秒 | 20.07 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 8529fbf7-d2ac-4dd3-9103-287945de2981 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 29,251 | 32,437 | 61,688 | 24 / 24 | — |
| 运行累计 | 29,251 | 32,437 | 61,688 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:5919 | completed | 0 | 51.51 | 0.00 | complete / not-produced | — | [result](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/8ada6067-f65b-4301-8aac-1cb952d1f407/result.json) · [文件清单](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/8ada6067-f65b-4301-8aac-1cb952d1f407/files.json) · [轨迹](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/8ada6067-f65b-4301-8aac-1cb952d1f407/agent/trajectory.jsonl) |
| test:5940 | completed | 1 | 5.09 | 0.00 | complete / not-produced | — | [result](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/03aa9fa8-9b11-4f25-b496-715b9d313bb0/result.json) · [文件清单](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/03aa9fa8-9b11-4f25-b496-715b9d313bb0/files.json) · [轨迹](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/03aa9fa8-9b11-4f25-b496-715b9d313bb0/agent/trajectory.jsonl) |
| test:6055 | completed | 1 | 3.34 | 0.00 | complete / not-produced | — | [result](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/e7dfbad5-d07a-4aba-9aad-e7c22d6d1683/result.json) · [文件清单](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/e7dfbad5-d07a-4aba-9aad-e7c22d6d1683/files.json) · [轨迹](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/e7dfbad5-d07a-4aba-9aad-e7c22d6d1683/agent/trajectory.jsonl) |
| test:6095 | completed | 1 | 4.14 | 0.00 | complete / not-produced | — | [result](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/70f9c63c-3280-4215-99d9-9370ff02c433/result.json) · [文件清单](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/70f9c63c-3280-4215-99d9-9370ff02c433/files.json) · [轨迹](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/70f9c63c-3280-4215-99d9-9370ff02c433/agent/trajectory.jsonl) |
| test:6120 | completed | 1 | 3.91 | 0.00 | complete / not-produced | — | [result](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/9b9ff991-64dd-4083-8462-07c86a9c3b0b/result.json) · [文件清单](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/9b9ff991-64dd-4083-8462-07c86a9c3b0b/files.json) · [轨迹](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/9b9ff991-64dd-4083-8462-07c86a9c3b0b/agent/trajectory.jsonl) |
| test:6123 | completed | 1 | 78.32 | 0.00 | complete / not-produced | — | [result](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/f09e7511-27e2-4f95-8e48-d14aabd8106f/result.json) · [文件清单](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/f09e7511-27e2-4f95-8e48-d14aabd8106f/files.json) · [轨迹](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/f09e7511-27e2-4f95-8e48-d14aabd8106f/agent/trajectory.jsonl) |
| test:6147 | completed | 0 | 16.20 | 0.00 | complete / not-produced | — | [result](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/7c334a00-b840-4fd7-ae48-4343aef9288c/result.json) · [文件清单](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/7c334a00-b840-4fd7-ae48-4343aef9288c/files.json) · [轨迹](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/7c334a00-b840-4fd7-ae48-4343aef9288c/agent/trajectory.jsonl) |
| test:6198 | completed | 0 | 8.06 | 0.00 | complete / not-produced | — | [result](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/7d596d52-4de4-4ea5-ad59-d530e1dfc259/result.json) · [文件清单](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/7d596d52-4de4-4ea5-ad59-d530e1dfc259/files.json) · [轨迹](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/7d596d52-4de4-4ea5-ad59-d530e1dfc259/agent/trajectory.jsonl) |
| test:6223 | completed | 1 | 7.54 | 0.00 | complete / not-produced | — | [result](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/44ebab66-25ef-475e-8503-0c11c7ef7ed8/result.json) · [文件清单](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/44ebab66-25ef-475e-8503-0c11c7ef7ed8/files.json) · [轨迹](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/44ebab66-25ef-475e-8503-0c11c7ef7ed8/agent/trajectory.jsonl) |
| test:6235 | completed | 1 | 4.09 | 0.00 | complete / not-produced | — | [result](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/41c6a627-5f59-4d75-88ef-457c2615da12/result.json) · [文件清单](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/41c6a627-5f59-4d75-88ef-457c2615da12/files.json) · [轨迹](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/41c6a627-5f59-4d75-88ef-457c2615da12/agent/trajectory.jsonl) |
| test:6403 | completed | 1 | 12.92 | 0.00 | complete / not-produced | — | [result](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/4a88bad3-e923-4698-a967-b18e908f5626/result.json) · [文件清单](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/4a88bad3-e923-4698-a967-b18e908f5626/files.json) · [轨迹](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/4a88bad3-e923-4698-a967-b18e908f5626/agent/trajectory.jsonl) |
| test:6436 | completed | 1 | 5.50 | 0.00 | complete / not-produced | — | [result](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/b7aadc41-498a-43a3-b513-9ba12a80d1ed/result.json) · [文件清单](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/b7aadc41-498a-43a3-b513-9ba12a80d1ed/files.json) · [轨迹](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/b7aadc41-498a-43a3-b513-9ba12a80d1ed/agent/trajectory.jsonl) |
| test:6508 | completed | 1 | 19.93 | 0.00 | complete / not-produced | — | [result](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/365b9c41-d13c-4885-ada9-dcb13d51d49f/result.json) · [文件清单](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/365b9c41-d13c-4885-ada9-dcb13d51d49f/files.json) · [轨迹](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/365b9c41-d13c-4885-ada9-dcb13d51d49f/agent/trajectory.jsonl) |
| test:6593 | completed | 1 | 4.07 | 0.00 | complete / not-produced | — | [result](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/101e8367-87d6-49ee-a815-0479b2bcda80/result.json) · [文件清单](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/101e8367-87d6-49ee-a815-0479b2bcda80/files.json) · [轨迹](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/101e8367-87d6-49ee-a815-0479b2bcda80/agent/trajectory.jsonl) |
| test:6655 | completed | 0 | 13.36 | 0.00 | complete / not-produced | — | [result](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/166ef8f2-8749-468a-9ee3-0b2f984bde58/result.json) · [文件清单](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/166ef8f2-8749-468a-9ee3-0b2f984bde58/files.json) · [轨迹](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/166ef8f2-8749-468a-9ee3-0b2f984bde58/agent/trajectory.jsonl) |
| test:6738 | completed | 0 | 19.11 | 0.00 | complete / not-produced | — | [result](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/022cebce-ef9f-4235-aba9-36944624bf05/result.json) · [文件清单](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/022cebce-ef9f-4235-aba9-36944624bf05/files.json) · [轨迹](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/022cebce-ef9f-4235-aba9-36944624bf05/agent/trajectory.jsonl) |
| test:6751 | completed | 1 | 3.80 | 0.00 | complete / not-produced | — | [result](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/e0aba091-a076-452c-9b2c-d2db7fb2be47/result.json) · [文件清单](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/e0aba091-a076-452c-9b2c-d2db7fb2be47/files.json) · [轨迹](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/e0aba091-a076-452c-9b2c-d2db7fb2be47/agent/trajectory.jsonl) |
| test:6784 | completed | 1 | 3.20 | 0.00 | complete / not-produced | — | [result](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/2c8e01ee-33df-4a9a-8063-3bfaffd9d27a/result.json) · [文件清单](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/2c8e01ee-33df-4a9a-8063-3bfaffd9d27a/files.json) · [轨迹](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/2c8e01ee-33df-4a9a-8063-3bfaffd9d27a/agent/trajectory.jsonl) |
| test:6792 | completed | 1 | 4.12 | 0.00 | complete / not-produced | — | [result](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/1ea2fbf2-b0d7-4e05-b098-4a5da556a2f7/result.json) · [文件清单](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/1ea2fbf2-b0d7-4e05-b098-4a5da556a2f7/files.json) · [轨迹](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/1ea2fbf2-b0d7-4e05-b098-4a5da556a2f7/agent/trajectory.jsonl) |
| test:6900 | completed | 1 | 3.18 | 0.00 | complete / not-produced | — | [result](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/7f1ced8d-1f14-440c-9f59-ab2c33ebd675/result.json) · [文件清单](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/7f1ced8d-1f14-440c-9f59-ab2c33ebd675/files.json) · [轨迹](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/7f1ced8d-1f14-440c-9f59-ab2c33ebd675/agent/trajectory.jsonl) |
| test:6928 | completed | 1 | 3.54 | 0.00 | complete / not-produced | — | [result](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/05201cd9-ffe7-47bf-9b7d-9cb769f208cb/result.json) · [文件清单](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/05201cd9-ffe7-47bf-9b7d-9cb769f208cb/files.json) · [轨迹](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/05201cd9-ffe7-47bf-9b7d-9cb769f208cb/agent/trajectory.jsonl) |
| test:6929 | completed | 1 | 5.17 | 0.00 | complete / not-produced | — | [result](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/3c16e155-1317-4cc3-94c5-ef76cb05f647/result.json) · [文件清单](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/3c16e155-1317-4cc3-94c5-ef76cb05f647/files.json) · [轨迹](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/3c16e155-1317-4cc3-94c5-ef76cb05f647/agent/trajectory.jsonl) |
| test:7161 | completed | 1 | 27.91 | 0.00 | complete / not-produced | — | [result](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/9c732dbc-9e3e-4fe1-9e69-86ded07feaa2/result.json) · [文件清单](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/9c732dbc-9e3e-4fe1-9e69-86ded07feaa2/files.json) · [轨迹](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/9c732dbc-9e3e-4fe1-9e69-86ded07feaa2/agent/trajectory.jsonl) |
| test:7181 | completed | 1 | 3.38 | 0.00 | complete / not-produced | — | [result](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/e78e589d-4947-4d50-a553-907e9f4560e5/result.json) · [文件清单](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/e78e589d-4947-4d50-a553-907e9f4560e5/files.json) · [轨迹](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/e78e589d-4947-4d50-a553-907e9f4560e5/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

