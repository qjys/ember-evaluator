<!-- snapshotDigest: 57f5cb59e42363681f2f18d7cee921b25dd0ba2df7f00f98f541a5f313eb9fc5 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 34.15%（70/205）**

Run: 3f567d3c-226c-453e-9fbe-cf0f42080011 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:02:51.522Z / 2026-11-12T07:26:04.785Z |
| 总耗时 | 22 分 27 秒 |
| 答对 / 答错 / 解题超时 | 70 / 9 / 0 |
| 清理未确认 | 2 |
| 轨迹不完整 / 产物不完整 | 2 / 0 |

已选择 210 题；已保存 84 条记录；待运行 129 题。
有效评分覆盖率：79/210（37.62%）。
执行失败 2；超时 0；取消 3；不支持 0。
Agent 解题超时 0（计 0 分）；无效 5。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 210 |
| 计分题数 | 205 |
| 正常评分题数 | 79 |
| 答对题数 | 70 |
| 无效评测 | 5 |
| 待运行 | 129 |
| 正确率 | 34.15% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 22 分 27 秒 |
| 环境准备耗时 | 23 分 3 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 41 秒 | 47.7 毫秒 | 4 分 24 秒 | 84 |
| 任务准备 | 0.55 毫秒 | 0.22 毫秒 | 8.71 毫秒 | 83 |
| 环境启动 | 20 秒 | 10 秒 | 32 秒 | 83 |
| 解题 | 12 秒 | 2 秒 | 4 分 0 秒 | 82 |
| 产物传输 | 3 秒 | 1 秒 | 7 秒 | 81 |
| 资源清理 | 7 秒 | 3 秒 | 15 秒 | 82 |
| 评分 | 0.62 毫秒 | 0.16 毫秒 | 3.65 毫秒 | 79 |
| 证据收集 | 26.88 毫秒 | 3.49 毫秒 | 316.34 毫秒 | 84 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 0ea0a997-4e16-437e-91b6-e09cd1efe8b6 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 114,559 | 52,321 | 166,880 | 80 / 210 | — |
| 运行累计 | 114,559 | 52,321 | 166,880 | 80 / 84 | 4 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:41 | completed | 1 | 5.90 | 0.00 | complete / not-produced | — | [result](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/83696512-c737-48b7-aeaa-15623c2c6348/result.json) · [文件清单](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/83696512-c737-48b7-aeaa-15623c2c6348/files.json) · [轨迹](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/83696512-c737-48b7-aeaa-15623c2c6348/agent/trajectory.jsonl) |
| test:61 | completed | 0 | 23.70 | 0.00 | complete / not-produced | — | [result](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/37c4a18b-b3d6-4079-bea3-4978b932e8aa/result.json) · [文件清单](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/37c4a18b-b3d6-4079-bea3-4978b932e8aa/files.json) · [轨迹](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/37c4a18b-b3d6-4079-bea3-4978b932e8aa/agent/trajectory.jsonl) |
| test:97 | completed | 1 | 18.06 | 0.00 | complete / not-produced | — | [result](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/f3ea58e6-6c9a-411e-b4e8-70772c5aac09/result.json) · [文件清单](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/f3ea58e6-6c9a-411e-b4e8-70772c5aac09/files.json) · [轨迹](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/f3ea58e6-6c9a-411e-b4e8-70772c5aac09/agent/trajectory.jsonl) |
| test:209 | completed | 1 | 6.48 | 0.00 | complete / not-produced | — | [result](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/db5fcefc-a981-46bc-87ae-48ac2af3e4d5/result.json) · [文件清单](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/db5fcefc-a981-46bc-87ae-48ac2af3e4d5/files.json) · [轨迹](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/db5fcefc-a981-46bc-87ae-48ac2af3e4d5/agent/trajectory.jsonl) |
| test:286 | completed | 1 | 4.96 | 0.00 | complete / not-produced | — | [result](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/f04fd006-b6b1-4ca2-aa0b-c6b8ec4714ba/result.json) · [文件清单](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/f04fd006-b6b1-4ca2-aa0b-c6b8ec4714ba/files.json) · [轨迹](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/f04fd006-b6b1-4ca2-aa0b-c6b8ec4714ba/agent/trajectory.jsonl) |
| test:299 | completed | 1 | 8.05 | 0.00 | complete / not-produced | — | [result](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/527c8819-1a2b-4154-b106-ff5e27bc7172/result.json) · [文件清单](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/527c8819-1a2b-4154-b106-ff5e27bc7172/files.json) · [轨迹](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/527c8819-1a2b-4154-b106-ff5e27bc7172/agent/trajectory.jsonl) |
| test:311 | completed | 1 | 11.80 | 0.00 | complete / not-produced | — | [result](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/367ceceb-6011-497c-b01e-e5d243b3ec0a/result.json) · [文件清单](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/367ceceb-6011-497c-b01e-e5d243b3ec0a/files.json) · [轨迹](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/367ceceb-6011-497c-b01e-e5d243b3ec0a/agent/trajectory.jsonl) |
| test:352 | completed | 1 | 5.97 | 0.00 | complete / not-produced | — | [result](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/cec18b83-9c8f-4603-95a8-aa087b335666/result.json) · [文件清单](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/cec18b83-9c8f-4603-95a8-aa087b335666/files.json) · [轨迹](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/cec18b83-9c8f-4603-95a8-aa087b335666/agent/trajectory.jsonl) |
| test:355 | completed | 1 | 5.53 | 0.00 | complete / not-produced | — | [result](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/9a701af5-32c9-440e-a6ab-f0efbdf2b4f6/result.json) · [文件清单](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/9a701af5-32c9-440e-a6ab-f0efbdf2b4f6/files.json) · [轨迹](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/9a701af5-32c9-440e-a6ab-f0efbdf2b4f6/agent/trajectory.jsonl) |
| test:476 | completed | 1 | 13.34 | 0.00 | complete / not-produced | — | [result](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/a241059f-a14f-47b5-9ded-a7829112edf0/result.json) · [文件清单](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/a241059f-a14f-47b5-9ded-a7829112edf0/files.json) · [轨迹](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/a241059f-a14f-47b5-9ded-a7829112edf0/agent/trajectory.jsonl) |
| test:511 | completed | 1 | 5.13 | 0.00 | complete / not-produced | — | [result](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/784eac32-1809-4d22-b931-6877e2cafdd4/result.json) · [文件清单](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/784eac32-1809-4d22-b931-6877e2cafdd4/files.json) · [轨迹](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/784eac32-1809-4d22-b931-6877e2cafdd4/agent/trajectory.jsonl) |
| test:552 | completed | 1 | 4.24 | 0.00 | complete / not-produced | — | [result](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/dafbde66-84f9-497a-a50f-8b53501c79fe/result.json) · [文件清单](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/dafbde66-84f9-497a-a50f-8b53501c79fe/files.json) · [轨迹](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/dafbde66-84f9-497a-a50f-8b53501c79fe/agent/trajectory.jsonl) |
| test:624 | completed | 1 | 4.46 | 0.00 | complete / not-produced | — | [result](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/f244d350-708e-456b-9963-3aa856f6dbce/result.json) · [文件清单](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/f244d350-708e-456b-9963-3aa856f6dbce/files.json) · [轨迹](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/f244d350-708e-456b-9963-3aa856f6dbce/agent/trajectory.jsonl) |
| test:669 | completed | 1 | 5.34 | 0.00 | complete / not-produced | — | [result](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/9e8bb450-6606-4c85-9983-c1a21e07362c/result.json) · [文件清单](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/9e8bb450-6606-4c85-9983-c1a21e07362c/files.json) · [轨迹](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/9e8bb450-6606-4c85-9983-c1a21e07362c/agent/trajectory.jsonl) |
| test:670 | completed | 1 | 4.76 | 0.00 | complete / not-produced | — | [result](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/fd8fead5-40d1-4300-8ad6-b8b44abcd2f3/result.json) · [文件清单](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/fd8fead5-40d1-4300-8ad6-b8b44abcd2f3/files.json) · [轨迹](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/fd8fead5-40d1-4300-8ad6-b8b44abcd2f3/agent/trajectory.jsonl) |
| test:796 | completed | 1 | 11.74 | 0.00 | complete / not-produced | — | [result](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/a9ecaa1a-7e5e-47f9-b457-4476ada76ae7/result.json) · [文件清单](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/a9ecaa1a-7e5e-47f9-b457-4476ada76ae7/files.json) · [轨迹](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/a9ecaa1a-7e5e-47f9-b457-4476ada76ae7/agent/trajectory.jsonl) |
| test:828 | completed | 1 | 10.01 | 0.00 | complete / not-produced | — | [result](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/33bcc288-d9f8-4c71-8542-f055a901a7bc/result.json) · [文件清单](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/33bcc288-d9f8-4c71-8542-f055a901a7bc/files.json) · [轨迹](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/33bcc288-d9f8-4c71-8542-f055a901a7bc/agent/trajectory.jsonl) |
| test:841 | completed | 1 | 17.43 | 0.00 | complete / not-produced | — | [result](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/c03bcf09-1ab7-46a2-9d0c-83dba1fbf5e6/result.json) · [文件清单](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/c03bcf09-1ab7-46a2-9d0c-83dba1fbf5e6/files.json) · [轨迹](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/c03bcf09-1ab7-46a2-9d0c-83dba1fbf5e6/agent/trajectory.jsonl) |
| test:883 | completed | 1 | 9.86 | 0.00 | complete / not-produced | — | [result](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/bf36f5da-b429-4e1a-91fa-805166267b65/result.json) · [文件清单](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/bf36f5da-b429-4e1a-91fa-805166267b65/files.json) · [轨迹](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/bf36f5da-b429-4e1a-91fa-805166267b65/agent/trajectory.jsonl) |
| test:938 | completed | 1 | 11.08 | 0.00 | complete / not-produced | — | [result](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/739d97e7-5d60-4703-964b-3005e26da6d8/result.json) · [文件清单](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/739d97e7-5d60-4703-964b-3005e26da6d8/files.json) · [轨迹](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/739d97e7-5d60-4703-964b-3005e26da6d8/agent/trajectory.jsonl) |
| test:1026 | completed | 0 | 9.59 | 0.00 | complete / not-produced | — | [result](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/f512b436-390a-4e1f-a1fe-480ed7639079/result.json) · [文件清单](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/f512b436-390a-4e1f-a1fe-480ed7639079/files.json) · [轨迹](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/f512b436-390a-4e1f-a1fe-480ed7639079/agent/trajectory.jsonl) |
| test:1229 | completed | 1 | 6.75 | 0.00 | complete / not-produced | — | [result](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/611117bf-1bfb-4c14-a2b0-5417912c743d/result.json) · [文件清单](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/611117bf-1bfb-4c14-a2b0-5417912c743d/files.json) · [轨迹](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/611117bf-1bfb-4c14-a2b0-5417912c743d/agent/trajectory.jsonl) |
| test:1252 | completed | 1 | 3.26 | 0.00 | complete / not-produced | — | [result](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/c26d683c-d4e3-4f11-b2eb-8b69d7881367/result.json) · [文件清单](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/c26d683c-d4e3-4f11-b2eb-8b69d7881367/files.json) · [轨迹](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/c26d683c-d4e3-4f11-b2eb-8b69d7881367/agent/trajectory.jsonl) |
| test:1399 | completed | 1 | 15.06 | 0.00 | complete / not-produced | — | [result](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/0dced400-1b45-4abe-a5d0-1ae693460f93/result.json) · [文件清单](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/0dced400-1b45-4abe-a5d0-1ae693460f93/files.json) · [轨迹](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/0dced400-1b45-4abe-a5d0-1ae693460f93/agent/trajectory.jsonl) |
| test:1454 | completed | 1 | 31.14 | 0.00 | complete / not-produced | — | [result](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/3e7e11b8-8ea5-4089-9551-59aa99825f7a/result.json) · [文件清单](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/3e7e11b8-8ea5-4089-9551-59aa99825f7a/files.json) · [轨迹](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/3e7e11b8-8ea5-4089-9551-59aa99825f7a/agent/trajectory.jsonl) |
| test:1514 | completed | 0 | 34.63 | 0.00 | complete / not-produced | — | [result](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/6a2eb15f-f196-4eb2-976e-e04636acad42/result.json) · [文件清单](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/6a2eb15f-f196-4eb2-976e-e04636acad42/files.json) · [轨迹](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/6a2eb15f-f196-4eb2-976e-e04636acad42/agent/trajectory.jsonl) |
| test:1531 | completed | 0 | 16.17 | 0.00 | complete / not-produced | — | [result](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/7a00db23-e7bb-4514-ac96-90df875e1e2a/result.json) · [文件清单](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/7a00db23-e7bb-4514-ac96-90df875e1e2a/files.json) · [轨迹](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/7a00db23-e7bb-4514-ac96-90df875e1e2a/agent/trajectory.jsonl) |
| test:1785 | completed | 0 | 27.74 | 0.00 | complete / not-produced | — | [result](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/0cd4dd68-652d-41ac-9c42-392bc94a6044/result.json) · [文件清单](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/0cd4dd68-652d-41ac-9c42-392bc94a6044/files.json) · [轨迹](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/0cd4dd68-652d-41ac-9c42-392bc94a6044/agent/trajectory.jsonl) |
| test:1806 | completed | 0 | 28.87 | 0.00 | complete / not-produced | — | [result](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/c5184a1f-551e-4186-b646-b15e21a43828/result.json) · [文件清单](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/c5184a1f-551e-4186-b646-b15e21a43828/files.json) · [轨迹](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/c5184a1f-551e-4186-b646-b15e21a43828/agent/trajectory.jsonl) |
| test:1827 | completed | 1 | 10.28 | 0.00 | complete / not-produced | — | [result](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/a162062f-6a5f-4561-aac9-064ffb2e369e/result.json) · [文件清单](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/a162062f-6a5f-4561-aac9-064ffb2e369e/files.json) · [轨迹](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/a162062f-6a5f-4561-aac9-064ffb2e369e/agent/trajectory.jsonl) |
| test:1904 | completed | 1 | 5.58 | 0.00 | complete / not-produced | — | [result](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/4e57a5c4-fb9e-48f8-8e2d-492e7283a5f7/result.json) · [文件清单](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/4e57a5c4-fb9e-48f8-8e2d-492e7283a5f7/files.json) · [轨迹](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/4e57a5c4-fb9e-48f8-8e2d-492e7283a5f7/agent/trajectory.jsonl) |
| test:1943 | completed | 1 | 6.60 | 0.00 | complete / not-produced | — | [result](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/b59234d3-8a80-40eb-acbe-777cb864e852/result.json) · [文件清单](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/b59234d3-8a80-40eb-acbe-777cb864e852/files.json) · [轨迹](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/b59234d3-8a80-40eb-acbe-777cb864e852/agent/trajectory.jsonl) |
| test:1998 | completed | 1 | 6.22 | 0.00 | complete / not-produced | — | [result](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/01b95160-8629-41cb-83e4-89c0eb2eba94/result.json) · [文件清单](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/01b95160-8629-41cb-83e4-89c0eb2eba94/files.json) · [轨迹](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/01b95160-8629-41cb-83e4-89c0eb2eba94/agent/trajectory.jsonl) |
| test:2023 | completed | 1 | 4.97 | 0.00 | complete / not-produced | — | [result](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/5505f592-3d85-47fc-b106-e2d82695028b/result.json) · [文件清单](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/5505f592-3d85-47fc-b106-e2d82695028b/files.json) · [轨迹](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/5505f592-3d85-47fc-b106-e2d82695028b/agent/trajectory.jsonl) |
| test:2096 | completed | 0 | 5.16 | 0.00 | complete / not-produced | — | [result](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/3b95622a-e0af-48c1-b179-a46d34c6861d/result.json) · [文件清单](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/3b95622a-e0af-48c1-b179-a46d34c6861d/files.json) · [轨迹](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/3b95622a-e0af-48c1-b179-a46d34c6861d/agent/trajectory.jsonl) |
| test:2152 | completed | 1 | 4.28 | 0.00 | complete / not-produced | — | [result](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/603d5047-f733-42fb-9192-e00c87e29e6b/result.json) · [文件清单](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/603d5047-f733-42fb-9192-e00c87e29e6b/files.json) · [轨迹](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/603d5047-f733-42fb-9192-e00c87e29e6b/agent/trajectory.jsonl) |
| test:2175 | completed | 1 | 4.06 | 0.00 | complete / not-produced | — | [result](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/760f72b8-1918-4668-a267-5310772f78d6/result.json) · [文件清单](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/760f72b8-1918-4668-a267-5310772f78d6/files.json) · [轨迹](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/760f72b8-1918-4668-a267-5310772f78d6/agent/trajectory.jsonl) |
| test:2177 | completed | 1 | 4.59 | 0.00 | complete / not-produced | — | [result](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/9a62aef5-1cde-45e3-827b-51c82130ab37/result.json) · [文件清单](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/9a62aef5-1cde-45e3-827b-51c82130ab37/files.json) · [轨迹](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/9a62aef5-1cde-45e3-827b-51c82130ab37/agent/trajectory.jsonl) |
| test:2206 | completed | 1 | 5.07 | 0.00 | complete / not-produced | — | [result](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/c6b94dbc-a72d-4bd9-a15e-eded930a126c/result.json) · [文件清单](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/c6b94dbc-a72d-4bd9-a15e-eded930a126c/files.json) · [轨迹](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/c6b94dbc-a72d-4bd9-a15e-eded930a126c/agent/trajectory.jsonl) |
| test:2280 | completed | 1 | 4.61 | 0.00 | complete / not-produced | — | [result](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/215e4660-d3da-4517-809d-7e6b2e66b734/result.json) · [文件清单](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/215e4660-d3da-4517-809d-7e6b2e66b734/files.json) · [轨迹](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/215e4660-d3da-4517-809d-7e6b2e66b734/agent/trajectory.jsonl) |
| test:2347 | completed | 1 | 34.22 | 0.00 | complete / not-produced | — | [result](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/0a00f85e-6c6f-4850-a892-e5076df6496c/result.json) · [文件清单](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/0a00f85e-6c6f-4850-a892-e5076df6496c/files.json) · [轨迹](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/0a00f85e-6c6f-4850-a892-e5076df6496c/agent/trajectory.jsonl) |
| test:2400 | completed | 1 | 3.41 | 0.00 | complete / not-produced | — | [result](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/0fdd0996-95ea-4791-94a3-d7a26996e749/result.json) · [文件清单](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/0fdd0996-95ea-4791-94a3-d7a26996e749/files.json) · [轨迹](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/0fdd0996-95ea-4791-94a3-d7a26996e749/agent/trajectory.jsonl) |
| test:2527 | completed | 1 | 3.23 | 0.00 | complete / not-produced | — | [result](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/83b73881-df54-4421-8349-120a510c9afd/result.json) · [文件清单](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/83b73881-df54-4421-8349-120a510c9afd/files.json) · [轨迹](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/83b73881-df54-4421-8349-120a510c9afd/agent/trajectory.jsonl) |
| test:2636 | invalid (infrastructure) | — | — | — | not-produced / not-produced | ENV\_PREPARATION\_TIMEOUT | [result](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/d5818490-78d2-47b9-9c2b-8b6c5152dcf6/result.json) · [文件清单](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/d5818490-78d2-47b9-9c2b-8b6c5152dcf6/files.json) |
| test:2641 | completed | 1 | 3.24 | 0.00 | complete / not-produced | — | [result](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/553265cd-5da6-41cd-8eaf-5783e9c426cb/result.json) · [文件清单](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/553265cd-5da6-41cd-8eaf-5783e9c426cb/files.json) · [轨迹](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/553265cd-5da6-41cd-8eaf-5783e9c426cb/agent/trajectory.jsonl) |
| test:2714 | completed | 1 | 4.35 | 0.00 | complete / not-produced | — | [result](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/6a833978-fa58-4ce0-a2ae-ae493444bf1e/result.json) · [文件清单](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/6a833978-fa58-4ce0-a2ae-ae493444bf1e/files.json) · [轨迹](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/6a833978-fa58-4ce0-a2ae-ae493444bf1e/agent/trajectory.jsonl) |
| test:2716 | completed | 1 | 11.81 | 0.00 | complete / not-produced | — | [result](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/51e5443f-aaa2-4ab3-8a53-3602372260c1/result.json) · [文件清单](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/51e5443f-aaa2-4ab3-8a53-3602372260c1/files.json) · [轨迹](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/51e5443f-aaa2-4ab3-8a53-3602372260c1/agent/trajectory.jsonl) |
| test:2747 | completed | 1 | 3.77 | 0.00 | complete / not-produced | — | [result](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/953b12ba-9bcd-4fa4-b234-616ec58bb674/result.json) · [文件清单](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/953b12ba-9bcd-4fa4-b234-616ec58bb674/files.json) · [轨迹](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/953b12ba-9bcd-4fa4-b234-616ec58bb674/agent/trajectory.jsonl) |
| test:2882 | completed | 0 | 3.63 | 0.00 | complete / not-produced | — | [result](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/eed5238b-3843-41cc-a238-7c8e41db7d63/result.json) · [文件清单](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/eed5238b-3843-41cc-a238-7c8e41db7d63/files.json) · [轨迹](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/eed5238b-3843-41cc-a238-7c8e41db7d63/agent/trajectory.jsonl) |
| test:2951 | completed | 1 | 3.45 | 0.00 | complete / not-produced | — | [result](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/bbcf0c45-c0c4-46fa-aabf-224bc5c03838/result.json) · [文件清单](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/bbcf0c45-c0c4-46fa-aabf-224bc5c03838/files.json) · [轨迹](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/bbcf0c45-c0c4-46fa-aabf-224bc5c03838/agent/trajectory.jsonl) |
| test:3037 | completed | 1 | 4.12 | 0.00 | complete / not-produced | — | [result](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/629822d3-0c33-48bf-88e8-092357701bb3/result.json) · [文件清单](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/629822d3-0c33-48bf-88e8-092357701bb3/files.json) · [轨迹](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/629822d3-0c33-48bf-88e8-092357701bb3/agent/trajectory.jsonl) |
| test:3053 | completed | 1 | 49.19 | 0.00 | complete / not-produced | — | [result](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/01fbc9fb-fb66-46d0-99c5-4d21375da403/result.json) · [文件清单](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/01fbc9fb-fb66-46d0-99c5-4d21375da403/files.json) · [轨迹](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/01fbc9fb-fb66-46d0-99c5-4d21375da403/agent/trajectory.jsonl) |
| test:3136 | completed | 0 | 26.13 | 0.00 | complete / not-produced | — | [result](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/e9134b0f-c385-47ab-85a3-4a6f11226918/result.json) · [文件清单](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/e9134b0f-c385-47ab-85a3-4a6f11226918/files.json) · [轨迹](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/e9134b0f-c385-47ab-85a3-4a6f11226918/agent/trajectory.jsonl) |
| test:3165 | completed | 1 | 6.33 | 0.00 | complete / not-produced | — | [result](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/97177130-eb1f-486f-988a-6c0d9d136fb7/result.json) · [文件清单](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/97177130-eb1f-486f-988a-6c0d9d136fb7/files.json) · [轨迹](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/97177130-eb1f-486f-988a-6c0d9d136fb7/agent/trajectory.jsonl) |
| test:3196 | completed | 1 | 3.40 | 0.00 | complete / not-produced | — | [result](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/2fdc7d27-f754-44e4-9726-3fc9ce09c3a7/result.json) · [文件清单](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/2fdc7d27-f754-44e4-9726-3fc9ce09c3a7/files.json) · [轨迹](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/2fdc7d27-f754-44e4-9726-3fc9ce09c3a7/agent/trajectory.jsonl) |
| test:3231 | completed | 1 | 4.50 | 0.00 | complete / not-produced | — | [result](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/e47de72d-a11d-4398-a9cf-5e4c3a847779/result.json) · [文件清单](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/e47de72d-a11d-4398-a9cf-5e4c3a847779/files.json) · [轨迹](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/e47de72d-a11d-4398-a9cf-5e4c3a847779/agent/trajectory.jsonl) |
| test:3236 | completed | 1 | 3.42 | 0.00 | complete / not-produced | — | [result](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/4c74d0c8-95b1-4ae6-90c4-5c32878c42c1/result.json) · [文件清单](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/4c74d0c8-95b1-4ae6-90c4-5c32878c42c1/files.json) · [轨迹](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/4c74d0c8-95b1-4ae6-90c4-5c32878c42c1/agent/trajectory.jsonl) |
| test:3270 | completed | 1 | 3.57 | 0.00 | complete / not-produced | — | [result](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/7f33e910-d7ee-4bfa-b6c0-9f2e0364821c/result.json) · [文件清单](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/7f33e910-d7ee-4bfa-b6c0-9f2e0364821c/files.json) · [轨迹](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/7f33e910-d7ee-4bfa-b6c0-9f2e0364821c/agent/trajectory.jsonl) |
| test:3293 | completed | 1 | 5.05 | 0.00 | complete / not-produced | — | [result](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/50da865e-25f4-4346-9eec-3ce715489952/result.json) · [文件清单](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/50da865e-25f4-4346-9eec-3ce715489952/files.json) · [轨迹](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/50da865e-25f4-4346-9eec-3ce715489952/agent/trajectory.jsonl) |
| test:3331 | completed | 1 | 3.40 | 0.00 | complete / not-produced | — | [result](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/452b4b14-834b-4fac-ab69-85d3631e998a/result.json) · [文件清单](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/452b4b14-834b-4fac-ab69-85d3631e998a/files.json) · [轨迹](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/452b4b14-834b-4fac-ab69-85d3631e998a/agent/trajectory.jsonl) |
| test:3488 | completed | 1 | 6.63 | 0.00 | complete / not-produced | — | [result](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/8bd9f7e6-8413-45f8-98df-3493ba2e550c/result.json) · [文件清单](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/8bd9f7e6-8413-45f8-98df-3493ba2e550c/files.json) · [轨迹](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/8bd9f7e6-8413-45f8-98df-3493ba2e550c/agent/trajectory.jsonl) |
| test:3491 | cancelled | — | 240.02 | — | partial / not-produced | SOLVER\_AGENT\_TIMEOUT; RUN\_CANCELLED; CLEANUP\_FAILED | [result](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/dfb96409-b9ca-4ff3-94d3-a608f26d280f/result.json) · [文件清单](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/dfb96409-b9ca-4ff3-94d3-a608f26d280f/files.json) · [轨迹](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/dfb96409-b9ca-4ff3-94d3-a608f26d280f/agent/trajectory.jsonl) |
| test:3552 | completed | 1 | 7.15 | 0.00 | complete / not-produced | — | [result](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/11af8d87-bf72-4839-b627-f500c61293a2/result.json) · [文件清单](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/11af8d87-bf72-4839-b627-f500c61293a2/files.json) · [轨迹](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/11af8d87-bf72-4839-b627-f500c61293a2/agent/trajectory.jsonl) |
| test:3599 | completed | 1 | 4.27 | 0.00 | complete / not-produced | — | [result](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/e87fa71b-7b2a-434d-82ea-5691c5895a9f/result.json) · [文件清单](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/e87fa71b-7b2a-434d-82ea-5691c5895a9f/files.json) · [轨迹](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/e87fa71b-7b2a-434d-82ea-5691c5895a9f/agent/trajectory.jsonl) |
| test:3626 | completed | 1 | 7.07 | 0.00 | complete / not-produced | — | [result](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/cfae74f9-19a4-4536-a64c-70757b2976ba/result.json) · [文件清单](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/cfae74f9-19a4-4536-a64c-70757b2976ba/files.json) · [轨迹](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/cfae74f9-19a4-4536-a64c-70757b2976ba/agent/trajectory.jsonl) |
| test:4021 | completed | 1 | 11.46 | 0.00 | complete / not-produced | — | [result](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/5bf1d7e4-99b1-483d-93b1-8612cb908b67/result.json) · [文件清单](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/5bf1d7e4-99b1-483d-93b1-8612cb908b67/files.json) · [轨迹](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/5bf1d7e4-99b1-483d-93b1-8612cb908b67/agent/trajectory.jsonl) |
| test:4034 | completed | 1 | 4.57 | 0.00 | complete / not-produced | — | [result](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/7ab86a9c-79f2-47ef-b36f-415eaa9349e0/result.json) · [文件清单](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/7ab86a9c-79f2-47ef-b36f-415eaa9349e0/files.json) · [轨迹](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/7ab86a9c-79f2-47ef-b36f-415eaa9349e0/agent/trajectory.jsonl) |
| test:4058 | completed | 1 | 3.93 | 0.00 | complete / not-produced | — | [result](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/7c317086-2f42-48db-80f6-07ebf5c5da4a/result.json) · [文件清单](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/7c317086-2f42-48db-80f6-07ebf5c5da4a/files.json) · [轨迹](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/7c317086-2f42-48db-80f6-07ebf5c5da4a/agent/trajectory.jsonl) |
| test:4075 | completed | 1 | 4.01 | 0.00 | complete / not-produced | — | [result](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/3eadbe87-8b6d-4a24-8961-b23054e812eb/result.json) · [文件清单](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/3eadbe87-8b6d-4a24-8961-b23054e812eb/files.json) · [轨迹](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/3eadbe87-8b6d-4a24-8961-b23054e812eb/agent/trajectory.jsonl) |
| test:4142 | completed | 1 | 7.61 | 0.00 | complete / not-produced | — | [result](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/d6e2c1ef-9914-4e8f-90fb-8a16bc37f45d/result.json) · [文件清单](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/d6e2c1ef-9914-4e8f-90fb-8a16bc37f45d/files.json) · [轨迹](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/d6e2c1ef-9914-4e8f-90fb-8a16bc37f45d/agent/trajectory.jsonl) |
| test:4208 | completed | 1 | 3.83 | 0.00 | complete / not-produced | — | [result](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/cecec838-c43f-497a-a742-be6b645efc80/result.json) · [文件清单](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/cecec838-c43f-497a-a742-be6b645efc80/files.json) · [轨迹](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/cecec838-c43f-497a-a742-be6b645efc80/agent/trajectory.jsonl) |
| test:4298 | completed | 1 | 2.96 | 0.00 | complete / not-produced | — | [result](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/b179b286-7614-4fdd-a8e3-e72823501a2f/result.json) · [文件清单](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/b179b286-7614-4fdd-a8e3-e72823501a2f/files.json) · [轨迹](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/b179b286-7614-4fdd-a8e3-e72823501a2f/agent/trajectory.jsonl) |
| test:4337 | completed | 1 | 10.61 | 0.00 | complete / not-produced | — | [result](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/bf931c94-3768-495d-8f4b-0b59b986521e/result.json) · [文件清单](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/bf931c94-3768-495d-8f4b-0b59b986521e/files.json) · [轨迹](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/bf931c94-3768-495d-8f4b-0b59b986521e/agent/trajectory.jsonl) |
| test:4376 | completed | 1 | 4.25 | 0.00 | complete / not-produced | — | [result](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/9a3bd5ef-4f97-4141-b763-006ce6e8cebc/result.json) · [文件清单](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/9a3bd5ef-4f97-4141-b763-006ce6e8cebc/files.json) · [轨迹](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/9a3bd5ef-4f97-4141-b763-006ce6e8cebc/agent/trajectory.jsonl) |
| test:4405 | completed | 1 | 5.19 | 0.00 | complete / not-produced | — | [result](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/529f0b4f-fe99-4fe3-bff6-cf235db8c394/result.json) · [文件清单](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/529f0b4f-fe99-4fe3-bff6-cf235db8c394/files.json) · [轨迹](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/529f0b4f-fe99-4fe3-bff6-cf235db8c394/agent/trajectory.jsonl) |
| test:4552 | completed | 1 | 5.17 | 0.00 | complete / not-produced | — | [result](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/31e0d9b8-28e0-4c78-8380-97696f602835/result.json) · [文件清单](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/31e0d9b8-28e0-4c78-8380-97696f602835/files.json) · [轨迹](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/31e0d9b8-28e0-4c78-8380-97696f602835/agent/trajectory.jsonl) |
| test:4560 | completed | 1 | 8.17 | 0.00 | complete / not-produced | — | [result](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/c1096830-13fa-4b9f-9fa9-65d282d6d9ca/result.json) · [文件清单](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/c1096830-13fa-4b9f-9fa9-65d282d6d9ca/files.json) · [轨迹](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/c1096830-13fa-4b9f-9fa9-65d282d6d9ca/agent/trajectory.jsonl) |
| test:4568 | completed | 1 | 3.97 | 0.00 | complete / not-produced | — | [result](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/7ba7a036-1616-4f9f-8f4f-83542f6e7ed9/result.json) · [文件清单](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/7ba7a036-1616-4f9f-8f4f-83542f6e7ed9/files.json) · [轨迹](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/7ba7a036-1616-4f9f-8f4f-83542f6e7ed9/agent/trajectory.jsonl) |
| test:4580 | completed | 1 | 6.27 | 0.00 | complete / not-produced | — | [result](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/10277e8d-ceed-4538-9b02-dc6eb02c87b0/result.json) · [文件清单](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/10277e8d-ceed-4538-9b02-dc6eb02c87b0/files.json) · [轨迹](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/10277e8d-ceed-4538-9b02-dc6eb02c87b0/agent/trajectory.jsonl) |
| test:4603 | completed | 1 | 5.32 | 0.00 | complete / not-produced | — | [result](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/3597b195-f7cd-4fe1-99f7-fab38f71e33c/result.json) · [文件清单](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/3597b195-f7cd-4fe1-99f7-fab38f71e33c/files.json) · [轨迹](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/3597b195-f7cd-4fe1-99f7-fab38f71e33c/agent/trajectory.jsonl) |
| test:4625 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/59800229-36e7-4b32-95dc-6a82656400c6/result.json) · [文件清单](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/59800229-36e7-4b32-95dc-6a82656400c6/files.json) |
| test:4627 | completed | 1 | 4.17 | 0.00 | complete / not-produced | — | [result](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/45349722-2590-40d2-98b6-272d5e38d577/result.json) · [文件清单](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/45349722-2590-40d2-98b6-272d5e38d577/files.json) · [轨迹](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/45349722-2590-40d2-98b6-272d5e38d577/agent/trajectory.jsonl) |
| test:4651 | invalid | — | 3.36 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/730e97ff-de0d-4b85-8988-ca91e6190b3c/result.json) · [文件清单](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/730e97ff-de0d-4b85-8988-ca91e6190b3c/files.json) · [轨迹](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/730e97ff-de0d-4b85-8988-ca91e6190b3c/agent/trajectory.jsonl) |
| test:4670 | cancelled | — | 2.05 | — | partial / not-produced | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/2c5c88f3-063a-4895-927f-156897038d4d/result.json) · [文件清单](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/2c5c88f3-063a-4895-927f-156897038d4d/files.json) · [轨迹](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/2c5c88f3-063a-4895-927f-156897038d4d/agent/trajectory.jsonl) |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 5；错误记录 9（主流程 4；证据收集 1；资源清理 4）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| prepare | ENV_PREPARATION_TIMEOUT | 1 | 1 |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |
| cleanup | RUN_CANCELLED | 1 | 1 |
| cleanup | CLEANUP_FAILED | 2 | 3 |
| environment | RUN_CANCELLED | 1 | 1 |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| test:3491 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

