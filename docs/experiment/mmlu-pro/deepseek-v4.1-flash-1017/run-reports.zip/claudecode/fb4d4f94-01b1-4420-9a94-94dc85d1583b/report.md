<!-- snapshotDigest: 5498e8ff5720415e5892252faaa89d51ccf1177e6e28823b8a021caad7344e22 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: fb4d4f94-01b1-4420-9a94-94dc85d1583b · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:10:09.439Z / 2026-11-12T08:15:25.697Z |
| 总耗时 | 5 分 5 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 5 秒 |
| 环境准备耗时 | 4 分 40 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 36 秒 | 26 秒 | 1 分 29 秒 | 24 |
| 任务准备 | 0.49 毫秒 | 0.31 毫秒 | 1.13 毫秒 | 24 |
| 环境启动 | 17 秒 | 13 秒 | 19 秒 | 24 |
| 解题 | 10 秒 | 4 秒 | 1 分 0 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 6 秒 | 5 秒 | 9 秒 | 24 |
| 评分 | 0.49 毫秒 | 0.21 毫秒 | 2 毫秒 | 24 |
| 证据收集 | 12.4 毫秒 | 3.84 毫秒 | 30.09 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 9979cbac-7118-4cfc-b0ba-b3b2bb487544 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 34,585 | 20,888 | 55,473 | 24 / 24 | — |
| 运行累计 | 34,585 | 20,888 | 55,473 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:9136 | completed | 1 | 7.19 | 0.00 | complete / not-produced | — | [result](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/28d1bb8e-d8ab-41f2-a9ab-a718103f39c7/result.json) · [文件清单](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/28d1bb8e-d8ab-41f2-a9ab-a718103f39c7/files.json) · [轨迹](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/28d1bb8e-d8ab-41f2-a9ab-a718103f39c7/agent/trajectory.jsonl) |
| test:9222 | completed | 1 | 4.49 | 0.00 | complete / not-produced | — | [result](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/dc509abc-49ce-46c0-8639-f11566d2bfb3/result.json) · [文件清单](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/dc509abc-49ce-46c0-8639-f11566d2bfb3/files.json) · [轨迹](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/dc509abc-49ce-46c0-8639-f11566d2bfb3/agent/trajectory.jsonl) |
| test:9391 | completed | 1 | 4.96 | 0.00 | complete / not-produced | — | [result](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/21c2c5f1-0e11-487d-a9d0-a3310a52e80a/result.json) · [文件清单](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/21c2c5f1-0e11-487d-a9d0-a3310a52e80a/files.json) · [轨迹](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/21c2c5f1-0e11-487d-a9d0-a3310a52e80a/agent/trajectory.jsonl) |
| test:9395 | completed | 1 | 11.46 | 0.00 | complete / not-produced | — | [result](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b5d9daf8-f6b8-4f64-936c-3800a5e6fb2b/result.json) · [文件清单](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b5d9daf8-f6b8-4f64-936c-3800a5e6fb2b/files.json) · [轨迹](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b5d9daf8-f6b8-4f64-936c-3800a5e6fb2b/agent/trajectory.jsonl) |
| test:9405 | completed | 1 | 35.42 | 0.00 | complete / not-produced | — | [result](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/7c671309-c62e-4bcb-af05-a8f582f9ab6a/result.json) · [文件清单](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/7c671309-c62e-4bcb-af05-a8f582f9ab6a/files.json) · [轨迹](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/7c671309-c62e-4bcb-af05-a8f582f9ab6a/agent/trajectory.jsonl) |
| test:9769 | completed | 1 | 6.39 | 0.00 | complete / not-produced | — | [result](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/96fff431-fb34-407b-8edf-87d420bfb4ad/result.json) · [文件清单](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/96fff431-fb34-407b-8edf-87d420bfb4ad/files.json) · [轨迹](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/96fff431-fb34-407b-8edf-87d420bfb4ad/agent/trajectory.jsonl) |
| test:9843 | completed | 1 | 11.63 | 0.00 | complete / not-produced | — | [result](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/6b0213ac-2c88-4927-b2bd-8d4e1c7f69cf/result.json) · [文件清单](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/6b0213ac-2c88-4927-b2bd-8d4e1c7f69cf/files.json) · [轨迹](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/6b0213ac-2c88-4927-b2bd-8d4e1c7f69cf/agent/trajectory.jsonl) |
| test:9864 | completed | 1 | 4.49 | 0.00 | complete / not-produced | — | [result](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/5d709135-1739-4a01-a151-ca8ffaf4da4e/result.json) · [文件清单](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/5d709135-1739-4a01-a151-ca8ffaf4da4e/files.json) · [轨迹](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/5d709135-1739-4a01-a151-ca8ffaf4da4e/agent/trajectory.jsonl) |
| test:9901 | completed | 1 | 5.59 | 0.00 | complete / not-produced | — | [result](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/a3e0e1db-a3fa-46cf-9516-133d6b5ce9db/result.json) · [文件清单](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/a3e0e1db-a3fa-46cf-9516-133d6b5ce9db/files.json) · [轨迹](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/a3e0e1db-a3fa-46cf-9516-133d6b5ce9db/agent/trajectory.jsonl) |
| test:9931 | completed | 0 | 59.89 | 0.00 | complete / not-produced | — | [result](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/7f3395a8-cc0d-4db7-9e3f-013796ac2eeb/result.json) · [文件清单](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/7f3395a8-cc0d-4db7-9e3f-013796ac2eeb/files.json) · [轨迹](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/7f3395a8-cc0d-4db7-9e3f-013796ac2eeb/agent/trajectory.jsonl) |
| test:10127 | completed | 1 | 5.70 | 0.00 | complete / not-produced | — | [result](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/5670e2f0-c749-4988-9843-8a20acbaba53/result.json) · [文件清单](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/5670e2f0-c749-4988-9843-8a20acbaba53/files.json) · [轨迹](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/5670e2f0-c749-4988-9843-8a20acbaba53/agent/trajectory.jsonl) |
| test:10140 | completed | 1 | 7.67 | 0.00 | complete / not-produced | — | [result](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/a57b84af-3060-47c7-bd26-e472f50c57fa/result.json) · [文件清单](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/a57b84af-3060-47c7-bd26-e472f50c57fa/files.json) · [轨迹](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/a57b84af-3060-47c7-bd26-e472f50c57fa/agent/trajectory.jsonl) |
| test:10174 | completed | 1 | 6.84 | 0.00 | complete / not-produced | — | [result](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/3a42796d-97be-4360-90e0-e15b41782dfb/result.json) · [文件清单](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/3a42796d-97be-4360-90e0-e15b41782dfb/files.json) · [轨迹](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/3a42796d-97be-4360-90e0-e15b41782dfb/agent/trajectory.jsonl) |
| test:10184 | completed | 1 | 3.70 | 0.00 | complete / not-produced | — | [result](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/927731a4-3ab9-4bb7-b997-143365231ac6/result.json) · [文件清单](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/927731a4-3ab9-4bb7-b997-143365231ac6/files.json) · [轨迹](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/927731a4-3ab9-4bb7-b997-143365231ac6/agent/trajectory.jsonl) |
| test:10189 | completed | 1 | 4.04 | 0.00 | complete / not-produced | — | [result](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/588318b5-aba2-48b8-bb72-12f395b21e59/result.json) · [文件清单](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/588318b5-aba2-48b8-bb72-12f395b21e59/files.json) · [轨迹](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/588318b5-aba2-48b8-bb72-12f395b21e59/agent/trajectory.jsonl) |
| test:10294 | completed | 1 | 5.03 | 0.00 | complete / not-produced | — | [result](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/2086ff90-8639-4204-a115-9b50dd44c8b1/result.json) · [文件清单](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/2086ff90-8639-4204-a115-9b50dd44c8b1/files.json) · [轨迹](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/2086ff90-8639-4204-a115-9b50dd44c8b1/agent/trajectory.jsonl) |
| test:10318 | completed | 1 | 8.68 | 0.00 | complete / not-produced | — | [result](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/6f743f67-cd1b-4327-be8d-b83eef54228d/result.json) · [文件清单](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/6f743f67-cd1b-4327-be8d-b83eef54228d/files.json) · [轨迹](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/6f743f67-cd1b-4327-be8d-b83eef54228d/agent/trajectory.jsonl) |
| test:10362 | completed | 1 | 11.25 | 0.00 | complete / not-produced | — | [result](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/133dcdb2-ea3f-45ba-8ba7-5b216e9365de/result.json) · [文件清单](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/133dcdb2-ea3f-45ba-8ba7-5b216e9365de/files.json) · [轨迹](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/133dcdb2-ea3f-45ba-8ba7-5b216e9365de/agent/trajectory.jsonl) |
| test:10396 | completed | 1 | 5.05 | 0.00 | complete / not-produced | — | [result](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/735dd771-58b0-421d-8efb-10e9aed6e52d/result.json) · [文件清单](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/735dd771-58b0-421d-8efb-10e9aed6e52d/files.json) · [轨迹](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/735dd771-58b0-421d-8efb-10e9aed6e52d/agent/trajectory.jsonl) |
| test:10401 | completed | 1 | 11.86 | 0.00 | complete / not-produced | — | [result](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/efeb82ad-c050-44c3-992d-0e8f1ec4cacf/result.json) · [文件清单](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/efeb82ad-c050-44c3-992d-0e8f1ec4cacf/files.json) · [轨迹](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/efeb82ad-c050-44c3-992d-0e8f1ec4cacf/agent/trajectory.jsonl) |
| test:10403 | completed | 1 | 4.91 | 0.00 | complete / not-produced | — | [result](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/acda7a93-d5cd-45a2-b2ba-f815f1da5d62/result.json) · [文件清单](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/acda7a93-d5cd-45a2-b2ba-f815f1da5d62/files.json) · [轨迹](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/acda7a93-d5cd-45a2-b2ba-f815f1da5d62/agent/trajectory.jsonl) |
| test:10412 | completed | 1 | 4.06 | 0.00 | complete / not-produced | — | [result](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/e451b07b-0d4d-47d5-a70a-ccd6ffb4df04/result.json) · [文件清单](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/e451b07b-0d4d-47d5-a70a-ccd6ffb4df04/files.json) · [轨迹](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/e451b07b-0d4d-47d5-a70a-ccd6ffb4df04/agent/trajectory.jsonl) |
| test:10421 | completed | 1 | 6.03 | 0.00 | complete / not-produced | — | [result](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/fd63880c-8918-45bf-b03b-204309cdc945/result.json) · [文件清单](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/fd63880c-8918-45bf-b03b-204309cdc945/files.json) · [轨迹](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/fd63880c-8918-45bf-b03b-204309cdc945/agent/trajectory.jsonl) |
| test:10424 | completed | 1 | 7.38 | 0.00 | complete / not-produced | — | [result](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/a316df6d-bb02-4803-b3b9-e6ffe069432c/result.json) · [文件清单](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/a316df6d-bb02-4803-b3b9-e6ffe069432c/files.json) · [轨迹](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/a316df6d-bb02-4803-b3b9-e6ffe069432c/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

