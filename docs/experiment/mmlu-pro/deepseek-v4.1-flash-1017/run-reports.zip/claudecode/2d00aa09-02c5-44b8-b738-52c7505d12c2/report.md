<!-- snapshotDigest: b4da5eb8e1bd0d9a8720ff68f4f6be6dd3c42607d7fa6804bf03a392c73cffb8 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 88.89%（8/9）**

Run: 2d00aa09-02c5-44b8-b738-52c7505d12c2 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:22:40.773Z / 2026-11-12T08:25:13.062Z |
| 总耗时 | 2 分 28 秒 |
| 答对 / 答错 / 解题超时 | 8 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 9 题；已保存 9 条记录；待运行 0 题。
有效评分覆盖率：9/9（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 9 |
| 计分题数 | 9 |
| 正常评分题数 | 9 |
| 答对题数 | 8 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 88.89% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 分 28 秒 |
| 环境准备耗时 | 1 分 41 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 44 秒 | 33 秒 | 57 秒 | 9 |
| 任务准备 | 0.6 毫秒 | 0.25 毫秒 | 1.78 毫秒 | 9 |
| 环境启动 | 19 秒 | 17 秒 | 24 秒 | 9 |
| 解题 | 14 秒 | 5 秒 | 28 秒 | 9 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 9 |
| 资源清理 | 7 秒 | 5 秒 | 10 秒 | 9 |
| 评分 | 0.58 毫秒 | 0.31 毫秒 | 1.93 毫秒 | 9 |
| 证据收集 | 8.08 毫秒 | 5.31 毫秒 | 16.95 毫秒 | 9 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| ed1e837b-9b29-43f8-b226-6cdcb606ec91 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 11,860 | 12,080 | 23,940 | 9 / 9 | — |
| 运行累计 | 11,860 | 12,080 | 23,940 | 9 / 9 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:11559 | completed | 1 | 6.29 | 0.00 | complete / not-produced | — | [result](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/32332190-5d64-41b8-8766-dd6134c897b7/result.json) · [文件清单](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/32332190-5d64-41b8-8766-dd6134c897b7/files.json) · [轨迹](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/32332190-5d64-41b8-8766-dd6134c897b7/agent/trajectory.jsonl) |
| test:11576 | completed | 0 | 17.33 | 0.00 | complete / not-produced | — | [result](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/8a7e208b-fd8e-4b85-98d9-4b5f3110478a/result.json) · [文件清单](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/8a7e208b-fd8e-4b85-98d9-4b5f3110478a/files.json) · [轨迹](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/8a7e208b-fd8e-4b85-98d9-4b5f3110478a/agent/trajectory.jsonl) |
| test:11629 | completed | 1 | 23.77 | 0.00 | complete / not-produced | — | [result](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/1a93d3a4-3fa7-4995-8518-4e7d227c28f5/result.json) · [文件清单](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/1a93d3a4-3fa7-4995-8518-4e7d227c28f5/files.json) · [轨迹](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/1a93d3a4-3fa7-4995-8518-4e7d227c28f5/agent/trajectory.jsonl) |
| test:11660 | completed | 1 | 28.28 | 0.00 | complete / not-produced | — | [result](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/7b5a7355-9b0a-4596-8da5-3e9c820e9c4b/result.json) · [文件清单](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/7b5a7355-9b0a-4596-8da5-3e9c820e9c4b/files.json) · [轨迹](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/7b5a7355-9b0a-4596-8da5-3e9c820e9c4b/agent/trajectory.jsonl) |
| test:11802 | completed | 1 | 5.85 | 0.00 | complete / not-produced | — | [result](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/19290288-8dc8-4909-a419-bc2ea0bd684d/result.json) · [文件清单](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/19290288-8dc8-4909-a419-bc2ea0bd684d/files.json) · [轨迹](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/19290288-8dc8-4909-a419-bc2ea0bd684d/agent/trajectory.jsonl) |
| test:11808 | completed | 1 | 12.52 | 0.00 | complete / not-produced | — | [result](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/22197b1e-5e22-40e0-b09c-840eddcaac6b/result.json) · [文件清单](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/22197b1e-5e22-40e0-b09c-840eddcaac6b/files.json) · [轨迹](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/22197b1e-5e22-40e0-b09c-840eddcaac6b/agent/trajectory.jsonl) |
| test:11824 | completed | 1 | 4.89 | 0.00 | complete / not-produced | — | [result](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/6678f889-25a5-4165-b006-765f43f61881/result.json) · [文件清单](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/6678f889-25a5-4165-b006-765f43f61881/files.json) · [轨迹](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/6678f889-25a5-4165-b006-765f43f61881/agent/trajectory.jsonl) |
| test:11925 | completed | 1 | 14.32 | 0.00 | complete / not-produced | — | [result](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/98cac462-fd3c-457f-a1e8-2c637392113e/result.json) · [文件清单](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/98cac462-fd3c-457f-a1e8-2c637392113e/files.json) · [轨迹](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/98cac462-fd3c-457f-a1e8-2c637392113e/agent/trajectory.jsonl) |
| test:12002 | completed | 1 | 8.85 | 0.00 | complete / not-produced | — | [result](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/044f020a-4dfc-4a3b-8f4c-0c84e82026fb/result.json) · [文件清单](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/044f020a-4dfc-4a3b-8f4c-0c84e82026fb/files.json) · [轨迹](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/044f020a-4dfc-4a3b-8f4c-0c84e82026fb/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

