<!-- snapshotDigest: d2315327c441f3fb03d063ff0beaedc63021298ff387ce9c4b4eb9cba91adabd -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 87.50%（21/24）**

Run: ed985537-b20b-453f-9fbf-5c6bf1e754ac · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:15:31.279Z / 2026-11-12T08:22:34.537Z |
| 总耗时 | 6 分 50 秒 |
| 答对 / 答错 / 解题超时 | 21 / 3 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 21 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 87.50% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 6 分 50 秒 |
| 环境准备耗时 | 3 分 49 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 49 秒 | 29 秒 | 2 分 51 秒 | 24 |
| 任务准备 | 0.55 毫秒 | 0.25 毫秒 | 3 毫秒 | 24 |
| 环境启动 | 16 秒 | 12 秒 | 19 秒 | 24 |
| 解题 | 23 秒 | 4 秒 | 2 分 26 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 6 秒 | 4 秒 | 8 秒 | 24 |
| 评分 | 0.87 毫秒 | 0.24 毫秒 | 5.25 毫秒 | 24 |
| 证据收集 | 13.12 毫秒 | 3.58 毫秒 | 50.37 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| f406b861-7562-4196-b0c5-588af0de3fe2 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 28,528 | 58,839 | 87,367 | 24 / 24 | — |
| 运行累计 | 28,528 | 58,839 | 87,367 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:10471 | completed | 1 | 4.05 | 0.00 | complete / not-produced | — | [result](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/a51a062d-35d4-4279-b925-337229a4761d/result.json) · [文件清单](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/a51a062d-35d4-4279-b925-337229a4761d/files.json) · [轨迹](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/a51a062d-35d4-4279-b925-337229a4761d/agent/trajectory.jsonl) |
| test:10479 | completed | 1 | 4.56 | 0.00 | complete / not-produced | — | [result](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/60284e14-b4dc-4a13-a465-ee2a734dba42/result.json) · [文件清单](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/60284e14-b4dc-4a13-a465-ee2a734dba42/files.json) · [轨迹](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/60284e14-b4dc-4a13-a465-ee2a734dba42/agent/trajectory.jsonl) |
| test:10524 | completed | 1 | 4.87 | 0.00 | complete / not-produced | — | [result](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/961075d8-5fde-4d16-a0b9-43e78de489bf/result.json) · [文件清单](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/961075d8-5fde-4d16-a0b9-43e78de489bf/files.json) · [轨迹](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/961075d8-5fde-4d16-a0b9-43e78de489bf/agent/trajectory.jsonl) |
| test:10607 | completed | 1 | 4.57 | 0.00 | complete / not-produced | — | [result](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/9fdccd0b-e756-48db-8958-a4a1a4d7a2e8/result.json) · [文件清单](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/9fdccd0b-e756-48db-8958-a4a1a4d7a2e8/files.json) · [轨迹](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/9fdccd0b-e756-48db-8958-a4a1a4d7a2e8/agent/trajectory.jsonl) |
| test:10656 | completed | 1 | 5.14 | 0.00 | complete / not-produced | — | [result](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/200d1f75-531b-46ef-a2ee-f1ef59b3d56e/result.json) · [文件清单](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/200d1f75-531b-46ef-a2ee-f1ef59b3d56e/files.json) · [轨迹](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/200d1f75-531b-46ef-a2ee-f1ef59b3d56e/agent/trajectory.jsonl) |
| test:10674 | completed | 1 | 7.51 | 0.00 | complete / not-produced | — | [result](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/da7ec6b2-1d3a-483c-8532-4b0d795e77aa/result.json) · [文件清单](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/da7ec6b2-1d3a-483c-8532-4b0d795e77aa/files.json) · [轨迹](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/da7ec6b2-1d3a-483c-8532-4b0d795e77aa/agent/trajectory.jsonl) |
| test:10683 | completed | 1 | 6.54 | 0.01 | complete / not-produced | — | [result](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/a181cd0a-b315-4bd2-830d-2884901da19b/result.json) · [文件清单](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/a181cd0a-b315-4bd2-830d-2884901da19b/files.json) · [轨迹](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/a181cd0a-b315-4bd2-830d-2884901da19b/agent/trajectory.jsonl) |
| test:10690 | completed | 1 | 7.68 | 0.00 | complete / not-produced | — | [result](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/97c34622-b91b-4039-a4b3-7705bffcda62/result.json) · [文件清单](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/97c34622-b91b-4039-a4b3-7705bffcda62/files.json) · [轨迹](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/97c34622-b91b-4039-a4b3-7705bffcda62/agent/trajectory.jsonl) |
| test:10765 | completed | 1 | 4.64 | 0.00 | complete / not-produced | — | [result](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/cdff7719-470e-4cbc-b753-754540b1df08/result.json) · [文件清单](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/cdff7719-470e-4cbc-b753-754540b1df08/files.json) · [轨迹](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/cdff7719-470e-4cbc-b753-754540b1df08/agent/trajectory.jsonl) |
| test:10770 | completed | 1 | 11.62 | 0.01 | complete / not-produced | — | [result](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/b39fa78f-4185-476d-bac9-a949597fca54/result.json) · [文件清单](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/b39fa78f-4185-476d-bac9-a949597fca54/files.json) · [轨迹](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/b39fa78f-4185-476d-bac9-a949597fca54/agent/trajectory.jsonl) |
| test:10815 | completed | 1 | 4.69 | 0.00 | complete / not-produced | — | [result](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/f6d5a55f-f63c-43fe-8fb9-a9f325a6ce09/result.json) · [文件清单](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/f6d5a55f-f63c-43fe-8fb9-a9f325a6ce09/files.json) · [轨迹](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/f6d5a55f-f63c-43fe-8fb9-a9f325a6ce09/agent/trajectory.jsonl) |
| test:10846 | completed | 1 | 35.33 | 0.00 | complete / not-produced | — | [result](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/63bf4210-667b-401c-afb7-4cffde0dc1c6/result.json) · [文件清单](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/63bf4210-667b-401c-afb7-4cffde0dc1c6/files.json) · [轨迹](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/63bf4210-667b-401c-afb7-4cffde0dc1c6/agent/trajectory.jsonl) |
| test:10898 | completed | 1 | 7.65 | 0.00 | complete / not-produced | — | [result](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/845abfd8-858d-4fcd-b50f-fe487e0f6054/result.json) · [文件清单](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/845abfd8-858d-4fcd-b50f-fe487e0f6054/files.json) · [轨迹](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/845abfd8-858d-4fcd-b50f-fe487e0f6054/agent/trajectory.jsonl) |
| test:10940 | completed | 1 | 5.51 | 0.00 | complete / not-produced | — | [result](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/8472f963-0e3b-4713-845b-5245b7497e97/result.json) · [文件清单](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/8472f963-0e3b-4713-845b-5245b7497e97/files.json) · [轨迹](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/8472f963-0e3b-4713-845b-5245b7497e97/agent/trajectory.jsonl) |
| test:10966 | completed | 1 | 4.61 | 0.00 | complete / not-produced | — | [result](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/85e04e2c-febb-42a2-a9c2-d525ec17ccb3/result.json) · [文件清单](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/85e04e2c-febb-42a2-a9c2-d525ec17ccb3/files.json) · [轨迹](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/85e04e2c-febb-42a2-a9c2-d525ec17ccb3/agent/trajectory.jsonl) |
| test:11045 | completed | 0 | 3.53 | 0.00 | complete / not-produced | — | [result](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/65f36dcc-b8f4-47b4-a608-d577a58177de/result.json) · [文件清单](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/65f36dcc-b8f4-47b4-a608-d577a58177de/files.json) · [轨迹](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/65f36dcc-b8f4-47b4-a608-d577a58177de/agent/trajectory.jsonl) |
| test:11050 | completed | 1 | 52.73 | 0.00 | complete / not-produced | — | [result](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/6099e844-b4f0-4876-8a13-7b025c637659/result.json) · [文件清单](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/6099e844-b4f0-4876-8a13-7b025c637659/files.json) · [轨迹](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/6099e844-b4f0-4876-8a13-7b025c637659/agent/trajectory.jsonl) |
| test:11060 | completed | 1 | 4.18 | 0.00 | complete / not-produced | — | [result](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/ed96251d-0485-4cd3-b25f-0608b4048983/result.json) · [文件清单](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/ed96251d-0485-4cd3-b25f-0608b4048983/files.json) · [轨迹](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/ed96251d-0485-4cd3-b25f-0608b4048983/agent/trajectory.jsonl) |
| test:11093 | completed | 1 | 145.34 | 0.00 | complete / not-produced | — | [result](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/370815fa-78ff-48bd-a142-ad7d857014f2/result.json) · [文件清单](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/370815fa-78ff-48bd-a142-ad7d857014f2/files.json) · [轨迹](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/370815fa-78ff-48bd-a142-ad7d857014f2/agent/trajectory.jsonl) |
| test:11210 | completed | 1 | 8.91 | 0.00 | complete / not-produced | — | [result](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/a820a70c-7c29-4617-8472-3a705ecfa33d/result.json) · [文件清单](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/a820a70c-7c29-4617-8472-3a705ecfa33d/files.json) · [轨迹](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/a820a70c-7c29-4617-8472-3a705ecfa33d/agent/trajectory.jsonl) |
| test:11354 | completed | 0 | 3.91 | 0.00 | complete / not-produced | — | [result](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/432b3141-9b07-419b-9e94-0cab39499dd7/result.json) · [文件清单](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/432b3141-9b07-419b-9e94-0cab39499dd7/files.json) · [轨迹](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/432b3141-9b07-419b-9e94-0cab39499dd7/agent/trajectory.jsonl) |
| test:11491 | completed | 1 | 25.09 | 0.00 | complete / not-produced | — | [result](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/f7873e02-071f-4ec3-b76a-c74ab5242885/result.json) · [文件清单](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/f7873e02-071f-4ec3-b76a-c74ab5242885/files.json) · [轨迹](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/f7873e02-071f-4ec3-b76a-c74ab5242885/agent/trajectory.jsonl) |
| test:11496 | completed | 1 | 145.94 | 0.00 | complete / not-produced | — | [result](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/e621eb3a-3e84-444a-83f5-3e1b01bf409a/result.json) · [文件清单](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/e621eb3a-3e84-444a-83f5-3e1b01bf409a/files.json) · [轨迹](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/e621eb3a-3e84-444a-83f5-3e1b01bf409a/agent/trajectory.jsonl) |
| test:11506 | completed | 0 | 53.52 | 0.00 | complete / not-produced | — | [result](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/f3719206-ca2c-41ad-8a97-92671600ab72/result.json) · [文件清单](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/f3719206-ca2c-41ad-8a97-92671600ab72/files.json) · [轨迹](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/f3719206-ca2c-41ad-8a97-92671600ab72/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

