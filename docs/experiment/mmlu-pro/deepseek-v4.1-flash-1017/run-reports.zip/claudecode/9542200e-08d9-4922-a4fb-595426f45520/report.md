<!-- snapshotDigest: 90408119eda25f2640ae01186e179010bae696e5b37653f57311bf990f2d79ba -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: 9542200e-08d9-4922-a4fb-595426f45520 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:04:50.825Z / 2026-11-12T08:10:02.240Z |
| 总耗时 | 5 分 2 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 2 秒 |
| 环境准备耗时 | 4 分 41 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 30 秒 | 22 秒 | 38 秒 | 24 |
| 任务准备 | 0.5 毫秒 | 0.29 毫秒 | 1.38 毫秒 | 24 |
| 环境启动 | 16 秒 | 10 秒 | 21 秒 | 24 |
| 解题 | 6 秒 | 4 秒 | 9 秒 | 24 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 24 |
| 资源清理 | 6 秒 | 4 秒 | 8 秒 | 24 |
| 评分 | 0.59 毫秒 | 0.24 毫秒 | 5.36 毫秒 | 24 |
| 证据收集 | 10.57 毫秒 | 2.97 毫秒 | 35.01 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 3c393036-daa4-40cc-9a8e-309224716195 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 37,496 | 5,650 | 43,146 | 24 / 24 | — |
| 运行累计 | 37,496 | 5,650 | 43,146 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:7217 | completed | 1 | 8.22 | 0.00 | complete / not-produced | — | [result](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/bfebe9cc-d7e9-431e-b35e-26d67932ab36/result.json) · [文件清单](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/bfebe9cc-d7e9-431e-b35e-26d67932ab36/files.json) · [轨迹](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/bfebe9cc-d7e9-431e-b35e-26d67932ab36/agent/trajectory.jsonl) |
| test:7290 | completed | 1 | 5.67 | 0.00 | complete / not-produced | — | [result](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/519a8da1-0e78-40ab-8b5e-e86c054178ef/result.json) · [文件清单](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/519a8da1-0e78-40ab-8b5e-e86c054178ef/files.json) · [轨迹](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/519a8da1-0e78-40ab-8b5e-e86c054178ef/agent/trajectory.jsonl) |
| test:7304 | completed | 1 | 5.61 | 0.00 | complete / not-produced | — | [result](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/b20256da-82dd-4360-85e2-5ee9640d95c6/result.json) · [文件清单](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/b20256da-82dd-4360-85e2-5ee9640d95c6/files.json) · [轨迹](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/b20256da-82dd-4360-85e2-5ee9640d95c6/agent/trajectory.jsonl) |
| test:7312 | completed | 1 | 4.27 | 0.01 | complete / not-produced | — | [result](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/84fdbaf9-c720-4885-b8ae-499e2505d660/result.json) · [文件清单](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/84fdbaf9-c720-4885-b8ae-499e2505d660/files.json) · [轨迹](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/84fdbaf9-c720-4885-b8ae-499e2505d660/agent/trajectory.jsonl) |
| test:7448 | completed | 1 | 7.78 | 0.00 | complete / not-produced | — | [result](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/166132ae-3203-4613-8b48-096404dd3071/result.json) · [文件清单](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/166132ae-3203-4613-8b48-096404dd3071/files.json) · [轨迹](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/166132ae-3203-4613-8b48-096404dd3071/agent/trajectory.jsonl) |
| test:7462 | completed | 1 | 4.17 | 0.00 | complete / not-produced | — | [result](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/d2790cc6-922a-4346-ae06-543a53ba3ad4/result.json) · [文件清单](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/d2790cc6-922a-4346-ae06-543a53ba3ad4/files.json) · [轨迹](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/d2790cc6-922a-4346-ae06-543a53ba3ad4/agent/trajectory.jsonl) |
| test:7526 | completed | 1 | 4.43 | 0.00 | complete / not-produced | — | [result](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/de0a681c-2524-448c-8677-0673c3ce6012/result.json) · [文件清单](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/de0a681c-2524-448c-8677-0673c3ce6012/files.json) · [轨迹](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/de0a681c-2524-448c-8677-0673c3ce6012/agent/trajectory.jsonl) |
| test:7727 | completed | 1 | 4.37 | 0.00 | complete / not-produced | — | [result](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/52ea78ab-bf74-4ee8-92e0-9a24dae698e8/result.json) · [文件清单](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/52ea78ab-bf74-4ee8-92e0-9a24dae698e8/files.json) · [轨迹](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/52ea78ab-bf74-4ee8-92e0-9a24dae698e8/agent/trajectory.jsonl) |
| test:7752 | completed | 0 | 4.23 | 0.00 | complete / not-produced | — | [result](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/341b5e49-2e46-4904-b8ae-652340cbf734/result.json) · [文件清单](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/341b5e49-2e46-4904-b8ae-652340cbf734/files.json) · [轨迹](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/341b5e49-2e46-4904-b8ae-652340cbf734/agent/trajectory.jsonl) |
| test:7838 | completed | 1 | 4.17 | 0.00 | complete / not-produced | — | [result](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/2d20826e-c471-4417-80d1-8fda0400ac89/result.json) · [文件清单](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/2d20826e-c471-4417-80d1-8fda0400ac89/files.json) · [轨迹](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/2d20826e-c471-4417-80d1-8fda0400ac89/agent/trajectory.jsonl) |
| test:7954 | completed | 1 | 5.66 | 0.00 | complete / not-produced | — | [result](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/23dcf83a-c007-4297-8795-ccc4d5338e3e/result.json) · [文件清单](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/23dcf83a-c007-4297-8795-ccc4d5338e3e/files.json) · [轨迹](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/23dcf83a-c007-4297-8795-ccc4d5338e3e/agent/trajectory.jsonl) |
| test:7976 | completed | 1 | 4.14 | 0.00 | complete / not-produced | — | [result](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/e04667c4-b019-4fa6-a1db-4b884d7690ff/result.json) · [文件清单](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/e04667c4-b019-4fa6-a1db-4b884d7690ff/files.json) · [轨迹](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/e04667c4-b019-4fa6-a1db-4b884d7690ff/agent/trajectory.jsonl) |
| test:8199 | completed | 1 | 4.86 | 0.00 | complete / not-produced | — | [result](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/53c83c52-1db1-49dc-a80a-e0a7a581786e/result.json) · [文件清单](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/53c83c52-1db1-49dc-a80a-e0a7a581786e/files.json) · [轨迹](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/53c83c52-1db1-49dc-a80a-e0a7a581786e/agent/trajectory.jsonl) |
| test:8207 | completed | 1 | 6.14 | 0.00 | complete / not-produced | — | [result](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/56d3248f-e000-4513-8a3a-5608d727eeb9/result.json) · [文件清单](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/56d3248f-e000-4513-8a3a-5608d727eeb9/files.json) · [轨迹](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/56d3248f-e000-4513-8a3a-5608d727eeb9/agent/trajectory.jsonl) |
| test:8304 | completed | 1 | 5.05 | 0.00 | complete / not-produced | — | [result](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/27b9deaa-6e05-40c9-8ad2-e5c0e5800944/result.json) · [文件清单](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/27b9deaa-6e05-40c9-8ad2-e5c0e5800944/files.json) · [轨迹](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/27b9deaa-6e05-40c9-8ad2-e5c0e5800944/agent/trajectory.jsonl) |
| test:8366 | completed | 1 | 5.00 | 0.00 | complete / not-produced | — | [result](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/b80f6b36-34dd-4296-9913-bf392167b727/result.json) · [文件清单](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/b80f6b36-34dd-4296-9913-bf392167b727/files.json) · [轨迹](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/b80f6b36-34dd-4296-9913-bf392167b727/agent/trajectory.jsonl) |
| test:8511 | completed | 1 | 5.00 | 0.00 | complete / not-produced | — | [result](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/ff5d23ef-b7bb-4205-aed4-fe252d65ee21/result.json) · [文件清单](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/ff5d23ef-b7bb-4205-aed4-fe252d65ee21/files.json) · [轨迹](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/ff5d23ef-b7bb-4205-aed4-fe252d65ee21/agent/trajectory.jsonl) |
| test:8525 | completed | 1 | 7.99 | 0.00 | complete / not-produced | — | [result](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/28ded37a-8b0c-4e92-8216-ce18a43026f6/result.json) · [文件清单](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/28ded37a-8b0c-4e92-8216-ce18a43026f6/files.json) · [轨迹](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/28ded37a-8b0c-4e92-8216-ce18a43026f6/agent/trajectory.jsonl) |
| test:8604 | completed | 1 | 6.11 | 0.00 | complete / not-produced | — | [result](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/f2cad3f2-1e4c-46a4-b128-d4ae3b35ca2b/result.json) · [文件清单](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/f2cad3f2-1e4c-46a4-b128-d4ae3b35ca2b/files.json) · [轨迹](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/f2cad3f2-1e4c-46a4-b128-d4ae3b35ca2b/agent/trajectory.jsonl) |
| test:8740 | completed | 1 | 8.85 | 0.00 | complete / not-produced | — | [result](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/cb98e8a3-aa75-43f1-836c-09a0a14eade3/result.json) · [文件清单](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/cb98e8a3-aa75-43f1-836c-09a0a14eade3/files.json) · [轨迹](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/cb98e8a3-aa75-43f1-836c-09a0a14eade3/agent/trajectory.jsonl) |
| test:8839 | completed | 1 | 4.10 | 0.00 | complete / not-produced | — | [result](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/9ba49bcf-ad5c-4720-bcd4-4acdf0db964b/result.json) · [文件清单](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/9ba49bcf-ad5c-4720-bcd4-4acdf0db964b/files.json) · [轨迹](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/9ba49bcf-ad5c-4720-bcd4-4acdf0db964b/agent/trajectory.jsonl) |
| test:8939 | completed | 1 | 6.62 | 0.00 | complete / not-produced | — | [result](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/3afc65bd-6cdb-4bc0-bcdd-b5b1fe48d03d/result.json) · [文件清单](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/3afc65bd-6cdb-4bc0-bcdd-b5b1fe48d03d/files.json) · [轨迹](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/3afc65bd-6cdb-4bc0-bcdd-b5b1fe48d03d/agent/trajectory.jsonl) |
| test:8967 | completed | 1 | 5.05 | 0.00 | complete / not-produced | — | [result](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/56982302-83de-4ecf-8841-c1a3efc5799c/result.json) · [文件清单](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/56982302-83de-4ecf-8841-c1a3efc5799c/files.json) · [轨迹](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/56982302-83de-4ecf-8841-c1a3efc5799c/agent/trajectory.jsonl) |
| test:8989 | completed | 1 | 4.75 | 0.00 | complete / not-produced | — | [result](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/3e26e9a8-efec-4d72-a372-af020a92928a/result.json) · [文件清单](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/3e26e9a8-efec-4d72-a372-af020a92928a/files.json) · [轨迹](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/3e26e9a8-efec-4d72-a372-af020a92928a/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

