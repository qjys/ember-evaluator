<!-- snapshotDigest: 179e1592b60ed26cceb58c6afbbc7abec8d136a79dce53ec00807f79669885db -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 100.00%（24/24）**

Run: f8f2e4af-3086-4d26-80d3-1beb10160986 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:16:13.715Z / 2026-11-12T08:24:00.106Z |
| 总耗时 | 7 分 31 秒 |
| 答对 / 答错 / 解题超时 | 24 / 0 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 24 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 100.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 7 分 31 秒 |
| 环境准备耗时 | 4 分 4 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 4 秒 | 49 秒 | 2 分 5 秒 | 24 |
| 任务准备 | 0.55 毫秒 | 0.22 毫秒 | 1.3 毫秒 | 24 |
| 环境启动 | 38 秒 | 27 秒 | 45 秒 | 24 |
| 解题 | 17 秒 | 10 秒 | 1 分 31 秒 | 24 |
| 产物传输 | 2 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 6 秒 | 4 秒 | 8 秒 | 24 |
| 评分 | 0.81 毫秒 | 0.22 毫秒 | 2.48 毫秒 | 24 |
| 证据收集 | 15.21 毫秒 | 4.92 毫秒 | 29.36 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 0b559426-5ac2-4629-9e62-94bb842e540f | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 20,554 | 66,270 | 24 / 24 | — |
| 运行累计 | — | 20,554 | 66,270 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:8525 | completed | 1 | 17.14 | 0.00 | complete / not-produced | — | [result](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/bb10e235-cbe4-4b51-91da-bef846e02e0c/result.json) · [文件清单](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/bb10e235-cbe4-4b51-91da-bef846e02e0c/files.json) · [轨迹](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/bb10e235-cbe4-4b51-91da-bef846e02e0c/agent/trajectory.jsonl) |
| test:8604 | completed | 1 | 12.76 | 0.00 | complete / not-produced | — | [result](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/b825b8a4-5393-4b8a-b9f4-da9d6d993b1a/result.json) · [文件清单](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/b825b8a4-5393-4b8a-b9f4-da9d6d993b1a/files.json) · [轨迹](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/b825b8a4-5393-4b8a-b9f4-da9d6d993b1a/agent/trajectory.jsonl) |
| test:8740 | completed | 1 | 15.11 | 0.00 | complete / not-produced | — | [result](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/dd2afb67-0cd9-4f1f-9c6f-3fe08326b140/result.json) · [文件清单](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/dd2afb67-0cd9-4f1f-9c6f-3fe08326b140/files.json) · [轨迹](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/dd2afb67-0cd9-4f1f-9c6f-3fe08326b140/agent/trajectory.jsonl) |
| test:8839 | completed | 1 | 13.18 | 0.00 | complete / not-produced | — | [result](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/33f4aeae-f3a7-4d6d-a31b-e52306505a83/result.json) · [文件清单](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/33f4aeae-f3a7-4d6d-a31b-e52306505a83/files.json) · [轨迹](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/33f4aeae-f3a7-4d6d-a31b-e52306505a83/agent/trajectory.jsonl) |
| test:8939 | completed | 1 | 13.66 | 0.00 | complete / not-produced | — | [result](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/5b24a479-9fda-426f-a681-37356398eade/result.json) · [文件清单](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/5b24a479-9fda-426f-a681-37356398eade/files.json) · [轨迹](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/5b24a479-9fda-426f-a681-37356398eade/agent/trajectory.jsonl) |
| test:8967 | completed | 1 | 14.29 | 0.00 | complete / not-produced | — | [result](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/bdafa001-c008-4ae4-87ac-2ce7ee853244/result.json) · [文件清单](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/bdafa001-c008-4ae4-87ac-2ce7ee853244/files.json) · [轨迹](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/bdafa001-c008-4ae4-87ac-2ce7ee853244/agent/trajectory.jsonl) |
| test:8989 | completed | 1 | 15.23 | 0.00 | complete / not-produced | — | [result](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/86b56cf3-2d18-4b53-948e-7cca428e9355/result.json) · [文件清单](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/86b56cf3-2d18-4b53-948e-7cca428e9355/files.json) · [轨迹](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/86b56cf3-2d18-4b53-948e-7cca428e9355/agent/trajectory.jsonl) |
| test:9136 | completed | 1 | 16.26 | 0.00 | complete / not-produced | — | [result](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/57222fb6-9346-4271-9720-beff3ef4be7c/result.json) · [文件清单](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/57222fb6-9346-4271-9720-beff3ef4be7c/files.json) · [轨迹](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/57222fb6-9346-4271-9720-beff3ef4be7c/agent/trajectory.jsonl) |
| test:9222 | completed | 1 | 10.30 | 0.00 | complete / not-produced | — | [result](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/9ba215fd-a92e-41ef-9c6d-07a87cd8cfc1/result.json) · [文件清单](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/9ba215fd-a92e-41ef-9c6d-07a87cd8cfc1/files.json) · [轨迹](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/9ba215fd-a92e-41ef-9c6d-07a87cd8cfc1/agent/trajectory.jsonl) |
| test:9391 | completed | 1 | 11.53 | 0.00 | complete / not-produced | — | [result](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/8e84334c-9425-48a9-9247-b064ab72bd51/result.json) · [文件清单](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/8e84334c-9425-48a9-9247-b064ab72bd51/files.json) · [轨迹](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/8e84334c-9425-48a9-9247-b064ab72bd51/agent/trajectory.jsonl) |
| test:9395 | completed | 1 | 20.50 | 0.00 | complete / not-produced | — | [result](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b1deef13-4245-4726-b398-ba19c7bdd9dc/result.json) · [文件清单](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b1deef13-4245-4726-b398-ba19c7bdd9dc/files.json) · [轨迹](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b1deef13-4245-4726-b398-ba19c7bdd9dc/agent/trajectory.jsonl) |
| test:9405 | completed | 1 | 16.51 | 0.00 | complete / not-produced | — | [result](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/1a0d9c09-9fa8-4969-9cca-032394fe13e6/result.json) · [文件清单](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/1a0d9c09-9fa8-4969-9cca-032394fe13e6/files.json) · [轨迹](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/1a0d9c09-9fa8-4969-9cca-032394fe13e6/agent/trajectory.jsonl) |
| test:9769 | completed | 1 | 13.71 | 0.00 | complete / not-produced | — | [result](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/a9246df9-b4cb-4c78-a84c-48ed9458fe16/result.json) · [文件清单](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/a9246df9-b4cb-4c78-a84c-48ed9458fe16/files.json) · [轨迹](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/a9246df9-b4cb-4c78-a84c-48ed9458fe16/agent/trajectory.jsonl) |
| test:9843 | completed | 1 | 20.72 | 0.00 | complete / not-produced | — | [result](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/17ce65ac-0d12-41ac-a20d-823396376fe6/result.json) · [文件清单](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/17ce65ac-0d12-41ac-a20d-823396376fe6/files.json) · [轨迹](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/17ce65ac-0d12-41ac-a20d-823396376fe6/agent/trajectory.jsonl) |
| test:9864 | completed | 1 | 10.48 | 0.00 | complete / not-produced | — | [result](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/cd4df997-1801-4154-9710-5b75ad83eb77/result.json) · [文件清单](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/cd4df997-1801-4154-9710-5b75ad83eb77/files.json) · [轨迹](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/cd4df997-1801-4154-9710-5b75ad83eb77/agent/trajectory.jsonl) |
| test:9901 | completed | 1 | 11.13 | 0.00 | complete / not-produced | — | [result](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/674e8c04-77a3-4c86-b578-700a72432e1d/result.json) · [文件清单](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/674e8c04-77a3-4c86-b578-700a72432e1d/files.json) · [轨迹](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/674e8c04-77a3-4c86-b578-700a72432e1d/agent/trajectory.jsonl) |
| test:9931 | completed | 1 | 91.03 | 0.00 | complete / not-produced | — | [result](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/36b46c2c-3536-4b5c-b541-b11601d76f54/result.json) · [文件清单](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/36b46c2c-3536-4b5c-b541-b11601d76f54/files.json) · [轨迹](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/36b46c2c-3536-4b5c-b541-b11601d76f54/agent/trajectory.jsonl) |
| test:10127 | completed | 1 | 14.02 | 0.00 | complete / not-produced | — | [result](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/f7299ca0-b539-4cc5-8205-fcc5aa947ed9/result.json) · [文件清单](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/f7299ca0-b539-4cc5-8205-fcc5aa947ed9/files.json) · [轨迹](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/f7299ca0-b539-4cc5-8205-fcc5aa947ed9/agent/trajectory.jsonl) |
| test:10140 | completed | 1 | 11.87 | 0.00 | complete / not-produced | — | [result](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/790b816c-601f-4d28-a9ce-4819cea8033d/result.json) · [文件清单](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/790b816c-601f-4d28-a9ce-4819cea8033d/files.json) · [轨迹](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/790b816c-601f-4d28-a9ce-4819cea8033d/agent/trajectory.jsonl) |
| test:10174 | completed | 1 | 14.14 | 0.00 | complete / not-produced | — | [result](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/b8a56e72-d293-4c69-84cd-afe038345d50/result.json) · [文件清单](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/b8a56e72-d293-4c69-84cd-afe038345d50/files.json) · [轨迹](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/b8a56e72-d293-4c69-84cd-afe038345d50/agent/trajectory.jsonl) |
| test:10184 | completed | 1 | 13.03 | 0.00 | complete / not-produced | — | [result](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/8194fdf1-b428-481f-9d46-8a08a8936804/result.json) · [文件清单](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/8194fdf1-b428-481f-9d46-8a08a8936804/files.json) · [轨迹](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/8194fdf1-b428-481f-9d46-8a08a8936804/agent/trajectory.jsonl) |
| test:10189 | completed | 1 | 14.51 | 0.00 | complete / not-produced | — | [result](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/23b2b296-a872-46b2-9b67-5be2ce2d31ae/result.json) · [文件清单](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/23b2b296-a872-46b2-9b67-5be2ce2d31ae/files.json) · [轨迹](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/23b2b296-a872-46b2-9b67-5be2ce2d31ae/agent/trajectory.jsonl) |
| test:10294 | completed | 1 | 12.71 | 0.00 | complete / not-produced | — | [result](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/87f0dee7-5fa3-4408-865b-0ac6998eba18/result.json) · [文件清单](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/87f0dee7-5fa3-4408-865b-0ac6998eba18/files.json) · [轨迹](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/87f0dee7-5fa3-4408-865b-0ac6998eba18/agent/trajectory.jsonl) |
| test:10318 | completed | 1 | 14.31 | 0.00 | complete / not-produced | — | [result](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/e4c7e62a-53f8-4795-ae84-8a1dd5309034/result.json) · [文件清单](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/e4c7e62a-53f8-4795-ae84-8a1dd5309034/files.json) · [轨迹](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/e4c7e62a-53f8-4795-ae84-8a1dd5309034/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

