<!-- snapshotDigest: a762d5e7ee26775a26b0f2134528152cfc61f580960bae43335006d6cefa1c9d -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 66.67%（16/24）**

Run: d86dbad0-5845-4635-a095-17e529be2251 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:02:19.650Z / 2026-11-12T08:08:16.183Z |
| 总耗时 | 5 分 45 秒 |
| 答对 / 答错 / 解题超时 | 16 / 8 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 16 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 66.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 45 秒 |
| 环境准备耗时 | 2 分 49 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 53 秒 | 38 秒 | 1 分 16 秒 | 24 |
| 任务准备 | 0.54 毫秒 | 0.32 毫秒 | 1.19 毫秒 | 24 |
| 环境启动 | 31 秒 | 23 秒 | 45 秒 | 24 |
| 解题 | 15 秒 | 10 秒 | 25 秒 | 24 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 24 |
| 资源清理 | 5 秒 | 3 秒 | 7 秒 | 24 |
| 评分 | 1.27 毫秒 | 0.3 毫秒 | 10.21 毫秒 | 24 |
| 证据收集 | 11.89 毫秒 | 5.31 毫秒 | 29.58 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| c46093b2-04ef-4b4b-a225-a1971dfeedd4 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 13,223 | 51,974 | 24 / 24 | — |
| 运行累计 | — | 13,223 | 51,974 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:5361 | completed | 0 | 24.81 | 0.01 | complete / not-produced | — | [result](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/901457b3-cdde-42fe-adb8-ddd864786bd8/result.json) · [文件清单](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/901457b3-cdde-42fe-adb8-ddd864786bd8/files.json) · [轨迹](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/901457b3-cdde-42fe-adb8-ddd864786bd8/agent/trajectory.jsonl) |
| test:5457 | completed | 1 | 9.56 | 0.00 | complete / not-produced | — | [result](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/2a8fbdc7-0891-4e83-a220-731a0f330677/result.json) · [文件清单](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/2a8fbdc7-0891-4e83-a220-731a0f330677/files.json) · [轨迹](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/2a8fbdc7-0891-4e83-a220-731a0f330677/agent/trajectory.jsonl) |
| test:5461 | completed | 1 | 10.67 | 0.00 | complete / not-produced | — | [result](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/77d71f36-0f17-4cf7-bd8c-274d71f296d1/result.json) · [文件清单](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/77d71f36-0f17-4cf7-bd8c-274d71f296d1/files.json) · [轨迹](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/77d71f36-0f17-4cf7-bd8c-274d71f296d1/agent/trajectory.jsonl) |
| test:5530 | completed | 0 | 14.30 | 0.00 | complete / not-produced | — | [result](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/9b460bd9-dc32-48d0-832c-cc4185e6e650/result.json) · [文件清单](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/9b460bd9-dc32-48d0-832c-cc4185e6e650/files.json) · [轨迹](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/9b460bd9-dc32-48d0-832c-cc4185e6e650/agent/trajectory.jsonl) |
| test:5578 | completed | 1 | 9.68 | 0.00 | complete / not-produced | — | [result](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/06478b94-d86a-443c-b434-16b2079b1776/result.json) · [文件清单](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/06478b94-d86a-443c-b434-16b2079b1776/files.json) · [轨迹](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/06478b94-d86a-443c-b434-16b2079b1776/agent/trajectory.jsonl) |
| test:5580 | completed | 1 | 12.72 | 0.00 | complete / not-produced | — | [result](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/67693557-2b6e-4bd6-b82f-80aa192de52a/result.json) · [文件清单](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/67693557-2b6e-4bd6-b82f-80aa192de52a/files.json) · [轨迹](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/67693557-2b6e-4bd6-b82f-80aa192de52a/agent/trajectory.jsonl) |
| test:5795 | completed | 1 | 9.72 | 0.00 | complete / not-produced | — | [result](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/74573190-89f0-445f-9d46-55acdfb459ea/result.json) · [文件清单](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/74573190-89f0-445f-9d46-55acdfb459ea/files.json) · [轨迹](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/74573190-89f0-445f-9d46-55acdfb459ea/agent/trajectory.jsonl) |
| test:5919 | completed | 0 | 12.80 | 0.00 | complete / not-produced | — | [result](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/b96c9f87-ea19-49f0-aee0-cf6e62d151b1/result.json) · [文件清单](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/b96c9f87-ea19-49f0-aee0-cf6e62d151b1/files.json) · [轨迹](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/b96c9f87-ea19-49f0-aee0-cf6e62d151b1/agent/trajectory.jsonl) |
| test:5940 | completed | 1 | 12.05 | 0.00 | complete / not-produced | — | [result](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/2bb61727-432e-436c-8dba-b3ffd87fc70c/result.json) · [文件清单](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/2bb61727-432e-436c-8dba-b3ffd87fc70c/files.json) · [轨迹](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/2bb61727-432e-436c-8dba-b3ffd87fc70c/agent/trajectory.jsonl) |
| test:6055 | completed | 1 | 12.54 | 0.00 | complete / not-produced | — | [result](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/68a1ef79-3954-4dc2-9cc3-83bb228e0842/result.json) · [文件清单](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/68a1ef79-3954-4dc2-9cc3-83bb228e0842/files.json) · [轨迹](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/68a1ef79-3954-4dc2-9cc3-83bb228e0842/agent/trajectory.jsonl) |
| test:6095 | completed | 1 | 12.83 | 0.00 | complete / not-produced | — | [result](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/c0c678f3-ed50-41c4-903c-49a95d788fac/result.json) · [文件清单](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/c0c678f3-ed50-41c4-903c-49a95d788fac/files.json) · [轨迹](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/c0c678f3-ed50-41c4-903c-49a95d788fac/agent/trajectory.jsonl) |
| test:6120 | completed | 1 | 10.79 | 0.00 | complete / not-produced | — | [result](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/a547d9d5-e12a-486d-83d9-4a34e62c27bc/result.json) · [文件清单](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/a547d9d5-e12a-486d-83d9-4a34e62c27bc/files.json) · [轨迹](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/a547d9d5-e12a-486d-83d9-4a34e62c27bc/agent/trajectory.jsonl) |
| test:6123 | completed | 0 | 16.91 | 0.00 | complete / not-produced | — | [result](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/f31d0a74-4a8c-478a-8889-cc5731c081f0/result.json) · [文件清单](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/f31d0a74-4a8c-478a-8889-cc5731c081f0/files.json) · [轨迹](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/f31d0a74-4a8c-478a-8889-cc5731c081f0/agent/trajectory.jsonl) |
| test:6147 | completed | 0 | 22.81 | 0.00 | complete / not-produced | — | [result](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/10e4c439-f3d7-4582-b838-358ae740dc57/result.json) · [文件清单](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/10e4c439-f3d7-4582-b838-358ae740dc57/files.json) · [轨迹](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/10e4c439-f3d7-4582-b838-358ae740dc57/agent/trajectory.jsonl) |
| test:6198 | completed | 0 | 21.91 | 0.00 | complete / not-produced | — | [result](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/58963719-8aab-4ed7-8de9-1b00da2cc5e6/result.json) · [文件清单](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/58963719-8aab-4ed7-8de9-1b00da2cc5e6/files.json) · [轨迹](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/58963719-8aab-4ed7-8de9-1b00da2cc5e6/agent/trajectory.jsonl) |
| test:6223 | completed | 1 | 22.33 | 0.00 | complete / not-produced | — | [result](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/633548e8-f577-49f6-b964-29cd77a48eb5/result.json) · [文件清单](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/633548e8-f577-49f6-b964-29cd77a48eb5/files.json) · [轨迹](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/633548e8-f577-49f6-b964-29cd77a48eb5/agent/trajectory.jsonl) |
| test:6235 | completed | 1 | 13.80 | 0.00 | complete / not-produced | — | [result](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/9b6ebaa9-7c0f-4443-92d8-9393e9159f15/result.json) · [文件清单](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/9b6ebaa9-7c0f-4443-92d8-9393e9159f15/files.json) · [轨迹](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/9b6ebaa9-7c0f-4443-92d8-9393e9159f15/agent/trajectory.jsonl) |
| test:6403 | completed | 1 | 18.47 | 0.00 | complete / not-produced | — | [result](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/63e0eb17-0b9f-45f6-a98f-fdc8f55eb045/result.json) · [文件清单](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/63e0eb17-0b9f-45f6-a98f-fdc8f55eb045/files.json) · [轨迹](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/63e0eb17-0b9f-45f6-a98f-fdc8f55eb045/agent/trajectory.jsonl) |
| test:6436 | completed | 1 | 12.43 | 0.00 | complete / not-produced | — | [result](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/b09b60f4-9f84-45b2-9bd0-b166e4ecdd58/result.json) · [文件清单](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/b09b60f4-9f84-45b2-9bd0-b166e4ecdd58/files.json) · [轨迹](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/b09b60f4-9f84-45b2-9bd0-b166e4ecdd58/agent/trajectory.jsonl) |
| test:6508 | completed | 1 | 12.12 | 0.00 | complete / not-produced | — | [result](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/f2e08e31-61ba-4997-8d60-c706618baa78/result.json) · [文件清单](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/f2e08e31-61ba-4997-8d60-c706618baa78/files.json) · [轨迹](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/f2e08e31-61ba-4997-8d60-c706618baa78/agent/trajectory.jsonl) |
| test:6593 | completed | 1 | 13.79 | 0.00 | complete / not-produced | — | [result](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/5a300682-6ef3-433e-98b3-f41ce2a64218/result.json) · [文件清单](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/5a300682-6ef3-433e-98b3-f41ce2a64218/files.json) · [轨迹](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/5a300682-6ef3-433e-98b3-f41ce2a64218/agent/trajectory.jsonl) |
| test:6655 | completed | 0 | 20.41 | 0.01 | complete / not-produced | — | [result](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/c067e3be-277e-47a7-bf90-8d50c0e67b36/result.json) · [文件清单](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/c067e3be-277e-47a7-bf90-8d50c0e67b36/files.json) · [轨迹](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/c067e3be-277e-47a7-bf90-8d50c0e67b36/agent/trajectory.jsonl) |
| test:6738 | completed | 0 | 20.61 | 0.00 | complete / not-produced | — | [result](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/0cf9eed7-6c89-4205-8f96-8ef898498ea3/result.json) · [文件清单](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/0cf9eed7-6c89-4205-8f96-8ef898498ea3/files.json) · [轨迹](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/0cf9eed7-6c89-4205-8f96-8ef898498ea3/agent/trajectory.jsonl) |
| test:6751 | completed | 1 | 10.95 | 0.00 | complete / not-produced | — | [result](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/7ab2a6da-46d4-45d8-bd77-1728c52025fb/result.json) · [文件清单](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/7ab2a6da-46d4-45d8-bd77-1728c52025fb/files.json) · [轨迹](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/7ab2a6da-46d4-45d8-bd77-1728c52025fb/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

