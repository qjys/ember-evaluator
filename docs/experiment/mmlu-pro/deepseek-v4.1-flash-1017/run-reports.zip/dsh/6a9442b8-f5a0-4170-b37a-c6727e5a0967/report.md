<!-- snapshotDigest: 41460d15d30f8f80b81424a3e9b237d61b4b944b1db90bfcf647f66b499b60a2 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 91.67%（22/24）**

Run: 6a9442b8-f5a0-4170-b37a-c6727e5a0967 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:56:48.372Z / 2026-11-12T08:02:14.108Z |
| 总耗时 | 5 分 15 秒 |
| 答对 / 答错 / 解题超时 | 22 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 22 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 91.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 15 秒 |
| 环境准备耗时 | 3 分 25 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 49 秒 | 34 秒 | 1 分 18 秒 | 24 |
| 任务准备 | 0.73 毫秒 | 0.26 毫秒 | 3.67 毫秒 | 24 |
| 环境启动 | 30 秒 | 17 秒 | 47 秒 | 24 |
| 解题 | 13 秒 | 8 秒 | 27 秒 | 24 |
| 产物传输 | 2 秒 | 836.11 毫秒 | 2 秒 | 24 |
| 资源清理 | 4 秒 | 2 秒 | 6 秒 | 24 |
| 评分 | 0.88 毫秒 | 0.27 毫秒 | 3.83 毫秒 | 24 |
| 证据收集 | 22.57 毫秒 | 5.28 毫秒 | 80.33 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 01d73c4e-014f-406d-8fa3-99012b69a86e | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 12,026 | 66,006 | 24 / 24 | — |
| 运行累计 | — | 12,026 | 66,006 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4376 | completed | 1 | 11.57 | 0.00 | complete / not-produced | — | [result](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/3644129d-1ba7-4c3a-94b7-521f9c33b2d1/result.json) · [文件清单](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/3644129d-1ba7-4c3a-94b7-521f9c33b2d1/files.json) · [轨迹](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/3644129d-1ba7-4c3a-94b7-521f9c33b2d1/agent/trajectory.jsonl) |
| test:4552 | completed | 1 | 25.60 | 0.00 | complete / not-produced | — | [result](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/ab966d7d-6d90-44c5-9e5d-9793d98ff01a/result.json) · [文件清单](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/ab966d7d-6d90-44c5-9e5d-9793d98ff01a/files.json) · [轨迹](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/ab966d7d-6d90-44c5-9e5d-9793d98ff01a/agent/trajectory.jsonl) |
| test:4560 | completed | 1 | 15.21 | 0.00 | complete / not-produced | — | [result](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/5591ac65-6722-4406-94cb-38ccab24d80f/result.json) · [文件清单](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/5591ac65-6722-4406-94cb-38ccab24d80f/files.json) · [轨迹](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/5591ac65-6722-4406-94cb-38ccab24d80f/agent/trajectory.jsonl) |
| test:4568 | completed | 1 | 10.58 | 0.00 | complete / not-produced | — | [result](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/597a5b8b-e463-4067-8b06-e4536ff76ba4/result.json) · [文件清单](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/597a5b8b-e463-4067-8b06-e4536ff76ba4/files.json) · [轨迹](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/597a5b8b-e463-4067-8b06-e4536ff76ba4/agent/trajectory.jsonl) |
| test:4580 | completed | 1 | 27.05 | 0.00 | complete / not-produced | — | [result](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/3c93b15c-915e-42be-85ca-2cddefe7a4db/result.json) · [文件清单](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/3c93b15c-915e-42be-85ca-2cddefe7a4db/files.json) · [轨迹](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/3c93b15c-915e-42be-85ca-2cddefe7a4db/agent/trajectory.jsonl) |
| test:4603 | completed | 1 | 13.78 | 0.00 | complete / not-produced | — | [result](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/6fbedb4e-59a7-4e45-8e3b-05156789dba5/result.json) · [文件清单](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/6fbedb4e-59a7-4e45-8e3b-05156789dba5/files.json) · [轨迹](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/6fbedb4e-59a7-4e45-8e3b-05156789dba5/agent/trajectory.jsonl) |
| test:4625 | completed | 1 | 12.13 | 0.00 | complete / not-produced | — | [result](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/0c680d10-0fc0-4a11-8942-bc20b2faf023/result.json) · [文件清单](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/0c680d10-0fc0-4a11-8942-bc20b2faf023/files.json) · [轨迹](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/0c680d10-0fc0-4a11-8942-bc20b2faf023/agent/trajectory.jsonl) |
| test:4627 | completed | 1 | 9.68 | 0.00 | complete / not-produced | — | [result](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/fff2e6f8-fd76-4859-ad08-5ebc8a0ddcee/result.json) · [文件清单](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/fff2e6f8-fd76-4859-ad08-5ebc8a0ddcee/files.json) · [轨迹](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/fff2e6f8-fd76-4859-ad08-5ebc8a0ddcee/agent/trajectory.jsonl) |
| test:4651 | completed | 1 | 9.66 | 0.00 | complete / not-produced | — | [result](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/cb832aed-29c0-42c5-a0a6-72616b3672f6/result.json) · [文件清单](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/cb832aed-29c0-42c5-a0a6-72616b3672f6/files.json) · [轨迹](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/cb832aed-29c0-42c5-a0a6-72616b3672f6/agent/trajectory.jsonl) |
| test:4670 | completed | 1 | 15.04 | 0.00 | complete / not-produced | — | [result](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/09d55c76-f5e7-4e7c-b156-6ff74c3a4da3/result.json) · [文件清单](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/09d55c76-f5e7-4e7c-b156-6ff74c3a4da3/files.json) · [轨迹](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/09d55c76-f5e7-4e7c-b156-6ff74c3a4da3/agent/trajectory.jsonl) |
| test:4700 | completed | 1 | 9.94 | 0.00 | complete / not-produced | — | [result](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/e153b221-6b28-4b3c-bd30-62c23ebb20db/result.json) · [文件清单](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/e153b221-6b28-4b3c-bd30-62c23ebb20db/files.json) · [轨迹](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/e153b221-6b28-4b3c-bd30-62c23ebb20db/agent/trajectory.jsonl) |
| test:4709 | completed | 0 | 16.94 | 0.00 | complete / not-produced | — | [result](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/ab63f96c-cdc7-4767-bb54-cfbe3d5e7a97/result.json) · [文件清单](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/ab63f96c-cdc7-4767-bb54-cfbe3d5e7a97/files.json) · [轨迹](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/ab63f96c-cdc7-4767-bb54-cfbe3d5e7a97/agent/trajectory.jsonl) |
| test:4763 | completed | 1 | 23.28 | 0.00 | complete / not-produced | — | [result](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/f3abb0c2-1629-49ef-985e-d187bb6661b6/result.json) · [文件清单](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/f3abb0c2-1629-49ef-985e-d187bb6661b6/files.json) · [轨迹](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/f3abb0c2-1629-49ef-985e-d187bb6661b6/agent/trajectory.jsonl) |
| test:4770 | completed | 1 | 8.17 | 0.00 | complete / not-produced | — | [result](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/db1b7407-f66d-40a4-b678-082e54471ad1/result.json) · [文件清单](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/db1b7407-f66d-40a4-b678-082e54471ad1/files.json) · [轨迹](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/db1b7407-f66d-40a4-b678-082e54471ad1/agent/trajectory.jsonl) |
| test:4786 | completed | 1 | 12.77 | 0.00 | complete / not-produced | — | [result](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/947495ac-33e2-470c-ae12-5cabb3386726/result.json) · [文件清单](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/947495ac-33e2-470c-ae12-5cabb3386726/files.json) · [轨迹](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/947495ac-33e2-470c-ae12-5cabb3386726/agent/trajectory.jsonl) |
| test:4879 | completed | 1 | 12.04 | 0.00 | complete / not-produced | — | [result](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/d8a0914d-3fe8-4579-97cf-c630aa29086b/result.json) · [文件清单](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/d8a0914d-3fe8-4579-97cf-c630aa29086b/files.json) · [轨迹](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/d8a0914d-3fe8-4579-97cf-c630aa29086b/agent/trajectory.jsonl) |
| test:5078 | completed | 1 | 22.68 | 0.00 | complete / not-produced | — | [result](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/ee49d702-1ee0-4877-9654-2514b06a3ae2/result.json) · [文件清单](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/ee49d702-1ee0-4877-9654-2514b06a3ae2/files.json) · [轨迹](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/ee49d702-1ee0-4877-9654-2514b06a3ae2/agent/trajectory.jsonl) |
| test:5123 | completed | 1 | 9.72 | 0.00 | complete / not-produced | — | [result](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/0f789da2-dde2-46c2-ad1f-cc302bcb5264/result.json) · [文件清单](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/0f789da2-dde2-46c2-ad1f-cc302bcb5264/files.json) · [轨迹](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/0f789da2-dde2-46c2-ad1f-cc302bcb5264/agent/trajectory.jsonl) |
| test:5174 | completed | 1 | 8.58 | 0.00 | complete / not-produced | — | [result](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/1cd11325-aa5b-49ea-8422-81254c7cab1b/result.json) · [文件清单](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/1cd11325-aa5b-49ea-8422-81254c7cab1b/files.json) · [轨迹](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/1cd11325-aa5b-49ea-8422-81254c7cab1b/agent/trajectory.jsonl) |
| test:5198 | completed | 1 | 8.33 | 0.00 | complete / not-produced | — | [result](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/2d1b93cf-7af1-4ed2-bb3a-d36306a06290/result.json) · [文件清单](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/2d1b93cf-7af1-4ed2-bb3a-d36306a06290/files.json) · [轨迹](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/2d1b93cf-7af1-4ed2-bb3a-d36306a06290/agent/trajectory.jsonl) |
| test:5243 | completed | 1 | 8.24 | 0.00 | complete / not-produced | — | [result](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/2df47142-8ae6-4a12-abd5-aff836107140/result.json) · [文件清单](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/2df47142-8ae6-4a12-abd5-aff836107140/files.json) · [轨迹](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/2df47142-8ae6-4a12-abd5-aff836107140/agent/trajectory.jsonl) |
| test:5309 | completed | 1 | 9.12 | 0.00 | complete / not-produced | — | [result](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/2ef4faa3-4e73-4d8e-ac79-e7f6c531f588/result.json) · [文件清单](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/2ef4faa3-4e73-4d8e-ac79-e7f6c531f588/files.json) · [轨迹](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/2ef4faa3-4e73-4d8e-ac79-e7f6c531f588/agent/trajectory.jsonl) |
| test:5319 | completed | 1 | 13.04 | 0.00 | complete / not-produced | — | [result](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/44090eba-48ca-4de1-82d2-783b22073615/result.json) · [文件清单](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/44090eba-48ca-4de1-82d2-783b22073615/files.json) · [轨迹](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/44090eba-48ca-4de1-82d2-783b22073615/agent/trajectory.jsonl) |
| test:5328 | completed | 0 | 8.87 | 0.00 | complete / not-produced | — | [result](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/b9f19543-ad4b-4737-b9a0-12d8f2a4106c/result.json) · [文件清单](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/b9f19543-ad4b-4737-b9a0-12d8f2a4106c/files.json) · [轨迹](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/b9f19543-ad4b-4737-b9a0-12d8f2a4106c/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

