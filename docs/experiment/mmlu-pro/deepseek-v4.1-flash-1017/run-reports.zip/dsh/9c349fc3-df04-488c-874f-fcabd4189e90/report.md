<!-- snapshotDigest: 258dd75a931182baca081fbe730c8dd7aae7c061b1109335f2f92d9b3e7ab1ac -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 68.75%（11/16）**

Run: 9c349fc3-df04-488c-874f-fcabd4189e90 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:33:12.901Z / 2026-11-12T08:40:39.708Z |
| 总耗时 | 7 分 12 秒 |
| 答对 / 答错 / 解题超时 | 11 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 16 题；已保存 16 条记录；待运行 0 题。
有效评分覆盖率：16/16（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 16 |
| 计分题数 | 16 |
| 正常评分题数 | 16 |
| 答对题数 | 11 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 68.75% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 7 分 12 秒 |
| 环境准备耗时 | 2 分 11 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 34 秒 | 1 分 7 秒 | 3 分 38 秒 | 16 |
| 任务准备 | 0.6 毫秒 | 0.31 毫秒 | 3.31 毫秒 | 16 |
| 环境启动 | 45 秒 | 38 秒 | 50 秒 | 16 |
| 解题 | 37 秒 | 13 秒 | 2 分 42 秒 | 16 |
| 产物传输 | 4 秒 | 2 秒 | 5 秒 | 16 |
| 资源清理 | 9 秒 | 6 秒 | 13 秒 | 16 |
| 评分 | 1.35 毫秒 | 0.29 毫秒 | 12.29 毫秒 | 16 |
| 证据收集 | 19.25 毫秒 | 8.87 毫秒 | 39.97 毫秒 | 16 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 079a0742-7666-4afe-be65-9a69f45e0aed | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 54,286 | 82,364 | 16 / 16 | — |
| 运行累计 | — | 54,286 | 82,364 | 16 / 16 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:11060 | completed | 1 | 15.13 | 0.00 | complete / not-produced | — | [result](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/971912d1-dfff-410f-8bc1-b2625267f75f/result.json) · [文件清单](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/971912d1-dfff-410f-8bc1-b2625267f75f/files.json) · [轨迹](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/971912d1-dfff-410f-8bc1-b2625267f75f/agent/trajectory.jsonl) |
| test:11093 | completed | 1 | 161.88 | 0.00 | complete / not-produced | — | [result](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/77d50889-b46b-447b-a5fd-25e7fcfaf2e9/result.json) · [文件清单](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/77d50889-b46b-447b-a5fd-25e7fcfaf2e9/files.json) · [轨迹](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/77d50889-b46b-447b-a5fd-25e7fcfaf2e9/agent/trajectory.jsonl) |
| test:11210 | completed | 1 | 16.00 | 0.00 | complete / not-produced | — | [result](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/255ca0f4-ef9f-42d9-bb45-a0316414f15b/result.json) · [文件清单](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/255ca0f4-ef9f-42d9-bb45-a0316414f15b/files.json) · [轨迹](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/255ca0f4-ef9f-42d9-bb45-a0316414f15b/agent/trajectory.jsonl) |
| test:11354 | completed | 0 | 14.10 | 0.00 | complete / not-produced | — | [result](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/c3a28423-5473-4daa-a633-be96213ae933/result.json) · [文件清单](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/c3a28423-5473-4daa-a633-be96213ae933/files.json) · [轨迹](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/c3a28423-5473-4daa-a633-be96213ae933/agent/trajectory.jsonl) |
| test:11491 | completed | 0 | 48.50 | 0.00 | complete / not-produced | — | [result](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/50ca0390-9d62-4d0c-b7d9-cc63a0aeff19/result.json) · [文件清单](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/50ca0390-9d62-4d0c-b7d9-cc63a0aeff19/files.json) · [轨迹](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/50ca0390-9d62-4d0c-b7d9-cc63a0aeff19/agent/trajectory.jsonl) |
| test:11496 | completed | 1 | 54.94 | 0.00 | complete / not-produced | — | [result](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/08e4c998-0f68-4a02-a6f5-1a2d354928fb/result.json) · [文件清单](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/08e4c998-0f68-4a02-a6f5-1a2d354928fb/files.json) · [轨迹](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/08e4c998-0f68-4a02-a6f5-1a2d354928fb/agent/trajectory.jsonl) |
| test:11506 | completed | 0 | 30.23 | 0.01 | complete / not-produced | — | [result](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/632ef380-c461-4d3f-9b16-71e12ea5efe5/result.json) · [文件清单](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/632ef380-c461-4d3f-9b16-71e12ea5efe5/files.json) · [轨迹](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/632ef380-c461-4d3f-9b16-71e12ea5efe5/agent/trajectory.jsonl) |
| test:11559 | completed | 1 | 13.05 | 0.00 | complete / not-produced | — | [result](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/e5d2812a-efdd-44ee-a77f-0964cf824300/result.json) · [文件清单](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/e5d2812a-efdd-44ee-a77f-0964cf824300/files.json) · [轨迹](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/e5d2812a-efdd-44ee-a77f-0964cf824300/agent/trajectory.jsonl) |
| test:11576 | completed | 0 | 29.26 | 0.00 | complete / not-produced | — | [result](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/22b88f6b-0061-40db-b1e7-8675e1f64d0f/result.json) · [文件清单](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/22b88f6b-0061-40db-b1e7-8675e1f64d0f/files.json) · [轨迹](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/22b88f6b-0061-40db-b1e7-8675e1f64d0f/agent/trajectory.jsonl) |
| test:11629 | completed | 0 | 41.43 | 0.00 | complete / not-produced | — | [result](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/8f6b077b-8486-4f25-b011-cb581fd69a21/result.json) · [文件清单](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/8f6b077b-8486-4f25-b011-cb581fd69a21/files.json) · [轨迹](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/8f6b077b-8486-4f25-b011-cb581fd69a21/agent/trajectory.jsonl) |
| test:11660 | completed | 1 | 63.69 | 0.00 | complete / not-produced | — | [result](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/efc03866-3709-4f86-8bf4-ffa449cc9c89/result.json) · [文件清单](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/efc03866-3709-4f86-8bf4-ffa449cc9c89/files.json) · [轨迹](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/efc03866-3709-4f86-8bf4-ffa449cc9c89/agent/trajectory.jsonl) |
| test:11802 | completed | 1 | 14.36 | 0.00 | complete / not-produced | — | [result](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/70b93dbc-39e4-43f8-97ea-d5ae3db430cd/result.json) · [文件清单](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/70b93dbc-39e4-43f8-97ea-d5ae3db430cd/files.json) · [轨迹](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/70b93dbc-39e4-43f8-97ea-d5ae3db430cd/agent/trajectory.jsonl) |
| test:11808 | completed | 1 | 17.57 | 0.00 | complete / not-produced | — | [result](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/447a8b29-0f2a-4a48-b7fb-08fce52f9eab/result.json) · [文件清单](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/447a8b29-0f2a-4a48-b7fb-08fce52f9eab/files.json) · [轨迹](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/447a8b29-0f2a-4a48-b7fb-08fce52f9eab/agent/trajectory.jsonl) |
| test:11824 | completed | 1 | 14.19 | 0.00 | complete / not-produced | — | [result](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/65c4646d-2418-45ad-9c0a-338e0ebc3f07/result.json) · [文件清单](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/65c4646d-2418-45ad-9c0a-338e0ebc3f07/files.json) · [轨迹](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/65c4646d-2418-45ad-9c0a-338e0ebc3f07/agent/trajectory.jsonl) |
| test:11925 | completed | 1 | 40.35 | 0.00 | complete / not-produced | — | [result](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/a009038c-f534-4e91-96dc-0029cc9372c6/result.json) · [文件清单](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/a009038c-f534-4e91-96dc-0029cc9372c6/files.json) · [轨迹](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/a009038c-f534-4e91-96dc-0029cc9372c6/agent/trajectory.jsonl) |
| test:12002 | completed | 1 | 22.19 | 0.00 | complete / not-produced | — | [result](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/c1abb040-2946-434d-8c49-b24eb72e8b48/result.json) · [文件清单](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/c1abb040-2946-434d-8c49-b24eb72e8b48/files.json) · [轨迹](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/c1abb040-2946-434d-8c49-b24eb72e8b48/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

