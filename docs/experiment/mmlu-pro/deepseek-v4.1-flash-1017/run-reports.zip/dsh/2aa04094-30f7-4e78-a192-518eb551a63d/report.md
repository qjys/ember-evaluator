<!-- snapshotDigest: 4c42816f00c14c8ecebff0524273c272485eff361179c95d7319068a32a28d14 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 22.40%（41/183）**

Run: 2aa04094-30f7-4e78-a192-518eb551a63d · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:25:04.848Z / 2026-11-12T07:52:11.146Z |
| 总耗时 | 26 分 13 秒 |
| 答对 / 答错 / 解题超时 | 41 / 8 / 0 |
| 清理未确认 | 1 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 185 题；已保存 51 条记录；待运行 135 题。
有效评分覆盖率：49/185（26.49%）。
执行失败 1；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 2。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 185 |
| 计分题数 | 183 |
| 正常评分题数 | 49 |
| 答对题数 | 41 |
| 无效评测 | 2 |
| 待运行 | 135 |
| 正确率 | 22.40% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 26 分 13 秒 |
| 环境准备耗时 | 27 分 1 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 0 秒 | 15 秒 | 4 分 27 秒 | 51 |
| 任务准备 | 0.52 毫秒 | 0.29 毫秒 | 3.04 毫秒 | 51 |
| 环境启动 | 30 秒 | 8 秒 | 1 分 4 秒 | 51 |
| 解题 | 24 秒 | 6 秒 | 4 分 0 秒 | 50 |
| 产物传输 | 1 秒 | 786.56 毫秒 | 4 秒 | 50 |
| 资源清理 | 5 秒 | 3 秒 | 14 秒 | 50 |
| 评分 | 1.48 毫秒 | 0.38 毫秒 | 3.29 毫秒 | 49 |
| 证据收集 | 33.53 毫秒 | 1.12 毫秒 | 436.44 毫秒 | 51 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 2923cf2e-415e-45cf-ae83-69eb39d388fc | 未设置 | 600 | 2 | 2 | 1200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 68,614 | 160,746 | 49 / 185 | — |
| 运行累计 | — | 68,614 | 160,746 | 49 / 51 | 2 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:1454 | completed | 0 | 109.81 | 0.00 | complete / not-produced | — | [result](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/28a6f0af-ff9a-4aeb-a49a-cda2ab9167c8/result.json) · [文件清单](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/28a6f0af-ff9a-4aeb-a49a-cda2ab9167c8/files.json) · [轨迹](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/28a6f0af-ff9a-4aeb-a49a-cda2ab9167c8/agent/trajectory.jsonl) |
| test:1514 | completed | 0 | 108.62 | 0.00 | complete / not-produced | — | [result](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/5afac10e-6468-4fa3-aab2-caa10cfa0015/result.json) · [文件清单](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/5afac10e-6468-4fa3-aab2-caa10cfa0015/files.json) · [轨迹](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/5afac10e-6468-4fa3-aab2-caa10cfa0015/agent/trajectory.jsonl) |
| test:1531 | completed | 0 | 61.63 | 0.00 | complete / not-produced | — | [result](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/53b22e3f-8d8a-4bf9-93d5-1d841cc17183/result.json) · [文件清单](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/53b22e3f-8d8a-4bf9-93d5-1d841cc17183/files.json) · [轨迹](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/53b22e3f-8d8a-4bf9-93d5-1d841cc17183/agent/trajectory.jsonl) |
| test:1785 | completed | 0 | 142.78 | 0.00 | complete / not-produced | — | [result](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/83c0fcd1-c540-4a9c-b659-ce19b8332026/result.json) · [文件清单](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/83c0fcd1-c540-4a9c-b659-ce19b8332026/files.json) · [轨迹](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/83c0fcd1-c540-4a9c-b659-ce19b8332026/agent/trajectory.jsonl) |
| test:1827 | completed | 1 | 9.77 | 0.00 | complete / not-produced | — | [result](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/45864b84-487c-4b11-83f8-ee9a73506c0d/result.json) · [文件清单](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/45864b84-487c-4b11-83f8-ee9a73506c0d/files.json) · [轨迹](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/45864b84-487c-4b11-83f8-ee9a73506c0d/agent/trajectory.jsonl) |
| test:1904 | completed | 1 | 7.88 | 0.00 | complete / not-produced | — | [result](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/0efe82a3-9f72-413d-9ea3-5925adfa3a58/result.json) · [文件清单](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/0efe82a3-9f72-413d-9ea3-5925adfa3a58/files.json) · [轨迹](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/0efe82a3-9f72-413d-9ea3-5925adfa3a58/agent/trajectory.jsonl) |
| test:1943 | completed | 1 | 27.17 | 0.00 | complete / not-produced | — | [result](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/561b6e4e-a968-4186-a49c-f913bd59649f/result.json) · [文件清单](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/561b6e4e-a968-4186-a49c-f913bd59649f/files.json) · [轨迹](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/561b6e4e-a968-4186-a49c-f913bd59649f/agent/trajectory.jsonl) |
| test:1998 | completed | 1 | 8.45 | 0.00 | complete / not-produced | — | [result](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/44bfde3f-8426-452a-9057-73aecbd68a13/result.json) · [文件清单](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/44bfde3f-8426-452a-9057-73aecbd68a13/files.json) · [轨迹](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/44bfde3f-8426-452a-9057-73aecbd68a13/agent/trajectory.jsonl) |
| test:2023 | completed | 1 | 12.10 | 0.00 | complete / not-produced | — | [result](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/986bbe84-1673-4194-83b7-e1f4324ad4a8/result.json) · [文件清单](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/986bbe84-1673-4194-83b7-e1f4324ad4a8/files.json) · [轨迹](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/986bbe84-1673-4194-83b7-e1f4324ad4a8/agent/trajectory.jsonl) |
| test:2096 | completed | 0 | 13.02 | 0.00 | complete / not-produced | — | [result](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/9b801fe4-4a77-4274-8ae9-cd5d19d28a9e/result.json) · [文件清单](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/9b801fe4-4a77-4274-8ae9-cd5d19d28a9e/files.json) · [轨迹](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/9b801fe4-4a77-4274-8ae9-cd5d19d28a9e/agent/trajectory.jsonl) |
| test:2152 | completed | 1 | 8.48 | 0.00 | complete / not-produced | — | [result](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/4c944ba6-13fa-4113-9f37-6f44b5f23010/result.json) · [文件清单](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/4c944ba6-13fa-4113-9f37-6f44b5f23010/files.json) · [轨迹](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/4c944ba6-13fa-4113-9f37-6f44b5f23010/agent/trajectory.jsonl) |
| test:2175 | completed | 1 | 10.63 | 0.00 | complete / not-produced | — | [result](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/4bea59ef-a330-4299-bb2b-e17b9803b328/result.json) · [文件清单](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/4bea59ef-a330-4299-bb2b-e17b9803b328/files.json) · [轨迹](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/4bea59ef-a330-4299-bb2b-e17b9803b328/agent/trajectory.jsonl) |
| test:2177 | completed | 1 | 10.00 | 0.00 | complete / not-produced | — | [result](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/492cb6dd-8977-4f16-ace3-c30a59e58da6/result.json) · [文件清单](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/492cb6dd-8977-4f16-ace3-c30a59e58da6/files.json) · [轨迹](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/492cb6dd-8977-4f16-ace3-c30a59e58da6/agent/trajectory.jsonl) |
| test:2206 | completed | 1 | 7.81 | 0.00 | complete / not-produced | — | [result](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/78c4fa89-b102-4920-8b56-2a4ee9d405be/result.json) · [文件清单](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/78c4fa89-b102-4920-8b56-2a4ee9d405be/files.json) · [轨迹](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/78c4fa89-b102-4920-8b56-2a4ee9d405be/agent/trajectory.jsonl) |
| test:2280 | completed | 1 | 7.49 | 0.00 | complete / not-produced | — | [result](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/d30370f4-e354-4bcb-be37-88c102d3835e/result.json) · [文件清单](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/d30370f4-e354-4bcb-be37-88c102d3835e/files.json) · [轨迹](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/d30370f4-e354-4bcb-be37-88c102d3835e/agent/trajectory.jsonl) |
| test:2347 | completed | 1 | 19.83 | 0.00 | complete / not-produced | — | [result](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/e2ae9599-d109-43fc-ae95-1a4db03d4216/result.json) · [文件清单](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/e2ae9599-d109-43fc-ae95-1a4db03d4216/files.json) · [轨迹](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/e2ae9599-d109-43fc-ae95-1a4db03d4216/agent/trajectory.jsonl) |
| test:2400 | completed | 1 | 8.95 | 0.00 | complete / not-produced | — | [result](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/69d8e9da-c18e-47bc-b303-f8559c0b2ce1/result.json) · [文件清单](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/69d8e9da-c18e-47bc-b303-f8559c0b2ce1/files.json) · [轨迹](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/69d8e9da-c18e-47bc-b303-f8559c0b2ce1/agent/trajectory.jsonl) |
| test:2527 | completed | 1 | 8.96 | 0.00 | complete / not-produced | — | [result](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/126b13f6-844a-4e2d-9a4c-5218cc50e2f2/result.json) · [文件清单](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/126b13f6-844a-4e2d-9a4c-5218cc50e2f2/files.json) · [轨迹](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/126b13f6-844a-4e2d-9a4c-5218cc50e2f2/agent/trajectory.jsonl) |
| test:2636 | completed | 1 | 10.10 | 0.00 | complete / not-produced | — | [result](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/81e025cc-ca35-415f-a2e5-ed564e0a23c2/result.json) · [文件清单](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/81e025cc-ca35-415f-a2e5-ed564e0a23c2/files.json) · [轨迹](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/81e025cc-ca35-415f-a2e5-ed564e0a23c2/agent/trajectory.jsonl) |
| test:2641 | completed | 1 | 10.75 | 0.00 | complete / not-produced | — | [result](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/d437c84e-84ee-48cf-a670-708a3219bd73/result.json) · [文件清单](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/d437c84e-84ee-48cf-a670-708a3219bd73/files.json) · [轨迹](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/d437c84e-84ee-48cf-a670-708a3219bd73/agent/trajectory.jsonl) |
| test:2714 | completed | 1 | 10.39 | 0.00 | complete / not-produced | — | [result](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/87433acc-8747-4535-8629-0d14e742b622/result.json) · [文件清单](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/87433acc-8747-4535-8629-0d14e742b622/files.json) · [轨迹](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/87433acc-8747-4535-8629-0d14e742b622/agent/trajectory.jsonl) |
| test:2716 | completed | 1 | 44.98 | 0.00 | complete / not-produced | — | [result](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/4c19e13f-b60f-42a0-bcf9-09e2fd725725/result.json) · [文件清单](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/4c19e13f-b60f-42a0-bcf9-09e2fd725725/files.json) · [轨迹](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/4c19e13f-b60f-42a0-bcf9-09e2fd725725/agent/trajectory.jsonl) |
| test:2747 | completed | 1 | 8.92 | 0.00 | complete / not-produced | — | [result](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/6570af5c-9519-471c-9ba2-9d1bc72ee733/result.json) · [文件清单](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/6570af5c-9519-471c-9ba2-9d1bc72ee733/files.json) · [轨迹](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/6570af5c-9519-471c-9ba2-9d1bc72ee733/agent/trajectory.jsonl) |
| test:2882 | completed | 0 | 9.70 | 0.00 | complete / not-produced | — | [result](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/b07d9a60-8e1e-4c46-87bc-732b6dd3fbb7/result.json) · [文件清单](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/b07d9a60-8e1e-4c46-87bc-732b6dd3fbb7/files.json) · [轨迹](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/b07d9a60-8e1e-4c46-87bc-732b6dd3fbb7/agent/trajectory.jsonl) |
| test:2951 | completed | 1 | 7.96 | 0.00 | complete / not-produced | — | [result](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/085a93bc-352d-4c9b-9331-5bf955f4106d/result.json) · [文件清单](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/085a93bc-352d-4c9b-9331-5bf955f4106d/files.json) · [轨迹](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/085a93bc-352d-4c9b-9331-5bf955f4106d/agent/trajectory.jsonl) |
| test:3037 | completed | 1 | 8.18 | 0.00 | complete / not-produced | — | [result](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/df65415a-912c-4477-a64d-4539b3f6174d/result.json) · [文件清单](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/df65415a-912c-4477-a64d-4539b3f6174d/files.json) · [轨迹](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/df65415a-912c-4477-a64d-4539b3f6174d/agent/trajectory.jsonl) |
| test:3053 | completed | 0 | 33.16 | 0.00 | complete / not-produced | — | [result](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/30bfd9c8-834d-4ac5-8139-d7914d198df4/result.json) · [文件清单](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/30bfd9c8-834d-4ac5-8139-d7914d198df4/files.json) · [轨迹](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/30bfd9c8-834d-4ac5-8139-d7914d198df4/agent/trajectory.jsonl) |
| test:3136 | completed | 1 | 18.66 | 0.00 | complete / not-produced | — | [result](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/2ee9e7fd-4d6d-4c7e-95d4-86607cd407f1/result.json) · [文件清单](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/2ee9e7fd-4d6d-4c7e-95d4-86607cd407f1/files.json) · [轨迹](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/2ee9e7fd-4d6d-4c7e-95d4-86607cd407f1/agent/trajectory.jsonl) |
| test:3165 | completed | 1 | 17.06 | 0.00 | complete / not-produced | — | [result](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/fd0c0c2a-2c43-448b-b646-5b8388045497/result.json) · [文件清单](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/fd0c0c2a-2c43-448b-b646-5b8388045497/files.json) · [轨迹](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/fd0c0c2a-2c43-448b-b646-5b8388045497/agent/trajectory.jsonl) |
| test:3196 | completed | 1 | 7.99 | 0.00 | complete / not-produced | — | [result](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/35fe8199-5659-4499-b726-41208327c120/result.json) · [文件清单](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/35fe8199-5659-4499-b726-41208327c120/files.json) · [轨迹](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/35fe8199-5659-4499-b726-41208327c120/agent/trajectory.jsonl) |
| test:3231 | completed | 1 | 9.69 | 0.00 | complete / not-produced | — | [result](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/3d715eeb-287d-43a0-99ff-62ff7d9b1da6/result.json) · [文件清单](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/3d715eeb-287d-43a0-99ff-62ff7d9b1da6/files.json) · [轨迹](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/3d715eeb-287d-43a0-99ff-62ff7d9b1da6/agent/trajectory.jsonl) |
| test:3236 | completed | 1 | 9.92 | 0.00 | complete / not-produced | — | [result](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/e8e18e8b-10a3-43aa-b533-81c60e440a10/result.json) · [文件清单](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/e8e18e8b-10a3-43aa-b533-81c60e440a10/files.json) · [轨迹](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/e8e18e8b-10a3-43aa-b533-81c60e440a10/agent/trajectory.jsonl) |
| test:3270 | completed | 1 | 7.51 | 0.00 | complete / not-produced | — | [result](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/4173769d-11f0-4c34-9606-09e37db34bf1/result.json) · [文件清单](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/4173769d-11f0-4c34-9606-09e37db34bf1/files.json) · [轨迹](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/4173769d-11f0-4c34-9606-09e37db34bf1/agent/trajectory.jsonl) |
| test:3293 | completed | 1 | 7.34 | 0.00 | complete / not-produced | — | [result](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/3f89508a-6ad9-407f-a6f0-b8b12d4ac29d/result.json) · [文件清单](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/3f89508a-6ad9-407f-a6f0-b8b12d4ac29d/files.json) · [轨迹](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/3f89508a-6ad9-407f-a6f0-b8b12d4ac29d/agent/trajectory.jsonl) |
| test:3331 | completed | 1 | 6.07 | 0.00 | complete / not-produced | — | [result](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/03b54ae8-bf04-4dbe-98f5-c50697c49739/result.json) · [文件清单](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/03b54ae8-bf04-4dbe-98f5-c50697c49739/files.json) · [轨迹](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/03b54ae8-bf04-4dbe-98f5-c50697c49739/agent/trajectory.jsonl) |
| test:3488 | completed | 1 | 10.45 | 0.00 | complete / not-produced | — | [result](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/a1e459c2-68df-4f52-926b-48189c91d2ec/result.json) · [文件清单](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/a1e459c2-68df-4f52-926b-48189c91d2ec/files.json) · [轨迹](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/a1e459c2-68df-4f52-926b-48189c91d2ec/agent/trajectory.jsonl) |
| test:3491 | completed | 0 | 240.02 | 0.00 | partial / not-produced | SOLVER\_AGENT\_TIMEOUT | [result](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/4b72e011-4844-4dd8-8268-7da40636c405/result.json) · [文件清单](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/4b72e011-4844-4dd8-8268-7da40636c405/files.json) · [轨迹](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/4b72e011-4844-4dd8-8268-7da40636c405/agent/trajectory.jsonl) |
| test:3552 | completed | 1 | 10.75 | 0.00 | complete / not-produced | — | [result](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/42ffc602-c516-4e90-b5a4-d21ea2a280a5/result.json) · [文件清单](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/42ffc602-c516-4e90-b5a4-d21ea2a280a5/files.json) · [轨迹](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/42ffc602-c516-4e90-b5a4-d21ea2a280a5/agent/trajectory.jsonl) |
| test:3599 | completed | 1 | 6.07 | 0.00 | complete / not-produced | — | [result](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/f1dbadfd-89e3-43ea-8e8b-c39045a0452b/result.json) · [文件清单](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/f1dbadfd-89e3-43ea-8e8b-c39045a0452b/files.json) · [轨迹](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/f1dbadfd-89e3-43ea-8e8b-c39045a0452b/agent/trajectory.jsonl) |
| test:3626 | completed | 1 | 7.62 | 0.00 | complete / not-produced | — | [result](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/018de3a0-4cea-44e3-b49b-345f800062c9/result.json) · [文件清单](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/018de3a0-4cea-44e3-b49b-345f800062c9/files.json) · [轨迹](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/018de3a0-4cea-44e3-b49b-345f800062c9/agent/trajectory.jsonl) |
| test:4021 | completed | 1 | 13.22 | 0.00 | complete / not-produced | — | [result](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/3247908a-327d-4d5b-af17-c86590e09ee5/result.json) · [文件清单](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/3247908a-327d-4d5b-af17-c86590e09ee5/files.json) · [轨迹](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/3247908a-327d-4d5b-af17-c86590e09ee5/agent/trajectory.jsonl) |
| test:4034 | completed | 1 | 7.20 | 0.00 | complete / not-produced | — | [result](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/1f410524-1407-413b-b58b-3d164b3fe5eb/result.json) · [文件清单](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/1f410524-1407-413b-b58b-3d164b3fe5eb/files.json) · [轨迹](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/1f410524-1407-413b-b58b-3d164b3fe5eb/agent/trajectory.jsonl) |
| test:4058 | completed | 1 | 8.07 | 0.00 | complete / not-produced | — | [result](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/554612c1-2c92-4dd5-8e0d-f27445e60962/result.json) · [文件清单](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/554612c1-2c92-4dd5-8e0d-f27445e60962/files.json) · [轨迹](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/554612c1-2c92-4dd5-8e0d-f27445e60962/agent/trajectory.jsonl) |
| test:4075 | completed | 1 | 7.75 | 0.00 | complete / not-produced | — | [result](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/be4c2c14-943e-4946-b84f-0dba25b0851f/result.json) · [文件清单](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/be4c2c14-943e-4946-b84f-0dba25b0851f/files.json) · [轨迹](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/be4c2c14-943e-4946-b84f-0dba25b0851f/agent/trajectory.jsonl) |
| test:4142 | completed | 1 | 12.97 | 0.00 | complete / not-produced | — | [result](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/ed272c60-4419-4118-9b93-945b671bf40f/result.json) · [文件清单](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/ed272c60-4419-4118-9b93-945b671bf40f/files.json) · [轨迹](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/ed272c60-4419-4118-9b93-945b671bf40f/agent/trajectory.jsonl) |
| test:4208 | completed | 1 | 7.82 | 0.00 | complete / not-produced | — | [result](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/4be694d2-0908-4c2e-a613-52f65ff80438/result.json) · [文件清单](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/4be694d2-0908-4c2e-a613-52f65ff80438/files.json) · [轨迹](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/4be694d2-0908-4c2e-a613-52f65ff80438/agent/trajectory.jsonl) |
| test:4298 | completed | 1 | 7.23 | 0.00 | complete / not-produced | — | [result](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/e70be8aa-b998-4de2-8dc0-b69f0538f904/result.json) · [文件清单](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/e70be8aa-b998-4de2-8dc0-b69f0538f904/files.json) · [轨迹](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/e70be8aa-b998-4de2-8dc0-b69f0538f904/agent/trajectory.jsonl) |
| test:4337 | completed | 1 | 16.52 | 0.00 | complete / not-produced | — | [result](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/7e1bd051-af47-418c-87e0-615e6773bd7a/result.json) · [文件清单](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/7e1bd051-af47-418c-87e0-615e6773bd7a/files.json) · [轨迹](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/7e1bd051-af47-418c-87e0-615e6773bd7a/agent/trajectory.jsonl) |
| test:4376 | invalid | — | 6.84 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/eb451434-e5a5-425e-9745-f533373d4d2f/result.json) · [文件清单](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/eb451434-e5a5-425e-9745-f533373d4d2f/files.json) · [轨迹](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/eb451434-e5a5-425e-9745-f533373d4d2f/agent/trajectory.jsonl) |
| test:4405 | completed | 1 | 8.64 | 0.00 | complete / not-produced | — | [result](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/de554106-7810-4856-9b0a-ede96c05bc07/result.json) · [文件清单](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/de554106-7810-4856-9b0a-ede96c05bc07/files.json) · [轨迹](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/de554106-7810-4856-9b0a-ede96c05bc07/agent/trajectory.jsonl) |
| test:4552 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/114d45e7-b36f-4835-82c7-02e457c46329/result.json) · [文件清单](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/114d45e7-b36f-4835-82c7-02e457c46329/files.json) |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 3；错误记录 4（主流程 2；证据收集 0；资源清理 2）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |
| cleanup | CLEANUP_FAILED | 1 | 2 |
| environment | RUN_CANCELLED | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| test:3491 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

