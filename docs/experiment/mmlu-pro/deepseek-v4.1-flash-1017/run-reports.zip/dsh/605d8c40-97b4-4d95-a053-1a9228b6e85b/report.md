<!-- snapshotDigest: 942ee8e19b547322cf450cf319958955c280a9c91ff8049344e164f046902b64 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 10.68%（22/206）**

Run: 605d8c40-97b4-4d95-a053-1a9228b6e85b · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:02:52.937Z / 2026-11-12T07:18:37.884Z |
| 总耗时 | 15 分 14 秒 |
| 答对 / 答错 / 解题超时 | 22 / 3 / 0 |
| 清理未确认 | 1 |
| 轨迹不完整 / 产物不完整 | 3 / 0 |

已选择 210 题；已保存 29 条记录；待运行 184 题。
有效评分覆盖率：25/210（11.90%）。
执行失败 1；超时 0；取消 3；不支持 0。
Agent 解题超时 0（计 0 分）；无效 4。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 210 |
| 计分题数 | 206 |
| 正常评分题数 | 25 |
| 答对题数 | 22 |
| 无效评测 | 4 |
| 待运行 | 184 |
| 正确率 | 10.68% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 15 分 14 秒 |
| 环境准备耗时 | 15 分 40 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 19 秒 | 44 秒 | 2 分 57 秒 | 29 |
| 任务准备 | 0.56 毫秒 | 0.28 毫秒 | 1.45 毫秒 | 29 |
| 环境启动 | 42 秒 | 27 秒 | 56 秒 | 29 |
| 解题 | 26 秒 | 3 秒 | 2 分 17 秒 | 29 |
| 产物传输 | 3 秒 | 1 秒 | 5 秒 | 26 |
| 资源清理 | 8 秒 | 4 秒 | 15 秒 | 29 |
| 评分 | 1.1 毫秒 | 0.32 毫秒 | 5.27 毫秒 | 25 |
| 证据收集 | 24.74 毫秒 | 5.61 毫秒 | 136.9 毫秒 | 29 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| dc8b4e04-ac0d-4fbf-88df-01e920521115 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 36,659 | 83,008 | 26 / 210 | — |
| 运行累计 | — | 36,659 | 83,008 | 26 / 29 | 3 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:41 | completed | 1 | 9.46 | 0.01 | complete / not-produced | — | [result](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/c2f902eb-d979-4ce2-a381-6678d77e6a15/result.json) · [文件清单](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/c2f902eb-d979-4ce2-a381-6678d77e6a15/files.json) · [轨迹](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/c2f902eb-d979-4ce2-a381-6678d77e6a15/agent/trajectory.jsonl) |
| test:61 | completed | 0 | 111.28 | 0.00 | complete / not-produced | — | [result](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/097db99c-79b7-4997-9f21-9d66bf5d08dd/result.json) · [文件清单](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/097db99c-79b7-4997-9f21-9d66bf5d08dd/files.json) · [轨迹](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/097db99c-79b7-4997-9f21-9d66bf5d08dd/agent/trajectory.jsonl) |
| test:97 | completed | 1 | 27.26 | 0.00 | complete / not-produced | — | [result](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/ca30bf79-29e2-4e42-9699-1dd2eaee07a1/result.json) · [文件清单](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/ca30bf79-29e2-4e42-9699-1dd2eaee07a1/files.json) · [轨迹](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/ca30bf79-29e2-4e42-9699-1dd2eaee07a1/agent/trajectory.jsonl) |
| test:209 | completed | 1 | 11.24 | 0.00 | complete / not-produced | — | [result](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/fc887f05-4e35-471e-8271-1094f5b932d1/result.json) · [文件清单](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/fc887f05-4e35-471e-8271-1094f5b932d1/files.json) · [轨迹](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/fc887f05-4e35-471e-8271-1094f5b932d1/agent/trajectory.jsonl) |
| test:286 | completed | 1 | 9.30 | 0.00 | complete / not-produced | — | [result](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/3ba07138-a9f1-41ed-ab5d-4c69a493a2d9/result.json) · [文件清单](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/3ba07138-a9f1-41ed-ab5d-4c69a493a2d9/files.json) · [轨迹](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/3ba07138-a9f1-41ed-ab5d-4c69a493a2d9/agent/trajectory.jsonl) |
| test:299 | completed | 1 | 14.80 | 0.00 | complete / not-produced | — | [result](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/160ae11b-5829-431b-ac44-3ccd7ab67608/result.json) · [文件清单](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/160ae11b-5829-431b-ac44-3ccd7ab67608/files.json) · [轨迹](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/160ae11b-5829-431b-ac44-3ccd7ab67608/agent/trajectory.jsonl) |
| test:311 | completed | 1 | 20.63 | 0.00 | complete / not-produced | — | [result](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/c8a58811-3746-4a11-9ccd-57dcdafa5c0a/result.json) · [文件清单](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/c8a58811-3746-4a11-9ccd-57dcdafa5c0a/files.json) · [轨迹](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/c8a58811-3746-4a11-9ccd-57dcdafa5c0a/agent/trajectory.jsonl) |
| test:352 | completed | 1 | 12.10 | 0.00 | complete / not-produced | — | [result](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/3e5ccb61-b3b0-4222-8fec-559d34053fea/result.json) · [文件清单](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/3e5ccb61-b3b0-4222-8fec-559d34053fea/files.json) · [轨迹](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/3e5ccb61-b3b0-4222-8fec-559d34053fea/agent/trajectory.jsonl) |
| test:355 | completed | 1 | 12.62 | 0.00 | complete / not-produced | — | [result](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/4b5b13e9-d1a5-4784-aa28-98dc2b3a8b39/result.json) · [文件清单](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/4b5b13e9-d1a5-4784-aa28-98dc2b3a8b39/files.json) · [轨迹](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/4b5b13e9-d1a5-4784-aa28-98dc2b3a8b39/agent/trajectory.jsonl) |
| test:476 | completed | 1 | 17.10 | 0.00 | complete / not-produced | — | [result](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/cf4dea7c-3d09-4bb4-b34e-40fe0b36c28e/result.json) · [文件清单](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/cf4dea7c-3d09-4bb4-b34e-40fe0b36c28e/files.json) · [轨迹](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/cf4dea7c-3d09-4bb4-b34e-40fe0b36c28e/agent/trajectory.jsonl) |
| test:511 | completed | 1 | 12.50 | 0.00 | complete / not-produced | — | [result](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/6893f8d2-232e-4a8f-a29a-0e9038c550a5/result.json) · [文件清单](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/6893f8d2-232e-4a8f-a29a-0e9038c550a5/files.json) · [轨迹](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/6893f8d2-232e-4a8f-a29a-0e9038c550a5/agent/trajectory.jsonl) |
| test:552 | completed | 1 | 13.67 | 0.00 | complete / not-produced | — | [result](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/591fd33f-7ebe-4d24-baaf-4bb1efe6cda6/result.json) · [文件清单](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/591fd33f-7ebe-4d24-baaf-4bb1efe6cda6/files.json) · [轨迹](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/591fd33f-7ebe-4d24-baaf-4bb1efe6cda6/agent/trajectory.jsonl) |
| test:624 | completed | 1 | 14.62 | 0.00 | complete / not-produced | — | [result](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/4d4917c7-16f5-442b-959a-3d04a9a37511/result.json) · [文件清单](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/4d4917c7-16f5-442b-959a-3d04a9a37511/files.json) · [轨迹](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/4d4917c7-16f5-442b-959a-3d04a9a37511/agent/trajectory.jsonl) |
| test:669 | completed | 1 | 14.31 | 0.00 | complete / not-produced | — | [result](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/b2e91fde-fea0-4e28-87af-c0ac25f2234b/result.json) · [文件清单](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/b2e91fde-fea0-4e28-87af-c0ac25f2234b/files.json) · [轨迹](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/b2e91fde-fea0-4e28-87af-c0ac25f2234b/agent/trajectory.jsonl) |
| test:670 | completed | 1 | 12.22 | 0.00 | complete / not-produced | — | [result](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/951a3b8f-ffd3-4fb9-88d4-6313c4ffbcbc/result.json) · [文件清单](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/951a3b8f-ffd3-4fb9-88d4-6313c4ffbcbc/files.json) · [轨迹](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/951a3b8f-ffd3-4fb9-88d4-6313c4ffbcbc/agent/trajectory.jsonl) |
| test:796 | completed | 1 | 32.34 | 0.00 | complete / not-produced | — | [result](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/d4eaee7b-0d4f-47ac-97f1-60582b37e3b0/result.json) · [文件清单](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/d4eaee7b-0d4f-47ac-97f1-60582b37e3b0/files.json) · [轨迹](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/d4eaee7b-0d4f-47ac-97f1-60582b37e3b0/agent/trajectory.jsonl) |
| test:828 | completed | 1 | 16.57 | 0.00 | complete / not-produced | — | [result](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/8d5d03a5-9e8a-4df0-bfd0-d3d0cee33121/result.json) · [文件清单](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/8d5d03a5-9e8a-4df0-bfd0-d3d0cee33121/files.json) · [轨迹](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/8d5d03a5-9e8a-4df0-bfd0-d3d0cee33121/agent/trajectory.jsonl) |
| test:841 | completed | 1 | 18.21 | 0.00 | complete / not-produced | — | [result](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/16f50b66-8fe1-4277-9087-dbbf5b1716f2/result.json) · [文件清单](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/16f50b66-8fe1-4277-9087-dbbf5b1716f2/files.json) · [轨迹](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/16f50b66-8fe1-4277-9087-dbbf5b1716f2/agent/trajectory.jsonl) |
| test:883 | completed | 1 | 14.50 | 0.00 | complete / not-produced | — | [result](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/03d35b57-1c19-463e-8b06-717d63bd9842/result.json) · [文件清单](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/03d35b57-1c19-463e-8b06-717d63bd9842/files.json) · [轨迹](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/03d35b57-1c19-463e-8b06-717d63bd9842/agent/trajectory.jsonl) |
| test:938 | completed | 1 | 18.68 | 0.00 | complete / not-produced | — | [result](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/6379135d-0af4-4e84-bf63-54c300b5ae30/result.json) · [文件清单](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/6379135d-0af4-4e84-bf63-54c300b5ae30/files.json) · [轨迹](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/6379135d-0af4-4e84-bf63-54c300b5ae30/agent/trajectory.jsonl) |
| test:1026 | completed | 0 | 35.47 | 0.00 | complete / not-produced | — | [result](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/a53ca06a-77d4-4a25-8fa1-2e56c2968029/result.json) · [文件清单](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/a53ca06a-77d4-4a25-8fa1-2e56c2968029/files.json) · [轨迹](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/a53ca06a-77d4-4a25-8fa1-2e56c2968029/agent/trajectory.jsonl) |
| test:1229 | completed | 1 | 12.85 | 0.00 | complete / not-produced | — | [result](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/24ec8890-7201-499a-8930-de7a3c72bf9f/result.json) · [文件清单](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/24ec8890-7201-499a-8930-de7a3c72bf9f/files.json) · [轨迹](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/24ec8890-7201-499a-8930-de7a3c72bf9f/agent/trajectory.jsonl) |
| test:1252 | completed | 1 | 11.79 | 0.00 | complete / not-produced | — | [result](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/08209f7c-e574-4936-b67e-0ecc59c6172e/result.json) · [文件清单](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/08209f7c-e574-4936-b67e-0ecc59c6172e/files.json) · [轨迹](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/08209f7c-e574-4936-b67e-0ecc59c6172e/agent/trajectory.jsonl) |
| test:1399 | completed | 1 | 30.98 | 0.00 | complete / not-produced | — | [result](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/f1a40ebc-f4c5-45cd-b0a9-cdabe33b13d8/result.json) · [文件清单](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/f1a40ebc-f4c5-45cd-b0a9-cdabe33b13d8/files.json) · [轨迹](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/f1a40ebc-f4c5-45cd-b0a9-cdabe33b13d8/agent/trajectory.jsonl) |
| test:1454 | cancelled | — | 137.46 | — | partial / not-produced | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/adbf79c2-7045-4f25-ab5b-021b36e2ea19/result.json) · [文件清单](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/adbf79c2-7045-4f25-ab5b-021b36e2ea19/files.json) · [轨迹](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/adbf79c2-7045-4f25-ab5b-021b36e2ea19/agent/trajectory.jsonl) |
| test:1514 | invalid | — | 44.91 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/22bb965e-65e5-4dfd-bff7-a53fea53cd41/result.json) · [文件清单](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/22bb965e-65e5-4dfd-bff7-a53fea53cd41/files.json) · [轨迹](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/22bb965e-65e5-4dfd-bff7-a53fea53cd41/agent/trajectory.jsonl) |
| test:1531 | cancelled | — | 3.03 | — | partial / not-produced | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/0ca369f2-7058-48e2-afe4-3e28cc8771b1/result.json) · [文件清单](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/0ca369f2-7058-48e2-afe4-3e28cc8771b1/files.json) · [轨迹](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/0ca369f2-7058-48e2-afe4-3e28cc8771b1/agent/trajectory.jsonl) |
| test:1785 | cancelled | — | 61.31 | — | partial / not-produced | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/59e1fa59-6eac-4ac0-9dfe-edd0b9c366df/result.json) · [文件清单](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/59e1fa59-6eac-4ac0-9dfe-edd0b9c366df/files.json) · [轨迹](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/59e1fa59-6eac-4ac0-9dfe-edd0b9c366df/agent/trajectory.jsonl) |
| test:1806 | completed | 0 | 15.56 | 0.00 | complete / not-produced | — | [result](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/c2c8f456-6034-47a3-9b1e-011568e0ba37/result.json) · [文件清单](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/c2c8f456-6034-47a3-9b1e-011568e0ba37/files.json) · [轨迹](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/c2c8f456-6034-47a3-9b1e-011568e0ba37/agent/trajectory.jsonl) |
| test:1827 | pending | — | — | — | — | — | — |
| test:1904 | pending | — | — | — | — | — | — |
| test:1943 | pending | — | — | — | — | — | — |
| test:1998 | pending | — | — | — | — | — | — |
| test:2023 | pending | — | — | — | — | — | — |
| test:2096 | pending | — | — | — | — | — | — |
| test:2152 | pending | — | — | — | — | — | — |
| test:2175 | pending | — | — | — | — | — | — |
| test:2177 | pending | — | — | — | — | — | — |
| test:2206 | pending | — | — | — | — | — | — |
| test:2280 | pending | — | — | — | — | — | — |
| test:2347 | pending | — | — | — | — | — | — |
| test:2400 | pending | — | — | — | — | — | — |
| test:2527 | pending | — | — | — | — | — | — |
| test:2636 | pending | — | — | — | — | — | — |
| test:2641 | pending | — | — | — | — | — | — |
| test:2714 | pending | — | — | — | — | — | — |
| test:2716 | pending | — | — | — | — | — | — |
| test:2747 | pending | — | — | — | — | — | — |
| test:2882 | pending | — | — | — | — | — | — |
| test:2951 | pending | — | — | — | — | — | — |
| test:3037 | pending | — | — | — | — | — | — |
| test:3053 | pending | — | — | — | — | — | — |
| test:3136 | pending | — | — | — | — | — | — |
| test:3165 | pending | — | — | — | — | — | — |
| test:3196 | pending | — | — | — | — | — | — |
| test:3231 | pending | — | — | — | — | — | — |
| test:3236 | pending | — | — | — | — | — | — |
| test:3270 | pending | — | — | — | — | — | — |
| test:3293 | pending | — | — | — | — | — | — |
| test:3331 | pending | — | — | — | — | — | — |
| test:3488 | pending | — | — | — | — | — | — |
| test:3491 | pending | — | — | — | — | — | — |
| test:3552 | pending | — | — | — | — | — | — |
| test:3599 | pending | — | — | — | — | — | — |
| test:3626 | pending | — | — | — | — | — | — |
| test:4021 | pending | — | — | — | — | — | — |
| test:4034 | pending | — | — | — | — | — | — |
| test:4058 | pending | — | — | — | — | — | — |
| test:4075 | pending | — | — | — | — | — | — |
| test:4142 | pending | — | — | — | — | — | — |
| test:4208 | pending | — | — | — | — | — | — |
| test:4298 | pending | — | — | — | — | — | — |
| test:4337 | pending | — | — | — | — | — | — |
| test:4376 | pending | — | — | — | — | — | — |
| test:4405 | pending | — | — | — | — | — | — |
| test:4552 | pending | — | — | — | — | — | — |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 4；错误记录 8（主流程 3；证据收集 3；资源清理 2）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | RUN_CANCELLED | 3 | 3 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 3 | 3 |
| cleanup | CLEANUP_FAILED | 1 | 2 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

