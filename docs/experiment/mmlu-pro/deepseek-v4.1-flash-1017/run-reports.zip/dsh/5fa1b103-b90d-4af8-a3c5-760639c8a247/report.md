<!-- snapshotDigest: 70f8dbaff8265fb37e23acecb7aae17c2d4b431119729a5ede767690c0ad566f -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 87.50%（21/24）**

Run: 5fa1b103-b90d-4af8-a3c5-760639c8a247 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:24:05.856Z / 2026-11-12T08:33:07.195Z |
| 总耗时 | 8 分 43 秒 |
| 答对 / 答错 / 解题超时 | 21 / 3 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 21 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 87.50% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 8 分 43 秒 |
| 环境准备耗时 | 4 分 52 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 17 秒 | 1 分 8 秒 | 1 分 42 秒 | 24 |
| 任务准备 | 0.51 毫秒 | 0.3 毫秒 | 1.27 毫秒 | 24 |
| 环境启动 | 48 秒 | 43 秒 | 53 秒 | 24 |
| 解题 | 18 秒 | 12 秒 | 42 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 8 秒 | 6 秒 | 10 秒 | 24 |
| 评分 | 0.98 毫秒 | 0.26 毫秒 | 5.92 毫秒 | 24 |
| 证据收集 | 16.75 毫秒 | 5.99 毫秒 | 33.29 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| a6a60fe0-9be8-4156-8786-28df9b2a0298 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 13,501 | 56,263 | 24 / 24 | — |
| 运行累计 | — | 13,501 | 56,263 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:10362 | completed | 1 | 16.57 | 0.00 | complete / not-produced | — | [result](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/e12b7961-ff3d-4abd-a83e-b9a9431e1ebb/result.json) · [文件清单](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/e12b7961-ff3d-4abd-a83e-b9a9431e1ebb/files.json) · [轨迹](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/e12b7961-ff3d-4abd-a83e-b9a9431e1ebb/agent/trajectory.jsonl) |
| test:10396 | completed | 1 | 15.24 | 0.00 | complete / not-produced | — | [result](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/efbd9214-3cf8-45eb-abfd-a29e9aad81b4/result.json) · [文件清单](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/efbd9214-3cf8-45eb-abfd-a29e9aad81b4/files.json) · [轨迹](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/efbd9214-3cf8-45eb-abfd-a29e9aad81b4/agent/trajectory.jsonl) |
| test:10401 | completed | 1 | 22.53 | 0.00 | complete / not-produced | — | [result](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/93037319-6ede-4292-a9bb-04de122d5b5f/result.json) · [文件清单](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/93037319-6ede-4292-a9bb-04de122d5b5f/files.json) · [轨迹](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/93037319-6ede-4292-a9bb-04de122d5b5f/agent/trajectory.jsonl) |
| test:10403 | completed | 1 | 15.53 | 0.00 | complete / not-produced | — | [result](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/00d67d9d-8f51-4784-8b1a-2fe8246d106d/result.json) · [文件清单](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/00d67d9d-8f51-4784-8b1a-2fe8246d106d/files.json) · [轨迹](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/00d67d9d-8f51-4784-8b1a-2fe8246d106d/agent/trajectory.jsonl) |
| test:10412 | completed | 1 | 14.16 | 0.00 | complete / not-produced | — | [result](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/615f0472-eace-4fb2-b9c3-763b1490c066/result.json) · [文件清单](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/615f0472-eace-4fb2-b9c3-763b1490c066/files.json) · [轨迹](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/615f0472-eace-4fb2-b9c3-763b1490c066/agent/trajectory.jsonl) |
| test:10421 | completed | 1 | 17.68 | 0.00 | complete / not-produced | — | [result](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/d900700b-02ca-428b-954e-84ee06b8ee1c/result.json) · [文件清单](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/d900700b-02ca-428b-954e-84ee06b8ee1c/files.json) · [轨迹](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/d900700b-02ca-428b-954e-84ee06b8ee1c/agent/trajectory.jsonl) |
| test:10424 | completed | 1 | 22.89 | 0.00 | complete / not-produced | — | [result](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/1f5960be-d4ca-4178-8cd9-eec52654d518/result.json) · [文件清单](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/1f5960be-d4ca-4178-8cd9-eec52654d518/files.json) · [轨迹](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/1f5960be-d4ca-4178-8cd9-eec52654d518/agent/trajectory.jsonl) |
| test:10471 | completed | 1 | 13.35 | 0.00 | complete / not-produced | — | [result](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/5105efe3-6bf9-4863-a4a0-a179d103324a/result.json) · [文件清单](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/5105efe3-6bf9-4863-a4a0-a179d103324a/files.json) · [轨迹](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/5105efe3-6bf9-4863-a4a0-a179d103324a/agent/trajectory.jsonl) |
| test:10479 | completed | 1 | 13.88 | 0.00 | complete / not-produced | — | [result](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/44c3c89f-2e23-437e-9ab4-25814ca45a34/result.json) · [文件清单](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/44c3c89f-2e23-437e-9ab4-25814ca45a34/files.json) · [轨迹](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/44c3c89f-2e23-437e-9ab4-25814ca45a34/agent/trajectory.jsonl) |
| test:10524 | completed | 1 | 13.61 | 0.00 | complete / not-produced | — | [result](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/05b404f0-52a3-49da-a947-24a659d07e24/result.json) · [文件清单](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/05b404f0-52a3-49da-a947-24a659d07e24/files.json) · [轨迹](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/05b404f0-52a3-49da-a947-24a659d07e24/agent/trajectory.jsonl) |
| test:10607 | completed | 1 | 12.41 | 0.00 | complete / not-produced | — | [result](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/b2c71d30-e958-43f6-b0b3-492130f1152c/result.json) · [文件清单](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/b2c71d30-e958-43f6-b0b3-492130f1152c/files.json) · [轨迹](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/b2c71d30-e958-43f6-b0b3-492130f1152c/agent/trajectory.jsonl) |
| test:10656 | completed | 1 | 12.57 | 0.00 | complete / not-produced | — | [result](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/c3efdee3-d82e-41ef-acb1-2fa8c773aa41/result.json) · [文件清单](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/c3efdee3-d82e-41ef-acb1-2fa8c773aa41/files.json) · [轨迹](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/c3efdee3-d82e-41ef-acb1-2fa8c773aa41/agent/trajectory.jsonl) |
| test:10674 | completed | 1 | 16.29 | 0.00 | complete / not-produced | — | [result](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/2d34ef7a-5082-4ebd-9659-d80a7629ace5/result.json) · [文件清单](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/2d34ef7a-5082-4ebd-9659-d80a7629ace5/files.json) · [轨迹](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/2d34ef7a-5082-4ebd-9659-d80a7629ace5/agent/trajectory.jsonl) |
| test:10683 | completed | 1 | 20.16 | 0.00 | complete / not-produced | — | [result](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/75de465e-e66a-4a5e-83dd-ca5bb091a6ec/result.json) · [文件清单](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/75de465e-e66a-4a5e-83dd-ca5bb091a6ec/files.json) · [轨迹](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/75de465e-e66a-4a5e-83dd-ca5bb091a6ec/agent/trajectory.jsonl) |
| test:10690 | completed | 1 | 17.53 | 0.00 | complete / not-produced | — | [result](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/25ba59b0-d979-440e-8d25-03efb93e9a4d/result.json) · [文件清单](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/25ba59b0-d979-440e-8d25-03efb93e9a4d/files.json) · [轨迹](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/25ba59b0-d979-440e-8d25-03efb93e9a4d/agent/trajectory.jsonl) |
| test:10765 | completed | 1 | 15.64 | 0.00 | complete / not-produced | — | [result](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/82b39b28-24d8-4ea0-a4b3-4f6c269ed731/result.json) · [文件清单](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/82b39b28-24d8-4ea0-a4b3-4f6c269ed731/files.json) · [轨迹](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/82b39b28-24d8-4ea0-a4b3-4f6c269ed731/agent/trajectory.jsonl) |
| test:10770 | completed | 1 | 22.42 | 0.00 | complete / not-produced | — | [result](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/f196ca63-dab7-4f4a-b829-bbdffd4f9443/result.json) · [文件清单](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/f196ca63-dab7-4f4a-b829-bbdffd4f9443/files.json) · [轨迹](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/f196ca63-dab7-4f4a-b829-bbdffd4f9443/agent/trajectory.jsonl) |
| test:10815 | completed | 1 | 14.10 | 0.00 | complete / not-produced | — | [result](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/6ed7a634-7faf-4695-8721-3265e25cf1e5/result.json) · [文件清单](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/6ed7a634-7faf-4695-8721-3265e25cf1e5/files.json) · [轨迹](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/6ed7a634-7faf-4695-8721-3265e25cf1e5/agent/trajectory.jsonl) |
| test:10846 | completed | 0 | 41.61 | 0.00 | complete / not-produced | — | [result](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/266ed9a7-b958-4100-90f9-c58947c8bcbf/result.json) · [文件清单](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/266ed9a7-b958-4100-90f9-c58947c8bcbf/files.json) · [轨迹](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/266ed9a7-b958-4100-90f9-c58947c8bcbf/agent/trajectory.jsonl) |
| test:10898 | completed | 1 | 13.68 | 0.00 | complete / not-produced | — | [result](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/9527d46e-8fa5-4808-a7d3-586742f96aee/result.json) · [文件清单](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/9527d46e-8fa5-4808-a7d3-586742f96aee/files.json) · [轨迹](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/9527d46e-8fa5-4808-a7d3-586742f96aee/agent/trajectory.jsonl) |
| test:10940 | completed | 1 | 18.95 | 0.00 | complete / not-produced | — | [result](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/f6907b8e-989f-4e3b-b7c4-28989d381e6a/result.json) · [文件清单](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/f6907b8e-989f-4e3b-b7c4-28989d381e6a/files.json) · [轨迹](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/f6907b8e-989f-4e3b-b7c4-28989d381e6a/agent/trajectory.jsonl) |
| test:10966 | completed | 1 | 17.80 | 0.00 | complete / not-produced | — | [result](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/3bcc2c88-29e3-467a-bd1d-8f88242b9788/result.json) · [文件清单](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/3bcc2c88-29e3-467a-bd1d-8f88242b9788/files.json) · [轨迹](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/3bcc2c88-29e3-467a-bd1d-8f88242b9788/agent/trajectory.jsonl) |
| test:11045 | completed | 0 | 16.71 | 0.00 | complete / not-produced | — | [result](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/d8c67123-281f-4bfd-866f-071b9db1fd0d/result.json) · [文件清单](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/d8c67123-281f-4bfd-866f-071b9db1fd0d/files.json) · [轨迹](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/d8c67123-281f-4bfd-866f-071b9db1fd0d/agent/trajectory.jsonl) |
| test:11050 | completed | 0 | 24.56 | 0.01 | complete / not-produced | — | [result](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/66fe2eec-d978-41ae-b41a-134f678fe3d6/result.json) · [文件清单](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/66fe2eec-d978-41ae-b41a-134f678fe3d6/files.json) · [轨迹](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/66fe2eec-d978-41ae-b41a-134f678fe3d6/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

