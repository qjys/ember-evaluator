<!-- snapshotDigest: 9cc32e0137160e17aa192d89a6529bf899dd4548a784e4cd5a71f4a5c6ac90a3 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: 7d092386-ec2b-4fd0-8a07-a12137ab4413 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:08:22.705Z / 2026-11-12T08:16:05.130Z |
| 总耗时 | 7 分 27 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 7 分 27 秒 |
| 环境准备耗时 | 3 分 53 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 5 秒 | 50 秒 | 1 分 54 秒 | 24 |
| 任务准备 | 0.49 毫秒 | 0.28 毫秒 | 0.84 毫秒 | 24 |
| 环境启动 | 41 秒 | 32 秒 | 49 秒 | 24 |
| 解题 | 16 秒 | 10 秒 | 1 分 8 秒 | 24 |
| 产物传输 | 2 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 6 秒 | 4 秒 | 9 秒 | 24 |
| 评分 | 1.05 毫秒 | 0.27 毫秒 | 4.47 毫秒 | 24 |
| 证据收集 | 21.43 毫秒 | 5.99 毫秒 | 61.83 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 483ab253-d997-4f68-879a-3d7d6735f46a | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 14,068 | 61,538 | 24 / 24 | — |
| 运行累计 | — | 14,068 | 61,538 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:6784 | completed | 1 | 14.11 | 0.00 | complete / not-produced | — | [result](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/895aab42-70de-4fdd-b177-fd22b2f1d14b/result.json) · [文件清单](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/895aab42-70de-4fdd-b177-fd22b2f1d14b/files.json) · [轨迹](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/895aab42-70de-4fdd-b177-fd22b2f1d14b/agent/trajectory.jsonl) |
| test:6792 | completed | 1 | 12.92 | 0.00 | complete / not-produced | — | [result](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/1b1cb739-014a-44c9-92a7-e37a8114f840/result.json) · [文件清单](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/1b1cb739-014a-44c9-92a7-e37a8114f840/files.json) · [轨迹](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/1b1cb739-014a-44c9-92a7-e37a8114f840/agent/trajectory.jsonl) |
| test:6900 | completed | 1 | 11.59 | 0.00 | complete / not-produced | — | [result](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/c3662672-3d69-46e3-9ebe-cc635e854d30/result.json) · [文件清单](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/c3662672-3d69-46e3-9ebe-cc635e854d30/files.json) · [轨迹](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/c3662672-3d69-46e3-9ebe-cc635e854d30/agent/trajectory.jsonl) |
| test:6928 | completed | 1 | 13.74 | 0.00 | complete / not-produced | — | [result](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/02223fb1-86e8-4039-a471-feb7424102d3/result.json) · [文件清单](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/02223fb1-86e8-4039-a471-feb7424102d3/files.json) · [轨迹](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/02223fb1-86e8-4039-a471-feb7424102d3/agent/trajectory.jsonl) |
| test:6929 | completed | 1 | 13.12 | 0.00 | complete / not-produced | — | [result](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/798e81e5-7cba-4671-9dca-ba71060e96f8/result.json) · [文件清单](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/798e81e5-7cba-4671-9dca-ba71060e96f8/files.json) · [轨迹](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/798e81e5-7cba-4671-9dca-ba71060e96f8/agent/trajectory.jsonl) |
| test:7161 | completed | 1 | 67.92 | 0.00 | complete / not-produced | — | [result](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/a319651b-c803-4fb0-80ed-c888557c6111/result.json) · [文件清单](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/a319651b-c803-4fb0-80ed-c888557c6111/files.json) · [轨迹](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/a319651b-c803-4fb0-80ed-c888557c6111/agent/trajectory.jsonl) |
| test:7181 | completed | 1 | 10.16 | 0.00 | complete / not-produced | — | [result](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/1ebb15c0-aab9-4643-bcdd-b2af6cfd4717/result.json) · [文件清单](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/1ebb15c0-aab9-4643-bcdd-b2af6cfd4717/files.json) · [轨迹](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/1ebb15c0-aab9-4643-bcdd-b2af6cfd4717/agent/trajectory.jsonl) |
| test:7217 | completed | 1 | 10.45 | 0.00 | complete / not-produced | — | [result](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/0215f231-c885-435c-829d-e2fe6caa6980/result.json) · [文件清单](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/0215f231-c885-435c-829d-e2fe6caa6980/files.json) · [轨迹](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/0215f231-c885-435c-829d-e2fe6caa6980/agent/trajectory.jsonl) |
| test:7290 | completed | 1 | 12.28 | 0.00 | complete / not-produced | — | [result](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/cced8c3e-63bb-49a2-9e05-463ced77a821/result.json) · [文件清单](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/cced8c3e-63bb-49a2-9e05-463ced77a821/files.json) · [轨迹](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/cced8c3e-63bb-49a2-9e05-463ced77a821/agent/trajectory.jsonl) |
| test:7304 | completed | 1 | 12.03 | 0.00 | complete / not-produced | — | [result](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/32f6ac2f-597b-4d22-b90c-853166a75f92/result.json) · [文件清单](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/32f6ac2f-597b-4d22-b90c-853166a75f92/files.json) · [轨迹](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/32f6ac2f-597b-4d22-b90c-853166a75f92/agent/trajectory.jsonl) |
| test:7312 | completed | 1 | 12.06 | 0.00 | complete / not-produced | — | [result](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/6e60aa95-9429-4977-a366-6f8d491af74e/result.json) · [文件清单](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/6e60aa95-9429-4977-a366-6f8d491af74e/files.json) · [轨迹](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/6e60aa95-9429-4977-a366-6f8d491af74e/agent/trajectory.jsonl) |
| test:7448 | completed | 1 | 30.24 | 0.00 | complete / not-produced | — | [result](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/b1555f22-4246-42b3-a9eb-5a41cfadf58e/result.json) · [文件清单](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/b1555f22-4246-42b3-a9eb-5a41cfadf58e/files.json) · [轨迹](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/b1555f22-4246-42b3-a9eb-5a41cfadf58e/agent/trajectory.jsonl) |
| test:7462 | completed | 1 | 15.34 | 0.00 | complete / not-produced | — | [result](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/5dbd5254-f0f8-452e-83e9-c7545b899cf2/result.json) · [文件清单](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/5dbd5254-f0f8-452e-83e9-c7545b899cf2/files.json) · [轨迹](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/5dbd5254-f0f8-452e-83e9-c7545b899cf2/agent/trajectory.jsonl) |
| test:7526 | completed | 1 | 16.34 | 0.00 | complete / not-produced | — | [result](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/447414d5-d0fc-4335-8e45-64fd248cdd60/result.json) · [文件清单](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/447414d5-d0fc-4335-8e45-64fd248cdd60/files.json) · [轨迹](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/447414d5-d0fc-4335-8e45-64fd248cdd60/agent/trajectory.jsonl) |
| test:7727 | completed | 1 | 16.75 | 0.00 | complete / not-produced | — | [result](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/358790bd-a512-45e1-97c0-e4ffde692eb3/result.json) · [文件清单](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/358790bd-a512-45e1-97c0-e4ffde692eb3/files.json) · [轨迹](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/358790bd-a512-45e1-97c0-e4ffde692eb3/agent/trajectory.jsonl) |
| test:7752 | completed | 0 | 13.78 | 0.00 | complete / not-produced | — | [result](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/74fc5f3f-540b-470b-a7dc-7ab789ca0ec6/result.json) · [文件清单](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/74fc5f3f-540b-470b-a7dc-7ab789ca0ec6/files.json) · [轨迹](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/74fc5f3f-540b-470b-a7dc-7ab789ca0ec6/agent/trajectory.jsonl) |
| test:7838 | completed | 1 | 14.18 | 0.00 | complete / not-produced | — | [result](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/7192ddad-85d8-45d8-99b8-99f9688d48b1/result.json) · [文件清单](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/7192ddad-85d8-45d8-99b8-99f9688d48b1/files.json) · [轨迹](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/7192ddad-85d8-45d8-99b8-99f9688d48b1/agent/trajectory.jsonl) |
| test:7954 | completed | 1 | 16.68 | 0.00 | complete / not-produced | — | [result](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/506efc14-705e-46c1-b9b9-212c8253ea13/result.json) · [文件清单](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/506efc14-705e-46c1-b9b9-212c8253ea13/files.json) · [轨迹](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/506efc14-705e-46c1-b9b9-212c8253ea13/agent/trajectory.jsonl) |
| test:7976 | completed | 1 | 13.84 | 0.00 | complete / not-produced | — | [result](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/d19a8ee1-6682-4cfa-8c95-4d219aa6137c/result.json) · [文件清单](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/d19a8ee1-6682-4cfa-8c95-4d219aa6137c/files.json) · [轨迹](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/d19a8ee1-6682-4cfa-8c95-4d219aa6137c/agent/trajectory.jsonl) |
| test:8199 | completed | 1 | 12.33 | 0.00 | complete / not-produced | — | [result](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/e0f1a019-e7af-4919-97e3-bcdb13d1de71/result.json) · [文件清单](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/e0f1a019-e7af-4919-97e3-bcdb13d1de71/files.json) · [轨迹](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/e0f1a019-e7af-4919-97e3-bcdb13d1de71/agent/trajectory.jsonl) |
| test:8207 | completed | 1 | 12.62 | 0.00 | complete / not-produced | — | [result](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/60193890-c06e-4e80-bc4d-6100e348a98b/result.json) · [文件清单](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/60193890-c06e-4e80-bc4d-6100e348a98b/files.json) · [轨迹](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/60193890-c06e-4e80-bc4d-6100e348a98b/agent/trajectory.jsonl) |
| test:8304 | completed | 1 | 11.25 | 0.00 | complete / not-produced | — | [result](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/378f5476-9fd0-449e-90f2-2e809cd8d0ec/result.json) · [文件清单](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/378f5476-9fd0-449e-90f2-2e809cd8d0ec/files.json) · [轨迹](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/378f5476-9fd0-449e-90f2-2e809cd8d0ec/agent/trajectory.jsonl) |
| test:8366 | completed | 1 | 11.46 | 0.00 | complete / not-produced | — | [result](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/4ba8d447-7e90-4fb9-8e59-6b0cd1c4a455/result.json) · [文件清单](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/4ba8d447-7e90-4fb9-8e59-6b0cd1c4a455/files.json) · [轨迹](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/4ba8d447-7e90-4fb9-8e59-6b0cd1c4a455/agent/trajectory.jsonl) |
| test:8511 | completed | 1 | 10.50 | 0.00 | complete / not-produced | — | [result](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/21d04a5f-3d5a-400f-9a8f-1e00b932af8c/result.json) · [文件清单](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/21d04a5f-3d5a-400f-9a8f-1e00b932af8c/files.json) · [轨迹](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/21d04a5f-3d5a-400f-9a8f-1e00b932af8c/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

