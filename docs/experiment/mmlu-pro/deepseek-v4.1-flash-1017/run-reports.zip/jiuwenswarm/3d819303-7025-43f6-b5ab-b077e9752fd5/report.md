<!-- snapshotDigest: e3a697d55a2ae051ece2c59ad461ef24f51ca15b291e3f18a02ec44b567ebc66 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: 3d819303-7025-43f6-b5ab-b077e9752fd5 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:18:42.978Z / 2026-11-12T08:27:07.129Z |
| 总耗时 | 8 分 12 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 8 分 12 秒 |
| 环境准备耗时 | 4 分 52 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 41 秒 | 1 分 26 秒 | 2 分 9 秒 | 24 |
| 任务准备 | 0.52 毫秒 | 0.33 毫秒 | 1.23 毫秒 | 24 |
| 环境启动 | 51 秒 | 41 秒 | 58 秒 | 24 |
| 解题 | 40 秒 | 30 秒 | 1 分 3 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 6 秒 | 24 |
| 资源清理 | 7 秒 | 5 秒 | 9 秒 | 24 |
| 评分 | 0.77 毫秒 | 0.26 毫秒 | 2.14 毫秒 | 24 |
| 证据收集 | 22.97 毫秒 | 4.9 毫秒 | 149.06 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 953f019e-abb7-442d-b218-4153c166b285 | 未设置 | 600 | 6 | 6 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 189,717 | 11,271 | 200,988 | 24 / 24 | — |
| 运行累计 | 189,717 | 11,271 | 200,988 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4021 | completed | 1 | 33.80 | 0.00 | complete / not-produced | — | [result](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/9aadf4fe-094a-4702-ba93-c2d201dc3286/result.json) · [文件清单](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/9aadf4fe-094a-4702-ba93-c2d201dc3286/files.json) · [轨迹](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/9aadf4fe-094a-4702-ba93-c2d201dc3286/agent/trajectory.jsonl) |
| test:4034 | completed | 1 | 30.84 | 0.00 | complete / not-produced | — | [result](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/2ed10b98-a1e3-4f69-b3f3-4ebd31155e13/result.json) · [文件清单](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/2ed10b98-a1e3-4f69-b3f3-4ebd31155e13/files.json) · [轨迹](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/2ed10b98-a1e3-4f69-b3f3-4ebd31155e13/agent/trajectory.jsonl) |
| test:4058 | completed | 1 | 30.80 | 0.00 | complete / not-produced | — | [result](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/d270eba1-8223-4335-b59b-5e5901d423d3/result.json) · [文件清单](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/d270eba1-8223-4335-b59b-5e5901d423d3/files.json) · [轨迹](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/d270eba1-8223-4335-b59b-5e5901d423d3/agent/trajectory.jsonl) |
| test:4075 | completed | 1 | 30.45 | 0.00 | complete / not-produced | — | [result](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/64f6551d-6d2b-45fc-816a-4ebabb8750de/result.json) · [文件清单](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/64f6551d-6d2b-45fc-816a-4ebabb8750de/files.json) · [轨迹](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/64f6551d-6d2b-45fc-816a-4ebabb8750de/agent/trajectory.jsonl) |
| test:4142 | completed | 1 | 35.31 | 0.00 | complete / not-produced | — | [result](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/3ccaa964-64c6-4312-94e7-272e23a9f992/result.json) · [文件清单](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/3ccaa964-64c6-4312-94e7-272e23a9f992/files.json) · [轨迹](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/3ccaa964-64c6-4312-94e7-272e23a9f992/agent/trajectory.jsonl) |
| test:4208 | completed | 1 | 35.77 | 0.00 | complete / not-produced | — | [result](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/49bdc204-59f6-4bc8-95e2-af92ddfaeefd/result.json) · [文件清单](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/49bdc204-59f6-4bc8-95e2-af92ddfaeefd/files.json) · [轨迹](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/49bdc204-59f6-4bc8-95e2-af92ddfaeefd/agent/trajectory.jsonl) |
| test:4298 | completed | 1 | 38.01 | 0.00 | complete / not-produced | — | [result](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/4e354235-de6f-478b-9cba-0c27b6cf5f8c/result.json) · [文件清单](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/4e354235-de6f-478b-9cba-0c27b6cf5f8c/files.json) · [轨迹](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/4e354235-de6f-478b-9cba-0c27b6cf5f8c/agent/trajectory.jsonl) |
| test:4337 | completed | 1 | 39.95 | 0.00 | complete / not-produced | — | [result](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/bf2af365-cc8d-4b12-8e63-fabf0553e666/result.json) · [文件清单](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/bf2af365-cc8d-4b12-8e63-fabf0553e666/files.json) · [轨迹](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/bf2af365-cc8d-4b12-8e63-fabf0553e666/agent/trajectory.jsonl) |
| test:4376 | completed | 1 | 39.27 | 0.00 | complete / not-produced | — | [result](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/8139fe27-9152-43e2-a0f8-29a608f19307/result.json) · [文件清单](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/8139fe27-9152-43e2-a0f8-29a608f19307/files.json) · [轨迹](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/8139fe27-9152-43e2-a0f8-29a608f19307/agent/trajectory.jsonl) |
| test:4405 | completed | 1 | 39.15 | 0.00 | complete / not-produced | — | [result](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/25fafeb3-8ead-4d4e-8673-aca6cbf978ca/result.json) · [文件清单](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/25fafeb3-8ead-4d4e-8673-aca6cbf978ca/files.json) · [轨迹](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/25fafeb3-8ead-4d4e-8673-aca6cbf978ca/agent/trajectory.jsonl) |
| test:4552 | completed | 1 | 38.26 | 0.00 | complete / not-produced | — | [result](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/f5fc2438-0d8d-4701-ab68-054390e95590/result.json) · [文件清单](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/f5fc2438-0d8d-4701-ab68-054390e95590/files.json) · [轨迹](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/f5fc2438-0d8d-4701-ab68-054390e95590/agent/trajectory.jsonl) |
| test:4560 | completed | 1 | 41.84 | 0.00 | complete / not-produced | — | [result](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/253a7f79-e2cf-434b-bb65-260fca6a2d90/result.json) · [文件清单](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/253a7f79-e2cf-434b-bb65-260fca6a2d90/files.json) · [轨迹](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/253a7f79-e2cf-434b-bb65-260fca6a2d90/agent/trajectory.jsonl) |
| test:4568 | completed | 1 | 34.51 | 0.00 | complete / not-produced | — | [result](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/4ca48b9f-a7bd-43be-8f88-985e5505c420/result.json) · [文件清单](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/4ca48b9f-a7bd-43be-8f88-985e5505c420/files.json) · [轨迹](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/4ca48b9f-a7bd-43be-8f88-985e5505c420/agent/trajectory.jsonl) |
| test:4580 | completed | 1 | 44.37 | 0.00 | complete / not-produced | — | [result](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/89c3d2c6-fb7d-457f-8539-86c6a4080ec5/result.json) · [文件清单](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/89c3d2c6-fb7d-457f-8539-86c6a4080ec5/files.json) · [轨迹](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/89c3d2c6-fb7d-457f-8539-86c6a4080ec5/agent/trajectory.jsonl) |
| test:4603 | completed | 1 | 40.87 | 0.00 | complete / not-produced | — | [result](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/745c6523-5f69-4e8b-a552-a7c509a2adb9/result.json) · [文件清单](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/745c6523-5f69-4e8b-a552-a7c509a2adb9/files.json) · [轨迹](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/745c6523-5f69-4e8b-a552-a7c509a2adb9/agent/trajectory.jsonl) |
| test:4625 | completed | 1 | 38.60 | 0.00 | complete / not-produced | — | [result](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/8cd54243-4553-4b4e-9649-0e260e69f8c4/result.json) · [文件清单](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/8cd54243-4553-4b4e-9649-0e260e69f8c4/files.json) · [轨迹](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/8cd54243-4553-4b4e-9649-0e260e69f8c4/agent/trajectory.jsonl) |
| test:4627 | completed | 1 | 41.56 | 0.00 | complete / not-produced | — | [result](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/b50707f8-443f-4fa4-9c3a-d6a41d2660fa/result.json) · [文件清单](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/b50707f8-443f-4fa4-9c3a-d6a41d2660fa/files.json) · [轨迹](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/b50707f8-443f-4fa4-9c3a-d6a41d2660fa/agent/trajectory.jsonl) |
| test:4651 | completed | 1 | 44.31 | 0.00 | complete / not-produced | — | [result](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/1269e93c-8537-452b-ac1e-7e673ee7e869/result.json) · [文件清单](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/1269e93c-8537-452b-ac1e-7e673ee7e869/files.json) · [轨迹](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/1269e93c-8537-452b-ac1e-7e673ee7e869/agent/trajectory.jsonl) |
| test:4670 | completed | 1 | 62.60 | 0.00 | complete / not-produced | — | [result](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/2c99e7f7-3d4a-423f-b206-be325f7a85a1/result.json) · [文件清单](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/2c99e7f7-3d4a-423f-b206-be325f7a85a1/files.json) · [轨迹](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/2c99e7f7-3d4a-423f-b206-be325f7a85a1/agent/trajectory.jsonl) |
| test:4700 | completed | 1 | 42.77 | 0.00 | complete / not-produced | — | [result](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/75e9165d-fa0f-4ee8-af0e-aee6ea1756f1/result.json) · [文件清单](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/75e9165d-fa0f-4ee8-af0e-aee6ea1756f1/files.json) · [轨迹](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/75e9165d-fa0f-4ee8-af0e-aee6ea1756f1/agent/trajectory.jsonl) |
| test:4709 | completed | 0 | 42.29 | 0.00 | complete / not-produced | — | [result](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/cd5c6f51-d692-404e-b414-ae76c606b179/result.json) · [文件清单](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/cd5c6f51-d692-404e-b414-ae76c606b179/files.json) · [轨迹](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/cd5c6f51-d692-404e-b414-ae76c606b179/agent/trajectory.jsonl) |
| test:4763 | completed | 1 | 43.21 | 0.00 | complete / not-produced | — | [result](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/6f6e4862-0570-4362-8566-d0a5b7f9f734/result.json) · [文件清单](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/6f6e4862-0570-4362-8566-d0a5b7f9f734/files.json) · [轨迹](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/6f6e4862-0570-4362-8566-d0a5b7f9f734/agent/trajectory.jsonl) |
| test:4770 | completed | 1 | 44.88 | 0.00 | complete / not-produced | — | [result](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/a014595f-ed47-4ed9-be7f-42f2fb9d8347/result.json) · [文件清单](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/a014595f-ed47-4ed9-be7f-42f2fb9d8347/files.json) · [轨迹](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/a014595f-ed47-4ed9-be7f-42f2fb9d8347/agent/trajectory.jsonl) |
| test:4786 | completed | 1 | 45.96 | 0.00 | complete / not-produced | — | [result](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/2abc0a0c-234f-408c-8208-7936e347ffeb/result.json) · [文件清单](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/2abc0a0c-234f-408c-8208-7936e347ffeb/files.json) · [轨迹](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/2abc0a0c-234f-408c-8208-7936e347ffeb/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

