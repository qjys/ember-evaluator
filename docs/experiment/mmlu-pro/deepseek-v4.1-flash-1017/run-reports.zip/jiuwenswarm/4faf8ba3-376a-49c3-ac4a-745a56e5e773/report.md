<!-- snapshotDigest: f96790568dd9d906d9978bc9fd742920d5c6d855d4b689bd9d499563ea655ce5 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 70.83%（17/24）**

Run: 4faf8ba3-376a-49c3-ac4a-745a56e5e773 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:59:25.196Z / 2026-11-12T09:05:31.603Z |
| 总耗时 | 5 分 59 秒 |
| 答对 / 答错 / 解题超时 | 17 / 7 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 17 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 70.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 59 秒 |
| 环境准备耗时 | 2 分 51 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 11 秒 | 27 秒 | 3 分 39 秒 | 24 |
| 任务准备 | 0.59 毫秒 | 0.18 毫秒 | 1.94 毫秒 | 24 |
| 环境启动 | 26 秒 | 13 秒 | 41 秒 | 24 |
| 解题 | 40 秒 | 11 秒 | 2 分 54 秒 | 24 |
| 产物传输 | 1 秒 | 724.87 毫秒 | 2 秒 | 24 |
| 资源清理 | 4 秒 | 2 秒 | 8 秒 | 24 |
| 评分 | 0.55 毫秒 | 0.16 毫秒 | 1.86 毫秒 | 24 |
| 证据收集 | 24.84 毫秒 | 4.87 毫秒 | 104.3 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 45eaba65-1afc-4a10-9f49-321ed35d4f6d | 未设置 | 600 | 8 | 8 | 4800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 172,606 | 73,412 | 246,018 | 24 / 24 | — |
| 运行累计 | 172,606 | 73,412 | 246,018 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:10765 | completed | 1 | 21.97 | 0.00 | complete / not-produced | — | [result](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/c898643b-501e-4bf9-bdcf-71b6eb06309a/result.json) · [文件清单](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/c898643b-501e-4bf9-bdcf-71b6eb06309a/files.json) · [轨迹](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/c898643b-501e-4bf9-bdcf-71b6eb06309a/agent/trajectory.jsonl) |
| test:10770 | completed | 1 | 27.53 | 0.00 | complete / not-produced | — | [result](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/65dfd955-5983-424e-a3ca-be204167ec66/result.json) · [文件清单](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/65dfd955-5983-424e-a3ca-be204167ec66/files.json) · [轨迹](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/65dfd955-5983-424e-a3ca-be204167ec66/agent/trajectory.jsonl) |
| test:10815 | completed | 1 | 25.77 | 0.00 | complete / not-produced | — | [result](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/075ffd64-5921-414d-afae-95841bb2401d/result.json) · [文件清单](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/075ffd64-5921-414d-afae-95841bb2401d/files.json) · [轨迹](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/075ffd64-5921-414d-afae-95841bb2401d/agent/trajectory.jsonl) |
| test:10846 | completed | 1 | 42.20 | 0.00 | complete / not-produced | — | [result](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/bf915318-90ac-4bd5-8e12-74964a3df109/result.json) · [文件清单](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/bf915318-90ac-4bd5-8e12-74964a3df109/files.json) · [轨迹](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/bf915318-90ac-4bd5-8e12-74964a3df109/agent/trajectory.jsonl) |
| test:10898 | completed | 1 | 23.70 | 0.00 | complete / not-produced | — | [result](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/3559f9e7-3a6a-4dce-963a-58ab52c3e1ea/result.json) · [文件清单](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/3559f9e7-3a6a-4dce-963a-58ab52c3e1ea/files.json) · [轨迹](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/3559f9e7-3a6a-4dce-963a-58ab52c3e1ea/agent/trajectory.jsonl) |
| test:10940 | completed | 1 | 25.27 | 0.00 | complete / not-produced | — | [result](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/b38ba0fb-8863-4a45-ac39-bb73a21aa672/result.json) · [文件清单](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/b38ba0fb-8863-4a45-ac39-bb73a21aa672/files.json) · [轨迹](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/b38ba0fb-8863-4a45-ac39-bb73a21aa672/agent/trajectory.jsonl) |
| test:10966 | completed | 1 | 21.86 | 0.00 | complete / not-produced | — | [result](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/33486f6d-f1d6-4c2c-911e-552b731baa1a/result.json) · [文件清单](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/33486f6d-f1d6-4c2c-911e-552b731baa1a/files.json) · [轨迹](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/33486f6d-f1d6-4c2c-911e-552b731baa1a/agent/trajectory.jsonl) |
| test:11045 | completed | 0 | 21.35 | 0.00 | complete / not-produced | — | [result](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/636d2a39-f1e8-4e96-82fd-5e0f03609f01/result.json) · [文件清单](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/636d2a39-f1e8-4e96-82fd-5e0f03609f01/files.json) · [轨迹](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/636d2a39-f1e8-4e96-82fd-5e0f03609f01/agent/trajectory.jsonl) |
| test:11050 | completed | 0 | 28.34 | 0.00 | complete / not-produced | — | [result](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/71df27bf-d15d-4c44-a941-b1a6e41dbbce/result.json) · [文件清单](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/71df27bf-d15d-4c44-a941-b1a6e41dbbce/files.json) · [轨迹](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/71df27bf-d15d-4c44-a941-b1a6e41dbbce/agent/trajectory.jsonl) |
| test:11060 | completed | 1 | 23.01 | 0.00 | complete / not-produced | — | [result](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/a54ac3be-9fec-4bed-8de9-80be4e146d8f/result.json) · [文件清单](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/a54ac3be-9fec-4bed-8de9-80be4e146d8f/files.json) · [轨迹](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/a54ac3be-9fec-4bed-8de9-80be4e146d8f/agent/trajectory.jsonl) |
| test:11093 | completed | 1 | 95.38 | 0.00 | complete / not-produced | — | [result](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/90bf57d6-7a11-4ffc-8c68-4423fed1486b/result.json) · [文件清单](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/90bf57d6-7a11-4ffc-8c68-4423fed1486b/files.json) · [轨迹](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/90bf57d6-7a11-4ffc-8c68-4423fed1486b/agent/trajectory.jsonl) |
| test:11210 | completed | 1 | 23.84 | 0.00 | complete / not-produced | — | [result](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/8dde30a9-7e04-43d3-8047-e3777cbeef02/result.json) · [文件清单](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/8dde30a9-7e04-43d3-8047-e3777cbeef02/files.json) · [轨迹](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/8dde30a9-7e04-43d3-8047-e3777cbeef02/agent/trajectory.jsonl) |
| test:11354 | completed | 0 | 22.25 | 0.00 | complete / not-produced | — | [result](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/1122a79e-7e5b-4e20-8208-069c29a68977/result.json) · [文件清单](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/1122a79e-7e5b-4e20-8208-069c29a68977/files.json) · [轨迹](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/1122a79e-7e5b-4e20-8208-069c29a68977/agent/trajectory.jsonl) |
| test:11491 | completed | 0 | 40.51 | 0.00 | complete / not-produced | — | [result](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/11966d8c-9f02-4b50-a47f-ccf65f1bd9af/result.json) · [文件清单](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/11966d8c-9f02-4b50-a47f-ccf65f1bd9af/files.json) · [轨迹](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/11966d8c-9f02-4b50-a47f-ccf65f1bd9af/agent/trajectory.jsonl) |
| test:11496 | completed | 0 | 162.92 | 0.00 | complete / not-produced | — | [result](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/2a3622c2-06fa-4c76-a9bc-137440a9fc09/result.json) · [文件清单](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/2a3622c2-06fa-4c76-a9bc-137440a9fc09/files.json) · [轨迹](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/2a3622c2-06fa-4c76-a9bc-137440a9fc09/agent/trajectory.jsonl) |
| test:11506 | completed | 0 | 173.56 | 0.00 | complete / not-produced | — | [result](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/0914ea74-15c6-41b8-8f30-f20c9c84934f/result.json) · [文件清单](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/0914ea74-15c6-41b8-8f30-f20c9c84934f/files.json) · [轨迹](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/0914ea74-15c6-41b8-8f30-f20c9c84934f/agent/trajectory.jsonl) |
| test:11559 | completed | 1 | 14.99 | 0.00 | complete / not-produced | — | [result](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/3132412d-6e8f-4546-8169-77e5451250f1/result.json) · [文件清单](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/3132412d-6e8f-4546-8169-77e5451250f1/files.json) · [轨迹](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/3132412d-6e8f-4546-8169-77e5451250f1/agent/trajectory.jsonl) |
| test:11576 | completed | 0 | 31.24 | 0.00 | complete / not-produced | — | [result](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/f744e955-0861-4891-887f-a6a07ea4e1c4/result.json) · [文件清单](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/f744e955-0861-4891-887f-a6a07ea4e1c4/files.json) · [轨迹](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/f744e955-0861-4891-887f-a6a07ea4e1c4/agent/trajectory.jsonl) |
| test:11629 | completed | 1 | 21.21 | 0.00 | complete / not-produced | — | [result](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/09c3a7ee-18d9-413b-b3b2-b13656b2d573/result.json) · [文件清单](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/09c3a7ee-18d9-413b-b3b2-b13656b2d573/files.json) · [轨迹](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/09c3a7ee-18d9-413b-b3b2-b13656b2d573/agent/trajectory.jsonl) |
| test:11660 | completed | 1 | 48.00 | 0.00 | complete / not-produced | — | [result](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/e4b788f3-24c5-4ae1-b120-8a1aa2e8e860/result.json) · [文件清单](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/e4b788f3-24c5-4ae1-b120-8a1aa2e8e860/files.json) · [轨迹](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/e4b788f3-24c5-4ae1-b120-8a1aa2e8e860/agent/trajectory.jsonl) |
| test:11802 | completed | 1 | 13.48 | 0.00 | complete / not-produced | — | [result](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/3751d537-2276-4bee-9cd4-83dea734691d/result.json) · [文件清单](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/3751d537-2276-4bee-9cd4-83dea734691d/files.json) · [轨迹](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/3751d537-2276-4bee-9cd4-83dea734691d/agent/trajectory.jsonl) |
| test:11808 | completed | 1 | 15.83 | 0.00 | complete / not-produced | — | [result](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/2b905589-56ec-40e9-8a35-9f48d4d643ec/result.json) · [文件清单](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/2b905589-56ec-40e9-8a35-9f48d4d643ec/files.json) · [轨迹](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/2b905589-56ec-40e9-8a35-9f48d4d643ec/agent/trajectory.jsonl) |
| test:11824 | completed | 1 | 11.08 | 0.00 | complete / not-produced | — | [result](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/71179de7-d092-4ed9-85a3-7c69462640ae/result.json) · [文件清单](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/71179de7-d092-4ed9-85a3-7c69462640ae/files.json) · [轨迹](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/71179de7-d092-4ed9-85a3-7c69462640ae/agent/trajectory.jsonl) |
| test:11925 | completed | 1 | 21.66 | 0.00 | complete / not-produced | — | [result](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/0da5f5e5-ca38-41e5-b963-d692e976377e/result.json) · [文件清单](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/0da5f5e5-ca38-41e5-b963-d692e976377e/files.json) · [轨迹](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/0da5f5e5-ca38-41e5-b963-d692e976377e/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

