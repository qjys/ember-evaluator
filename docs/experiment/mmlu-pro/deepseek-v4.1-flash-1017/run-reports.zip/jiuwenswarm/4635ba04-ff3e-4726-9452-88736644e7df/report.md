<!-- snapshotDigest: b7bf33aec88232d43b9bb9a36516d4d9e456fc1ee785d9499a2c837d17adec0b -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: 4635ba04-ff3e-4726-9452-88736644e7df · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:53:24.252Z / 2026-11-12T08:59:15.019Z |
| 总耗时 | 5 分 45 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 45 秒 |
| 环境准备耗时 | 3 分 43 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 24 秒 | 52 秒 | 2 分 27 秒 | 24 |
| 任务准备 | 0.46 毫秒 | 0.22 毫秒 | 0.84 毫秒 | 24 |
| 环境启动 | 41 秒 | 30 秒 | 52 秒 | 24 |
| 解题 | 34 秒 | 15 秒 | 1 分 34 秒 | 24 |
| 产物传输 | 3 秒 | 1 秒 | 6 秒 | 24 |
| 资源清理 | 6 秒 | 3 秒 | 10 秒 | 24 |
| 评分 | 0.52 毫秒 | 0.17 毫秒 | 2.11 毫秒 | 24 |
| 证据收集 | 17.99 毫秒 | 5.05 毫秒 | 126.42 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| b42b1f8b-95d5-499f-813f-b574fbfb1855 | 未设置 | 600 | 8 | 8 | 4800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 178,027 | 15,074 | 193,101 | 24 / 24 | — |
| 运行累计 | 178,027 | 15,074 | 193,101 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:9901 | completed | 1 | 34.93 | 0.00 | complete / not-produced | — | [result](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/216f2c88-c3a4-4f1e-b6e2-f97b90170961/result.json) · [文件清单](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/216f2c88-c3a4-4f1e-b6e2-f97b90170961/files.json) · [轨迹](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/216f2c88-c3a4-4f1e-b6e2-f97b90170961/agent/trajectory.jsonl) |
| test:9931 | completed | 1 | 94.46 | 0.00 | complete / not-produced | — | [result](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/154dc202-c53a-41f4-8ef5-30ecb26afa93/result.json) · [文件清单](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/154dc202-c53a-41f4-8ef5-30ecb26afa93/files.json) · [轨迹](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/154dc202-c53a-41f4-8ef5-30ecb26afa93/agent/trajectory.jsonl) |
| test:10127 | completed | 1 | 37.00 | 0.00 | complete / not-produced | — | [result](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/48ea95d0-4ff1-492b-bc99-b9529e3076d1/result.json) · [文件清单](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/48ea95d0-4ff1-492b-bc99-b9529e3076d1/files.json) · [轨迹](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/48ea95d0-4ff1-492b-bc99-b9529e3076d1/agent/trajectory.jsonl) |
| test:10140 | completed | 1 | 35.48 | 0.00 | complete / not-produced | — | [result](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/b9759a18-f852-429a-b0c9-b410c7c1cfe4/result.json) · [文件清单](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/b9759a18-f852-429a-b0c9-b410c7c1cfe4/files.json) · [轨迹](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/b9759a18-f852-429a-b0c9-b410c7c1cfe4/agent/trajectory.jsonl) |
| test:10174 | completed | 1 | 35.93 | 0.00 | complete / not-produced | — | [result](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/e57db978-c89b-43a0-9662-dbdc5fe87eea/result.json) · [文件清单](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/e57db978-c89b-43a0-9662-dbdc5fe87eea/files.json) · [轨迹](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/e57db978-c89b-43a0-9662-dbdc5fe87eea/agent/trajectory.jsonl) |
| test:10184 | completed | 1 | 37.16 | 0.00 | complete / not-produced | — | [result](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/70ce5a63-ce02-4d35-82be-24bb0706e57b/result.json) · [文件清单](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/70ce5a63-ce02-4d35-82be-24bb0706e57b/files.json) · [轨迹](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/70ce5a63-ce02-4d35-82be-24bb0706e57b/agent/trajectory.jsonl) |
| test:10189 | completed | 1 | 36.00 | 0.00 | complete / not-produced | — | [result](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/b767cf42-5095-494f-ad0a-447ec35b7623/result.json) · [文件清单](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/b767cf42-5095-494f-ad0a-447ec35b7623/files.json) · [轨迹](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/b767cf42-5095-494f-ad0a-447ec35b7623/agent/trajectory.jsonl) |
| test:10294 | completed | 1 | 37.85 | 0.00 | complete / not-produced | — | [result](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/84c0b260-9d3f-479d-8666-ff299239761b/result.json) · [文件清单](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/84c0b260-9d3f-479d-8666-ff299239761b/files.json) · [轨迹](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/84c0b260-9d3f-479d-8666-ff299239761b/agent/trajectory.jsonl) |
| test:10318 | completed | 1 | 32.31 | 0.00 | complete / not-produced | — | [result](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/53d1af56-d548-4a7b-85d4-a30be22f0002/result.json) · [文件清单](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/53d1af56-d548-4a7b-85d4-a30be22f0002/files.json) · [轨迹](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/53d1af56-d548-4a7b-85d4-a30be22f0002/agent/trajectory.jsonl) |
| test:10362 | completed | 1 | 34.34 | 0.00 | complete / not-produced | — | [result](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/15cd3881-aa42-4f27-89ee-84eb523695f2/result.json) · [文件清单](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/15cd3881-aa42-4f27-89ee-84eb523695f2/files.json) · [轨迹](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/15cd3881-aa42-4f27-89ee-84eb523695f2/agent/trajectory.jsonl) |
| test:10396 | completed | 1 | 30.86 | 0.00 | complete / not-produced | — | [result](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/baa758ae-17f0-45ce-a387-465265871fbf/result.json) · [文件清单](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/baa758ae-17f0-45ce-a387-465265871fbf/files.json) · [轨迹](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/baa758ae-17f0-45ce-a387-465265871fbf/agent/trajectory.jsonl) |
| test:10401 | completed | 1 | 31.14 | 0.00 | complete / not-produced | — | [result](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/6c8c0081-e9b0-4cfc-a77e-b0765e45c455/result.json) · [文件清单](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/6c8c0081-e9b0-4cfc-a77e-b0765e45c455/files.json) · [轨迹](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/6c8c0081-e9b0-4cfc-a77e-b0765e45c455/agent/trajectory.jsonl) |
| test:10403 | completed | 1 | 29.79 | 0.00 | complete / not-produced | — | [result](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/eeffc0d1-f47c-4299-a6d3-8460fc5bf047/result.json) · [文件清单](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/eeffc0d1-f47c-4299-a6d3-8460fc5bf047/files.json) · [轨迹](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/eeffc0d1-f47c-4299-a6d3-8460fc5bf047/agent/trajectory.jsonl) |
| test:10412 | completed | 1 | 30.82 | 0.00 | complete / not-produced | — | [result](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/0ab5e75c-7c35-4ed2-a132-3ddd55dfe7a7/result.json) · [文件清单](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/0ab5e75c-7c35-4ed2-a132-3ddd55dfe7a7/files.json) · [轨迹](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/0ab5e75c-7c35-4ed2-a132-3ddd55dfe7a7/agent/trajectory.jsonl) |
| test:10421 | completed | 1 | 38.90 | 0.00 | complete / not-produced | — | [result](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/81adabd8-08a0-40aa-9003-2f8cf26a00d5/result.json) · [文件清单](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/81adabd8-08a0-40aa-9003-2f8cf26a00d5/files.json) · [轨迹](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/81adabd8-08a0-40aa-9003-2f8cf26a00d5/agent/trajectory.jsonl) |
| test:10424 | completed | 0 | 26.73 | 0.00 | complete / not-produced | — | [result](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/b3c05d1b-5dde-4a4d-a779-bb6ef5e82378/result.json) · [文件清单](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/b3c05d1b-5dde-4a4d-a779-bb6ef5e82378/files.json) · [轨迹](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/b3c05d1b-5dde-4a4d-a779-bb6ef5e82378/agent/trajectory.jsonl) |
| test:10471 | completed | 1 | 26.21 | 0.00 | complete / not-produced | — | [result](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/e334ea2b-a1a4-4553-9a90-c2b9bde15200/result.json) · [文件清单](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/e334ea2b-a1a4-4553-9a90-c2b9bde15200/files.json) · [轨迹](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/e334ea2b-a1a4-4553-9a90-c2b9bde15200/agent/trajectory.jsonl) |
| test:10479 | completed | 1 | 27.59 | 0.00 | complete / not-produced | — | [result](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/e28fe4b3-3521-48a8-85fc-ccd08d60f9c0/result.json) · [文件清单](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/e28fe4b3-3521-48a8-85fc-ccd08d60f9c0/files.json) · [轨迹](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/e28fe4b3-3521-48a8-85fc-ccd08d60f9c0/agent/trajectory.jsonl) |
| test:10524 | completed | 1 | 28.68 | 0.00 | complete / not-produced | — | [result](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/a018c3ac-1922-41e3-8820-9de6ba7dd362/result.json) · [文件清单](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/a018c3ac-1922-41e3-8820-9de6ba7dd362/files.json) · [轨迹](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/a018c3ac-1922-41e3-8820-9de6ba7dd362/agent/trajectory.jsonl) |
| test:10607 | completed | 1 | 26.11 | 0.00 | complete / not-produced | — | [result](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/58965cab-c32e-483f-a9c1-e22d2c135bd1/result.json) · [文件清单](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/58965cab-c32e-483f-a9c1-e22d2c135bd1/files.json) · [轨迹](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/58965cab-c32e-483f-a9c1-e22d2c135bd1/agent/trajectory.jsonl) |
| test:10656 | completed | 1 | 26.51 | 0.00 | complete / not-produced | — | [result](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/28b7958c-91eb-4519-bf63-3b52123fc9b3/result.json) · [文件清单](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/28b7958c-91eb-4519-bf63-3b52123fc9b3/files.json) · [轨迹](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/28b7958c-91eb-4519-bf63-3b52123fc9b3/agent/trajectory.jsonl) |
| test:10674 | completed | 1 | 29.86 | 0.00 | complete / not-produced | — | [result](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/f665eaef-707e-4ad5-8525-ab6dd8b36f2a/result.json) · [文件清单](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/f665eaef-707e-4ad5-8525-ab6dd8b36f2a/files.json) · [轨迹](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/f665eaef-707e-4ad5-8525-ab6dd8b36f2a/agent/trajectory.jsonl) |
| test:10683 | completed | 1 | 25.68 | 0.00 | complete / not-produced | — | [result](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/3ea5898e-f925-4b35-9a4a-f391ecb45928/result.json) · [文件清单](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/3ea5898e-f925-4b35-9a4a-f391ecb45928/files.json) · [轨迹](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/3ea5898e-f925-4b35-9a4a-f391ecb45928/agent/trajectory.jsonl) |
| test:10690 | completed | 1 | 15.42 | 0.00 | complete / not-produced | — | [result](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/b93ae02a-72ca-4f36-a805-6aa3272118cc/result.json) · [文件清单](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/b93ae02a-72ca-4f36-a805-6aa3272118cc/files.json) · [轨迹](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/b93ae02a-72ca-4f36-a805-6aa3272118cc/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

