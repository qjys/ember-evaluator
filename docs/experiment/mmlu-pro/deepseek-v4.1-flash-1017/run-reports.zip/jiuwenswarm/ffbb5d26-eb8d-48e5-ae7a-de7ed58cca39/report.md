<!-- snapshotDigest: aae9fa980d564c40a0858e7a63c14c9faeb50462dc5bf2b805891d37b012ff8c -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 75.00%（18/24）**

Run: ffbb5d26-eb8d-48e5-ae7a-de7ed58cca39 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:27:21.716Z / 2026-11-12T08:38:03.776Z |
| 总耗时 | 10 分 27 秒 |
| 答对 / 答错 / 解题超时 | 18 / 6 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 18 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 75.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 10 分 27 秒 |
| 环境准备耗时 | 5 分 59 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 57 秒 | 1 分 36 秒 | 3 分 30 秒 | 24 |
| 任务准备 | 0.54 毫秒 | 0.31 毫秒 | 1.9 毫秒 | 24 |
| 环境启动 | 55 秒 | 41 秒 | 1 分 13 秒 | 24 |
| 解题 | 49 秒 | 35 秒 | 2 分 34 秒 | 24 |
| 产物传输 | 4 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 8 秒 | 5 秒 | 11 秒 | 24 |
| 评分 | 0.81 毫秒 | 0.26 毫秒 | 3.97 毫秒 | 24 |
| 证据收集 | 18.37 毫秒 | 6.52 毫秒 | 105.45 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 48eb55bc-c867-45f9-86b1-f340a8ad3d6a | 未设置 | 600 | 6 | 6 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 169,716 | 30,883 | 200,599 | 24 / 24 | — |
| 运行累计 | 169,716 | 30,883 | 200,599 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4879 | completed | 0 | 51.67 | 0.00 | complete / not-produced | — | [result](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/cab8c3a8-0144-44f9-af7a-a7d367e1ab17/result.json) · [文件清单](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/cab8c3a8-0144-44f9-af7a-a7d367e1ab17/files.json) · [轨迹](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/cab8c3a8-0144-44f9-af7a-a7d367e1ab17/agent/trajectory.jsonl) |
| test:5078 | completed | 1 | 48.35 | 0.00 | complete / not-produced | — | [result](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/e96a3084-1079-4796-a900-ad6e5a6f9d28/result.json) · [文件清单](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/e96a3084-1079-4796-a900-ad6e5a6f9d28/files.json) · [轨迹](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/e96a3084-1079-4796-a900-ad6e5a6f9d28/agent/trajectory.jsonl) |
| test:5123 | completed | 1 | 47.11 | 0.00 | complete / not-produced | — | [result](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/289fb99d-e0b8-4ec9-9e68-24888a925aa5/result.json) · [文件清单](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/289fb99d-e0b8-4ec9-9e68-24888a925aa5/files.json) · [轨迹](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/289fb99d-e0b8-4ec9-9e68-24888a925aa5/agent/trajectory.jsonl) |
| test:5174 | completed | 1 | 44.54 | 0.00 | complete / not-produced | — | [result](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/fd2b1938-923f-479f-a272-30f651c962bc/result.json) · [文件清单](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/fd2b1938-923f-479f-a272-30f651c962bc/files.json) · [轨迹](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/fd2b1938-923f-479f-a272-30f651c962bc/agent/trajectory.jsonl) |
| test:5198 | completed | 1 | 45.52 | 0.00 | complete / not-produced | — | [result](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/eb945c14-f8b5-4d73-b1ac-22294cb959e7/result.json) · [文件清单](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/eb945c14-f8b5-4d73-b1ac-22294cb959e7/files.json) · [轨迹](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/eb945c14-f8b5-4d73-b1ac-22294cb959e7/agent/trajectory.jsonl) |
| test:5243 | completed | 1 | 42.33 | 0.00 | complete / not-produced | — | [result](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/104550e3-e008-440a-8afa-57ca8cfe18f9/result.json) · [文件清单](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/104550e3-e008-440a-8afa-57ca8cfe18f9/files.json) · [轨迹](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/104550e3-e008-440a-8afa-57ca8cfe18f9/agent/trajectory.jsonl) |
| test:5309 | completed | 1 | 45.18 | 0.00 | complete / not-produced | — | [result](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/ff25f670-fd53-4e3d-be3c-53b612965e56/result.json) · [文件清单](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/ff25f670-fd53-4e3d-be3c-53b612965e56/files.json) · [轨迹](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/ff25f670-fd53-4e3d-be3c-53b612965e56/agent/trajectory.jsonl) |
| test:5319 | completed | 1 | 45.90 | 0.00 | complete / not-produced | — | [result](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/4976f0f1-bf34-41d6-9558-3cb354e56020/result.json) · [文件清单](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/4976f0f1-bf34-41d6-9558-3cb354e56020/files.json) · [轨迹](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/4976f0f1-bf34-41d6-9558-3cb354e56020/agent/trajectory.jsonl) |
| test:5328 | completed | 0 | 46.17 | 0.00 | complete / not-produced | — | [result](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/d6510539-06ec-4b7f-b643-683ebea011ff/result.json) · [文件清单](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/d6510539-06ec-4b7f-b643-683ebea011ff/files.json) · [轨迹](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/d6510539-06ec-4b7f-b643-683ebea011ff/agent/trajectory.jsonl) |
| test:5361 | completed | 0 | 102.01 | 0.00 | complete / not-produced | — | [result](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/781c5f6a-efe7-40ca-b9c6-65c01a9694b6/result.json) · [文件清单](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/781c5f6a-efe7-40ca-b9c6-65c01a9694b6/files.json) · [轨迹](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/781c5f6a-efe7-40ca-b9c6-65c01a9694b6/agent/trajectory.jsonl) |
| test:5457 | completed | 1 | 42.80 | 0.00 | complete / not-produced | — | [result](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/fe29875e-24d0-46d3-b760-3834412c6855/result.json) · [文件清单](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/fe29875e-24d0-46d3-b760-3834412c6855/files.json) · [轨迹](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/fe29875e-24d0-46d3-b760-3834412c6855/agent/trajectory.jsonl) |
| test:5461 | completed | 1 | 36.94 | 0.00 | complete / not-produced | — | [result](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/3d645572-f222-44e4-a4e9-7e864fedfc66/result.json) · [文件清单](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/3d645572-f222-44e4-a4e9-7e864fedfc66/files.json) · [轨迹](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/3d645572-f222-44e4-a4e9-7e864fedfc66/agent/trajectory.jsonl) |
| test:5530 | completed | 0 | 35.96 | 0.00 | complete / not-produced | — | [result](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/f5f59878-14a9-42e4-9d65-60964822220e/result.json) · [文件清单](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/f5f59878-14a9-42e4-9d65-60964822220e/files.json) · [轨迹](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/f5f59878-14a9-42e4-9d65-60964822220e/agent/trajectory.jsonl) |
| test:5578 | completed | 1 | 37.70 | 0.00 | complete / not-produced | — | [result](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/a54a4608-dc2b-4e7a-8f9e-610b98fd0509/result.json) · [文件清单](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/a54a4608-dc2b-4e7a-8f9e-610b98fd0509/files.json) · [轨迹](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/a54a4608-dc2b-4e7a-8f9e-610b98fd0509/agent/trajectory.jsonl) |
| test:5580 | completed | 1 | 38.10 | 0.00 | complete / not-produced | — | [result](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/996c0f91-9957-4c6d-93a4-a4470d7aa6d1/result.json) · [文件清单](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/996c0f91-9957-4c6d-93a4-a4470d7aa6d1/files.json) · [轨迹](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/996c0f91-9957-4c6d-93a4-a4470d7aa6d1/agent/trajectory.jsonl) |
| test:5795 | completed | 1 | 34.82 | 0.00 | complete / not-produced | — | [result](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/543f8988-8b75-4dc6-a00b-6662b7e6b9d0/result.json) · [文件清单](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/543f8988-8b75-4dc6-a00b-6662b7e6b9d0/files.json) · [轨迹](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/543f8988-8b75-4dc6-a00b-6662b7e6b9d0/agent/trajectory.jsonl) |
| test:5919 | completed | 0 | 154.29 | 0.00 | complete / not-produced | — | [result](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/5e2809ef-9992-48d8-b45d-38fe6fdf119c/result.json) · [文件清单](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/5e2809ef-9992-48d8-b45d-38fe6fdf119c/files.json) · [轨迹](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/5e2809ef-9992-48d8-b45d-38fe6fdf119c/agent/trajectory.jsonl) |
| test:5940 | completed | 1 | 38.20 | 0.00 | complete / not-produced | — | [result](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/3103da3c-c5ed-42eb-8f73-576cdf8cc998/result.json) · [文件清单](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/3103da3c-c5ed-42eb-8f73-576cdf8cc998/files.json) · [轨迹](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/3103da3c-c5ed-42eb-8f73-576cdf8cc998/agent/trajectory.jsonl) |
| test:6055 | completed | 1 | 36.98 | 0.00 | complete / not-produced | — | [result](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/3b120a97-246f-4216-bc56-0a31d531c023/result.json) · [文件清单](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/3b120a97-246f-4216-bc56-0a31d531c023/files.json) · [轨迹](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/3b120a97-246f-4216-bc56-0a31d531c023/agent/trajectory.jsonl) |
| test:6095 | completed | 1 | 36.05 | 0.00 | complete / not-produced | — | [result](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/9736f1d9-5f8c-4e00-988a-0073d8de913d/result.json) · [文件清单](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/9736f1d9-5f8c-4e00-988a-0073d8de913d/files.json) · [轨迹](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/9736f1d9-5f8c-4e00-988a-0073d8de913d/agent/trajectory.jsonl) |
| test:6120 | completed | 1 | 38.29 | 0.00 | complete / not-produced | — | [result](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/0b24222b-cd9d-4dae-a225-f2faf3bd4e53/result.json) · [文件清单](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/0b24222b-cd9d-4dae-a225-f2faf3bd4e53/files.json) · [轨迹](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/0b24222b-cd9d-4dae-a225-f2faf3bd4e53/agent/trajectory.jsonl) |
| test:6123 | completed | 1 | 41.82 | 0.00 | complete / not-produced | — | [result](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/1d4ac7e6-f7d8-4393-8e8f-0d69f7714468/result.json) · [文件清单](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/1d4ac7e6-f7d8-4393-8e8f-0d69f7714468/files.json) · [轨迹](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/1d4ac7e6-f7d8-4393-8e8f-0d69f7714468/agent/trajectory.jsonl) |
| test:6147 | completed | 1 | 46.01 | 0.00 | complete / not-produced | — | [result](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/9d37cf26-47f3-432d-9937-291121a10052/result.json) · [文件清单](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/9d37cf26-47f3-432d-9937-291121a10052/files.json) · [轨迹](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/9d37cf26-47f3-432d-9937-291121a10052/agent/trajectory.jsonl) |
| test:6198 | completed | 0 | 49.18 | 0.00 | complete / not-produced | — | [result](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/1b299233-0123-4ee2-baf3-cc6626d05e1b/result.json) · [文件清单](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/1b299233-0123-4ee2-baf3-cc6626d05e1b/files.json) · [轨迹](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/1b299233-0123-4ee2-baf3-cc6626d05e1b/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

