<!-- snapshotDigest: 7643aaa8ae3837c9a4eb792a2528daa4e5e586027572e86cb4d28f227dc0921d -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 66.67%（16/24）**

Run: c4962c68-96dc-4702-815d-6a2290ffc0c5 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:56:52.976Z / 2026-11-12T08:07:03.241Z |
| 总耗时 | 9 分 57 秒 |
| 答对 / 答错 / 解题超时 | 16 / 8 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 16 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 66.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 分 57 秒 |
| 环境准备耗时 | 5 分 52 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 21 秒 | 59 秒 | 2 分 28 秒 | 24 |
| 任务准备 | 0.66 毫秒 | 0.29 毫秒 | 3.42 毫秒 | 24 |
| 环境启动 | 38 秒 | 27 秒 | 51 秒 | 24 |
| 解题 | 36 秒 | 22 秒 | 1 分 51 秒 | 24 |
| 产物传输 | 2 秒 | 907.76 毫秒 | 3 秒 | 24 |
| 资源清理 | 5 秒 | 2 秒 | 8 秒 | 24 |
| 评分 | 1.17 毫秒 | 0.3 毫秒 | 3.84 毫秒 | 24 |
| 证据收集 | 19.94 毫秒 | 4.83 毫秒 | 54.93 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 7557427b-46bf-4f55-891f-1dcea74ed719 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 176,394 | 24,990 | 201,384 | 24 / 24 | — |
| 运行累计 | 176,394 | 24,990 | 201,384 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:841 | completed | 0 | 33.92 | 0.00 | complete / not-produced | — | [result](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/a6976326-3137-499f-9fc9-28332940dc41/result.json) · [文件清单](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/a6976326-3137-499f-9fc9-28332940dc41/files.json) · [轨迹](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/a6976326-3137-499f-9fc9-28332940dc41/agent/trajectory.jsonl) |
| test:883 | completed | 1 | 30.11 | 0.00 | complete / not-produced | — | [result](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/9cff8d4d-d523-46e0-9a27-8fb62ccac7b4/result.json) · [文件清单](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/9cff8d4d-d523-46e0-9a27-8fb62ccac7b4/files.json) · [轨迹](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/9cff8d4d-d523-46e0-9a27-8fb62ccac7b4/agent/trajectory.jsonl) |
| test:938 | completed | 1 | 33.31 | 0.00 | complete / not-produced | — | [result](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/c8e3dda1-b106-401e-ad97-43f1e97c21a0/result.json) · [文件清单](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/c8e3dda1-b106-401e-ad97-43f1e97c21a0/files.json) · [轨迹](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/c8e3dda1-b106-401e-ad97-43f1e97c21a0/agent/trajectory.jsonl) |
| test:1026 | completed | 0 | 34.13 | 0.00 | complete / not-produced | — | [result](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/b442226b-4046-453e-b978-da983bb387b1/result.json) · [文件清单](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/b442226b-4046-453e-b978-da983bb387b1/files.json) · [轨迹](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/b442226b-4046-453e-b978-da983bb387b1/agent/trajectory.jsonl) |
| test:1229 | completed | 1 | 28.27 | 0.00 | complete / not-produced | — | [result](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/8ff6ccfa-e7bc-4ae0-b71d-90270b817115/result.json) · [文件清单](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/8ff6ccfa-e7bc-4ae0-b71d-90270b817115/files.json) · [轨迹](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/8ff6ccfa-e7bc-4ae0-b71d-90270b817115/agent/trajectory.jsonl) |
| test:1252 | completed | 1 | 22.10 | 0.00 | complete / not-produced | — | [result](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/687eb5f5-5c45-415c-896c-089da45c9d20/result.json) · [文件清单](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/687eb5f5-5c45-415c-896c-089da45c9d20/files.json) · [轨迹](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/687eb5f5-5c45-415c-896c-089da45c9d20/agent/trajectory.jsonl) |
| test:1399 | completed | 1 | 25.92 | 0.00 | complete / not-produced | — | [result](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/4692e4ea-7cd2-4a33-afde-2b706670b423/result.json) · [文件清单](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/4692e4ea-7cd2-4a33-afde-2b706670b423/files.json) · [轨迹](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/4692e4ea-7cd2-4a33-afde-2b706670b423/agent/trajectory.jsonl) |
| test:1454 | completed | 1 | 41.84 | 0.00 | complete / not-produced | — | [result](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/66f7ff49-b434-4b40-a680-c8c5d50a48e4/result.json) · [文件清单](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/66f7ff49-b434-4b40-a680-c8c5d50a48e4/files.json) · [轨迹](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/66f7ff49-b434-4b40-a680-c8c5d50a48e4/agent/trajectory.jsonl) |
| test:1514 | completed | 0 | 32.64 | 0.00 | complete / not-produced | — | [result](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/e40360c4-aa02-4ad6-b7a5-438841507af2/result.json) · [文件清单](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/e40360c4-aa02-4ad6-b7a5-438841507af2/files.json) · [轨迹](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/e40360c4-aa02-4ad6-b7a5-438841507af2/agent/trajectory.jsonl) |
| test:1531 | completed | 0 | 57.01 | 0.00 | complete / not-produced | — | [result](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/272f96f9-e5b9-4d11-ab36-d269bd859e8e/result.json) · [文件清单](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/272f96f9-e5b9-4d11-ab36-d269bd859e8e/files.json) · [轨迹](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/272f96f9-e5b9-4d11-ab36-d269bd859e8e/agent/trajectory.jsonl) |
| test:1785 | completed | 0 | 111.35 | 0.00 | complete / not-produced | — | [result](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/456aa2c3-705c-454f-9f93-d079e602c763/result.json) · [文件清单](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/456aa2c3-705c-454f-9f93-d079e602c763/files.json) · [轨迹](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/456aa2c3-705c-454f-9f93-d079e602c763/agent/trajectory.jsonl) |
| test:1806 | completed | 0 | 28.70 | 0.00 | complete / not-produced | — | [result](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/486752ce-cf64-451b-8d31-3c00bb6998c6/result.json) · [文件清单](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/486752ce-cf64-451b-8d31-3c00bb6998c6/files.json) · [轨迹](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/486752ce-cf64-451b-8d31-3c00bb6998c6/agent/trajectory.jsonl) |
| test:1827 | completed | 1 | 25.96 | 0.00 | complete / not-produced | — | [result](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/9a1428c9-d6f6-4591-9379-c2f37a6ba7ea/result.json) · [文件清单](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/9a1428c9-d6f6-4591-9379-c2f37a6ba7ea/files.json) · [轨迹](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/9a1428c9-d6f6-4591-9379-c2f37a6ba7ea/agent/trajectory.jsonl) |
| test:1904 | completed | 1 | 26.68 | 0.00 | complete / not-produced | — | [result](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/4d22f191-71a2-43e0-9da4-4fd40eca1e84/result.json) · [文件清单](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/4d22f191-71a2-43e0-9da4-4fd40eca1e84/files.json) · [轨迹](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/4d22f191-71a2-43e0-9da4-4fd40eca1e84/agent/trajectory.jsonl) |
| test:1943 | completed | 1 | 25.91 | 0.00 | complete / not-produced | — | [result](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/f03bd04f-9ca4-4e5b-90b2-60e6c0f01a03/result.json) · [文件清单](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/f03bd04f-9ca4-4e5b-90b2-60e6c0f01a03/files.json) · [轨迹](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/f03bd04f-9ca4-4e5b-90b2-60e6c0f01a03/agent/trajectory.jsonl) |
| test:1998 | completed | 1 | 26.75 | 0.00 | complete / not-produced | — | [result](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/40654c5e-7cd4-4f3a-92ad-baa0a125e334/result.json) · [文件清单](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/40654c5e-7cd4-4f3a-92ad-baa0a125e334/files.json) · [轨迹](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/40654c5e-7cd4-4f3a-92ad-baa0a125e334/agent/trajectory.jsonl) |
| test:2023 | completed | 1 | 26.58 | 0.00 | complete / not-produced | — | [result](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/5e3ca0b2-c4ea-48f5-b1b2-c445b3793a6d/result.json) · [文件清单](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/5e3ca0b2-c4ea-48f5-b1b2-c445b3793a6d/files.json) · [轨迹](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/5e3ca0b2-c4ea-48f5-b1b2-c445b3793a6d/agent/trajectory.jsonl) |
| test:2096 | completed | 0 | 31.94 | 0.00 | complete / not-produced | — | [result](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/72869561-b347-4288-a45b-1502220b4706/result.json) · [文件清单](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/72869561-b347-4288-a45b-1502220b4706/files.json) · [轨迹](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/72869561-b347-4288-a45b-1502220b4706/agent/trajectory.jsonl) |
| test:2152 | completed | 1 | 30.92 | 0.00 | complete / not-produced | — | [result](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/73100604-5fc1-4779-8784-552e5e0c5c44/result.json) · [文件清单](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/73100604-5fc1-4779-8784-552e5e0c5c44/files.json) · [轨迹](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/73100604-5fc1-4779-8784-552e5e0c5c44/agent/trajectory.jsonl) |
| test:2175 | completed | 1 | 32.67 | 0.00 | complete / not-produced | — | [result](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/12dd7eee-06aa-4391-80d2-2f15c91b22d0/result.json) · [文件清单](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/12dd7eee-06aa-4391-80d2-2f15c91b22d0/files.json) · [轨迹](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/12dd7eee-06aa-4391-80d2-2f15c91b22d0/agent/trajectory.jsonl) |
| test:2177 | completed | 1 | 39.36 | 0.00 | complete / not-produced | — | [result](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/6423c087-ea42-41ff-8473-8c0267a4102d/result.json) · [文件清单](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/6423c087-ea42-41ff-8473-8c0267a4102d/files.json) · [轨迹](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/6423c087-ea42-41ff-8473-8c0267a4102d/agent/trajectory.jsonl) |
| test:2206 | completed | 1 | 40.07 | 0.00 | complete / not-produced | — | [result](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/feb9e9f4-1343-4107-991d-c451b518c1a0/result.json) · [文件清单](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/feb9e9f4-1343-4107-991d-c451b518c1a0/files.json) · [轨迹](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/feb9e9f4-1343-4107-991d-c451b518c1a0/agent/trajectory.jsonl) |
| test:2280 | completed | 1 | 40.16 | 0.00 | complete / not-produced | — | [result](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/1c52cbaa-fe9f-47ba-9a5d-43ac175eb49c/result.json) · [文件清单](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/1c52cbaa-fe9f-47ba-9a5d-43ac175eb49c/files.json) · [轨迹](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/1c52cbaa-fe9f-47ba-9a5d-43ac175eb49c/agent/trajectory.jsonl) |
| test:2347 | completed | 0 | 39.66 | 0.00 | complete / not-produced | — | [result](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/a3c1c682-750f-47f7-bf4f-2eb1b5cc1b5c/result.json) · [文件清单](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/a3c1c682-750f-47f7-bf4f-2eb1b5cc1b5c/files.json) · [轨迹](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/a3c1c682-750f-47f7-bf4f-2eb1b5cc1b5c/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

