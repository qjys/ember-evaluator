<!-- snapshotDigest: 36b42e60d4fa92118c78af54fc57d82269dd660d861b17a6b20c6d21d75e3b34 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 91.67%（22/24）**

Run: 0738818a-5e50-47f5-996d-b91996579046 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:07:14.674Z / 2026-11-12T08:18:32.839Z |
| 总耗时 | 11 分 0 秒 |
| 答对 / 答错 / 解题超时 | 22 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 22 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 91.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 11 分 0 秒 |
| 环境准备耗时 | 6 分 32 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 38 秒 | 1 分 19 秒 | 2 分 14 秒 | 24 |
| 任务准备 | 0.58 毫秒 | 0.27 毫秒 | 2.68 毫秒 | 24 |
| 环境启动 | 49 秒 | 38 秒 | 1 分 4 秒 | 24 |
| 解题 | 39 秒 | 29 秒 | 1 分 20 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 6 秒 | 24 |
| 资源清理 | 7 秒 | 5 秒 | 9 秒 | 24 |
| 评分 | 1.37 毫秒 | 0.28 毫秒 | 8.33 毫秒 | 24 |
| 证据收集 | 24.74 毫秒 | 4.6 毫秒 | 86.96 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 55b9d843-fc97-460a-bbec-7a48cf069653 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 177,158 | 13,691 | 190,849 | 24 / 24 | — |
| 运行累计 | 177,158 | 13,691 | 190,849 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:2400 | completed | 1 | 42.45 | 0.00 | complete / not-produced | — | [result](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/a0af47a9-f3a0-46c9-be7f-21ccddfc451e/result.json) · [文件清单](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/a0af47a9-f3a0-46c9-be7f-21ccddfc451e/files.json) · [轨迹](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/a0af47a9-f3a0-46c9-be7f-21ccddfc451e/agent/trajectory.jsonl) |
| test:2527 | completed | 1 | 42.09 | 0.00 | complete / not-produced | — | [result](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/999671f5-1746-4ea8-89c4-2b489e3405b0/result.json) · [文件清单](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/999671f5-1746-4ea8-89c4-2b489e3405b0/files.json) · [轨迹](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/999671f5-1746-4ea8-89c4-2b489e3405b0/agent/trajectory.jsonl) |
| test:2636 | completed | 1 | 41.14 | 0.00 | complete / not-produced | — | [result](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/fae28445-c420-4198-b916-7d21235187ca/result.json) · [文件清单](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/fae28445-c420-4198-b916-7d21235187ca/files.json) · [轨迹](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/fae28445-c420-4198-b916-7d21235187ca/agent/trajectory.jsonl) |
| test:2641 | completed | 1 | 40.66 | 0.00 | complete / not-produced | — | [result](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/03ddbe80-ca69-40e8-bfa8-e9317ad40f1f/result.json) · [文件清单](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/03ddbe80-ca69-40e8-bfa8-e9317ad40f1f/files.json) · [轨迹](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/03ddbe80-ca69-40e8-bfa8-e9317ad40f1f/agent/trajectory.jsonl) |
| test:2714 | completed | 1 | 29.08 | 0.00 | complete / not-produced | — | [result](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/eb7ebb37-46fe-4d8c-8cb7-858e7ecae1f2/result.json) · [文件清单](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/eb7ebb37-46fe-4d8c-8cb7-858e7ecae1f2/files.json) · [轨迹](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/eb7ebb37-46fe-4d8c-8cb7-858e7ecae1f2/agent/trajectory.jsonl) |
| test:2716 | completed | 1 | 34.00 | 0.00 | complete / not-produced | — | [result](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/fc30a638-7a19-402a-bfd4-b10909cf86a1/result.json) · [文件清单](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/fc30a638-7a19-402a-bfd4-b10909cf86a1/files.json) · [轨迹](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/fc30a638-7a19-402a-bfd4-b10909cf86a1/agent/trajectory.jsonl) |
| test:2747 | completed | 1 | 30.62 | 0.00 | complete / not-produced | — | [result](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/e143188c-7536-40dc-99f8-dc68c118fd5e/result.json) · [文件清单](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/e143188c-7536-40dc-99f8-dc68c118fd5e/files.json) · [轨迹](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/e143188c-7536-40dc-99f8-dc68c118fd5e/agent/trajectory.jsonl) |
| test:2882 | completed | 0 | 32.06 | 0.00 | complete / not-produced | — | [result](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/1c89a1ab-2119-4869-8518-6634af6f042e/result.json) · [文件清单](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/1c89a1ab-2119-4869-8518-6634af6f042e/files.json) · [轨迹](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/1c89a1ab-2119-4869-8518-6634af6f042e/agent/trajectory.jsonl) |
| test:2951 | completed | 1 | 42.98 | 0.00 | complete / not-produced | — | [result](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/dfcf22bc-ed44-43f1-b9cf-890b6c8cf319/result.json) · [文件清单](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/dfcf22bc-ed44-43f1-b9cf-890b6c8cf319/files.json) · [轨迹](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/dfcf22bc-ed44-43f1-b9cf-890b6c8cf319/agent/trajectory.jsonl) |
| test:3037 | completed | 1 | 40.51 | 0.00 | complete / not-produced | — | [result](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/6c27c7d6-f308-45fa-95d3-69171e222415/result.json) · [文件清单](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/6c27c7d6-f308-45fa-95d3-69171e222415/files.json) · [轨迹](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/6c27c7d6-f308-45fa-95d3-69171e222415/agent/trajectory.jsonl) |
| test:3053 | completed | 1 | 44.64 | 0.00 | complete / not-produced | — | [result](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/b191c349-1edc-4729-9f0b-e9fafda4c302/result.json) · [文件清单](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/b191c349-1edc-4729-9f0b-e9fafda4c302/files.json) · [轨迹](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/b191c349-1edc-4729-9f0b-e9fafda4c302/agent/trajectory.jsonl) |
| test:3136 | completed | 1 | 41.43 | 0.00 | complete / not-produced | — | [result](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/3c12966f-47fe-4198-ba3c-eea4b5d83199/result.json) · [文件清单](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/3c12966f-47fe-4198-ba3c-eea4b5d83199/files.json) · [轨迹](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/3c12966f-47fe-4198-ba3c-eea4b5d83199/agent/trajectory.jsonl) |
| test:3165 | completed | 1 | 42.16 | 0.00 | complete / not-produced | — | [result](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/b4739de4-d48f-4725-b55f-9baebe699027/result.json) · [文件清单](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/b4739de4-d48f-4725-b55f-9baebe699027/files.json) · [轨迹](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/b4739de4-d48f-4725-b55f-9baebe699027/agent/trajectory.jsonl) |
| test:3196 | completed | 1 | 39.59 | 0.00 | complete / not-produced | — | [result](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/c23d5c99-1d63-4817-b0aa-d906e1f2543b/result.json) · [文件清单](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/c23d5c99-1d63-4817-b0aa-d906e1f2543b/files.json) · [轨迹](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/c23d5c99-1d63-4817-b0aa-d906e1f2543b/agent/trajectory.jsonl) |
| test:3231 | completed | 1 | 36.23 | 0.00 | complete / not-produced | — | [result](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/bc6f9e2a-24e9-4dfb-bd51-ab30c8a93351/result.json) · [文件清单](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/bc6f9e2a-24e9-4dfb-bd51-ab30c8a93351/files.json) · [轨迹](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/bc6f9e2a-24e9-4dfb-bd51-ab30c8a93351/agent/trajectory.jsonl) |
| test:3236 | completed | 1 | 35.56 | 0.00 | complete / not-produced | — | [result](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/07c5df97-76b8-45d7-8a72-4aad549e886a/result.json) · [文件清单](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/07c5df97-76b8-45d7-8a72-4aad549e886a/files.json) · [轨迹](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/07c5df97-76b8-45d7-8a72-4aad549e886a/agent/trajectory.jsonl) |
| test:3270 | completed | 1 | 30.79 | 0.00 | complete / not-produced | — | [result](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/6d007929-5903-452a-a7e6-3049860cc896/result.json) · [文件清单](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/6d007929-5903-452a-a7e6-3049860cc896/files.json) · [轨迹](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/6d007929-5903-452a-a7e6-3049860cc896/agent/trajectory.jsonl) |
| test:3293 | completed | 1 | 30.42 | 0.00 | complete / not-produced | — | [result](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/af51dab5-35df-4e88-a947-eebf93aba358/result.json) · [文件清单](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/af51dab5-35df-4e88-a947-eebf93aba358/files.json) · [轨迹](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/af51dab5-35df-4e88-a947-eebf93aba358/agent/trajectory.jsonl) |
| test:3331 | completed | 1 | 32.46 | 0.00 | complete / not-produced | — | [result](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/e8b4c8cf-a2c0-48b3-b191-3b98bd3dd0d8/result.json) · [文件清单](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/e8b4c8cf-a2c0-48b3-b191-3b98bd3dd0d8/files.json) · [轨迹](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/e8b4c8cf-a2c0-48b3-b191-3b98bd3dd0d8/agent/trajectory.jsonl) |
| test:3488 | completed | 1 | 40.97 | 0.00 | complete / not-produced | — | [result](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/c86c09b9-0cde-4589-9d2a-99c5bf94c476/result.json) · [文件清单](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/c86c09b9-0cde-4589-9d2a-99c5bf94c476/files.json) · [轨迹](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/c86c09b9-0cde-4589-9d2a-99c5bf94c476/agent/trajectory.jsonl) |
| test:3491 | completed | 0 | 79.62 | 0.01 | complete / not-produced | — | [result](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/6bb32dd0-b9c2-4f4b-82df-328ea9e1d107/result.json) · [文件清单](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/6bb32dd0-b9c2-4f4b-82df-328ea9e1d107/files.json) · [轨迹](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/6bb32dd0-b9c2-4f4b-82df-328ea9e1d107/agent/trajectory.jsonl) |
| test:3552 | completed | 1 | 36.80 | 0.00 | complete / not-produced | — | [result](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/d33512bc-d77a-474c-ba73-43a60639f2e0/result.json) · [文件清单](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/d33512bc-d77a-474c-ba73-43a60639f2e0/files.json) · [轨迹](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/d33512bc-d77a-474c-ba73-43a60639f2e0/agent/trajectory.jsonl) |
| test:3599 | completed | 1 | 33.11 | 0.00 | complete / not-produced | — | [result](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/a9f39f88-e857-487a-82e5-516255819b2d/result.json) · [文件清单](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/a9f39f88-e857-487a-82e5-516255819b2d/files.json) · [轨迹](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/a9f39f88-e857-487a-82e5-516255819b2d/agent/trajectory.jsonl) |
| test:3626 | completed | 1 | 36.00 | 0.00 | complete / not-produced | — | [result](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/0794f381-01a8-4715-9a78-16ae10bb8b76/result.json) · [文件清单](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/0794f381-01a8-4715-9a78-16ae10bb8b76/files.json) · [轨迹](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/0794f381-01a8-4715-9a78-16ae10bb8b76/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

