<!-- snapshotDigest: e89ccf43c6a3077d08b7165e1d02c93984daf68ec690d9a57374e18822661566 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 91.67%（22/24）**

Run: b87243b1-88cf-4bca-a6bb-bea307848f63 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:38:18.005Z / 2026-11-12T08:46:07.126Z |
| 总耗时 | 7 分 40 秒 |
| 答对 / 答错 / 解题超时 | 22 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 22 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 91.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 7 分 40 秒 |
| 环境准备耗时 | 4 分 40 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 56 秒 | 1 分 43 秒 | 2 分 7 秒 | 24 |
| 任务准备 | 0.61 毫秒 | 0.29 毫秒 | 3.18 毫秒 | 24 |
| 环境启动 | 1 分 1 秒 | 50 秒 | 1 分 8 秒 | 24 |
| 解题 | 41 秒 | 36 秒 | 54 秒 | 24 |
| 产物传输 | 4 秒 | 3 秒 | 7 秒 | 24 |
| 资源清理 | 9 秒 | 6 秒 | 14 秒 | 24 |
| 评分 | 0.67 毫秒 | 0.29 毫秒 | 2.09 毫秒 | 24 |
| 证据收集 | 25.82 毫秒 | 4.46 毫秒 | 108.21 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 0a9cd8ce-43ed-4e81-9921-e11ba4362f66 | 未设置 | 600 | 8 | 8 | 4800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 174,403 | 8,614 | 183,017 | 24 / 24 | — |
| 运行累计 | 174,403 | 8,614 | 183,017 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:6223 | completed | 1 | 36.44 | 0.00 | complete / not-produced | — | [result](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/7a68d7b3-ac8e-4e28-b947-addb5ed19cfe/result.json) · [文件清单](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/7a68d7b3-ac8e-4e28-b947-addb5ed19cfe/files.json) · [轨迹](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/7a68d7b3-ac8e-4e28-b947-addb5ed19cfe/agent/trajectory.jsonl) |
| test:6235 | completed | 1 | 37.98 | 0.00 | complete / not-produced | — | [result](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/5164bd83-1518-459f-8882-cf6c08daa645/result.json) · [文件清单](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/5164bd83-1518-459f-8882-cf6c08daa645/files.json) · [轨迹](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/5164bd83-1518-459f-8882-cf6c08daa645/agent/trajectory.jsonl) |
| test:6403 | completed | 1 | 43.53 | 0.00 | complete / not-produced | — | [result](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/1196eaa0-7ab4-455a-b929-8ef747b01df6/result.json) · [文件清单](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/1196eaa0-7ab4-455a-b929-8ef747b01df6/files.json) · [轨迹](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/1196eaa0-7ab4-455a-b929-8ef747b01df6/agent/trajectory.jsonl) |
| test:6436 | completed | 1 | 40.59 | 0.00 | complete / not-produced | — | [result](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/0bcd9964-1d7d-44f1-b160-89060accec77/result.json) · [文件清单](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/0bcd9964-1d7d-44f1-b160-89060accec77/files.json) · [轨迹](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/0bcd9964-1d7d-44f1-b160-89060accec77/agent/trajectory.jsonl) |
| test:6508 | completed | 1 | 42.14 | 0.00 | complete / not-produced | — | [result](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/b0c76674-7f21-45e7-848c-9686c7ea6cec/result.json) · [文件清单](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/b0c76674-7f21-45e7-848c-9686c7ea6cec/files.json) · [轨迹](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/b0c76674-7f21-45e7-848c-9686c7ea6cec/agent/trajectory.jsonl) |
| test:6593 | completed | 1 | 37.67 | 0.00 | complete / not-produced | — | [result](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/6dbf2e58-d317-40c4-8edd-b1f8ee2aed3e/result.json) · [文件清单](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/6dbf2e58-d317-40c4-8edd-b1f8ee2aed3e/files.json) · [轨迹](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/6dbf2e58-d317-40c4-8edd-b1f8ee2aed3e/agent/trajectory.jsonl) |
| test:6655 | completed | 0 | 37.88 | 0.00 | complete / not-produced | — | [result](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/6f9301bf-8f3f-44c2-82d1-6424f097775a/result.json) · [文件清单](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/6f9301bf-8f3f-44c2-82d1-6424f097775a/files.json) · [轨迹](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/6f9301bf-8f3f-44c2-82d1-6424f097775a/agent/trajectory.jsonl) |
| test:6738 | completed | 1 | 41.11 | 0.00 | complete / not-produced | — | [result](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/dc3c4f84-65ae-4bba-b116-428594628a9d/result.json) · [文件清单](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/dc3c4f84-65ae-4bba-b116-428594628a9d/files.json) · [轨迹](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/dc3c4f84-65ae-4bba-b116-428594628a9d/agent/trajectory.jsonl) |
| test:6751 | completed | 1 | 37.73 | 0.00 | complete / not-produced | — | [result](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/d29a7f41-b15a-4c6e-b817-1243a98aafea/result.json) · [文件清单](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/d29a7f41-b15a-4c6e-b817-1243a98aafea/files.json) · [轨迹](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/d29a7f41-b15a-4c6e-b817-1243a98aafea/agent/trajectory.jsonl) |
| test:6784 | completed | 1 | 37.17 | 0.00 | complete / not-produced | — | [result](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/26e5f535-14de-4e12-9158-6fd02fe2b65e/result.json) · [文件清单](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/26e5f535-14de-4e12-9158-6fd02fe2b65e/files.json) · [轨迹](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/26e5f535-14de-4e12-9158-6fd02fe2b65e/agent/trajectory.jsonl) |
| test:6792 | completed | 1 | 41.76 | 0.00 | complete / not-produced | — | [result](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/59f4a3c5-757e-4144-8123-bc83a51884e5/result.json) · [文件清单](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/59f4a3c5-757e-4144-8123-bc83a51884e5/files.json) · [轨迹](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/59f4a3c5-757e-4144-8123-bc83a51884e5/agent/trajectory.jsonl) |
| test:6900 | completed | 1 | 39.32 | 0.00 | complete / not-produced | — | [result](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/5c5c3d85-a444-4660-abce-5027d4139d4e/result.json) · [文件清单](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/5c5c3d85-a444-4660-abce-5027d4139d4e/files.json) · [轨迹](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/5c5c3d85-a444-4660-abce-5027d4139d4e/agent/trajectory.jsonl) |
| test:6928 | completed | 1 | 38.15 | 0.00 | complete / not-produced | — | [result](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/c2334991-818d-4ce7-8980-01f21f13fc13/result.json) · [文件清单](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/c2334991-818d-4ce7-8980-01f21f13fc13/files.json) · [轨迹](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/c2334991-818d-4ce7-8980-01f21f13fc13/agent/trajectory.jsonl) |
| test:6929 | completed | 1 | 39.27 | 0.00 | complete / not-produced | — | [result](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/437aa293-ae89-4f51-aea1-6478af9c338d/result.json) · [文件清单](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/437aa293-ae89-4f51-aea1-6478af9c338d/files.json) · [轨迹](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/437aa293-ae89-4f51-aea1-6478af9c338d/agent/trajectory.jsonl) |
| test:7161 | completed | 1 | 53.70 | 0.00 | complete / not-produced | — | [result](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/56026653-62a0-4df7-a6b5-7a5cb519ad53/result.json) · [文件清单](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/56026653-62a0-4df7-a6b5-7a5cb519ad53/files.json) · [轨迹](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/56026653-62a0-4df7-a6b5-7a5cb519ad53/agent/trajectory.jsonl) |
| test:7181 | completed | 1 | 44.22 | 0.00 | complete / not-produced | — | [result](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/7da9ca9c-02c7-4b9b-bdda-29cfe37ff081/result.json) · [文件清单](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/7da9ca9c-02c7-4b9b-bdda-29cfe37ff081/files.json) · [轨迹](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/7da9ca9c-02c7-4b9b-bdda-29cfe37ff081/agent/trajectory.jsonl) |
| test:7217 | completed | 1 | 47.23 | 0.00 | complete / not-produced | — | [result](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/98f18715-fe86-4243-a5ca-be3db323a9f0/result.json) · [文件清单](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/98f18715-fe86-4243-a5ca-be3db323a9f0/files.json) · [轨迹](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/98f18715-fe86-4243-a5ca-be3db323a9f0/agent/trajectory.jsonl) |
| test:7290 | completed | 1 | 46.07 | 0.00 | complete / not-produced | — | [result](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/de7efe69-ca23-4e6e-88be-42296acba6fc/result.json) · [文件清单](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/de7efe69-ca23-4e6e-88be-42296acba6fc/files.json) · [轨迹](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/de7efe69-ca23-4e6e-88be-42296acba6fc/agent/trajectory.jsonl) |
| test:7304 | completed | 1 | 43.77 | 0.00 | complete / not-produced | — | [result](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/770bcaac-5b53-44d2-a35f-0d9b4b22c318/result.json) · [文件清单](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/770bcaac-5b53-44d2-a35f-0d9b4b22c318/files.json) · [轨迹](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/770bcaac-5b53-44d2-a35f-0d9b4b22c318/agent/trajectory.jsonl) |
| test:7312 | completed | 1 | 42.88 | 0.00 | complete / not-produced | — | [result](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/3c82a263-c5c5-4a3e-a112-ccd220701557/result.json) · [文件清单](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/3c82a263-c5c5-4a3e-a112-ccd220701557/files.json) · [轨迹](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/3c82a263-c5c5-4a3e-a112-ccd220701557/agent/trajectory.jsonl) |
| test:7448 | completed | 0 | 41.67 | 0.00 | complete / not-produced | — | [result](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/e0032cc7-e228-458e-8885-c4a60431b171/result.json) · [文件清单](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/e0032cc7-e228-458e-8885-c4a60431b171/files.json) · [轨迹](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/e0032cc7-e228-458e-8885-c4a60431b171/agent/trajectory.jsonl) |
| test:7462 | completed | 1 | 37.80 | 0.00 | complete / not-produced | — | [result](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/81a2da73-f8ad-4785-8243-47a052c640b9/result.json) · [文件清单](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/81a2da73-f8ad-4785-8243-47a052c640b9/files.json) · [轨迹](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/81a2da73-f8ad-4785-8243-47a052c640b9/agent/trajectory.jsonl) |
| test:7526 | completed | 1 | 35.89 | 0.00 | complete / not-produced | — | [result](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/f20f1a3b-67ab-4f1a-9742-9a5f4f81eb1d/result.json) · [文件清单](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/f20f1a3b-67ab-4f1a-9742-9a5f4f81eb1d/files.json) · [轨迹](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/f20f1a3b-67ab-4f1a-9742-9a5f4f81eb1d/agent/trajectory.jsonl) |
| test:7727 | completed | 1 | 38.38 | 0.00 | complete / not-produced | — | [result](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/5d388465-8049-40f9-9f0f-c29ef4af0e4e/result.json) · [文件清单](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/5d388465-8049-40f9-9f0f-c29ef4af0e4e/files.json) · [轨迹](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/5d388465-8049-40f9-9f0f-c29ef4af0e4e/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

