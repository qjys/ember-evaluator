<!-- snapshotDigest: 579e7e876efc7a337d1d204b0bad727e44331779cc6ca5960255e94cd77a2f69 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 0.52%（1/194）**

Run: 8e0017d9-d433-4744-9e83-2e7c329c4200 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:46:31.811Z / 2026-11-12T07:51:50.022Z |
| 总耗时 | 5 分 12 秒 |
| 答对 / 答错 / 解题超时 | 1 / 1 / 0 |
| 清理未确认 | 1 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 195 题；已保存 3 条记录；待运行 192 题。
有效评分覆盖率：2/195（1.03%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 195 |
| 计分题数 | 194 |
| 正常评分题数 | 2 |
| 答对题数 | 1 |
| 无效评测 | 1 |
| 待运行 | 192 |
| 正确率 | 0.52% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 12 秒 |
| 环境准备耗时 | 5 分 15 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 21 秒 | 1 分 2 秒 | 1 分 39 秒 | 3 |
| 任务准备 | 1.14 毫秒 | 0.45 毫秒 | 2.48 毫秒 | 3 |
| 环境启动 | 46 秒 | 37 秒 | 59 秒 | 3 |
| 解题 | 23 秒 | 20 秒 | 25 秒 | 3 |
| 产物传输 | 1 秒 | 1 秒 | 1 秒 | 3 |
| 资源清理 | 10 秒 | 4 秒 | 14 秒 | 3 |
| 评分 | 6.03 毫秒 | 4.55 毫秒 | 7.51 毫秒 | 2 |
| 证据收集 | 22.99 毫秒 | 13.13 毫秒 | 33.14 毫秒 | 3 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 3b9426ad-5268-4528-8b40-bbec258c4255 | 未设置 | 600 | 1 | 1 | 600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 21,636 | 1,168 | 22,804 | 3 / 195 | — |
| 运行累计 | 21,636 | 1,168 | 22,804 | 3 / 3 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:41 | completed | 1 | 19.51 | 0.01 | complete / not-produced | — | [result](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/d194d658-88ec-4762-97f6-8076cf2dfc67/result.json) · [文件清单](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/d194d658-88ec-4762-97f6-8076cf2dfc67/files.json) · [轨迹](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/d194d658-88ec-4762-97f6-8076cf2dfc67/agent/trajectory.jsonl) |
| test:61 | completed | 0 | 25.31 | 0.00 | complete / not-produced | — | [result](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/9e29f77d-5d57-4f7e-9ff1-6fc078a73613/result.json) · [文件清单](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/9e29f77d-5d57-4f7e-9ff1-6fc078a73613/files.json) · [轨迹](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/9e29f77d-5d57-4f7e-9ff1-6fc078a73613/agent/trajectory.jsonl) |
| test:841 | invalid | — | 24.93 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/9285e615-a80a-4cae-a32e-fb8ef20143d5/result.json) · [文件清单](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/9285e615-a80a-4cae-a32e-fb8ef20143d5/files.json) · [轨迹](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/9285e615-a80a-4cae-a32e-fb8ef20143d5/agent/trajectory.jsonl) |
| test:883 | pending | — | — | — | — | — | — |
| test:938 | pending | — | — | — | — | — | — |
| test:1026 | pending | — | — | — | — | — | — |
| test:1229 | pending | — | — | — | — | — | — |
| test:1252 | pending | — | — | — | — | — | — |
| test:1399 | pending | — | — | — | — | — | — |
| test:1454 | pending | — | — | — | — | — | — |
| test:1514 | pending | — | — | — | — | — | — |
| test:1531 | pending | — | — | — | — | — | — |
| test:1785 | pending | — | — | — | — | — | — |
| test:1806 | pending | — | — | — | — | — | — |
| test:1827 | pending | — | — | — | — | — | — |
| test:1904 | pending | — | — | — | — | — | — |
| test:1943 | pending | — | — | — | — | — | — |
| test:1998 | pending | — | — | — | — | — | — |
| test:2023 | pending | — | — | — | — | — | — |
| test:2096 | pending | — | — | — | — | — | — |
| test:2152 | pending | — | — | — | — | — | — |
| test:2175 | pending | — | — | — | — | — | — |
| test:2177 | pending | — | — | — | — | — | — |
| test:2206 | pending | — | — | — | — | — | — |
| test:2280 | pending | — | — | — | — | — | — |
| test:2347 | pending | — | — | — | — | — | — |
| test:2400 | pending | — | — | — | — | — | — |
| test:2527 | pending | — | — | — | — | — | — |
| test:2636 | pending | — | — | — | — | — | — |
| test:2641 | pending | — | — | — | — | — | — |
| test:2714 | pending | — | — | — | — | — | — |
| test:2716 | pending | — | — | — | — | — | — |
| test:2747 | pending | — | — | — | — | — | — |
| test:2882 | pending | — | — | — | — | — | — |
| test:2951 | pending | — | — | — | — | — | — |
| test:3037 | pending | — | — | — | — | — | — |
| test:3053 | pending | — | — | — | — | — | — |
| test:3136 | pending | — | — | — | — | — | — |
| test:3165 | pending | — | — | — | — | — | — |
| test:3196 | pending | — | — | — | — | — | — |
| test:3231 | pending | — | — | — | — | — | — |
| test:3236 | pending | — | — | — | — | — | — |
| test:3270 | pending | — | — | — | — | — | — |
| test:3293 | pending | — | — | — | — | — | — |
| test:3331 | pending | — | — | — | — | — | — |
| test:3488 | pending | — | — | — | — | — | — |
| test:3491 | pending | — | — | — | — | — | — |
| test:3552 | pending | — | — | — | — | — | — |
| test:3599 | pending | — | — | — | — | — | — |
| test:3626 | pending | — | — | — | — | — | — |
| test:4021 | pending | — | — | — | — | — | — |
| test:4034 | pending | — | — | — | — | — | — |
| test:4058 | pending | — | — | — | — | — | — |
| test:4075 | pending | — | — | — | — | — | — |
| test:4142 | pending | — | — | — | — | — | — |
| test:4208 | pending | — | — | — | — | — | — |
| test:4298 | pending | — | — | — | — | — | — |
| test:4337 | pending | — | — | — | — | — | — |
| test:4376 | pending | — | — | — | — | — | — |
| test:4405 | pending | — | — | — | — | — | — |
| test:4552 | pending | — | — | — | — | — | — |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 0；证据收集 0；资源清理 2）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| cleanup | CLEANUP_FAILED | 1 | 2 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

