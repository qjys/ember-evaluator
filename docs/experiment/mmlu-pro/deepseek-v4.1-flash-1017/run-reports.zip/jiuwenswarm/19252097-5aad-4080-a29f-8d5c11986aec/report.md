<!-- snapshotDigest: 5f1c3775691893063773a2a8e1d29ff6fa30a195e1091c73716fd8c5b980adcd -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 7.28%（15/206）**

Run: 19252097-5aad-4080-a29f-8d5c11986aec · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:30:04.821Z / 2026-11-12T07:43:13.239Z |
| 总耗时 | 12 分 51 秒 |
| 答对 / 答错 / 解题超时 | 15 / 0 / 0 |
| 清理未确认 | 1 |
| 轨迹不完整 / 产物不完整 | 2 / 0 |

已选择 210 题；已保存 19 条记录；待运行 192 题。
有效评分覆盖率：15/210（7.14%）。
执行失败 3；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 4。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 210 |
| 计分题数 | 206 |
| 正常评分题数 | 15 |
| 答对题数 | 15 |
| 无效评测 | 4 |
| 待运行 | 192 |
| 正确率 | 7.28% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 12 分 51 秒 |
| 环境准备耗时 | 13 分 3 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 16 秒 | 19 秒 | 3 分 12 秒 | 19 |
| 任务准备 | 0.51 毫秒 | 0.34 毫秒 | 1.82 毫秒 | 19 |
| 环境启动 | 37 秒 | 16 秒 | 1 分 5 秒 | 19 |
| 解题 | 34 秒 | 22 秒 | 2 分 35 秒 | 18 |
| 资源清理 | 6 秒 | 3 秒 | 13 秒 | 18 |
| 证据收集 | 30.55 毫秒 | 3.14 毫秒 | 95.14 毫秒 | 19 |
| 产物传输 | 2 秒 | 1 秒 | 4 秒 | 16 |
| 评分 | 1.73 毫秒 | 0.53 毫秒 | 3 毫秒 | 15 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 54302cb7-7048-4fc6-9113-8e4bfdbeade9 | 未设置 | 600 | 2 | 2 | 1200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 115,004 | 23,462 | 138,466 | 16 / 210 | — |
| 运行累计 | 115,004 | 23,462 | 138,466 | 16 / 19 | 3 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:41 | invalid | — | 34.56 | — | partial / not-produced | INTERNAL\_ERROR; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/a6017884-1749-44af-b4b1-e07d869f9274/result.json) · [文件清单](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/a6017884-1749-44af-b4b1-e07d869f9274/files.json) · [轨迹](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/a6017884-1749-44af-b4b1-e07d869f9274/agent/trajectory.jsonl) |
| test:61 | invalid | — | 33.08 | — | partial / not-produced | INTERNAL\_ERROR; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/e8fab1e9-8d14-4f20-9cc7-a5fa67c8a2ee/result.json) · [文件清单](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/e8fab1e9-8d14-4f20-9cc7-a5fa67c8a2ee/files.json) · [轨迹](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/e8fab1e9-8d14-4f20-9cc7-a5fa67c8a2ee/agent/trajectory.jsonl) |
| test:97 | completed | 1 | 23.39 | 0.00 | complete / not-produced | — | [result](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/0fbef12c-ebf8-4f16-b888-5216073462d8/result.json) · [文件清单](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/0fbef12c-ebf8-4f16-b888-5216073462d8/files.json) · [轨迹](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/0fbef12c-ebf8-4f16-b888-5216073462d8/agent/trajectory.jsonl) |
| test:209 | completed | 1 | 22.77 | 0.00 | complete / not-produced | — | [result](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/fc0f755d-6167-4449-9246-bc4e9e055135/result.json) · [文件清单](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/fc0f755d-6167-4449-9246-bc4e9e055135/files.json) · [轨迹](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/fc0f755d-6167-4449-9246-bc4e9e055135/agent/trajectory.jsonl) |
| test:286 | completed | 1 | 24.84 | 0.00 | complete / not-produced | — | [result](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/eaf783bf-d6cc-45a9-b0a8-4c5b0e87f5ed/result.json) · [文件清单](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/eaf783bf-d6cc-45a9-b0a8-4c5b0e87f5ed/files.json) · [轨迹](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/eaf783bf-d6cc-45a9-b0a8-4c5b0e87f5ed/agent/trajectory.jsonl) |
| test:299 | completed | 1 | 23.50 | 0.00 | complete / not-produced | — | [result](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/300898a5-bf4b-49f3-b707-44d7dd6fef54/result.json) · [文件清单](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/300898a5-bf4b-49f3-b707-44d7dd6fef54/files.json) · [轨迹](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/300898a5-bf4b-49f3-b707-44d7dd6fef54/agent/trajectory.jsonl) |
| test:311 | completed | 1 | 30.99 | 0.00 | complete / not-produced | — | [result](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/5868ba4f-e7a2-4d8b-bb7b-4c8b957d6aca/result.json) · [文件清单](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/5868ba4f-e7a2-4d8b-bb7b-4c8b957d6aca/files.json) · [轨迹](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/5868ba4f-e7a2-4d8b-bb7b-4c8b957d6aca/agent/trajectory.jsonl) |
| test:352 | completed | 1 | 25.29 | 0.00 | complete / not-produced | — | [result](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/80d085f5-c610-4775-83a9-b0ffb3301301/result.json) · [文件清单](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/80d085f5-c610-4775-83a9-b0ffb3301301/files.json) · [轨迹](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/80d085f5-c610-4775-83a9-b0ffb3301301/agent/trajectory.jsonl) |
| test:355 | completed | 1 | 24.24 | 0.00 | complete / not-produced | — | [result](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/732d19ad-5d1c-49d7-8b0f-0bcf6232fa7c/result.json) · [文件清单](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/732d19ad-5d1c-49d7-8b0f-0bcf6232fa7c/files.json) · [轨迹](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/732d19ad-5d1c-49d7-8b0f-0bcf6232fa7c/agent/trajectory.jsonl) |
| test:476 | completed | 1 | 34.51 | 0.00 | complete / not-produced | — | [result](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/7d9964e4-2eca-46bb-862a-7fe27ba3ba15/result.json) · [文件清单](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/7d9964e4-2eca-46bb-862a-7fe27ba3ba15/files.json) · [轨迹](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/7d9964e4-2eca-46bb-862a-7fe27ba3ba15/agent/trajectory.jsonl) |
| test:511 | completed | 1 | 23.19 | 0.00 | complete / not-produced | — | [result](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/9f2a2a47-8a08-43aa-ad3e-591c9e71880f/result.json) · [文件清单](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/9f2a2a47-8a08-43aa-ad3e-591c9e71880f/files.json) · [轨迹](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/9f2a2a47-8a08-43aa-ad3e-591c9e71880f/agent/trajectory.jsonl) |
| test:552 | completed | 1 | 23.80 | 0.00 | complete / not-produced | — | [result](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/494dc1a3-d27b-4e1d-8671-80d1bbc9d36a/result.json) · [文件清单](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/494dc1a3-d27b-4e1d-8671-80d1bbc9d36a/files.json) · [轨迹](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/494dc1a3-d27b-4e1d-8671-80d1bbc9d36a/agent/trajectory.jsonl) |
| test:624 | completed | 1 | 23.90 | 0.00 | complete / not-produced | — | [result](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/d19b204c-4545-4f9b-93cc-d137e30b1938/result.json) · [文件清单](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/d19b204c-4545-4f9b-93cc-d137e30b1938/files.json) · [轨迹](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/d19b204c-4545-4f9b-93cc-d137e30b1938/agent/trajectory.jsonl) |
| test:669 | completed | 1 | 23.55 | 0.00 | complete / not-produced | — | [result](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/e07768f3-45e4-40c4-a4f9-6069191c50ac/result.json) · [文件清单](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/e07768f3-45e4-40c4-a4f9-6069191c50ac/files.json) · [轨迹](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/e07768f3-45e4-40c4-a4f9-6069191c50ac/agent/trajectory.jsonl) |
| test:670 | completed | 1 | 21.59 | 0.00 | complete / not-produced | — | [result](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/c28087a5-b79c-4e9c-a3d2-e9407a7d3c16/result.json) · [文件清单](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/c28087a5-b79c-4e9c-a3d2-e9407a7d3c16/files.json) · [轨迹](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/c28087a5-b79c-4e9c-a3d2-e9407a7d3c16/agent/trajectory.jsonl) |
| test:796 | completed | 1 | 154.70 | 0.00 | complete / not-produced | — | [result](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/735916a5-e99c-4e36-bc3f-40c1a7f4700e/result.json) · [文件清单](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/735916a5-e99c-4e36-bc3f-40c1a7f4700e/files.json) · [轨迹](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/735916a5-e99c-4e36-bc3f-40c1a7f4700e/agent/trajectory.jsonl) |
| test:828 | completed | 1 | 26.69 | 0.00 | complete / not-produced | — | [result](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/0450c020-15c0-4111-a552-a82a925f8360/result.json) · [文件清单](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/0450c020-15c0-4111-a552-a82a925f8360/files.json) · [轨迹](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/0450c020-15c0-4111-a552-a82a925f8360/agent/trajectory.jsonl) |
| test:841 | invalid | — | 29.35 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/65c4b192-6cc7-4beb-827f-15923ce28397/result.json) · [文件清单](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/65c4b192-6cc7-4beb-827f-15923ce28397/files.json) · [轨迹](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/65c4b192-6cc7-4beb-827f-15923ce28397/agent/trajectory.jsonl) |
| test:883 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/5666f440-f089-4152-b798-4add612be4bc/result.json) · [文件清单](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/5666f440-f089-4152-b798-4add612be4bc/files.json) |
| test:938 | pending | — | — | — | — | — | — |
| test:1026 | pending | — | — | — | — | — | — |
| test:1229 | pending | — | — | — | — | — | — |
| test:1252 | pending | — | — | — | — | — | — |
| test:1399 | pending | — | — | — | — | — | — |
| test:1454 | pending | — | — | — | — | — | — |
| test:1514 | pending | — | — | — | — | — | — |
| test:1531 | pending | — | — | — | — | — | — |
| test:1785 | pending | — | — | — | — | — | — |
| test:1806 | pending | — | — | — | — | — | — |
| test:1827 | pending | — | — | — | — | — | — |
| test:1904 | pending | — | — | — | — | — | — |
| test:1943 | pending | — | — | — | — | — | — |
| test:1998 | pending | — | — | — | — | — | — |
| test:2023 | pending | — | — | — | — | — | — |
| test:2096 | pending | — | — | — | — | — | — |
| test:2152 | pending | — | — | — | — | — | — |
| test:2175 | pending | — | — | — | — | — | — |
| test:2177 | pending | — | — | — | — | — | — |
| test:2206 | pending | — | — | — | — | — | — |
| test:2280 | pending | — | — | — | — | — | — |
| test:2347 | pending | — | — | — | — | — | — |
| test:2400 | pending | — | — | — | — | — | — |
| test:2527 | pending | — | — | — | — | — | — |
| test:2636 | pending | — | — | — | — | — | — |
| test:2641 | pending | — | — | — | — | — | — |
| test:2714 | pending | — | — | — | — | — | — |
| test:2716 | pending | — | — | — | — | — | — |
| test:2747 | pending | — | — | — | — | — | — |
| test:2882 | pending | — | — | — | — | — | — |
| test:2951 | pending | — | — | — | — | — | — |
| test:3037 | pending | — | — | — | — | — | — |
| test:3053 | pending | — | — | — | — | — | — |
| test:3136 | pending | — | — | — | — | — | — |
| test:3165 | pending | — | — | — | — | — | — |
| test:3196 | pending | — | — | — | — | — | — |
| test:3231 | pending | — | — | — | — | — | — |
| test:3236 | pending | — | — | — | — | — | — |
| test:3270 | pending | — | — | — | — | — | — |
| test:3293 | pending | — | — | — | — | — | — |
| test:3331 | pending | — | — | — | — | — | — |
| test:3488 | pending | — | — | — | — | — | — |
| test:3491 | pending | — | — | — | — | — | — |
| test:3552 | pending | — | — | — | — | — | — |
| test:3599 | pending | — | — | — | — | — | — |
| test:3626 | pending | — | — | — | — | — | — |
| test:4021 | pending | — | — | — | — | — | — |
| test:4034 | pending | — | — | — | — | — | — |
| test:4058 | pending | — | — | — | — | — | — |
| test:4075 | pending | — | — | — | — | — | — |
| test:4142 | pending | — | — | — | — | — | — |
| test:4208 | pending | — | — | — | — | — | — |
| test:4298 | pending | — | — | — | — | — | — |
| test:4337 | pending | — | — | — | — | — | — |
| test:4376 | pending | — | — | — | — | — | — |
| test:4405 | pending | — | — | — | — | — | — |
| test:4552 | pending | — | — | — | — | — | — |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 4；错误记录 7（主流程 3；证据收集 2；资源清理 2）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | INTERNAL_ERROR | 2 | 2 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 2 | 2 |
| cleanup | CLEANUP_FAILED | 1 | 2 |
| environment | RUN_CANCELLED | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

