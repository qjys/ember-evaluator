<!-- snapshotDigest: e8032f8f5ba05d8446e0b2d634f0c70ba768ffc90b22c3d19368e59e647baee2 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: 87103fdf-f813-4b4c-bc89-12fe29211adc · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:46:19.711Z / 2026-11-12T08:53:11.437Z |
| 总耗时 | 6 分 43 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 6 分 43 秒 |
| 环境准备耗时 | 4 分 25 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 43 秒 | 1 分 21 秒 | 2 分 2 秒 | 24 |
| 任务准备 | 0.49 毫秒 | 0.28 毫秒 | 1.27 毫秒 | 24 |
| 环境启动 | 54 秒 | 40 秒 | 1 分 11 秒 | 24 |
| 解题 | 38 秒 | 30 秒 | 46 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 9 秒 | 24 |
| 资源清理 | 7 秒 | 4 秒 | 12 秒 | 24 |
| 评分 | 0.69 毫秒 | 0.3 毫秒 | 2.09 毫秒 | 24 |
| 证据收集 | 22.88 毫秒 | 5.09 毫秒 | 182.62 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| d0639587-12c7-474f-8578-6778e508a3f2 | 未设置 | 600 | 8 | 8 | 4800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 180,046 | 10,591 | 190,637 | 24 / 24 | — |
| 运行累计 | 180,046 | 10,591 | 190,637 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:7752 | completed | 0 | 45.90 | 0.00 | complete / not-produced | — | [result](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/33f2ad95-a063-4c5d-bf08-fffd26e74686/result.json) · [文件清单](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/33f2ad95-a063-4c5d-bf08-fffd26e74686/files.json) · [轨迹](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/33f2ad95-a063-4c5d-bf08-fffd26e74686/agent/trajectory.jsonl) |
| test:7838 | completed | 1 | 44.93 | 0.00 | complete / not-produced | — | [result](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/2a55e419-5922-47fc-800c-35ce5c41a3e3/result.json) · [文件清单](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/2a55e419-5922-47fc-800c-35ce5c41a3e3/files.json) · [轨迹](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/2a55e419-5922-47fc-800c-35ce5c41a3e3/agent/trajectory.jsonl) |
| test:7954 | completed | 1 | 39.66 | 0.00 | complete / not-produced | — | [result](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/7ad1dda0-bd96-4406-a7db-2e20ce061a8c/result.json) · [文件清单](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/7ad1dda0-bd96-4406-a7db-2e20ce061a8c/files.json) · [轨迹](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/7ad1dda0-bd96-4406-a7db-2e20ce061a8c/agent/trajectory.jsonl) |
| test:7976 | completed | 1 | 35.06 | 0.00 | complete / not-produced | — | [result](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/733a393e-042f-4acb-9eee-03baca0f8400/result.json) · [文件清单](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/733a393e-042f-4acb-9eee-03baca0f8400/files.json) · [轨迹](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/733a393e-042f-4acb-9eee-03baca0f8400/agent/trajectory.jsonl) |
| test:8199 | completed | 1 | 43.62 | 0.00 | complete / not-produced | — | [result](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/fdd7f9d8-7030-47ec-86b3-5e149ae35675/result.json) · [文件清单](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/fdd7f9d8-7030-47ec-86b3-5e149ae35675/files.json) · [轨迹](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/fdd7f9d8-7030-47ec-86b3-5e149ae35675/agent/trajectory.jsonl) |
| test:8207 | completed | 1 | 41.27 | 0.00 | complete / not-produced | — | [result](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/d0ee0827-4699-46e0-8620-22dd5e68944c/result.json) · [文件清单](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/d0ee0827-4699-46e0-8620-22dd5e68944c/files.json) · [轨迹](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/d0ee0827-4699-46e0-8620-22dd5e68944c/agent/trajectory.jsonl) |
| test:8304 | completed | 1 | 42.15 | 0.00 | complete / not-produced | — | [result](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/91c311ec-f4d7-4fa7-9cf6-f0abd103bc93/result.json) · [文件清单](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/91c311ec-f4d7-4fa7-9cf6-f0abd103bc93/files.json) · [轨迹](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/91c311ec-f4d7-4fa7-9cf6-f0abd103bc93/agent/trajectory.jsonl) |
| test:8366 | completed | 1 | 44.86 | 0.00 | complete / not-produced | — | [result](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/0971a3db-db15-4f71-8359-bd47a846a0b5/result.json) · [文件清单](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/0971a3db-db15-4f71-8359-bd47a846a0b5/files.json) · [轨迹](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/0971a3db-db15-4f71-8359-bd47a846a0b5/agent/trajectory.jsonl) |
| test:8511 | completed | 1 | 35.35 | 0.00 | complete / not-produced | — | [result](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/ffa75be3-9f95-44d1-ac6b-67cc4806a135/result.json) · [文件清单](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/ffa75be3-9f95-44d1-ac6b-67cc4806a135/files.json) · [轨迹](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/ffa75be3-9f95-44d1-ac6b-67cc4806a135/agent/trajectory.jsonl) |
| test:8525 | completed | 1 | 38.42 | 0.00 | complete / not-produced | — | [result](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/5e274647-2954-4d3d-b0cc-9fdcabde75f0/result.json) · [文件清单](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/5e274647-2954-4d3d-b0cc-9fdcabde75f0/files.json) · [轨迹](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/5e274647-2954-4d3d-b0cc-9fdcabde75f0/agent/trajectory.jsonl) |
| test:8604 | completed | 1 | 36.43 | 0.00 | complete / not-produced | — | [result](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/f5abf9d3-4038-49d2-9744-e5af689c1b87/result.json) · [文件清单](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/f5abf9d3-4038-49d2-9744-e5af689c1b87/files.json) · [轨迹](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/f5abf9d3-4038-49d2-9744-e5af689c1b87/agent/trajectory.jsonl) |
| test:8740 | completed | 1 | 37.36 | 0.00 | complete / not-produced | — | [result](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/193a0813-17c6-456a-89e6-2d9ff083a8ca/result.json) · [文件清单](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/193a0813-17c6-456a-89e6-2d9ff083a8ca/files.json) · [轨迹](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/193a0813-17c6-456a-89e6-2d9ff083a8ca/agent/trajectory.jsonl) |
| test:8839 | completed | 1 | 32.23 | 0.00 | complete / not-produced | — | [result](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/2c22e710-18d3-47eb-aec2-19d53c4744d5/result.json) · [文件清单](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/2c22e710-18d3-47eb-aec2-19d53c4744d5/files.json) · [轨迹](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/2c22e710-18d3-47eb-aec2-19d53c4744d5/agent/trajectory.jsonl) |
| test:8939 | completed | 1 | 36.06 | 0.00 | complete / not-produced | — | [result](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/1f5ff0ac-78c9-4523-97a5-f01e9491b842/result.json) · [文件清单](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/1f5ff0ac-78c9-4523-97a5-f01e9491b842/files.json) · [轨迹](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/1f5ff0ac-78c9-4523-97a5-f01e9491b842/agent/trajectory.jsonl) |
| test:8967 | completed | 1 | 32.74 | 0.00 | complete / not-produced | — | [result](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/a1a568cb-475c-4dd7-803b-391dc3c56eb7/result.json) · [文件清单](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/a1a568cb-475c-4dd7-803b-391dc3c56eb7/files.json) · [轨迹](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/a1a568cb-475c-4dd7-803b-391dc3c56eb7/agent/trajectory.jsonl) |
| test:8989 | completed | 1 | 30.04 | 0.00 | complete / not-produced | — | [result](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/6ef49b8b-51f3-400d-b38a-788116e6e7e3/result.json) · [文件清单](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/6ef49b8b-51f3-400d-b38a-788116e6e7e3/files.json) · [轨迹](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/6ef49b8b-51f3-400d-b38a-788116e6e7e3/agent/trajectory.jsonl) |
| test:9136 | completed | 1 | 35.72 | 0.00 | complete / not-produced | — | [result](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/0a8470e8-d15d-46ef-9a99-a26de5abaa53/result.json) · [文件清单](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/0a8470e8-d15d-46ef-9a99-a26de5abaa53/files.json) · [轨迹](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/0a8470e8-d15d-46ef-9a99-a26de5abaa53/agent/trajectory.jsonl) |
| test:9222 | completed | 1 | 34.22 | 0.00 | complete / not-produced | — | [result](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/b757ab61-9f4b-45bc-8377-9eaa2a78d1ff/result.json) · [文件清单](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/b757ab61-9f4b-45bc-8377-9eaa2a78d1ff/files.json) · [轨迹](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/b757ab61-9f4b-45bc-8377-9eaa2a78d1ff/agent/trajectory.jsonl) |
| test:9391 | completed | 1 | 35.15 | 0.00 | complete / not-produced | — | [result](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/13d4a391-82af-4b74-8793-d2e546d427e8/result.json) · [文件清单](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/13d4a391-82af-4b74-8793-d2e546d427e8/files.json) · [轨迹](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/13d4a391-82af-4b74-8793-d2e546d427e8/agent/trajectory.jsonl) |
| test:9395 | completed | 1 | 41.75 | 0.00 | complete / not-produced | — | [result](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/380a1354-8e15-4182-8b83-81e955088260/result.json) · [文件清单](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/380a1354-8e15-4182-8b83-81e955088260/files.json) · [轨迹](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/380a1354-8e15-4182-8b83-81e955088260/agent/trajectory.jsonl) |
| test:9405 | completed | 1 | 43.91 | 0.00 | complete / not-produced | — | [result](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/43e90705-1f22-4a8d-9810-4a4d9c6e21e5/result.json) · [文件清单](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/43e90705-1f22-4a8d-9810-4a4d9c6e21e5/files.json) · [轨迹](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/43e90705-1f22-4a8d-9810-4a4d9c6e21e5/agent/trajectory.jsonl) |
| test:9769 | completed | 1 | 31.55 | 0.00 | complete / not-produced | — | [result](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/fab962d7-e228-4f04-b4ca-e12411b439cd/result.json) · [文件清单](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/fab962d7-e228-4f04-b4ca-e12411b439cd/files.json) · [轨迹](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/fab962d7-e228-4f04-b4ca-e12411b439cd/agent/trajectory.jsonl) |
| test:9843 | completed | 1 | 34.43 | 0.00 | complete / not-produced | — | [result](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/8eede4c4-f95c-418a-94fc-33948a095a6f/result.json) · [文件清单](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/8eede4c4-f95c-418a-94fc-33948a095a6f/files.json) · [轨迹](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/8eede4c4-f95c-418a-94fc-33948a095a6f/agent/trajectory.jsonl) |
| test:9864 | completed | 1 | 30.17 | 0.00 | complete / not-produced | — | [result](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/1f16b5fc-4aec-48f9-8c15-707032bceab3/result.json) · [文件清单](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/1f16b5fc-4aec-48f9-8c15-707032bceab3/files.json) · [轨迹](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/1f16b5fc-4aec-48f9-8c15-707032bceab3/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

