<!-- snapshotDigest: f3e216df73fa64ca6a7f9bca31b5943cb44f50f05184234799b087f24bb004e2 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 27.67%（57/206）**

Run: 427fda75-a5a9-4be3-a9fe-f883ad69554f · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:02:50.819Z / 2026-11-12T07:23:44.172Z |
| 总耗时 | 20 分 11 秒 |
| 答对 / 答错 / 解题超时 | 57 / 11 / 0 |
| 清理未确认 | 2 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 210 题；已保存 72 条记录；待运行 141 题。
有效评分覆盖率：68/210（32.38%）。
执行失败 1；超时 0；取消 3；不支持 0。
Agent 解题超时 0（计 0 分）；无效 4。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 210 |
| 计分题数 | 206 |
| 正常评分题数 | 68 |
| 答对题数 | 57 |
| 无效评测 | 4 |
| 待运行 | 141 |
| 正确率 | 27.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 20 分 11 秒 |
| 环境准备耗时 | 20 分 50 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 38 秒 | 12 秒 | 1 分 44 秒 | 72 |
| 任务准备 | 0.48 毫秒 | 0.18 毫秒 | 4.81 毫秒 | 72 |
| 环境启动 | 18 秒 | 6 秒 | 43 秒 | 72 |
| 解题 | 13 秒 | 5 秒 | 1 分 24 秒 | 70 |
| 产物传输 | 2 秒 | 1 秒 | 5 秒 | 70 |
| 资源清理 | 6 秒 | 3 秒 | 14 秒 | 70 |
| 评分 | 0.46 毫秒 | 0.2 毫秒 | 2.27 毫秒 | 68 |
| 证据收集 | 21.14 毫秒 | 1.12 毫秒 | 255.51 毫秒 | 72 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 4f1686ce-c12b-4e9e-91e0-7cc010863218 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 94,559 | 60,263 | 154,822 | 70 / 210 | — |
| 运行累计 | 94,559 | 60,263 | 154,822 | 70 / 72 | 2 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:41 | completed | 1 | 5.09 | 0.00 | complete / not-produced | — | [result](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/56d09cf1-cac1-47f8-8b6c-8c5f7d6d0499/result.json) · [文件清单](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/56d09cf1-cac1-47f8-8b6c-8c5f7d6d0499/files.json) · [轨迹](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/56d09cf1-cac1-47f8-8b6c-8c5f7d6d0499/agent/trajectory.jsonl) |
| test:61 | completed | 0 | 23.57 | 0.00 | complete / not-produced | — | [result](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/fd712d23-0475-4c05-9e6d-aa544daa12cd/result.json) · [文件清单](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/fd712d23-0475-4c05-9e6d-aa544daa12cd/files.json) · [轨迹](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/fd712d23-0475-4c05-9e6d-aa544daa12cd/agent/trajectory.jsonl) |
| test:97 | completed | 1 | 36.67 | 0.00 | complete / not-produced | — | [result](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/5492cc50-d2be-42bb-afeb-28318c35aa15/result.json) · [文件清单](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/5492cc50-d2be-42bb-afeb-28318c35aa15/files.json) · [轨迹](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/5492cc50-d2be-42bb-afeb-28318c35aa15/agent/trajectory.jsonl) |
| test:209 | completed | 1 | 5.89 | 0.00 | complete / not-produced | — | [result](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/6cbb1acf-f192-40f2-b646-51222d2f81bd/result.json) · [文件清单](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/6cbb1acf-f192-40f2-b646-51222d2f81bd/files.json) · [轨迹](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/6cbb1acf-f192-40f2-b646-51222d2f81bd/agent/trajectory.jsonl) |
| test:286 | completed | 1 | 5.99 | 0.00 | complete / not-produced | — | [result](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/4157cd4d-8271-4b2e-b63d-2f9d4091261f/result.json) · [文件清单](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/4157cd4d-8271-4b2e-b63d-2f9d4091261f/files.json) · [轨迹](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/4157cd4d-8271-4b2e-b63d-2f9d4091261f/agent/trajectory.jsonl) |
| test:299 | completed | 1 | 7.65 | 0.00 | complete / not-produced | — | [result](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/db390b7a-c013-4426-8067-2e81b3999366/result.json) · [文件清单](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/db390b7a-c013-4426-8067-2e81b3999366/files.json) · [轨迹](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/db390b7a-c013-4426-8067-2e81b3999366/agent/trajectory.jsonl) |
| test:311 | completed | 1 | 14.77 | 0.00 | complete / not-produced | — | [result](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/44030e78-fe05-4680-8d45-6c3bb3c43b95/result.json) · [文件清单](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/44030e78-fe05-4680-8d45-6c3bb3c43b95/files.json) · [轨迹](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/44030e78-fe05-4680-8d45-6c3bb3c43b95/agent/trajectory.jsonl) |
| test:352 | completed | 1 | 5.96 | 0.00 | complete / not-produced | — | [result](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/2453411e-f1ea-4aa4-8398-b5b3e4e3eef8/result.json) · [文件清单](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/2453411e-f1ea-4aa4-8398-b5b3e4e3eef8/files.json) · [轨迹](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/2453411e-f1ea-4aa4-8398-b5b3e4e3eef8/agent/trajectory.jsonl) |
| test:355 | completed | 1 | 5.33 | 0.00 | complete / not-produced | — | [result](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/d238a462-052c-4742-9d30-007a394242b5/result.json) · [文件清单](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/d238a462-052c-4742-9d30-007a394242b5/files.json) · [轨迹](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/d238a462-052c-4742-9d30-007a394242b5/agent/trajectory.jsonl) |
| test:476 | completed | 1 | 9.96 | 0.00 | complete / not-produced | — | [result](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/ca872263-b23e-428e-b734-90309af76413/result.json) · [文件清单](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/ca872263-b23e-428e-b734-90309af76413/files.json) · [轨迹](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/ca872263-b23e-428e-b734-90309af76413/agent/trajectory.jsonl) |
| test:511 | completed | 1 | 10.02 | 0.00 | complete / not-produced | — | [result](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/56ae0004-978b-4581-9744-bb5edad9bd01/result.json) · [文件清单](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/56ae0004-978b-4581-9744-bb5edad9bd01/files.json) · [轨迹](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/56ae0004-978b-4581-9744-bb5edad9bd01/agent/trajectory.jsonl) |
| test:552 | completed | 1 | 7.46 | 0.00 | complete / not-produced | — | [result](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/0dfb334a-f68b-4dd0-8e36-ee712f8b6a91/result.json) · [文件清单](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/0dfb334a-f68b-4dd0-8e36-ee712f8b6a91/files.json) · [轨迹](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/0dfb334a-f68b-4dd0-8e36-ee712f8b6a91/agent/trajectory.jsonl) |
| test:624 | completed | 1 | 14.00 | 0.00 | complete / not-produced | — | [result](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/dd4c0e9d-879e-4854-8280-3e7e1988070c/result.json) · [文件清单](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/dd4c0e9d-879e-4854-8280-3e7e1988070c/files.json) · [轨迹](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/dd4c0e9d-879e-4854-8280-3e7e1988070c/agent/trajectory.jsonl) |
| test:669 | completed | 1 | 10.46 | 0.00 | complete / not-produced | — | [result](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/3d6883f9-6308-4986-8195-826557845f3f/result.json) · [文件清单](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/3d6883f9-6308-4986-8195-826557845f3f/files.json) · [轨迹](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/3d6883f9-6308-4986-8195-826557845f3f/agent/trajectory.jsonl) |
| test:670 | completed | 1 | 6.51 | 0.00 | complete / not-produced | — | [result](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/38c84416-53aa-4330-b332-0a1cc6116e5d/result.json) · [文件清单](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/38c84416-53aa-4330-b332-0a1cc6116e5d/files.json) · [轨迹](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/38c84416-53aa-4330-b332-0a1cc6116e5d/agent/trajectory.jsonl) |
| test:796 | completed | 1 | 27.01 | 0.00 | complete / not-produced | — | [result](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/e3d607f6-bdb3-47fd-bc81-8a453bfbc7cb/result.json) · [文件清单](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/e3d607f6-bdb3-47fd-bc81-8a453bfbc7cb/files.json) · [轨迹](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/e3d607f6-bdb3-47fd-bc81-8a453bfbc7cb/agent/trajectory.jsonl) |
| test:828 | completed | 1 | 11.33 | 0.00 | complete / not-produced | — | [result](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/5f84eb44-4454-45a8-8374-303a0b9b6fbc/result.json) · [文件清单](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/5f84eb44-4454-45a8-8374-303a0b9b6fbc/files.json) · [轨迹](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/5f84eb44-4454-45a8-8374-303a0b9b6fbc/agent/trajectory.jsonl) |
| test:841 | completed | 1 | 18.14 | 0.00 | complete / not-produced | — | [result](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/edd112d9-d12a-43ee-9df9-c3108ba3709f/result.json) · [文件清单](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/edd112d9-d12a-43ee-9df9-c3108ba3709f/files.json) · [轨迹](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/edd112d9-d12a-43ee-9df9-c3108ba3709f/agent/trajectory.jsonl) |
| test:883 | completed | 1 | 9.15 | 0.00 | complete / not-produced | — | [result](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/f2be0eba-6ff3-42a8-91a9-4b9d3c7ec464/result.json) · [文件清单](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/f2be0eba-6ff3-42a8-91a9-4b9d3c7ec464/files.json) · [轨迹](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/f2be0eba-6ff3-42a8-91a9-4b9d3c7ec464/agent/trajectory.jsonl) |
| test:938 | completed | 1 | 9.82 | 0.00 | complete / not-produced | — | [result](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/3cb926d8-75d2-4bcf-9eab-55fa4a74e449/result.json) · [文件清单](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/3cb926d8-75d2-4bcf-9eab-55fa4a74e449/files.json) · [轨迹](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/3cb926d8-75d2-4bcf-9eab-55fa4a74e449/agent/trajectory.jsonl) |
| test:1026 | completed | 0 | 16.50 | 0.00 | complete / not-produced | — | [result](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/efa76d8c-0fe1-4d20-b35d-5044fe6c7539/result.json) · [文件清单](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/efa76d8c-0fe1-4d20-b35d-5044fe6c7539/files.json) · [轨迹](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/efa76d8c-0fe1-4d20-b35d-5044fe6c7539/agent/trajectory.jsonl) |
| test:1229 | completed | 1 | 7.12 | 0.00 | complete / not-produced | — | [result](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/81e3a411-6685-4ddc-a033-527116b5bcee/result.json) · [文件清单](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/81e3a411-6685-4ddc-a033-527116b5bcee/files.json) · [轨迹](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/81e3a411-6685-4ddc-a033-527116b5bcee/agent/trajectory.jsonl) |
| test:1252 | completed | 1 | 5.71 | 0.00 | complete / not-produced | — | [result](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/1f9ee8ae-029e-44c9-9b6a-dc9c929cf46b/result.json) · [文件清单](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/1f9ee8ae-029e-44c9-9b6a-dc9c929cf46b/files.json) · [轨迹](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/1f9ee8ae-029e-44c9-9b6a-dc9c929cf46b/agent/trajectory.jsonl) |
| test:1399 | completed | 0 | 17.31 | 0.00 | complete / not-produced | — | [result](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/b950af73-a323-4cdd-9a8e-3f87aaa955b7/result.json) · [文件清单](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/b950af73-a323-4cdd-9a8e-3f87aaa955b7/files.json) · [轨迹](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/b950af73-a323-4cdd-9a8e-3f87aaa955b7/agent/trajectory.jsonl) |
| test:1454 | completed | 1 | 30.22 | 0.00 | complete / not-produced | — | [result](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/642746a4-5a6a-4815-b927-df5ad801a427/result.json) · [文件清单](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/642746a4-5a6a-4815-b927-df5ad801a427/files.json) · [轨迹](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/642746a4-5a6a-4815-b927-df5ad801a427/agent/trajectory.jsonl) |
| test:1514 | completed | 0 | 26.75 | 0.00 | complete / not-produced | — | [result](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/9e1ba280-a147-4d78-a941-8e3772353145/result.json) · [文件清单](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/9e1ba280-a147-4d78-a941-8e3772353145/files.json) · [轨迹](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/9e1ba280-a147-4d78-a941-8e3772353145/agent/trajectory.jsonl) |
| test:1531 | completed | 0 | 22.27 | 0.00 | complete / not-produced | — | [result](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/6eb5c0e8-f69a-4bcd-9090-e8a874502a44/result.json) · [文件清单](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/6eb5c0e8-f69a-4bcd-9090-e8a874502a44/files.json) · [轨迹](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/6eb5c0e8-f69a-4bcd-9090-e8a874502a44/agent/trajectory.jsonl) |
| test:1785 | completed | 0 | 37.50 | 0.00 | complete / not-produced | — | [result](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/1f73784d-4f64-45e4-bcad-a9b52d1dc599/result.json) · [文件清单](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/1f73784d-4f64-45e4-bcad-a9b52d1dc599/files.json) · [轨迹](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/1f73784d-4f64-45e4-bcad-a9b52d1dc599/agent/trajectory.jsonl) |
| test:1806 | completed | 0 | 19.01 | 0.00 | complete / not-produced | — | [result](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/8ae4f347-a660-46c4-95b6-d01aa8dc30e7/result.json) · [文件清单](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/8ae4f347-a660-46c4-95b6-d01aa8dc30e7/files.json) · [轨迹](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/8ae4f347-a660-46c4-95b6-d01aa8dc30e7/agent/trajectory.jsonl) |
| test:1827 | completed | 1 | 11.88 | 0.00 | complete / not-produced | — | [result](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/d8be572f-128a-40af-9e28-6dae95546e19/result.json) · [文件清单](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/d8be572f-128a-40af-9e28-6dae95546e19/files.json) · [轨迹](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/d8be572f-128a-40af-9e28-6dae95546e19/agent/trajectory.jsonl) |
| test:1904 | completed | 1 | 8.07 | 0.00 | complete / not-produced | — | [result](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/4d49a83c-58b5-4c6e-9471-642e89af624e/result.json) · [文件清单](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/4d49a83c-58b5-4c6e-9471-642e89af624e/files.json) · [轨迹](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/4d49a83c-58b5-4c6e-9471-642e89af624e/agent/trajectory.jsonl) |
| test:1943 | completed | 1 | 8.09 | 0.00 | complete / not-produced | — | [result](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/15ac6781-ab57-448e-9f27-3bc4b26d70c4/result.json) · [文件清单](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/15ac6781-ab57-448e-9f27-3bc4b26d70c4/files.json) · [轨迹](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/15ac6781-ab57-448e-9f27-3bc4b26d70c4/agent/trajectory.jsonl) |
| test:1998 | completed | 1 | 9.33 | 0.00 | complete / not-produced | — | [result](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/43128892-7e84-43df-8b9e-f043ad20313e/result.json) · [文件清单](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/43128892-7e84-43df-8b9e-f043ad20313e/files.json) · [轨迹](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/43128892-7e84-43df-8b9e-f043ad20313e/agent/trajectory.jsonl) |
| test:2023 | completed | 1 | 9.76 | 0.00 | complete / not-produced | — | [result](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/ff29012f-e3f7-4cf4-bcfc-d13a9daf1676/result.json) · [文件清单](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/ff29012f-e3f7-4cf4-bcfc-d13a9daf1676/files.json) · [轨迹](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/ff29012f-e3f7-4cf4-bcfc-d13a9daf1676/agent/trajectory.jsonl) |
| test:2096 | completed | 0 | 10.37 | 0.00 | complete / not-produced | — | [result](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/aced0149-bb90-41f6-9154-114c2bcca71d/result.json) · [文件清单](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/aced0149-bb90-41f6-9154-114c2bcca71d/files.json) · [轨迹](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/aced0149-bb90-41f6-9154-114c2bcca71d/agent/trajectory.jsonl) |
| test:2152 | completed | 1 | 8.00 | 0.00 | complete / not-produced | — | [result](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/af775d85-ced6-4f6b-b068-b7dfa7c48598/result.json) · [文件清单](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/af775d85-ced6-4f6b-b068-b7dfa7c48598/files.json) · [轨迹](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/af775d85-ced6-4f6b-b068-b7dfa7c48598/agent/trajectory.jsonl) |
| test:2175 | completed | 1 | 7.04 | 0.00 | complete / not-produced | — | [result](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/55408ee3-bb39-481b-9721-7a20fa8bfdf9/result.json) · [文件清单](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/55408ee3-bb39-481b-9721-7a20fa8bfdf9/files.json) · [轨迹](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/55408ee3-bb39-481b-9721-7a20fa8bfdf9/agent/trajectory.jsonl) |
| test:2177 | completed | 1 | 8.47 | 0.00 | complete / not-produced | — | [result](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/e9e7ecf3-9e65-488b-b8ae-ca1a19b225df/result.json) · [文件清单](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/e9e7ecf3-9e65-488b-b8ae-ca1a19b225df/files.json) · [轨迹](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/e9e7ecf3-9e65-488b-b8ae-ca1a19b225df/agent/trajectory.jsonl) |
| test:2206 | completed | 1 | 7.96 | 0.00 | complete / not-produced | — | [result](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/91ac7fc9-df3f-4953-bf2e-684ae7ef8388/result.json) · [文件清单](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/91ac7fc9-df3f-4953-bf2e-684ae7ef8388/files.json) · [轨迹](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/91ac7fc9-df3f-4953-bf2e-684ae7ef8388/agent/trajectory.jsonl) |
| test:2280 | completed | 1 | 8.54 | 0.00 | complete / not-produced | — | [result](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/bd36cd18-1c42-46af-8f89-9432d8998470/result.json) · [文件清单](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/bd36cd18-1c42-46af-8f89-9432d8998470/files.json) · [轨迹](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/bd36cd18-1c42-46af-8f89-9432d8998470/agent/trajectory.jsonl) |
| test:2347 | completed | 0 | 13.67 | 0.00 | complete / not-produced | — | [result](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/5e533460-282d-4216-9a87-c5602054c471/result.json) · [文件清单](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/5e533460-282d-4216-9a87-c5602054c471/files.json) · [轨迹](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/5e533460-282d-4216-9a87-c5602054c471/agent/trajectory.jsonl) |
| test:2400 | completed | 1 | 8.14 | 0.00 | complete / not-produced | — | [result](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/697be0ac-5693-4bcd-b1dc-8130ec1cb6d8/result.json) · [文件清单](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/697be0ac-5693-4bcd-b1dc-8130ec1cb6d8/files.json) · [轨迹](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/697be0ac-5693-4bcd-b1dc-8130ec1cb6d8/agent/trajectory.jsonl) |
| test:2527 | completed | 1 | 7.34 | 0.00 | complete / not-produced | — | [result](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/f8066c46-46bd-42b9-8c96-7bad2ccc0337/result.json) · [文件清单](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/f8066c46-46bd-42b9-8c96-7bad2ccc0337/files.json) · [轨迹](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/f8066c46-46bd-42b9-8c96-7bad2ccc0337/agent/trajectory.jsonl) |
| test:2636 | completed | 1 | 6.47 | 0.00 | complete / not-produced | — | [result](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/db13dad5-0a59-4a83-bc3d-9d8f94a70eed/result.json) · [文件清单](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/db13dad5-0a59-4a83-bc3d-9d8f94a70eed/files.json) · [轨迹](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/db13dad5-0a59-4a83-bc3d-9d8f94a70eed/agent/trajectory.jsonl) |
| test:2641 | completed | 1 | 5.51 | 0.00 | complete / not-produced | — | [result](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/fc2a0518-dde2-48c1-9772-82bd94bb9fcd/result.json) · [文件清单](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/fc2a0518-dde2-48c1-9772-82bd94bb9fcd/files.json) · [轨迹](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/fc2a0518-dde2-48c1-9772-82bd94bb9fcd/agent/trajectory.jsonl) |
| test:2714 | completed | 1 | 7.86 | 0.00 | complete / not-produced | — | [result](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/f43199ef-9898-4eb2-8c16-da2dd36b90fd/result.json) · [文件清单](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/f43199ef-9898-4eb2-8c16-da2dd36b90fd/files.json) · [轨迹](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/f43199ef-9898-4eb2-8c16-da2dd36b90fd/agent/trajectory.jsonl) |
| test:2716 | completed | 1 | 43.09 | 0.00 | complete / not-produced | — | [result](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/db88061c-520c-4f5e-9473-ccfe64aa3f42/result.json) · [文件清单](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/db88061c-520c-4f5e-9473-ccfe64aa3f42/files.json) · [轨迹](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/db88061c-520c-4f5e-9473-ccfe64aa3f42/agent/trajectory.jsonl) |
| test:2747 | completed | 1 | 6.22 | 0.00 | complete / not-produced | — | [result](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/9efc6aa5-510a-4b1e-a599-cf7e74e81e9d/result.json) · [文件清单](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/9efc6aa5-510a-4b1e-a599-cf7e74e81e9d/files.json) · [轨迹](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/9efc6aa5-510a-4b1e-a599-cf7e74e81e9d/agent/trajectory.jsonl) |
| test:2882 | completed | 0 | 7.11 | 0.00 | complete / not-produced | — | [result](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/653c5e68-bc88-40eb-be9b-bb60afcdc7c7/result.json) · [文件清单](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/653c5e68-bc88-40eb-be9b-bb60afcdc7c7/files.json) · [轨迹](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/653c5e68-bc88-40eb-be9b-bb60afcdc7c7/agent/trajectory.jsonl) |
| test:2951 | completed | 1 | 6.47 | 0.00 | complete / not-produced | — | [result](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/3a2cd2dd-9846-4967-9fbf-97653b2f67c5/result.json) · [文件清单](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/3a2cd2dd-9846-4967-9fbf-97653b2f67c5/files.json) · [轨迹](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/3a2cd2dd-9846-4967-9fbf-97653b2f67c5/agent/trajectory.jsonl) |
| test:3037 | completed | 1 | 6.02 | 0.00 | complete / not-produced | — | [result](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/8bbbbd90-b6ae-4494-b8c1-1332ebce52fe/result.json) · [文件清单](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/8bbbbd90-b6ae-4494-b8c1-1332ebce52fe/files.json) · [轨迹](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/8bbbbd90-b6ae-4494-b8c1-1332ebce52fe/agent/trajectory.jsonl) |
| test:3053 | completed | 0 | 25.57 | 0.00 | complete / not-produced | — | [result](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/96d83b95-c294-4a06-b009-5bb95366ae71/result.json) · [文件清单](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/96d83b95-c294-4a06-b009-5bb95366ae71/files.json) · [轨迹](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/96d83b95-c294-4a06-b009-5bb95366ae71/agent/trajectory.jsonl) |
| test:3136 | completed | 1 | 14.74 | 0.00 | complete / not-produced | — | [result](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/0fe5904b-77ab-4095-a27f-0930ca329752/result.json) · [文件清单](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/0fe5904b-77ab-4095-a27f-0930ca329752/files.json) · [轨迹](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/0fe5904b-77ab-4095-a27f-0930ca329752/agent/trajectory.jsonl) |
| test:3165 | completed | 1 | 6.94 | 0.00 | complete / not-produced | — | [result](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/5d977f16-8691-48d6-ad18-c1f8a97526cf/result.json) · [文件清单](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/5d977f16-8691-48d6-ad18-c1f8a97526cf/files.json) · [轨迹](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/5d977f16-8691-48d6-ad18-c1f8a97526cf/agent/trajectory.jsonl) |
| test:3196 | completed | 1 | 5.96 | 0.00 | complete / not-produced | — | [result](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/2e6cd2db-88ad-40b7-b3f9-7cf7eb314b93/result.json) · [文件清单](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/2e6cd2db-88ad-40b7-b3f9-7cf7eb314b93/files.json) · [轨迹](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/2e6cd2db-88ad-40b7-b3f9-7cf7eb314b93/agent/trajectory.jsonl) |
| test:3231 | completed | 1 | 5.91 | 0.00 | complete / not-produced | — | [result](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/51cc66a1-e4fa-4c93-b2ff-55fdbc543618/result.json) · [文件清单](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/51cc66a1-e4fa-4c93-b2ff-55fdbc543618/files.json) · [轨迹](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/51cc66a1-e4fa-4c93-b2ff-55fdbc543618/agent/trajectory.jsonl) |
| test:3236 | completed | 1 | 5.70 | 0.00 | complete / not-produced | — | [result](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/08abaea8-382e-4ebe-9a23-f45fb36caaba/result.json) · [文件清单](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/08abaea8-382e-4ebe-9a23-f45fb36caaba/files.json) · [轨迹](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/08abaea8-382e-4ebe-9a23-f45fb36caaba/agent/trajectory.jsonl) |
| test:3270 | completed | 1 | 8.38 | 0.00 | complete / not-produced | — | [result](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/93d8c9b2-ca21-4d95-85e2-4d536435bedc/result.json) · [文件清单](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/93d8c9b2-ca21-4d95-85e2-4d536435bedc/files.json) · [轨迹](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/93d8c9b2-ca21-4d95-85e2-4d536435bedc/agent/trajectory.jsonl) |
| test:3293 | completed | 1 | 5.09 | 0.00 | complete / not-produced | — | [result](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/ec9a37d5-5536-47f7-b0ac-e5951c787acb/result.json) · [文件清单](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/ec9a37d5-5536-47f7-b0ac-e5951c787acb/files.json) · [轨迹](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/ec9a37d5-5536-47f7-b0ac-e5951c787acb/agent/trajectory.jsonl) |
| test:3331 | completed | 1 | 5.64 | 0.00 | complete / not-produced | — | [result](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/3401011c-1962-4062-aa21-83937cf29412/result.json) · [文件清单](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/3401011c-1962-4062-aa21-83937cf29412/files.json) · [轨迹](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/3401011c-1962-4062-aa21-83937cf29412/agent/trajectory.jsonl) |
| test:3488 | completed | 1 | 10.35 | 0.00 | complete / not-produced | — | [result](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/9023dae9-9745-419f-a368-225664a69802/result.json) · [文件清单](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/9023dae9-9745-419f-a368-225664a69802/files.json) · [轨迹](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/9023dae9-9745-419f-a368-225664a69802/agent/trajectory.jsonl) |
| test:3491 | completed | 1 | 83.61 | 0.00 | complete / not-produced | — | [result](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/f0cdc553-5c25-43fc-9b48-8c2275c1c150/result.json) · [文件清单](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/f0cdc553-5c25-43fc-9b48-8c2275c1c150/files.json) · [轨迹](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/f0cdc553-5c25-43fc-9b48-8c2275c1c150/agent/trajectory.jsonl) |
| test:3552 | completed | 1 | 7.86 | 0.00 | complete / not-produced | — | [result](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/bd690a18-ddbd-47c6-af20-07aab1fb2afc/result.json) · [文件清单](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/bd690a18-ddbd-47c6-af20-07aab1fb2afc/files.json) · [轨迹](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/bd690a18-ddbd-47c6-af20-07aab1fb2afc/agent/trajectory.jsonl) |
| test:3599 | completed | 1 | 5.46 | 0.00 | complete / not-produced | — | [result](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/4ff87272-458d-49b7-a5c8-5258819401d6/result.json) · [文件清单](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/4ff87272-458d-49b7-a5c8-5258819401d6/files.json) · [轨迹](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/4ff87272-458d-49b7-a5c8-5258819401d6/agent/trajectory.jsonl) |
| test:3626 | completed | 1 | 8.35 | 0.00 | complete / not-produced | — | [result](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/3ccda6b9-2988-4345-a588-eedabef6ae71/result.json) · [文件清单](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/3ccda6b9-2988-4345-a588-eedabef6ae71/files.json) · [轨迹](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/3ccda6b9-2988-4345-a588-eedabef6ae71/agent/trajectory.jsonl) |
| test:4021 | completed | 1 | 10.76 | 0.00 | complete / not-produced | — | [result](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/c90ea269-5740-42eb-a4cc-7bf988e31249/result.json) · [文件清单](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/c90ea269-5740-42eb-a4cc-7bf988e31249/files.json) · [轨迹](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/c90ea269-5740-42eb-a4cc-7bf988e31249/agent/trajectory.jsonl) |
| test:4034 | completed | 1 | 5.88 | 0.00 | complete / not-produced | — | [result](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/33bc9cb5-8406-4fba-ad07-60469069fbb7/result.json) · [文件清单](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/33bc9cb5-8406-4fba-ad07-60469069fbb7/files.json) · [轨迹](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/33bc9cb5-8406-4fba-ad07-60469069fbb7/agent/trajectory.jsonl) |
| test:4058 | completed | 1 | 5.06 | 0.00 | complete / not-produced | — | [result](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/e9ca1e59-6e9a-43b6-b887-9af5b5c0e06d/result.json) · [文件清单](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/e9ca1e59-6e9a-43b6-b887-9af5b5c0e06d/files.json) · [轨迹](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/e9ca1e59-6e9a-43b6-b887-9af5b5c0e06d/agent/trajectory.jsonl) |
| test:4075 | invalid | — | 5.63 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/1314f722-2c30-4f13-8416-5784e12ae3e8/result.json) · [文件清单](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/1314f722-2c30-4f13-8416-5784e12ae3e8/files.json) · [轨迹](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/1314f722-2c30-4f13-8416-5784e12ae3e8/agent/trajectory.jsonl) |
| test:4142 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/2247daa2-6739-444b-9a95-533f42d5c46e/result.json) · [文件清单](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/2247daa2-6739-444b-9a95-533f42d5c46e/files.json) |
| test:4208 | cancelled | — | 6.61 | — | complete / not-produced | RUN\_CANCELLED | [result](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/bda48ef8-f342-4676-a14c-2b314843e7ea/result.json) · [文件清单](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/bda48ef8-f342-4676-a14c-2b314843e7ea/files.json) · [轨迹](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/bda48ef8-f342-4676-a14c-2b314843e7ea/agent/trajectory.jsonl) |
| test:4298 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/e8e2b31b-81e3-4ea1-b762-e20204554f20/result.json) · [文件清单](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/e8e2b31b-81e3-4ea1-b762-e20204554f20/files.json) |
| test:4337 | pending | — | — | — | — | — | — |
| test:4376 | pending | — | — | — | — | — | — |
| test:4405 | pending | — | — | — | — | — | — |
| test:4552 | pending | — | — | — | — | — | — |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 4；错误记录 5（主流程 2；证据收集 0；资源清理 3）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| cleanup | CLEANUP_FAILED | 1 | 2 |
| environment | RUN_CANCELLED | 2 | 2 |
| cleanup | RUN_CANCELLED | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

