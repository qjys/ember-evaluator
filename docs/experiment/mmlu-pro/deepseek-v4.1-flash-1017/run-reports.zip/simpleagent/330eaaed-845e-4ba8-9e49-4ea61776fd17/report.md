<!-- snapshotDigest: a3fbdbec9f70197468689a9054df71d7f98451106dedce50b5f2cdd204939897 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 66.67%（16/24）**

Run: 330eaaed-845e-4ba8-9e49-4ea61776fd17 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:58:58.854Z / 2026-11-12T09:05:20.140Z |
| 总耗时 | 6 分 9 秒 |
| 答对 / 答错 / 解题超时 | 16 / 8 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 16 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 66.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 6 分 9 秒 |
| 环境准备耗时 | 1 分 24 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 47 秒 | 12 秒 | 4 分 12 秒 | 24 |
| 任务准备 | 0.34 毫秒 | 0.21 毫秒 | 0.74 毫秒 | 24 |
| 环境启动 | 7 秒 | 4 秒 | 10 秒 | 24 |
| 解题 | 35 秒 | 3 秒 | 4 分 0 秒 | 24 |
| 产物传输 | 1 秒 | 841.84 毫秒 | 2 秒 | 24 |
| 资源清理 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 评分 | 0.71 毫秒 | 0.16 毫秒 | 4.49 毫秒 | 24 |
| 证据收集 | 9.08 毫秒 | 3.97 毫秒 | 33.89 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 1b664483-7fbc-4d8a-a345-fdf44e0078e6 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 26,796 | 73,152 | 99,948 | 23 / 24 | — |
| 运行累计 | 26,796 | 73,152 | 99,948 | 23 / 24 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:10674 | completed | 0 | 6.34 | 0.00 | complete / not-produced | — | [result](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/568f260a-4552-4f94-a5eb-428cd7960b5b/result.json) · [文件清单](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/568f260a-4552-4f94-a5eb-428cd7960b5b/files.json) · [轨迹](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/568f260a-4552-4f94-a5eb-428cd7960b5b/agent/trajectory.jsonl) |
| test:10683 | completed | 1 | 4.65 | 0.00 | complete / not-produced | — | [result](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/21c7c7c6-8701-4f78-a252-8886021a79cb/result.json) · [文件清单](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/21c7c7c6-8701-4f78-a252-8886021a79cb/files.json) · [轨迹](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/21c7c7c6-8701-4f78-a252-8886021a79cb/agent/trajectory.jsonl) |
| test:10690 | completed | 1 | 8.18 | 0.00 | complete / not-produced | — | [result](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/892aa44d-ca2d-4ee6-b6ba-2c2dae2e12d5/result.json) · [文件清单](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/892aa44d-ca2d-4ee6-b6ba-2c2dae2e12d5/files.json) · [轨迹](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/892aa44d-ca2d-4ee6-b6ba-2c2dae2e12d5/agent/trajectory.jsonl) |
| test:10765 | completed | 1 | 4.67 | 0.00 | complete / not-produced | — | [result](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/4c62cf6f-e217-40ad-9455-f6cb2a9dc7e4/result.json) · [文件清单](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/4c62cf6f-e217-40ad-9455-f6cb2a9dc7e4/files.json) · [轨迹](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/4c62cf6f-e217-40ad-9455-f6cb2a9dc7e4/agent/trajectory.jsonl) |
| test:10770 | completed | 1 | 8.75 | 0.00 | complete / not-produced | — | [result](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/4fd51e06-10f7-42ce-9f76-d5d00eced78c/result.json) · [文件清单](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/4fd51e06-10f7-42ce-9f76-d5d00eced78c/files.json) · [轨迹](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/4fd51e06-10f7-42ce-9f76-d5d00eced78c/agent/trajectory.jsonl) |
| test:10815 | completed | 1 | 14.44 | 0.00 | complete / not-produced | — | [result](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/2097def9-d254-4248-84ef-80f52db783fb/result.json) · [文件清单](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/2097def9-d254-4248-84ef-80f52db783fb/files.json) · [轨迹](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/2097def9-d254-4248-84ef-80f52db783fb/agent/trajectory.jsonl) |
| test:10846 | completed | 1 | 83.70 | 0.00 | complete / not-produced | — | [result](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/74c27a2d-c160-4445-8e45-c43dcc470964/result.json) · [文件清单](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/74c27a2d-c160-4445-8e45-c43dcc470964/files.json) · [轨迹](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/74c27a2d-c160-4445-8e45-c43dcc470964/agent/trajectory.jsonl) |
| test:10898 | completed | 1 | 6.96 | 0.00 | complete / not-produced | — | [result](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/20c98fc5-fa24-41e9-8d06-4272109f3480/result.json) · [文件清单](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/20c98fc5-fa24-41e9-8d06-4272109f3480/files.json) · [轨迹](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/20c98fc5-fa24-41e9-8d06-4272109f3480/agent/trajectory.jsonl) |
| test:10940 | completed | 1 | 6.44 | 0.00 | complete / not-produced | — | [result](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/ec7c49ca-cbb9-4d97-a089-8345c0173baf/result.json) · [文件清单](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/ec7c49ca-cbb9-4d97-a089-8345c0173baf/files.json) · [轨迹](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/ec7c49ca-cbb9-4d97-a089-8345c0173baf/agent/trajectory.jsonl) |
| test:10966 | completed | 1 | 3.94 | 0.00 | complete / not-produced | — | [result](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/8fd612a3-d185-4476-b8b4-de7527d036a2/result.json) · [文件清单](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/8fd612a3-d185-4476-b8b4-de7527d036a2/files.json) · [轨迹](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/8fd612a3-d185-4476-b8b4-de7527d036a2/agent/trajectory.jsonl) |
| test:11045 | completed | 0 | 4.04 | 0.00 | complete / not-produced | — | [result](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/f0fb7b5d-48e3-41ea-9421-cc971a3ba857/result.json) · [文件清单](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/f0fb7b5d-48e3-41ea-9421-cc971a3ba857/files.json) · [轨迹](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/f0fb7b5d-48e3-41ea-9421-cc971a3ba857/agent/trajectory.jsonl) |
| test:11050 | completed | 0 | 24.25 | 0.00 | complete / not-produced | — | [result](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/b23f7000-b739-4bbf-9145-3813a87978cb/result.json) · [文件清单](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/b23f7000-b739-4bbf-9145-3813a87978cb/files.json) · [轨迹](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/b23f7000-b739-4bbf-9145-3813a87978cb/agent/trajectory.jsonl) |
| test:11060 | completed | 1 | 4.46 | 0.00 | complete / not-produced | — | [result](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/a7afba80-0f1e-4597-9eb0-6be8be20206f/result.json) · [文件清单](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/a7afba80-0f1e-4597-9eb0-6be8be20206f/files.json) · [轨迹](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/a7afba80-0f1e-4597-9eb0-6be8be20206f/agent/trajectory.jsonl) |
| test:11093 | completed | 1 | 159.41 | 0.00 | complete / not-produced | — | [result](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/f8df1ad3-2a62-4bb1-8d15-d4c4ac6bf446/result.json) · [文件清单](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/f8df1ad3-2a62-4bb1-8d15-d4c4ac6bf446/files.json) · [轨迹](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/f8df1ad3-2a62-4bb1-8d15-d4c4ac6bf446/agent/trajectory.jsonl) |
| test:11210 | completed | 1 | 6.48 | 0.00 | complete / not-produced | — | [result](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/c1286b5b-b077-43c8-93fd-a1a860c87633/result.json) · [文件清单](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/c1286b5b-b077-43c8-93fd-a1a860c87633/files.json) · [轨迹](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/c1286b5b-b077-43c8-93fd-a1a860c87633/agent/trajectory.jsonl) |
| test:11354 | completed | 0 | 4.33 | 0.00 | complete / not-produced | — | [result](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/395902aa-1a99-42bf-94d5-1a876835cd63/result.json) · [文件清单](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/395902aa-1a99-42bf-94d5-1a876835cd63/files.json) · [轨迹](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/395902aa-1a99-42bf-94d5-1a876835cd63/agent/trajectory.jsonl) |
| test:11491 | completed | 0 | 110.66 | 0.00 | complete / not-produced | — | [result](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/56fe5d22-3a80-4e56-b7c3-e5757f0c0221/result.json) · [文件清单](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/56fe5d22-3a80-4e56-b7c3-e5757f0c0221/files.json) · [轨迹](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/56fe5d22-3a80-4e56-b7c3-e5757f0c0221/agent/trajectory.jsonl) |
| test:11496 | completed | 0 | 240.01 | 0.00 | partial / not-produced | SOLVER\_AGENT\_TIMEOUT | [result](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/6342ede9-e45a-461c-8e40-9397b6572237/result.json) · [文件清单](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/6342ede9-e45a-461c-8e40-9397b6572237/files.json) · [轨迹](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/6342ede9-e45a-461c-8e40-9397b6572237/agent/trajectory.jsonl) |
| test:11506 | completed | 0 | 55.04 | 0.00 | complete / not-produced | — | [result](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/4b43598d-8ebd-433a-a213-dbacf78739ac/result.json) · [文件清单](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/4b43598d-8ebd-433a-a213-dbacf78739ac/files.json) · [轨迹](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/4b43598d-8ebd-433a-a213-dbacf78739ac/agent/trajectory.jsonl) |
| test:11559 | completed | 1 | 5.14 | 0.00 | complete / not-produced | — | [result](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/c468484f-e17d-4adf-81fd-de78023d2288/result.json) · [文件清单](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/c468484f-e17d-4adf-81fd-de78023d2288/files.json) · [轨迹](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/c468484f-e17d-4adf-81fd-de78023d2288/agent/trajectory.jsonl) |
| test:11576 | completed | 0 | 21.03 | 0.00 | complete / not-produced | — | [result](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/9b302878-e28c-4e49-a815-a4d780f6cdef/result.json) · [文件清单](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/9b302878-e28c-4e49-a815-a4d780f6cdef/files.json) · [轨迹](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/9b302878-e28c-4e49-a815-a4d780f6cdef/agent/trajectory.jsonl) |
| test:11629 | completed | 1 | 28.43 | 0.00 | complete / not-produced | — | [result](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/1bb0853b-d4a8-4b39-ae45-a865a712e214/result.json) · [文件清单](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/1bb0853b-d4a8-4b39-ae45-a865a712e214/files.json) · [轨迹](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/1bb0853b-d4a8-4b39-ae45-a865a712e214/agent/trajectory.jsonl) |
| test:11660 | completed | 1 | 30.45 | 0.00 | complete / not-produced | — | [result](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/e88bfdc2-8fdf-4d9c-b53d-b80d3c64d781/result.json) · [文件清单](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/e88bfdc2-8fdf-4d9c-b53d-b80d3c64d781/files.json) · [轨迹](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/e88bfdc2-8fdf-4d9c-b53d-b80d3c64d781/agent/trajectory.jsonl) |
| test:11802 | completed | 1 | 2.70 | 0.00 | complete / not-produced | — | [result](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/480c8102-03aa-467d-8830-878ae823bc55/result.json) · [文件清单](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/480c8102-03aa-467d-8830-878ae823bc55/files.json) · [轨迹](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/480c8102-03aa-467d-8830-878ae823bc55/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 1（主流程 1；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| test:11496 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

