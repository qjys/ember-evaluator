<!-- snapshotDigest: ca7c1f7e43db11bd2d395d0c58fc5200f24aad7e33a56c3d6286845582168837 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 79.17%（19/24）**

Run: 0e363678-3a35-4b58-82ce-3d534ef32ee0 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:46:13.699Z / 2026-11-12T08:51:29.690Z |
| 总耗时 | 5 分 6 秒 |
| 答对 / 答错 / 解题超时 | 19 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 19 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 79.17% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 6 秒 |
| 环境准备耗时 | 3 分 8 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 46 秒 | 31 秒 | 1 分 41 秒 | 24 |
| 任务准备 | 0.44 毫秒 | 0.23 毫秒 | 0.92 毫秒 | 24 |
| 环境启动 | 18 秒 | 14 秒 | 25 秒 | 24 |
| 解题 | 17 秒 | 6 秒 | 1 分 13 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 7 秒 | 5 秒 | 12 秒 | 24 |
| 评分 | 0.63 毫秒 | 0.24 毫秒 | 4.77 毫秒 | 24 |
| 证据收集 | 9.91 毫秒 | 3.09 毫秒 | 31.54 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| bd00618a-e5f2-4080-b239-10dd1f5acaf9 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 29,919 | 29,933 | 59,852 | 24 / 24 | — |
| 运行累计 | 29,919 | 29,933 | 59,852 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:6123 | completed | 0 | 29.44 | 0.00 | complete / not-produced | — | [result](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/fd89562e-2fb2-4f49-aa4e-9a7c9da0dade/result.json) · [文件清单](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/fd89562e-2fb2-4f49-aa4e-9a7c9da0dade/files.json) · [轨迹](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/fd89562e-2fb2-4f49-aa4e-9a7c9da0dade/agent/trajectory.jsonl) |
| test:6147 | completed | 0 | 27.24 | 0.00 | complete / not-produced | — | [result](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/8163a17b-c9f8-41fe-a78c-04c365712ad2/result.json) · [文件清单](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/8163a17b-c9f8-41fe-a78c-04c365712ad2/files.json) · [轨迹](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/8163a17b-c9f8-41fe-a78c-04c365712ad2/agent/trajectory.jsonl) |
| test:6198 | completed | 0 | 11.85 | 0.00 | complete / not-produced | — | [result](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/d5cf1796-e0b8-4a4a-81db-8090672cc3b0/result.json) · [文件清单](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/d5cf1796-e0b8-4a4a-81db-8090672cc3b0/files.json) · [轨迹](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/d5cf1796-e0b8-4a4a-81db-8090672cc3b0/agent/trajectory.jsonl) |
| test:6223 | completed | 1 | 13.59 | 0.00 | complete / not-produced | — | [result](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/a16e5f3d-9935-4a30-8763-13b413897bd9/result.json) · [文件清单](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/a16e5f3d-9935-4a30-8763-13b413897bd9/files.json) · [轨迹](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/a16e5f3d-9935-4a30-8763-13b413897bd9/agent/trajectory.jsonl) |
| test:6235 | completed | 1 | 8.43 | 0.00 | complete / not-produced | — | [result](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/00a0a6c4-901b-43b4-a1e6-82d6e72396f2/result.json) · [文件清单](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/00a0a6c4-901b-43b4-a1e6-82d6e72396f2/files.json) · [轨迹](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/00a0a6c4-901b-43b4-a1e6-82d6e72396f2/agent/trajectory.jsonl) |
| test:6403 | completed | 1 | 18.36 | 0.00 | complete / not-produced | — | [result](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/170f3d54-bcdf-4d83-9f33-ae6285bb2458/result.json) · [文件清单](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/170f3d54-bcdf-4d83-9f33-ae6285bb2458/files.json) · [轨迹](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/170f3d54-bcdf-4d83-9f33-ae6285bb2458/agent/trajectory.jsonl) |
| test:6436 | completed | 1 | 8.13 | 0.00 | complete / not-produced | — | [result](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/93075b32-2412-45e1-8e64-724eaa67a142/result.json) · [文件清单](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/93075b32-2412-45e1-8e64-724eaa67a142/files.json) · [轨迹](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/93075b32-2412-45e1-8e64-724eaa67a142/agent/trajectory.jsonl) |
| test:6508 | completed | 0 | 55.00 | 0.00 | complete / not-produced | — | [result](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/7e4672da-60da-45b4-b263-185ff267c9b1/result.json) · [文件清单](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/7e4672da-60da-45b4-b263-185ff267c9b1/files.json) · [轨迹](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/7e4672da-60da-45b4-b263-185ff267c9b1/agent/trajectory.jsonl) |
| test:6593 | completed | 1 | 12.51 | 0.00 | complete / not-produced | — | [result](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/fa4b77f0-3126-4538-9d37-fccfce3648f9/result.json) · [文件清单](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/fa4b77f0-3126-4538-9d37-fccfce3648f9/files.json) · [轨迹](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/fa4b77f0-3126-4538-9d37-fccfce3648f9/agent/trajectory.jsonl) |
| test:6655 | completed | 0 | 26.16 | 0.00 | complete / not-produced | — | [result](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/1b887073-d867-4ed9-a6b4-c46ffefea948/result.json) · [文件清单](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/1b887073-d867-4ed9-a6b4-c46ffefea948/files.json) · [轨迹](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/1b887073-d867-4ed9-a6b4-c46ffefea948/agent/trajectory.jsonl) |
| test:6738 | completed | 1 | 19.64 | 0.00 | complete / not-produced | — | [result](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/c54ed6fa-c42e-4c07-a3a3-893f8b990907/result.json) · [文件清单](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/c54ed6fa-c42e-4c07-a3a3-893f8b990907/files.json) · [轨迹](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/c54ed6fa-c42e-4c07-a3a3-893f8b990907/agent/trajectory.jsonl) |
| test:6751 | completed | 1 | 8.48 | 0.00 | complete / not-produced | — | [result](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/fc230a53-07db-461a-9c91-ba27e55d18bd/result.json) · [文件清单](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/fc230a53-07db-461a-9c91-ba27e55d18bd/files.json) · [轨迹](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/fc230a53-07db-461a-9c91-ba27e55d18bd/agent/trajectory.jsonl) |
| test:6784 | completed | 1 | 10.83 | 0.00 | complete / not-produced | — | [result](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/23605047-a05a-4152-bac8-87a43949a3ce/result.json) · [文件清单](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/23605047-a05a-4152-bac8-87a43949a3ce/files.json) · [轨迹](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/23605047-a05a-4152-bac8-87a43949a3ce/agent/trajectory.jsonl) |
| test:6792 | completed | 1 | 5.94 | 0.00 | complete / not-produced | — | [result](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/97d050c2-9424-4f8b-9109-12ef82c9bb0a/result.json) · [文件清单](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/97d050c2-9424-4f8b-9109-12ef82c9bb0a/files.json) · [轨迹](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/97d050c2-9424-4f8b-9109-12ef82c9bb0a/agent/trajectory.jsonl) |
| test:6900 | completed | 1 | 10.02 | 0.00 | complete / not-produced | — | [result](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/8d26465e-926e-499c-8835-56874bae8df3/result.json) · [文件清单](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/8d26465e-926e-499c-8835-56874bae8df3/files.json) · [轨迹](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/8d26465e-926e-499c-8835-56874bae8df3/agent/trajectory.jsonl) |
| test:6928 | completed | 1 | 7.03 | 0.00 | complete / not-produced | — | [result](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/499c0b15-f913-4a5e-817c-fdac0fb92f50/result.json) · [文件清单](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/499c0b15-f913-4a5e-817c-fdac0fb92f50/files.json) · [轨迹](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/499c0b15-f913-4a5e-817c-fdac0fb92f50/agent/trajectory.jsonl) |
| test:6929 | completed | 1 | 8.43 | 0.00 | complete / not-produced | — | [result](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/d4516d62-1fa1-4d44-9e3d-767c9a6117ff/result.json) · [文件清单](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/d4516d62-1fa1-4d44-9e3d-767c9a6117ff/files.json) · [轨迹](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/d4516d62-1fa1-4d44-9e3d-767c9a6117ff/agent/trajectory.jsonl) |
| test:7161 | completed | 1 | 72.57 | 0.00 | complete / not-produced | — | [result](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/b065064e-2ab4-4721-b969-e1ba877dcbb9/result.json) · [文件清单](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/b065064e-2ab4-4721-b969-e1ba877dcbb9/files.json) · [轨迹](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/b065064e-2ab4-4721-b969-e1ba877dcbb9/agent/trajectory.jsonl) |
| test:7181 | completed | 1 | 6.70 | 0.00 | complete / not-produced | — | [result](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/985e7935-1ae6-4b43-9eec-f8888325e153/result.json) · [文件清单](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/985e7935-1ae6-4b43-9eec-f8888325e153/files.json) · [轨迹](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/985e7935-1ae6-4b43-9eec-f8888325e153/agent/trajectory.jsonl) |
| test:7217 | completed | 1 | 9.97 | 0.00 | complete / not-produced | — | [result](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/b2878694-8541-422b-aad2-ab2ab210d649/result.json) · [文件清单](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/b2878694-8541-422b-aad2-ab2ab210d649/files.json) · [轨迹](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/b2878694-8541-422b-aad2-ab2ab210d649/agent/trajectory.jsonl) |
| test:7290 | completed | 1 | 7.39 | 0.00 | complete / not-produced | — | [result](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/a919d9da-b125-4e1c-9416-33d63d32b610/result.json) · [文件清单](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/a919d9da-b125-4e1c-9416-33d63d32b610/files.json) · [轨迹](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/a919d9da-b125-4e1c-9416-33d63d32b610/agent/trajectory.jsonl) |
| test:7304 | completed | 1 | 8.46 | 0.00 | complete / not-produced | — | [result](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/7f311f0b-26e2-49dd-8bbd-902fa43866ea/result.json) · [文件清单](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/7f311f0b-26e2-49dd-8bbd-902fa43866ea/files.json) · [轨迹](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/7f311f0b-26e2-49dd-8bbd-902fa43866ea/agent/trajectory.jsonl) |
| test:7312 | completed | 1 | 9.50 | 0.00 | complete / not-produced | — | [result](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/fae22289-a8ef-4e00-bfce-58860336307f/result.json) · [文件清单](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/fae22289-a8ef-4e00-bfce-58860336307f/files.json) · [轨迹](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/fae22289-a8ef-4e00-bfce-58860336307f/agent/trajectory.jsonl) |
| test:7448 | completed | 1 | 11.21 | 0.00 | complete / not-produced | — | [result](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/a82fccdc-0dac-44a9-abc3-8686b2b6d76f/result.json) · [文件清单](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/a82fccdc-0dac-44a9-abc3-8686b2b6d76f/files.json) · [轨迹](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/a82fccdc-0dac-44a9-abc3-8686b2b6d76f/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

