<!-- snapshotDigest: c379ed4325e08435f31179375345fdd98fd51258784b42726d9e303152842ed5 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: 36a48320-8249-4892-a3d4-3e41eb3b8ffd · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:55:10.614Z / 2026-11-12T08:58:56.057Z |
| 总耗时 | 3 分 37 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 3 分 37 秒 |
| 环境准备耗时 | 2 分 34 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 32 秒 | 16 秒 | 1 分 51 秒 | 24 |
| 任务准备 | 0.41 毫秒 | 0.21 毫秒 | 1.09 毫秒 | 24 |
| 环境启动 | 13 秒 | 8 秒 | 19 秒 | 24 |
| 解题 | 11 秒 | 4 秒 | 1 分 26 秒 | 24 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 24 |
| 资源清理 | 6 秒 | 3 秒 | 7 秒 | 24 |
| 评分 | 0.7 毫秒 | 0.21 毫秒 | 4.64 毫秒 | 24 |
| 证据收集 | 10.42 毫秒 | 3.28 毫秒 | 44.79 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 47e0363a-f599-4087-8770-a26ffb62dbb1 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 34,956 | 18,512 | 53,468 | 24 / 24 | — |
| 运行累计 | 34,956 | 18,512 | 53,468 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:9769 | completed | 1 | 11.31 | 0.00 | complete / not-produced | — | [result](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/c7d33078-6122-4c35-9fb9-df3e56f32883/result.json) · [文件清单](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/c7d33078-6122-4c35-9fb9-df3e56f32883/files.json) · [轨迹](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/c7d33078-6122-4c35-9fb9-df3e56f32883/agent/trajectory.jsonl) |
| test:9843 | completed | 1 | 17.47 | 0.00 | complete / not-produced | — | [result](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/e24b4708-f9b2-4a83-9d05-e12d6c7ba1b6/result.json) · [文件清单](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/e24b4708-f9b2-4a83-9d05-e12d6c7ba1b6/files.json) · [轨迹](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/e24b4708-f9b2-4a83-9d05-e12d6c7ba1b6/agent/trajectory.jsonl) |
| test:9864 | completed | 1 | 7.74 | 0.00 | complete / not-produced | — | [result](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/4820dc63-9795-46e7-a967-8bb4e8bb90a5/result.json) · [文件清单](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/4820dc63-9795-46e7-a967-8bb4e8bb90a5/files.json) · [轨迹](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/4820dc63-9795-46e7-a967-8bb4e8bb90a5/agent/trajectory.jsonl) |
| test:9901 | completed | 1 | 8.99 | 0.00 | complete / not-produced | — | [result](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/b733a405-ca24-4617-8d70-8459af40629e/result.json) · [文件清单](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/b733a405-ca24-4617-8d70-8459af40629e/files.json) · [轨迹](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/b733a405-ca24-4617-8d70-8459af40629e/agent/trajectory.jsonl) |
| test:9931 | completed | 0 | 86.00 | 0.00 | complete / not-produced | — | [result](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/88434e90-90cf-443b-8303-12aa67e242e8/result.json) · [文件清单](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/88434e90-90cf-443b-8303-12aa67e242e8/files.json) · [轨迹](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/88434e90-90cf-443b-8303-12aa67e242e8/agent/trajectory.jsonl) |
| test:10127 | completed | 1 | 7.45 | 0.00 | complete / not-produced | — | [result](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/74a98126-062f-4eec-bcd7-13e8f4cd33f5/result.json) · [文件清单](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/74a98126-062f-4eec-bcd7-13e8f4cd33f5/files.json) · [轨迹](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/74a98126-062f-4eec-bcd7-13e8f4cd33f5/agent/trajectory.jsonl) |
| test:10140 | completed | 1 | 5.98 | 0.00 | complete / not-produced | — | [result](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/f0a2349c-1cd2-4139-b8b5-992aa768374c/result.json) · [文件清单](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/f0a2349c-1cd2-4139-b8b5-992aa768374c/files.json) · [轨迹](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/f0a2349c-1cd2-4139-b8b5-992aa768374c/agent/trajectory.jsonl) |
| test:10174 | completed | 1 | 9.07 | 0.00 | complete / not-produced | — | [result](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/f38e59c3-7b8c-4a4b-92b0-cf4437e19e5b/result.json) · [文件清单](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/f38e59c3-7b8c-4a4b-92b0-cf4437e19e5b/files.json) · [轨迹](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/f38e59c3-7b8c-4a4b-92b0-cf4437e19e5b/agent/trajectory.jsonl) |
| test:10184 | completed | 1 | 6.13 | 0.00 | complete / not-produced | — | [result](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/ddcbf266-0901-4e93-b41c-c2672276a598/result.json) · [文件清单](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/ddcbf266-0901-4e93-b41c-c2672276a598/files.json) · [轨迹](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/ddcbf266-0901-4e93-b41c-c2672276a598/agent/trajectory.jsonl) |
| test:10189 | completed | 1 | 6.24 | 0.00 | complete / not-produced | — | [result](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/ae0f6e98-eb78-4609-89f3-a7db68e1d3b1/result.json) · [文件清单](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/ae0f6e98-eb78-4609-89f3-a7db68e1d3b1/files.json) · [轨迹](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/ae0f6e98-eb78-4609-89f3-a7db68e1d3b1/agent/trajectory.jsonl) |
| test:10294 | completed | 1 | 5.84 | 0.00 | complete / not-produced | — | [result](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/2158db9b-640c-4d07-ab7a-aafe08ff83d9/result.json) · [文件清单](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/2158db9b-640c-4d07-ab7a-aafe08ff83d9/files.json) · [轨迹](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/2158db9b-640c-4d07-ab7a-aafe08ff83d9/agent/trajectory.jsonl) |
| test:10318 | completed | 1 | 8.22 | 0.00 | complete / not-produced | — | [result](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/f5b86db4-40b6-4b59-bf7d-ccd73e010255/result.json) · [文件清单](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/f5b86db4-40b6-4b59-bf7d-ccd73e010255/files.json) · [轨迹](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/f5b86db4-40b6-4b59-bf7d-ccd73e010255/agent/trajectory.jsonl) |
| test:10362 | completed | 1 | 8.49 | 0.00 | complete / not-produced | — | [result](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/a52bdf6d-15d7-4424-a085-b436bf4691d5/result.json) · [文件清单](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/a52bdf6d-15d7-4424-a085-b436bf4691d5/files.json) · [轨迹](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/a52bdf6d-15d7-4424-a085-b436bf4691d5/agent/trajectory.jsonl) |
| test:10396 | completed | 1 | 6.12 | 0.00 | complete / not-produced | — | [result](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/af54eec6-6884-415a-adc6-84a149d207e6/result.json) · [文件清单](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/af54eec6-6884-415a-adc6-84a149d207e6/files.json) · [轨迹](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/af54eec6-6884-415a-adc6-84a149d207e6/agent/trajectory.jsonl) |
| test:10401 | completed | 1 | 10.62 | 0.00 | complete / not-produced | — | [result](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/e077801d-34d6-42dd-ab7d-8161992d6639/result.json) · [文件清单](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/e077801d-34d6-42dd-ab7d-8161992d6639/files.json) · [轨迹](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/e077801d-34d6-42dd-ab7d-8161992d6639/agent/trajectory.jsonl) |
| test:10403 | completed | 1 | 6.27 | 0.00 | complete / not-produced | — | [result](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/0f030dd7-0649-4cca-a47d-2a802c07b0b4/result.json) · [文件清单](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/0f030dd7-0649-4cca-a47d-2a802c07b0b4/files.json) · [轨迹](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/0f030dd7-0649-4cca-a47d-2a802c07b0b4/agent/trajectory.jsonl) |
| test:10412 | completed | 1 | 5.43 | 0.00 | complete / not-produced | — | [result](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/d28b1b0e-32b9-47db-9206-da903a6c6eb3/result.json) · [文件清单](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/d28b1b0e-32b9-47db-9206-da903a6c6eb3/files.json) · [轨迹](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/d28b1b0e-32b9-47db-9206-da903a6c6eb3/agent/trajectory.jsonl) |
| test:10421 | completed | 1 | 6.71 | 0.00 | complete / not-produced | — | [result](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/d8a97f41-7a25-4f0d-bc29-7b15dea2e976/result.json) · [文件清单](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/d8a97f41-7a25-4f0d-bc29-7b15dea2e976/files.json) · [轨迹](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/d8a97f41-7a25-4f0d-bc29-7b15dea2e976/agent/trajectory.jsonl) |
| test:10424 | completed | 1 | 6.79 | 0.00 | complete / not-produced | — | [result](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/c56c4643-c0b3-45cb-98b9-a33e38d1050b/result.json) · [文件清单](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/c56c4643-c0b3-45cb-98b9-a33e38d1050b/files.json) · [轨迹](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/c56c4643-c0b3-45cb-98b9-a33e38d1050b/agent/trajectory.jsonl) |
| test:10471 | completed | 1 | 6.66 | 0.00 | complete / not-produced | — | [result](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/cb6f1cea-9259-4497-be69-f9116548c84d/result.json) · [文件清单](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/cb6f1cea-9259-4497-be69-f9116548c84d/files.json) · [轨迹](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/cb6f1cea-9259-4497-be69-f9116548c84d/agent/trajectory.jsonl) |
| test:10479 | completed | 1 | 5.93 | 0.00 | complete / not-produced | — | [result](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/975176c4-c4a1-45e6-814b-c60cbccef1e8/result.json) · [文件清单](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/975176c4-c4a1-45e6-814b-c60cbccef1e8/files.json) · [轨迹](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/975176c4-c4a1-45e6-814b-c60cbccef1e8/agent/trajectory.jsonl) |
| test:10524 | completed | 1 | 7.21 | 0.00 | complete / not-produced | — | [result](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/f65b4230-c0f8-4a72-8b9e-d6d13547abad/result.json) · [文件清单](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/f65b4230-c0f8-4a72-8b9e-d6d13547abad/files.json) · [轨迹](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/f65b4230-c0f8-4a72-8b9e-d6d13547abad/agent/trajectory.jsonl) |
| test:10607 | completed | 1 | 5.39 | 0.00 | complete / not-produced | — | [result](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/3709f3ed-109b-47fe-a74c-36cb5edca0e3/result.json) · [文件清单](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/3709f3ed-109b-47fe-a74c-36cb5edca0e3/files.json) · [轨迹](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/3709f3ed-109b-47fe-a74c-36cb5edca0e3/agent/trajectory.jsonl) |
| test:10656 | completed | 1 | 4.17 | 0.00 | complete / not-produced | — | [result](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/f933edad-459c-4f10-8e42-5ef94e2a2202/result.json) · [文件清单](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/f933edad-459c-4f10-8e42-5ef94e2a2202/files.json) · [轨迹](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/f933edad-459c-4f10-8e42-5ef94e2a2202/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

