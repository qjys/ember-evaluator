<!-- snapshotDigest: dfd81988df88de6f668e6c3944d4e956e139f753df3008722ce62d5a8eec22c9 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: a7ec0022-aabe-40d0-be28-d782a1174ea9 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:51:34.910Z / 2026-11-12T08:55:06.247Z |
| 总耗时 | 3 分 24 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 3 分 24 秒 |
| 环境准备耗时 | 2 分 12 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 29 秒 | 23 秒 | 37 秒 | 24 |
| 任务准备 | 0.39 毫秒 | 0.21 毫秒 | 0.73 毫秒 | 24 |
| 环境启动 | 13 秒 | 9 秒 | 18 秒 | 24 |
| 解题 | 8 秒 | 5 秒 | 14 秒 | 24 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 24 |
| 资源清理 | 6 秒 | 4 秒 | 9 秒 | 24 |
| 评分 | 0.66 毫秒 | 0.18 毫秒 | 3.93 毫秒 | 24 |
| 证据收集 | 17.48 毫秒 | 2.82 毫秒 | 122.03 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 16869615-c850-4c2a-a3cf-9a13ffdd6b00 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 37,445 | 7,835 | 45,280 | 24 / 24 | — |
| 运行累计 | 37,445 | 7,835 | 45,280 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:7462 | completed | 1 | 9.13 | 0.00 | complete / not-produced | — | [result](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/b98d4d3e-02c5-4d4c-9bd8-40633354d2a1/result.json) · [文件清单](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/b98d4d3e-02c5-4d4c-9bd8-40633354d2a1/files.json) · [轨迹](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/b98d4d3e-02c5-4d4c-9bd8-40633354d2a1/agent/trajectory.jsonl) |
| test:7526 | completed | 1 | 7.40 | 0.00 | complete / not-produced | — | [result](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/a7e39041-bb2a-4f87-8791-c4318e1e0d88/result.json) · [文件清单](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/a7e39041-bb2a-4f87-8791-c4318e1e0d88/files.json) · [轨迹](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/a7e39041-bb2a-4f87-8791-c4318e1e0d88/agent/trajectory.jsonl) |
| test:7727 | completed | 1 | 8.69 | 0.00 | complete / not-produced | — | [result](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/50993bb6-de0d-4b19-b22d-9bb197e7d8bb/result.json) · [文件清单](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/50993bb6-de0d-4b19-b22d-9bb197e7d8bb/files.json) · [轨迹](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/50993bb6-de0d-4b19-b22d-9bb197e7d8bb/agent/trajectory.jsonl) |
| test:7752 | completed | 0 | 9.67 | 0.00 | complete / not-produced | — | [result](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/cff74e11-18de-4d7b-ac5a-2ad083bb52c2/result.json) · [文件清单](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/cff74e11-18de-4d7b-ac5a-2ad083bb52c2/files.json) · [轨迹](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/cff74e11-18de-4d7b-ac5a-2ad083bb52c2/agent/trajectory.jsonl) |
| test:7838 | completed | 1 | 7.15 | 0.00 | complete / not-produced | — | [result](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/771f034a-e299-4f37-8c96-661634f3a97a/result.json) · [文件清单](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/771f034a-e299-4f37-8c96-661634f3a97a/files.json) · [轨迹](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/771f034a-e299-4f37-8c96-661634f3a97a/agent/trajectory.jsonl) |
| test:7954 | completed | 1 | 6.32 | 0.00 | complete / not-produced | — | [result](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/c9dd65a3-82b2-41fd-b1b0-a54fd7adcb71/result.json) · [文件清单](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/c9dd65a3-82b2-41fd-b1b0-a54fd7adcb71/files.json) · [轨迹](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/c9dd65a3-82b2-41fd-b1b0-a54fd7adcb71/agent/trajectory.jsonl) |
| test:7976 | completed | 1 | 5.50 | 0.00 | complete / not-produced | — | [result](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/f0417e01-2635-4962-af41-e209bb752575/result.json) · [文件清单](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/f0417e01-2635-4962-af41-e209bb752575/files.json) · [轨迹](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/f0417e01-2635-4962-af41-e209bb752575/agent/trajectory.jsonl) |
| test:8199 | completed | 1 | 5.64 | 0.00 | complete / not-produced | — | [result](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/8fddb37b-ffb8-4498-8777-d60d3600bcfb/result.json) · [文件清单](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/8fddb37b-ffb8-4498-8777-d60d3600bcfb/files.json) · [轨迹](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/8fddb37b-ffb8-4498-8777-d60d3600bcfb/agent/trajectory.jsonl) |
| test:8207 | completed | 1 | 5.91 | 0.00 | complete / not-produced | — | [result](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/805179ef-075e-4429-b2d3-514e34e39713/result.json) · [文件清单](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/805179ef-075e-4429-b2d3-514e34e39713/files.json) · [轨迹](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/805179ef-075e-4429-b2d3-514e34e39713/agent/trajectory.jsonl) |
| test:8304 | completed | 1 | 6.71 | 0.00 | complete / not-produced | — | [result](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/c5f1ebd7-6d94-4ded-be93-9f7abe72199e/result.json) · [文件清单](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/c5f1ebd7-6d94-4ded-be93-9f7abe72199e/files.json) · [轨迹](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/c5f1ebd7-6d94-4ded-be93-9f7abe72199e/agent/trajectory.jsonl) |
| test:8366 | completed | 1 | 6.31 | 0.00 | complete / not-produced | — | [result](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/51ecfd52-8c97-4a79-b744-434d463591e8/result.json) · [文件清单](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/51ecfd52-8c97-4a79-b744-434d463591e8/files.json) · [轨迹](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/51ecfd52-8c97-4a79-b744-434d463591e8/agent/trajectory.jsonl) |
| test:8511 | completed | 1 | 5.60 | 0.00 | complete / not-produced | — | [result](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/be512222-6e9d-4758-ac28-4093cc179be5/result.json) · [文件清单](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/be512222-6e9d-4758-ac28-4093cc179be5/files.json) · [轨迹](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/be512222-6e9d-4758-ac28-4093cc179be5/agent/trajectory.jsonl) |
| test:8525 | completed | 1 | 7.52 | 0.00 | complete / not-produced | — | [result](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/de4cfdce-b60b-4b40-bb7a-53c74653f6ba/result.json) · [文件清单](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/de4cfdce-b60b-4b40-bb7a-53c74653f6ba/files.json) · [轨迹](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/de4cfdce-b60b-4b40-bb7a-53c74653f6ba/agent/trajectory.jsonl) |
| test:8604 | completed | 1 | 4.96 | 0.00 | complete / not-produced | — | [result](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/f94d0c02-5656-40cc-86bd-5fe9d50a0b77/result.json) · [文件清单](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/f94d0c02-5656-40cc-86bd-5fe9d50a0b77/files.json) · [轨迹](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/f94d0c02-5656-40cc-86bd-5fe9d50a0b77/agent/trajectory.jsonl) |
| test:8740 | completed | 1 | 7.30 | 0.00 | complete / not-produced | — | [result](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/da616989-b167-4b74-977c-6edcbda66c67/result.json) · [文件清单](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/da616989-b167-4b74-977c-6edcbda66c67/files.json) · [轨迹](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/da616989-b167-4b74-977c-6edcbda66c67/agent/trajectory.jsonl) |
| test:8839 | completed | 1 | 5.12 | 0.00 | complete / not-produced | — | [result](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/02633c7a-be8d-43c3-bc97-399083987f26/result.json) · [文件清单](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/02633c7a-be8d-43c3-bc97-399083987f26/files.json) · [轨迹](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/02633c7a-be8d-43c3-bc97-399083987f26/agent/trajectory.jsonl) |
| test:8939 | completed | 1 | 8.36 | 0.00 | complete / not-produced | — | [result](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/6a2551ef-9a87-4841-b152-71b59e58bb24/result.json) · [文件清单](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/6a2551ef-9a87-4841-b152-71b59e58bb24/files.json) · [轨迹](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/6a2551ef-9a87-4841-b152-71b59e58bb24/agent/trajectory.jsonl) |
| test:8967 | completed | 1 | 8.58 | 0.00 | complete / not-produced | — | [result](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/7f1ddfb3-6930-44fc-adbb-c0c36e80d200/result.json) · [文件清单](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/7f1ddfb3-6930-44fc-adbb-c0c36e80d200/files.json) · [轨迹](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/7f1ddfb3-6930-44fc-adbb-c0c36e80d200/agent/trajectory.jsonl) |
| test:8989 | completed | 1 | 12.30 | 0.00 | complete / not-produced | — | [result](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/64cc3dc9-8044-49bb-846f-997ffb652cde/result.json) · [文件清单](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/64cc3dc9-8044-49bb-846f-997ffb652cde/files.json) · [轨迹](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/64cc3dc9-8044-49bb-846f-997ffb652cde/agent/trajectory.jsonl) |
| test:9136 | completed | 1 | 10.29 | 0.00 | complete / not-produced | — | [result](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/59c3c793-8c45-4a0f-a0dd-989e7c91ab3d/result.json) · [文件清单](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/59c3c793-8c45-4a0f-a0dd-989e7c91ab3d/files.json) · [轨迹](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/59c3c793-8c45-4a0f-a0dd-989e7c91ab3d/agent/trajectory.jsonl) |
| test:9222 | completed | 1 | 4.96 | 0.00 | complete / not-produced | — | [result](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/7550d57c-fe54-4d6a-a297-d656d1cafe86/result.json) · [文件清单](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/7550d57c-fe54-4d6a-a297-d656d1cafe86/files.json) · [轨迹](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/7550d57c-fe54-4d6a-a297-d656d1cafe86/agent/trajectory.jsonl) |
| test:9391 | completed | 1 | 5.71 | 0.00 | complete / not-produced | — | [result](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/d8b1894b-51fc-49c4-8a0c-f0ef1e658d79/result.json) · [文件清单](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/d8b1894b-51fc-49c4-8a0c-f0ef1e658d79/files.json) · [轨迹](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/d8b1894b-51fc-49c4-8a0c-f0ef1e658d79/agent/trajectory.jsonl) |
| test:9395 | completed | 1 | 13.81 | 0.00 | complete / not-produced | — | [result](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b1b5fe35-1ed7-471e-aa65-e4a9f439b0c5/result.json) · [文件清单](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b1b5fe35-1ed7-471e-aa65-e4a9f439b0c5/files.json) · [轨迹](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b1b5fe35-1ed7-471e-aa65-e4a9f439b0c5/agent/trajectory.jsonl) |
| test:9405 | completed | 1 | 10.75 | 0.00 | complete / not-produced | — | [result](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/7f05f129-d994-4bb2-b642-afa47d0bc62f/result.json) · [文件清单](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/7f05f129-d994-4bb2-b642-afa47d0bc62f/files.json) · [轨迹](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/7f05f129-d994-4bb2-b642-afa47d0bc62f/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

