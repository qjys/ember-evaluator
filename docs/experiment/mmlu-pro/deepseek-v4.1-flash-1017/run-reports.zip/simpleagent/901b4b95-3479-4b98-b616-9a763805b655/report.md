<!-- snapshotDigest: d7a2e7e609ea51a1d1f8ddce09c38685636727d15d38e40ec89ace7fbca9cfe0 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 12.77%（18/141）**

Run: 901b4b95-3479-4b98-b616-9a763805b655 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:40:27.665Z / 2026-11-12T07:52:52.700Z |
| 总耗时 | 12 分 0 秒 |
| 答对 / 答错 / 解题超时 | 18 / 0 / 0 |
| 清理未确认 | 1 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 142 题；已保存 19 条记录；待运行 123 题。
有效评分覆盖率：18/142（12.68%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 142 |
| 计分题数 | 141 |
| 正常评分题数 | 18 |
| 答对题数 | 18 |
| 无效评测 | 1 |
| 待运行 | 123 |
| 正确率 | 12.77% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 12 分 0 秒 |
| 环境准备耗时 | 12 分 22 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 36 秒 | 19 秒 | 1 分 2 秒 | 19 |
| 任务准备 | 0.53 毫秒 | 0.28 毫秒 | 1.43 毫秒 | 19 |
| 环境启动 | 18 秒 | 9 秒 | 32 秒 | 19 |
| 解题 | 10 秒 | 4 秒 | 44 秒 | 19 |
| 产物传输 | 2 秒 | 805.24 毫秒 | 6 秒 | 19 |
| 资源清理 | 6 秒 | 3 秒 | 13 秒 | 19 |
| 评分 | 1.72 毫秒 | 0.48 毫秒 | 2.71 毫秒 | 18 |
| 证据收集 | 18.88 毫秒 | 9.25 毫秒 | 48.77 毫秒 | 19 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| f9e3e6ba-1254-4638-b0e3-1f2de8c3681b | 未设置 | 600 | 1 | 1 | 600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 36,752 | 14,873 | 51,625 | 19 / 142 | — |
| 运行累计 | 36,752 | 14,873 | 51,625 | 19 / 19 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4075 | completed | 1 | 6.66 | 0.00 | complete / not-produced | — | [result](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/05ed2d09-f9ee-4c08-b0aa-e29943af24c6/result.json) · [文件清单](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/05ed2d09-f9ee-4c08-b0aa-e29943af24c6/files.json) · [轨迹](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/05ed2d09-f9ee-4c08-b0aa-e29943af24c6/agent/trajectory.jsonl) |
| test:4142 | completed | 1 | 9.60 | 0.00 | complete / not-produced | — | [result](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/88e1b679-4bcd-419b-8056-ee3e8a200fd1/result.json) · [文件清单](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/88e1b679-4bcd-419b-8056-ee3e8a200fd1/files.json) · [轨迹](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/88e1b679-4bcd-419b-8056-ee3e8a200fd1/agent/trajectory.jsonl) |
| test:4208 | completed | 1 | 8.43 | 0.00 | complete / not-produced | — | [result](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/575db4e5-7764-4100-8ae8-55827efa0411/result.json) · [文件清单](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/575db4e5-7764-4100-8ae8-55827efa0411/files.json) · [轨迹](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/575db4e5-7764-4100-8ae8-55827efa0411/agent/trajectory.jsonl) |
| test:4298 | completed | 1 | 4.16 | 0.00 | complete / not-produced | — | [result](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/663fde5e-2877-4fa8-adb0-83e5ee7c1ef5/result.json) · [文件清单](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/663fde5e-2877-4fa8-adb0-83e5ee7c1ef5/files.json) · [轨迹](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/663fde5e-2877-4fa8-adb0-83e5ee7c1ef5/agent/trajectory.jsonl) |
| test:4337 | completed | 1 | 9.95 | 0.00 | complete / not-produced | — | [result](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/fec202a9-f563-4d37-9de1-629646c0842f/result.json) · [文件清单](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/fec202a9-f563-4d37-9de1-629646c0842f/files.json) · [轨迹](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/fec202a9-f563-4d37-9de1-629646c0842f/agent/trajectory.jsonl) |
| test:4376 | completed | 1 | 4.33 | 0.00 | complete / not-produced | — | [result](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/8c7eacf7-aedb-4a86-b9dc-afc5e1dfc99f/result.json) · [文件清单](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/8c7eacf7-aedb-4a86-b9dc-afc5e1dfc99f/files.json) · [轨迹](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/8c7eacf7-aedb-4a86-b9dc-afc5e1dfc99f/agent/trajectory.jsonl) |
| test:4405 | completed | 1 | 5.31 | 0.00 | complete / not-produced | — | [result](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/b207cc4f-342c-4bf4-9c75-404313ae2cef/result.json) · [文件清单](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/b207cc4f-342c-4bf4-9c75-404313ae2cef/files.json) · [轨迹](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/b207cc4f-342c-4bf4-9c75-404313ae2cef/agent/trajectory.jsonl) |
| test:4552 | completed | 1 | 43.75 | 0.00 | complete / not-produced | — | [result](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/935e6f45-7df4-4bb7-ac1f-e50d3a612ad1/result.json) · [文件清单](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/935e6f45-7df4-4bb7-ac1f-e50d3a612ad1/files.json) · [轨迹](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/935e6f45-7df4-4bb7-ac1f-e50d3a612ad1/agent/trajectory.jsonl) |
| test:4560 | completed | 1 | 6.14 | 0.00 | complete / not-produced | — | [result](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/cc5886ed-8640-4ff8-8a9b-303a29ad0be3/result.json) · [文件清单](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/cc5886ed-8640-4ff8-8a9b-303a29ad0be3/files.json) · [轨迹](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/cc5886ed-8640-4ff8-8a9b-303a29ad0be3/agent/trajectory.jsonl) |
| test:4568 | completed | 1 | 4.95 | 0.00 | complete / not-produced | — | [result](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/46e8afd3-b06a-42d7-a82c-ea807b76f31f/result.json) · [文件清单](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/46e8afd3-b06a-42d7-a82c-ea807b76f31f/files.json) · [轨迹](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/46e8afd3-b06a-42d7-a82c-ea807b76f31f/agent/trajectory.jsonl) |
| test:4580 | completed | 1 | 23.20 | 0.00 | complete / not-produced | — | [result](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/1d9d1386-1f89-41c4-9ca6-46c600cd3d15/result.json) · [文件清单](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/1d9d1386-1f89-41c4-9ca6-46c600cd3d15/files.json) · [轨迹](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/1d9d1386-1f89-41c4-9ca6-46c600cd3d15/agent/trajectory.jsonl) |
| test:4603 | completed | 1 | 5.92 | 0.00 | complete / not-produced | — | [result](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/05908a24-aa95-4a03-9805-49d3eba08ebe/result.json) · [文件清单](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/05908a24-aa95-4a03-9805-49d3eba08ebe/files.json) · [轨迹](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/05908a24-aa95-4a03-9805-49d3eba08ebe/agent/trajectory.jsonl) |
| test:4625 | completed | 1 | 4.75 | 0.00 | complete / not-produced | — | [result](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/63d4ce34-6bfe-4687-8c22-47527b6c6003/result.json) · [文件清单](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/63d4ce34-6bfe-4687-8c22-47527b6c6003/files.json) · [轨迹](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/63d4ce34-6bfe-4687-8c22-47527b6c6003/agent/trajectory.jsonl) |
| test:4627 | completed | 1 | 4.69 | 0.00 | complete / not-produced | — | [result](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/d33b4f88-6c62-4ddf-94e5-30b8f8a17e48/result.json) · [文件清单](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/d33b4f88-6c62-4ddf-94e5-30b8f8a17e48/files.json) · [轨迹](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/d33b4f88-6c62-4ddf-94e5-30b8f8a17e48/agent/trajectory.jsonl) |
| test:4651 | completed | 1 | 4.20 | 0.00 | complete / not-produced | — | [result](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/913fc2fa-d8a0-4484-9422-68aa08fa4bed/result.json) · [文件清单](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/913fc2fa-d8a0-4484-9422-68aa08fa4bed/files.json) · [轨迹](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/913fc2fa-d8a0-4484-9422-68aa08fa4bed/agent/trajectory.jsonl) |
| test:4670 | completed | 1 | 12.82 | 0.00 | complete / not-produced | — | [result](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/fc08e4b6-f08a-418e-82d2-a212aa3f0e0b/result.json) · [文件清单](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/fc08e4b6-f08a-418e-82d2-a212aa3f0e0b/files.json) · [轨迹](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/fc08e4b6-f08a-418e-82d2-a212aa3f0e0b/agent/trajectory.jsonl) |
| test:4700 | completed | 1 | 5.59 | 0.00 | complete / not-produced | — | [result](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/a63e6f80-e0a9-472c-a8ea-13909147e566/result.json) · [文件清单](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/a63e6f80-e0a9-472c-a8ea-13909147e566/files.json) · [轨迹](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/a63e6f80-e0a9-472c-a8ea-13909147e566/agent/trajectory.jsonl) |
| test:4709 | completed | 1 | 23.33 | 0.00 | complete / not-produced | — | [result](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/74b8fd85-b398-48cc-b243-977109a1b404/result.json) · [文件清单](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/74b8fd85-b398-48cc-b243-977109a1b404/files.json) · [轨迹](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/74b8fd85-b398-48cc-b243-977109a1b404/agent/trajectory.jsonl) |
| test:4763 | invalid | — | 9.72 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/f7a51767-4e1a-47a8-aec6-54f7573cae81/result.json) · [文件清单](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/f7a51767-4e1a-47a8-aec6-54f7573cae81/files.json) · [轨迹](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/f7a51767-4e1a-47a8-aec6-54f7573cae81/agent/trajectory.jsonl) |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 0；证据收集 0；资源清理 2）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| cleanup | CLEANUP_FAILED | 1 | 2 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

