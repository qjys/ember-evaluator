<!-- snapshotDigest: 6a4780545249c3d039a3bfa3e4f5004f7a037f6c228bb722f79083ad775c7c18 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 79.17%（19/24）**

Run: 0f92d26a-f6c7-461f-9435-a83d60fb1b33 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:41:05.022Z / 2026-11-12T08:46:07.439Z |
| 总耗时 | 4 分 52 秒 |
| 答对 / 答错 / 解题超时 | 19 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 19 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 79.17% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 4 分 52 秒 |
| 环境准备耗时 | 3 分 3 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 43 秒 | 34 秒 | 58 秒 | 24 |
| 任务准备 | 0.46 毫秒 | 0.29 毫秒 | 0.88 毫秒 | 24 |
| 环境启动 | 20 秒 | 15 秒 | 25 秒 | 24 |
| 解题 | 11 秒 | 6 秒 | 23 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 9 秒 | 8 秒 | 13 秒 | 24 |
| 评分 | 2.06 毫秒 | 0.28 毫秒 | 11.61 毫秒 | 24 |
| 证据收集 | 11.89 毫秒 | 3.56 毫秒 | 36.52 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 302de5a2-55d1-4836-b8ec-3c960530b049 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 29,388 | 10,992 | 40,380 | 24 / 24 | — |
| 运行累计 | 29,388 | 10,992 | 40,380 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4763 | completed | 0 | 11.28 | 0.00 | complete / not-produced | — | [result](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/baa75498-a19d-4a48-a14b-3a1405cd71f1/result.json) · [文件清单](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/baa75498-a19d-4a48-a14b-3a1405cd71f1/files.json) · [轨迹](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/baa75498-a19d-4a48-a14b-3a1405cd71f1/agent/trajectory.jsonl) |
| test:4770 | completed | 1 | 9.53 | 0.01 | complete / not-produced | — | [result](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/4ba61a62-f418-46b5-9a25-9d6d2c309a68/result.json) · [文件清单](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/4ba61a62-f418-46b5-9a25-9d6d2c309a68/files.json) · [轨迹](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/4ba61a62-f418-46b5-9a25-9d6d2c309a68/agent/trajectory.jsonl) |
| test:4786 | completed | 1 | 9.38 | 0.00 | complete / not-produced | — | [result](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/cb10880c-b530-4b0b-ba78-f41d66364724/result.json) · [文件清单](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/cb10880c-b530-4b0b-ba78-f41d66364724/files.json) · [轨迹](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/cb10880c-b530-4b0b-ba78-f41d66364724/agent/trajectory.jsonl) |
| test:4879 | completed | 1 | 16.48 | 0.00 | complete / not-produced | — | [result](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/1eb4bb17-cae9-463d-a7a1-30cf106c5294/result.json) · [文件清单](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/1eb4bb17-cae9-463d-a7a1-30cf106c5294/files.json) · [轨迹](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/1eb4bb17-cae9-463d-a7a1-30cf106c5294/agent/trajectory.jsonl) |
| test:5078 | completed | 0 | 22.72 | 0.01 | complete / not-produced | — | [result](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/0bf4daec-c3da-4018-87d8-d46c5475469b/result.json) · [文件清单](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/0bf4daec-c3da-4018-87d8-d46c5475469b/files.json) · [轨迹](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/0bf4daec-c3da-4018-87d8-d46c5475469b/agent/trajectory.jsonl) |
| test:5123 | completed | 1 | 8.11 | 0.00 | complete / not-produced | — | [result](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/922fdac0-191b-41b5-8277-15a900fe4f72/result.json) · [文件清单](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/922fdac0-191b-41b5-8277-15a900fe4f72/files.json) · [轨迹](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/922fdac0-191b-41b5-8277-15a900fe4f72/agent/trajectory.jsonl) |
| test:5174 | completed | 1 | 7.26 | 0.00 | complete / not-produced | — | [result](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/79df88f0-8f98-49f5-a1aa-e9e35b82fe4c/result.json) · [文件清单](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/79df88f0-8f98-49f5-a1aa-e9e35b82fe4c/files.json) · [轨迹](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/79df88f0-8f98-49f5-a1aa-e9e35b82fe4c/agent/trajectory.jsonl) |
| test:5198 | completed | 1 | 6.43 | 0.00 | complete / not-produced | — | [result](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/46babaf4-4c69-42f4-9121-17e5b73c81f9/result.json) · [文件清单](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/46babaf4-4c69-42f4-9121-17e5b73c81f9/files.json) · [轨迹](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/46babaf4-4c69-42f4-9121-17e5b73c81f9/agent/trajectory.jsonl) |
| test:5243 | completed | 1 | 9.30 | 0.00 | complete / not-produced | — | [result](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/127cb4f6-90b0-4c36-8865-a4120a88feef/result.json) · [文件清单](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/127cb4f6-90b0-4c36-8865-a4120a88feef/files.json) · [轨迹](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/127cb4f6-90b0-4c36-8865-a4120a88feef/agent/trajectory.jsonl) |
| test:5309 | completed | 1 | 8.05 | 0.00 | complete / not-produced | — | [result](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/c69d602b-05ff-4156-bed8-32fe0d8cc83e/result.json) · [文件清单](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/c69d602b-05ff-4156-bed8-32fe0d8cc83e/files.json) · [轨迹](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/c69d602b-05ff-4156-bed8-32fe0d8cc83e/agent/trajectory.jsonl) |
| test:5319 | completed | 1 | 10.67 | 0.00 | complete / not-produced | — | [result](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/c85ad50f-a12f-416d-8352-741a4a25e3a5/result.json) · [文件清单](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/c85ad50f-a12f-416d-8352-741a4a25e3a5/files.json) · [轨迹](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/c85ad50f-a12f-416d-8352-741a4a25e3a5/agent/trajectory.jsonl) |
| test:5328 | completed | 0 | 9.74 | 0.00 | complete / not-produced | — | [result](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/96b72730-ca0f-4283-9464-829b28e19fe8/result.json) · [文件清单](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/96b72730-ca0f-4283-9464-829b28e19fe8/files.json) · [轨迹](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/96b72730-ca0f-4283-9464-829b28e19fe8/agent/trajectory.jsonl) |
| test:5361 | completed | 0 | 22.08 | 0.01 | complete / not-produced | — | [result](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/ff79c469-6b58-4a5a-ad3a-9bf8745116a5/result.json) · [文件清单](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/ff79c469-6b58-4a5a-ad3a-9bf8745116a5/files.json) · [轨迹](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/ff79c469-6b58-4a5a-ad3a-9bf8745116a5/agent/trajectory.jsonl) |
| test:5457 | completed | 1 | 8.56 | 0.00 | complete / not-produced | — | [result](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/8cc178fa-8188-49c7-93d0-26240d2a29e5/result.json) · [文件清单](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/8cc178fa-8188-49c7-93d0-26240d2a29e5/files.json) · [轨迹](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/8cc178fa-8188-49c7-93d0-26240d2a29e5/agent/trajectory.jsonl) |
| test:5461 | completed | 1 | 7.59 | 0.00 | complete / not-produced | — | [result](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/eb6fb575-a10a-4c22-b55f-534ac2be3036/result.json) · [文件清单](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/eb6fb575-a10a-4c22-b55f-534ac2be3036/files.json) · [轨迹](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/eb6fb575-a10a-4c22-b55f-534ac2be3036/agent/trajectory.jsonl) |
| test:5530 | completed | 0 | 12.42 | 0.00 | complete / not-produced | — | [result](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/f3c23e97-9729-4c76-b939-40cbf198f1bf/result.json) · [文件清单](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/f3c23e97-9729-4c76-b939-40cbf198f1bf/files.json) · [轨迹](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/f3c23e97-9729-4c76-b939-40cbf198f1bf/agent/trajectory.jsonl) |
| test:5578 | completed | 1 | 11.48 | 0.00 | complete / not-produced | — | [result](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/c18a1d7b-5465-409d-8ae7-8e7739cf86b7/result.json) · [文件清单](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/c18a1d7b-5465-409d-8ae7-8e7739cf86b7/files.json) · [轨迹](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/c18a1d7b-5465-409d-8ae7-8e7739cf86b7/agent/trajectory.jsonl) |
| test:5580 | completed | 1 | 14.62 | 0.00 | complete / not-produced | — | [result](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/8f581d47-5b3c-4b69-80ae-0438875a3310/result.json) · [文件清单](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/8f581d47-5b3c-4b69-80ae-0438875a3310/files.json) · [轨迹](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/8f581d47-5b3c-4b69-80ae-0438875a3310/agent/trajectory.jsonl) |
| test:5795 | completed | 1 | 7.51 | 0.00 | complete / not-produced | — | [result](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/7df71e9a-834e-474f-b108-b60633b8abcb/result.json) · [文件清单](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/7df71e9a-834e-474f-b108-b60633b8abcb/files.json) · [轨迹](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/7df71e9a-834e-474f-b108-b60633b8abcb/agent/trajectory.jsonl) |
| test:5919 | completed | 1 | 14.80 | 0.00 | complete / not-produced | — | [result](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/ed1b4730-1875-4b36-85e1-b9a00fa71617/result.json) · [文件清单](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/ed1b4730-1875-4b36-85e1-b9a00fa71617/files.json) · [轨迹](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/ed1b4730-1875-4b36-85e1-b9a00fa71617/agent/trajectory.jsonl) |
| test:5940 | completed | 1 | 6.42 | 0.00 | complete / not-produced | — | [result](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/c157678f-527a-4136-80ca-aabccfd200ac/result.json) · [文件清单](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/c157678f-527a-4136-80ca-aabccfd200ac/files.json) · [轨迹](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/c157678f-527a-4136-80ca-aabccfd200ac/agent/trajectory.jsonl) |
| test:6055 | completed | 1 | 6.12 | 0.00 | complete / not-produced | — | [result](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/07d01b86-3a37-49e5-a109-f437f1561503/result.json) · [文件清单](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/07d01b86-3a37-49e5-a109-f437f1561503/files.json) · [轨迹](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/07d01b86-3a37-49e5-a109-f437f1561503/agent/trajectory.jsonl) |
| test:6095 | completed | 1 | 6.66 | 0.00 | complete / not-produced | — | [result](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/47095080-45f6-42fe-bac0-ea65fdb9a483/result.json) · [文件清单](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/47095080-45f6-42fe-bac0-ea65fdb9a483/files.json) · [轨迹](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/47095080-45f6-42fe-bac0-ea65fdb9a483/agent/trajectory.jsonl) |
| test:6120 | completed | 1 | 7.60 | 0.00 | complete / not-produced | — | [result](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/2201359c-857d-4fe0-943a-779eb57ca848/result.json) · [文件清单](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/2201359c-857d-4fe0-943a-779eb57ca848/files.json) · [轨迹](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/2201359c-857d-4fe0-943a-779eb57ca848/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

