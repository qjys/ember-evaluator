<!-- snapshotDigest: 9e371f654a240ef42dc2fcc14008438e846c0c16c7fb81f4f35d60daad1a9769 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 100.00%（4/4）**

Run: d70d9e9f-73d1-42e1-91f5-b1fd4147ff2f · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T09:05:22.104Z / 2026-11-12T09:06:00.151Z |
| 总耗时 | 37 秒 |
| 答对 / 答错 / 解题超时 | 4 / 0 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 4 题；已保存 4 条记录；待运行 0 题。
有效评分覆盖率：4/4（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 4 |
| 计分题数 | 4 |
| 正常评分题数 | 4 |
| 答对题数 | 4 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 100.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 37 秒 |
| 环境准备耗时 | 11 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 17 秒 | 14 秒 | 19 秒 | 4 |
| 任务准备 | 0.39 毫秒 | 0.25 毫秒 | 0.81 毫秒 | 4 |
| 环境启动 | 6 秒 | 5 秒 | 8 秒 | 4 |
| 解题 | 7 秒 | 4 秒 | 8 秒 | 4 |
| 产物传输 | 948.15 毫秒 | 817.01 毫秒 | 1 秒 | 4 |
| 资源清理 | 3 秒 | 2 秒 | 3 秒 | 4 |
| 评分 | 0.61 毫秒 | 0.3 毫秒 | 1.45 毫秒 | 4 |
| 证据收集 | 5.64 毫秒 | 3.25 毫秒 | 9.99 毫秒 | 4 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 64c11971-8b28-4f85-a888-d2537ca1c5d4 | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 5,196 | 2,793 | 7,989 | 4 / 4 | — |
| 运行累计 | 5,196 | 2,793 | 7,989 | 4 / 4 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:11808 | completed | 1 | 7.76 | 0.00 | complete / not-produced | — | [result](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/c83fdc22-d38b-480d-9cbf-1caaedf3e116/result.json) · [文件清单](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/c83fdc22-d38b-480d-9cbf-1caaedf3e116/files.json) · [轨迹](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/c83fdc22-d38b-480d-9cbf-1caaedf3e116/agent/trajectory.jsonl) |
| test:11824 | completed | 1 | 3.72 | 0.00 | complete / not-produced | — | [result](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/f2e5abbe-89a0-4ff1-be05-d4a4701c6174/result.json) · [文件清单](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/f2e5abbe-89a0-4ff1-be05-d4a4701c6174/files.json) · [轨迹](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/f2e5abbe-89a0-4ff1-be05-d4a4701c6174/agent/trajectory.jsonl) |
| test:11925 | completed | 1 | 7.70 | 0.00 | complete / not-produced | — | [result](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/e10b0921-1196-4f19-8221-77b51129b129/result.json) · [文件清单](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/e10b0921-1196-4f19-8221-77b51129b129/files.json) · [轨迹](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/e10b0921-1196-4f19-8221-77b51129b129/agent/trajectory.jsonl) |
| test:12002 | completed | 1 | 8.20 | 0.00 | complete / not-produced | — | [result](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/5de5b380-29cb-449a-a828-499fe43272ad/result.json) · [文件清单](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/5de5b380-29cb-449a-a828-499fe43272ad/files.json) · [轨迹](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/5de5b380-29cb-449a-a828-499fe43272ad/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

