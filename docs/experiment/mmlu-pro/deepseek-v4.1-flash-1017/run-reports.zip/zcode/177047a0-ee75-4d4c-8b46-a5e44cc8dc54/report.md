<!-- snapshotDigest: 8f6bfa8f042302848d4b88c65ba14175bd96a9c67f3125cd0b8245ffcedd71bf -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 2.91%（6/206）**

Run: 177047a0-ee75-4d4c-8b46-a5e44cc8dc54 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:18:06.183Z / 2026-11-12T07:27:13.591Z |
| 总耗时 | 8 分 50 秒 |
| 答对 / 答错 / 解题超时 | 6 / 1 / 0 |
| 清理未确认 | 1 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 210 题；已保存 11 条记录；待运行 202 题。
有效评分覆盖率：7/210（3.33%）。
执行失败 1；超时 0；取消 3；不支持 0。
Agent 解题超时 0（计 0 分）；无效 4。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 210 |
| 计分题数 | 206 |
| 正常评分题数 | 7 |
| 答对题数 | 6 |
| 无效评测 | 4 |
| 待运行 | 202 |
| 正确率 | 2.91% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 8 分 50 秒 |
| 环境准备耗时 | 9 分 0 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 37 秒 | 216.96 毫秒 | 1 分 8 秒 | 11 |
| 任务准备 | 3.32 毫秒 | 0.32 毫秒 | 25.07 毫秒 | 11 |
| 环境启动 | 17 秒 | 138.38 毫秒 | 31 秒 | 11 |
| 解题 | 15 秒 | 10 秒 | 30 秒 | 9 |
| 产物传输 | 2 秒 | 273.99 毫秒 | 2 秒 | 9 |
| 资源清理 | 7 秒 | 4 秒 | 14 秒 | 9 |
| 评分 | 1.14 毫秒 | 0.46 毫秒 | 2.59 毫秒 | 7 |
| 证据收集 | 91.14 毫秒 | 3.14 毫秒 | 440.79 毫秒 | 11 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| d31e0f02-c77b-4e49-98e7-9478a16ecf65 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 17,264 | 7,349 | 24,613 | 9 / 210 | — |
| 运行累计 | 17,264 | 7,349 | 24,613 | 9 / 11 | 2 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:41 | completed | 1 | 11.09 | 0.00 | complete / not-produced | — | [result](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/ccd7dde1-7ff1-44a9-ad7e-6cf8161c0fef/result.json) · [文件清单](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/ccd7dde1-7ff1-44a9-ad7e-6cf8161c0fef/files.json) · [轨迹](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/ccd7dde1-7ff1-44a9-ad7e-6cf8161c0fef/agent/trajectory.jsonl) |
| test:61 | completed | 0 | 20.89 | 0.00 | complete / not-produced | — | [result](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/ffa77a8e-6b64-4e74-877d-08b96ae4ce88/result.json) · [文件清单](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/ffa77a8e-6b64-4e74-877d-08b96ae4ce88/files.json) · [轨迹](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/ffa77a8e-6b64-4e74-877d-08b96ae4ce88/agent/trajectory.jsonl) |
| test:97 | completed | 1 | 30.23 | 0.00 | complete / not-produced | — | [result](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/add117b8-7a70-404d-8fdb-02f526f8e9cc/result.json) · [文件清单](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/add117b8-7a70-404d-8fdb-02f526f8e9cc/files.json) · [轨迹](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/add117b8-7a70-404d-8fdb-02f526f8e9cc/agent/trajectory.jsonl) |
| test:209 | completed | 1 | 10.48 | 0.00 | complete / not-produced | — | [result](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/7eb59b3e-fb3f-4dd7-a2bf-3280b9dadb1c/result.json) · [文件清单](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/7eb59b3e-fb3f-4dd7-a2bf-3280b9dadb1c/files.json) · [轨迹](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/7eb59b3e-fb3f-4dd7-a2bf-3280b9dadb1c/agent/trajectory.jsonl) |
| test:286 | completed | 1 | 11.01 | 0.00 | complete / not-produced | — | [result](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/b1d6450d-e6b3-43d9-b379-c0e71d18cf8a/result.json) · [文件清单](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/b1d6450d-e6b3-43d9-b379-c0e71d18cf8a/files.json) · [轨迹](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/b1d6450d-e6b3-43d9-b379-c0e71d18cf8a/agent/trajectory.jsonl) |
| test:299 | completed | 1 | 12.68 | 0.00 | complete / not-produced | — | [result](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/224f4d6a-1aa9-413a-91c3-5559dcace7c1/result.json) · [文件清单](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/224f4d6a-1aa9-413a-91c3-5559dcace7c1/files.json) · [轨迹](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/224f4d6a-1aa9-413a-91c3-5559dcace7c1/agent/trajectory.jsonl) |
| test:311 | invalid | — | 18.42 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/4ac9fa21-d183-46c6-83fb-9d914e6f10d3/result.json) · [文件清单](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/4ac9fa21-d183-46c6-83fb-9d914e6f10d3/files.json) · [轨迹](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/4ac9fa21-d183-46c6-83fb-9d914e6f10d3/agent/trajectory.jsonl) |
| test:352 | completed | 1 | 11.26 | 0.00 | complete / not-produced | — | [result](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/7845e08c-b13a-472b-8278-08a4631a7135/result.json) · [文件清单](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/7845e08c-b13a-472b-8278-08a4631a7135/files.json) · [轨迹](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/7845e08c-b13a-472b-8278-08a4631a7135/agent/trajectory.jsonl) |
| test:355 | cancelled | — | 10.88 | — | complete / not-produced | RUN\_CANCELLED | [result](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/27a56b31-6e4e-4883-8eff-a30b111a87ab/result.json) · [文件清单](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/27a56b31-6e4e-4883-8eff-a30b111a87ab/files.json) · [轨迹](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/27a56b31-6e4e-4883-8eff-a30b111a87ab/agent/trajectory.jsonl) |
| test:476 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/283be75a-bfe1-41d3-9009-0d264a04a6f4/result.json) · [文件清单](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/283be75a-bfe1-41d3-9009-0d264a04a6f4/files.json) |
| test:511 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/fc46efdd-667d-49b4-950a-dfd3e3497ce4/result.json) · [文件清单](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/fc46efdd-667d-49b4-950a-dfd3e3497ce4/files.json) |
| test:552 | pending | — | — | — | — | — | — |
| test:624 | pending | — | — | — | — | — | — |
| test:669 | pending | — | — | — | — | — | — |
| test:670 | pending | — | — | — | — | — | — |
| test:796 | pending | — | — | — | — | — | — |
| test:828 | pending | — | — | — | — | — | — |
| test:841 | pending | — | — | — | — | — | — |
| test:883 | pending | — | — | — | — | — | — |
| test:938 | pending | — | — | — | — | — | — |
| test:1026 | pending | — | — | — | — | — | — |
| test:1229 | pending | — | — | — | — | — | — |
| test:1252 | pending | — | — | — | — | — | — |
| test:1399 | pending | — | — | — | — | — | — |
| test:1454 | pending | — | — | — | — | — | — |
| test:1514 | pending | — | — | — | — | — | — |
| test:1531 | pending | — | — | — | — | — | — |
| test:1785 | pending | — | — | — | — | — | — |
| test:1806 | pending | — | — | — | — | — | — |
| test:1827 | pending | — | — | — | — | — | — |
| test:1904 | pending | — | — | — | — | — | — |
| test:1943 | pending | — | — | — | — | — | — |
| test:1998 | pending | — | — | — | — | — | — |
| test:2023 | pending | — | — | — | — | — | — |
| test:2096 | pending | — | — | — | — | — | — |
| test:2152 | pending | — | — | — | — | — | — |
| test:2175 | pending | — | — | — | — | — | — |
| test:2177 | pending | — | — | — | — | — | — |
| test:2206 | pending | — | — | — | — | — | — |
| test:2280 | pending | — | — | — | — | — | — |
| test:2347 | pending | — | — | — | — | — | — |
| test:2400 | pending | — | — | — | — | — | — |
| test:2527 | pending | — | — | — | — | — | — |
| test:2636 | pending | — | — | — | — | — | — |
| test:2641 | pending | — | — | — | — | — | — |
| test:2714 | pending | — | — | — | — | — | — |
| test:2716 | pending | — | — | — | — | — | — |
| test:2747 | pending | — | — | — | — | — | — |
| test:2882 | pending | — | — | — | — | — | — |
| test:2951 | pending | — | — | — | — | — | — |
| test:3037 | pending | — | — | — | — | — | — |
| test:3053 | pending | — | — | — | — | — | — |
| test:3136 | pending | — | — | — | — | — | — |
| test:3165 | pending | — | — | — | — | — | — |
| test:3196 | pending | — | — | — | — | — | — |
| test:3231 | pending | — | — | — | — | — | — |
| test:3236 | pending | — | — | — | — | — | — |
| test:3270 | pending | — | — | — | — | — | — |
| test:3293 | pending | — | — | — | — | — | — |
| test:3331 | pending | — | — | — | — | — | — |
| test:3488 | pending | — | — | — | — | — | — |
| test:3491 | pending | — | — | — | — | — | — |
| test:3552 | pending | — | — | — | — | — | — |
| test:3599 | pending | — | — | — | — | — | — |
| test:3626 | pending | — | — | — | — | — | — |
| test:4021 | pending | — | — | — | — | — | — |
| test:4034 | pending | — | — | — | — | — | — |
| test:4058 | pending | — | — | — | — | — | — |
| test:4075 | pending | — | — | — | — | — | — |
| test:4142 | pending | — | — | — | — | — | — |
| test:4208 | pending | — | — | — | — | — | — |
| test:4298 | pending | — | — | — | — | — | — |
| test:4337 | pending | — | — | — | — | — | — |
| test:4376 | pending | — | — | — | — | — | — |
| test:4405 | pending | — | — | — | — | — | — |
| test:4552 | pending | — | — | — | — | — | — |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 4；错误记录 5（主流程 3；证据收集 0；资源清理 2）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| cleanup | CLEANUP_FAILED | 1 | 2 |
| transfer | RUN_CANCELLED | 1 | 1 |
| environment | RUN_CANCELLED | 2 | 2 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

