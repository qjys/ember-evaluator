<!-- snapshotDigest: 78faee782c0ab6c94102b847cd8443fa95e23b16a135801b919f9e87d777a5f5 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 13.93%（28/201）**

Run: f1b6679e-b9e4-4016-99db-a35095b1e0c9 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:35:08.750Z / 2026-11-12T07:51:29.190Z |
| 总耗时 | 15 分 49 秒 |
| 答对 / 答错 / 解题超时 | 28 / 6 / 0 |
| 清理未确认 | 1 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 203 题；已保存 36 条记录；待运行 168 题。
有效评分覆盖率：34/203（16.75%）。
执行失败 1；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 2。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 203 |
| 计分题数 | 201 |
| 正常评分题数 | 34 |
| 答对题数 | 28 |
| 无效评测 | 2 |
| 待运行 | 168 |
| 正确率 | 13.93% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 15 分 49 秒 |
| 环境准备耗时 | 16 分 18 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 51 秒 | 22 秒 | 3 分 43 秒 | 36 |
| 任务准备 | 0.44 毫秒 | 0.22 毫秒 | 2.08 毫秒 | 36 |
| 环境启动 | 22 秒 | 9 秒 | 54 秒 | 36 |
| 解题 | 22 秒 | 2 秒 | 3 分 16 秒 | 36 |
| 产物传输 | 2 秒 | 741.53 毫秒 | 4 秒 | 35 |
| 资源清理 | 6 秒 | 3 秒 | 15 秒 | 36 |
| 评分 | 1.3 毫秒 | 0.41 毫秒 | 2.67 毫秒 | 34 |
| 证据收集 | 32.26 毫秒 | 7.99 毫秒 | 201.39 毫秒 | 36 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 7a91cf9f-d600-454c-86a9-96911f6b6fb3 | 未设置 | 600 | 2 | 2 | 1200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 73,635 | 55,960 | 129,595 | 35 / 203 | — |
| 运行累计 | 73,635 | 55,960 | 129,595 | 35 / 36 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:311 | completed | 1 | 21.57 | 0.00 | complete / not-produced | — | [result](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/c548496e-e3c9-4f83-bc19-445c48dc853b/result.json) · [文件清单](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/c548496e-e3c9-4f83-bc19-445c48dc853b/files.json) · [轨迹](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/c548496e-e3c9-4f83-bc19-445c48dc853b/agent/trajectory.jsonl) |
| test:355 | completed | 1 | 13.04 | 0.00 | complete / not-produced | — | [result](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/901af272-414a-4fd8-b177-348b81bb276e/result.json) · [文件清单](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/901af272-414a-4fd8-b177-348b81bb276e/files.json) · [轨迹](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/901af272-414a-4fd8-b177-348b81bb276e/agent/trajectory.jsonl) |
| test:476 | completed | 1 | 13.53 | 0.00 | complete / not-produced | — | [result](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/82d1a881-150a-4b72-abbe-746d7c7205e9/result.json) · [文件清单](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/82d1a881-150a-4b72-abbe-746d7c7205e9/files.json) · [轨迹](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/82d1a881-150a-4b72-abbe-746d7c7205e9/agent/trajectory.jsonl) |
| test:511 | completed | 1 | 12.19 | 0.00 | complete / not-produced | — | [result](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/8400be1c-d92a-4e10-89b4-a73a52e32e7d/result.json) · [文件清单](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/8400be1c-d92a-4e10-89b4-a73a52e32e7d/files.json) · [轨迹](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/8400be1c-d92a-4e10-89b4-a73a52e32e7d/agent/trajectory.jsonl) |
| test:552 | completed | 1 | 12.55 | 0.00 | complete / not-produced | — | [result](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/5961153e-c875-4815-8e21-5d0c63157a30/result.json) · [文件清单](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/5961153e-c875-4815-8e21-5d0c63157a30/files.json) · [轨迹](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/5961153e-c875-4815-8e21-5d0c63157a30/agent/trajectory.jsonl) |
| test:624 | completed | 1 | 9.97 | 0.00 | complete / not-produced | — | [result](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/1d035137-ba63-4eb6-a32f-0110073fdd8b/result.json) · [文件清单](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/1d035137-ba63-4eb6-a32f-0110073fdd8b/files.json) · [轨迹](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/1d035137-ba63-4eb6-a32f-0110073fdd8b/agent/trajectory.jsonl) |
| test:669 | completed | 1 | 9.96 | 0.00 | complete / not-produced | — | [result](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/7b45d5b5-4ba5-4d4e-951b-3e3ba10b113e/result.json) · [文件清单](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/7b45d5b5-4ba5-4d4e-951b-3e3ba10b113e/files.json) · [轨迹](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/7b45d5b5-4ba5-4d4e-951b-3e3ba10b113e/agent/trajectory.jsonl) |
| test:670 | completed | 1 | 10.88 | 0.00 | complete / not-produced | — | [result](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/e86654fe-f6b2-4a1b-8203-237c7851d9db/result.json) · [文件清单](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/e86654fe-f6b2-4a1b-8203-237c7851d9db/files.json) · [轨迹](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/e86654fe-f6b2-4a1b-8203-237c7851d9db/agent/trajectory.jsonl) |
| test:796 | completed | 1 | 17.11 | 0.00 | complete / not-produced | — | [result](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/d77cae33-2a6a-47ea-ab61-df9bf858d5fe/result.json) · [文件清单](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/d77cae33-2a6a-47ea-ab61-df9bf858d5fe/files.json) · [轨迹](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/d77cae33-2a6a-47ea-ab61-df9bf858d5fe/agent/trajectory.jsonl) |
| test:828 | completed | 1 | 12.96 | 0.00 | complete / not-produced | — | [result](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/f00f8202-fdd1-4625-a1d8-6fcf37096c3e/result.json) · [文件清单](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/f00f8202-fdd1-4625-a1d8-6fcf37096c3e/files.json) · [轨迹](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/f00f8202-fdd1-4625-a1d8-6fcf37096c3e/agent/trajectory.jsonl) |
| test:841 | completed | 0 | 32.99 | 0.00 | complete / not-produced | — | [result](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/fd94f50c-e824-43d5-9ec3-2bc488f3f741/result.json) · [文件清单](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/fd94f50c-e824-43d5-9ec3-2bc488f3f741/files.json) · [轨迹](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/fd94f50c-e824-43d5-9ec3-2bc488f3f741/agent/trajectory.jsonl) |
| test:883 | completed | 1 | 12.97 | 0.00 | complete / not-produced | — | [result](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/6f2d52df-dbf1-41ca-b7ef-8a40c9f0bf6a/result.json) · [文件清单](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/6f2d52df-dbf1-41ca-b7ef-8a40c9f0bf6a/files.json) · [轨迹](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/6f2d52df-dbf1-41ca-b7ef-8a40c9f0bf6a/agent/trajectory.jsonl) |
| test:938 | completed | 1 | 17.31 | 0.00 | complete / not-produced | — | [result](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/d30957f9-6ce9-4437-b0a3-402700b0124a/result.json) · [文件清单](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/d30957f9-6ce9-4437-b0a3-402700b0124a/files.json) · [轨迹](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/d30957f9-6ce9-4437-b0a3-402700b0124a/agent/trajectory.jsonl) |
| test:1026 | completed | 0 | 20.64 | 0.00 | complete / not-produced | — | [result](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/1efe43d8-78eb-448d-8563-ea09df72be47/result.json) · [文件清单](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/1efe43d8-78eb-448d-8563-ea09df72be47/files.json) · [轨迹](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/1efe43d8-78eb-448d-8563-ea09df72be47/agent/trajectory.jsonl) |
| test:1229 | completed | 1 | 11.62 | 0.00 | complete / not-produced | — | [result](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/8470b7d5-f9f2-4025-9e0c-9dfaa473a222/result.json) · [文件清单](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/8470b7d5-f9f2-4025-9e0c-9dfaa473a222/files.json) · [轨迹](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/8470b7d5-f9f2-4025-9e0c-9dfaa473a222/agent/trajectory.jsonl) |
| test:1252 | completed | 1 | 9.57 | 0.00 | complete / not-produced | — | [result](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/9bbb7699-025e-49ad-b3e1-9b86021a195e/result.json) · [文件清单](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/9bbb7699-025e-49ad-b3e1-9b86021a195e/files.json) · [轨迹](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/9bbb7699-025e-49ad-b3e1-9b86021a195e/agent/trajectory.jsonl) |
| test:1399 | completed | 1 | 11.38 | 0.00 | complete / not-produced | — | [result](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/6b62bac9-f34c-439d-af4f-631ae464ae02/result.json) · [文件清单](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/6b62bac9-f34c-439d-af4f-631ae464ae02/files.json) · [轨迹](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/6b62bac9-f34c-439d-af4f-631ae464ae02/agent/trajectory.jsonl) |
| test:1454 | completed | 1 | 50.93 | 0.00 | complete / not-produced | — | [result](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/e17479df-cd15-4cc3-a9e2-f189c5af13a2/result.json) · [文件清单](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/e17479df-cd15-4cc3-a9e2-f189c5af13a2/files.json) · [轨迹](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/e17479df-cd15-4cc3-a9e2-f189c5af13a2/agent/trajectory.jsonl) |
| test:1514 | completed | 1 | 18.18 | 0.00 | complete / not-produced | — | [result](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/361f993f-8739-462b-8c69-fd769fb09149/result.json) · [文件清单](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/361f993f-8739-462b-8c69-fd769fb09149/files.json) · [轨迹](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/361f993f-8739-462b-8c69-fd769fb09149/agent/trajectory.jsonl) |
| test:1531 | completed | 0 | 16.28 | 0.00 | complete / not-produced | — | [result](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/565e44f3-ef62-4863-93e6-42df4a930ea7/result.json) · [文件清单](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/565e44f3-ef62-4863-93e6-42df4a930ea7/files.json) · [轨迹](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/565e44f3-ef62-4863-93e6-42df4a930ea7/agent/trajectory.jsonl) |
| test:1785 | completed | 0 | 124.24 | 0.00 | complete / not-produced | — | [result](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/61425495-fc9d-4bc2-bceb-4a64cd186126/result.json) · [文件清单](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/61425495-fc9d-4bc2-bceb-4a64cd186126/files.json) · [轨迹](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/61425495-fc9d-4bc2-bceb-4a64cd186126/agent/trajectory.jsonl) |
| test:1806 | completed | 0 | 195.58 | 0.00 | complete / not-produced | — | [result](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/c3b4de4a-e23f-4010-9f0f-032ac45650b9/result.json) · [文件清单](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/c3b4de4a-e23f-4010-9f0f-032ac45650b9/files.json) · [轨迹](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/c3b4de4a-e23f-4010-9f0f-032ac45650b9/agent/trajectory.jsonl) |
| test:1827 | completed | 1 | 20.38 | 0.00 | complete / not-produced | — | [result](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/6e6549a8-a997-4af6-beda-119b587c443d/result.json) · [文件清单](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/6e6549a8-a997-4af6-beda-119b587c443d/files.json) · [轨迹](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/6e6549a8-a997-4af6-beda-119b587c443d/agent/trajectory.jsonl) |
| test:1904 | completed | 1 | 8.07 | 0.00 | complete / not-produced | — | [result](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/e764cd64-ccc0-4717-a244-5f883f715a9b/result.json) · [文件清单](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/e764cd64-ccc0-4717-a244-5f883f715a9b/files.json) · [轨迹](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/e764cd64-ccc0-4717-a244-5f883f715a9b/agent/trajectory.jsonl) |
| test:1943 | completed | 1 | 7.67 | 0.00 | complete / not-produced | — | [result](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/ee462556-c0ed-47ce-a096-c42be61be29e/result.json) · [文件清单](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/ee462556-c0ed-47ce-a096-c42be61be29e/files.json) · [轨迹](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/ee462556-c0ed-47ce-a096-c42be61be29e/agent/trajectory.jsonl) |
| test:1998 | completed | 1 | 7.87 | 0.00 | complete / not-produced | — | [result](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/7d5d4641-40b1-4da4-bc23-0202dc38f98e/result.json) · [文件清单](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/7d5d4641-40b1-4da4-bc23-0202dc38f98e/files.json) · [轨迹](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/7d5d4641-40b1-4da4-bc23-0202dc38f98e/agent/trajectory.jsonl) |
| test:2023 | completed | 1 | 7.59 | 0.00 | complete / not-produced | — | [result](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/e5fef4e5-a65b-4cdb-9f6b-cf20ca7581c3/result.json) · [文件清单](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/e5fef4e5-a65b-4cdb-9f6b-cf20ca7581c3/files.json) · [轨迹](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/e5fef4e5-a65b-4cdb-9f6b-cf20ca7581c3/agent/trajectory.jsonl) |
| test:2096 | completed | 0 | 9.79 | 0.00 | complete / not-produced | — | [result](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/11a8efab-9a7e-4e60-8730-ce7fc15e1f71/result.json) · [文件清单](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/11a8efab-9a7e-4e60-8730-ce7fc15e1f71/files.json) · [轨迹](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/11a8efab-9a7e-4e60-8730-ce7fc15e1f71/agent/trajectory.jsonl) |
| test:2152 | completed | 1 | 7.84 | 0.00 | complete / not-produced | — | [result](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/e957acd4-fb5b-4cb7-888b-7fcaaefa6a99/result.json) · [文件清单](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/e957acd4-fb5b-4cb7-888b-7fcaaefa6a99/files.json) · [轨迹](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/e957acd4-fb5b-4cb7-888b-7fcaaefa6a99/agent/trajectory.jsonl) |
| test:2175 | completed | 1 | 7.54 | 0.00 | complete / not-produced | — | [result](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/8684b32f-bd0e-4c1f-87f9-b1c4c92a5d79/result.json) · [文件清单](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/8684b32f-bd0e-4c1f-87f9-b1c4c92a5d79/files.json) · [轨迹](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/8684b32f-bd0e-4c1f-87f9-b1c4c92a5d79/agent/trajectory.jsonl) |
| test:2177 | completed | 1 | 8.30 | 0.00 | complete / not-produced | — | [result](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/f8963e58-8f5a-44e0-a28c-ac08a0a4a73d/result.json) · [文件清单](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/f8963e58-8f5a-44e0-a28c-ac08a0a4a73d/files.json) · [轨迹](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/f8963e58-8f5a-44e0-a28c-ac08a0a4a73d/agent/trajectory.jsonl) |
| test:2206 | completed | 1 | 8.57 | 0.00 | complete / not-produced | — | [result](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/e345fe38-8445-4751-a7c9-bf9a3ace2412/result.json) · [文件清单](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/e345fe38-8445-4751-a7c9-bf9a3ace2412/files.json) · [轨迹](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/e345fe38-8445-4751-a7c9-bf9a3ace2412/agent/trajectory.jsonl) |
| test:2280 | completed | 1 | 10.60 | 0.00 | complete / not-produced | — | [result](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/35ee2510-d54d-44c3-8bec-3ee27c1ac9cd/result.json) · [文件清单](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/35ee2510-d54d-44c3-8bec-3ee27c1ac9cd/files.json) · [轨迹](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/35ee2510-d54d-44c3-8bec-3ee27c1ac9cd/agent/trajectory.jsonl) |
| test:2347 | completed | 1 | 11.56 | 0.00 | complete / not-produced | — | [result](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/52a78ee2-24dc-4a39-a35a-883ace0ad3f3/result.json) · [文件清单](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/52a78ee2-24dc-4a39-a35a-883ace0ad3f3/files.json) · [轨迹](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/52a78ee2-24dc-4a39-a35a-883ace0ad3f3/agent/trajectory.jsonl) |
| test:2400 | invalid | — | 9.45 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/49a70444-685f-421f-ae00-83b4beb95acb/result.json) · [文件清单](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/49a70444-685f-421f-ae00-83b4beb95acb/files.json) · [轨迹](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/49a70444-685f-421f-ae00-83b4beb95acb/agent/trajectory.jsonl) |
| test:2527 | cancelled | — | 2.21 | — | partial / not-produced | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/e24e184e-a4aa-4ad3-a92e-cf930f768194/result.json) · [文件清单](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/e24e184e-a4aa-4ad3-a92e-cf930f768194/files.json) · [轨迹](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/e24e184e-a4aa-4ad3-a92e-cf930f768194/agent/trajectory.jsonl) |
| test:2636 | pending | — | — | — | — | — | — |
| test:2641 | pending | — | — | — | — | — | — |
| test:2714 | pending | — | — | — | — | — | — |
| test:2716 | pending | — | — | — | — | — | — |
| test:2747 | pending | — | — | — | — | — | — |
| test:2882 | pending | — | — | — | — | — | — |
| test:2951 | pending | — | — | — | — | — | — |
| test:3037 | pending | — | — | — | — | — | — |
| test:3053 | pending | — | — | — | — | — | — |
| test:3136 | pending | — | — | — | — | — | — |
| test:3165 | pending | — | — | — | — | — | — |
| test:3196 | pending | — | — | — | — | — | — |
| test:3231 | pending | — | — | — | — | — | — |
| test:3236 | pending | — | — | — | — | — | — |
| test:3270 | pending | — | — | — | — | — | — |
| test:3293 | pending | — | — | — | — | — | — |
| test:3331 | pending | — | — | — | — | — | — |
| test:3488 | pending | — | — | — | — | — | — |
| test:3491 | pending | — | — | — | — | — | — |
| test:3552 | pending | — | — | — | — | — | — |
| test:3599 | pending | — | — | — | — | — | — |
| test:3626 | pending | — | — | — | — | — | — |
| test:4021 | pending | — | — | — | — | — | — |
| test:4034 | pending | — | — | — | — | — | — |
| test:4058 | pending | — | — | — | — | — | — |
| test:4075 | pending | — | — | — | — | — | — |
| test:4142 | pending | — | — | — | — | — | — |
| test:4208 | pending | — | — | — | — | — | — |
| test:4298 | pending | — | — | — | — | — | — |
| test:4337 | pending | — | — | — | — | — | — |
| test:4376 | pending | — | — | — | — | — | — |
| test:4405 | pending | — | — | — | — | — | — |
| test:4552 | pending | — | — | — | — | — | — |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 2；错误记录 4（主流程 1；证据收集 1；资源清理 2）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| cleanup | CLEANUP_FAILED | 1 | 2 |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

