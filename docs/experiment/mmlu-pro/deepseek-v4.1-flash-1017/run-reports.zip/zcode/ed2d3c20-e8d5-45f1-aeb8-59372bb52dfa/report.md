<!-- snapshotDigest: d09f85dad2486a6244f464b732ab8111a9411d5d46d527cac3fce424b6657449 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: ed2d3c20-e8d5-45f1-aeb8-59372bb52dfa · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:15:13.166Z / 2026-11-12T08:21:18.296Z |
| 总耗时 | 5 分 53 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 53 秒 |
| 环境准备耗时 | 3 分 5 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 49 秒 | 33 秒 | 3 分 8 秒 | 24 |
| 任务准备 | 0.44 毫秒 | 0.23 毫秒 | 0.86 毫秒 | 24 |
| 环境启动 | 16 秒 | 13 秒 | 21 秒 | 24 |
| 解题 | 24 秒 | 11 秒 | 2 分 45 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 6 秒 | 6 秒 | 8 秒 | 24 |
| 评分 | 0.67 毫秒 | 0.24 毫秒 | 3.3 毫秒 | 24 |
| 证据收集 | 25.82 毫秒 | 5.26 毫秒 | 210.6 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 601b365d-e2db-4be1-a9a3-5e0c2f2bb939 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 50,034 | 36,377 | 86,411 | 24 / 24 | — |
| 运行累计 | 50,034 | 36,377 | 86,411 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:6223 | completed | 1 | 13.09 | 0.00 | complete / not-produced | — | [result](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/d9507d5a-d6f4-485b-b123-2818c2a2a439/result.json) · [文件清单](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/d9507d5a-d6f4-485b-b123-2818c2a2a439/files.json) · [轨迹](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/d9507d5a-d6f4-485b-b123-2818c2a2a439/agent/trajectory.jsonl) |
| test:6235 | completed | 1 | 12.62 | 0.00 | complete / not-produced | — | [result](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/18f2eed2-ac91-45c8-9851-915e71f5b34a/result.json) · [文件清单](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/18f2eed2-ac91-45c8-9851-915e71f5b34a/files.json) · [轨迹](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/18f2eed2-ac91-45c8-9851-915e71f5b34a/agent/trajectory.jsonl) |
| test:6403 | completed | 1 | 20.02 | 0.00 | complete / not-produced | — | [result](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/0a86941e-7de7-4c78-a40f-3e3e44e17993/result.json) · [文件清单](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/0a86941e-7de7-4c78-a40f-3e3e44e17993/files.json) · [轨迹](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/0a86941e-7de7-4c78-a40f-3e3e44e17993/agent/trajectory.jsonl) |
| test:6436 | completed | 1 | 14.18 | 0.00 | complete / not-produced | — | [result](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/7a636f8f-e62f-4377-a61e-3aefeb027cb0/result.json) · [文件清单](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/7a636f8f-e62f-4377-a61e-3aefeb027cb0/files.json) · [轨迹](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/7a636f8f-e62f-4377-a61e-3aefeb027cb0/agent/trajectory.jsonl) |
| test:6508 | completed | 0 | 58.26 | 0.00 | complete / not-produced | — | [result](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/18d0618b-6237-46d0-93fd-9a15e0fc8b4e/result.json) · [文件清单](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/18d0618b-6237-46d0-93fd-9a15e0fc8b4e/files.json) · [轨迹](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/18d0618b-6237-46d0-93fd-9a15e0fc8b4e/agent/trajectory.jsonl) |
| test:6593 | completed | 1 | 16.53 | 0.00 | complete / not-produced | — | [result](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/3c0c92a5-5ba7-4695-856d-f80d14ee9295/result.json) · [文件清单](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/3c0c92a5-5ba7-4695-856d-f80d14ee9295/files.json) · [轨迹](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/3c0c92a5-5ba7-4695-856d-f80d14ee9295/agent/trajectory.jsonl) |
| test:6655 | completed | 1 | 28.47 | 0.00 | complete / not-produced | — | [result](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/679b3c23-8ea5-41d5-9b38-f4eb6183f6cd/result.json) · [文件清单](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/679b3c23-8ea5-41d5-9b38-f4eb6183f6cd/files.json) · [轨迹](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/679b3c23-8ea5-41d5-9b38-f4eb6183f6cd/agent/trajectory.jsonl) |
| test:6738 | completed | 1 | 42.67 | 0.00 | complete / not-produced | — | [result](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/31783555-e2ca-49d6-884b-1463f332591f/result.json) · [文件清单](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/31783555-e2ca-49d6-884b-1463f332591f/files.json) · [轨迹](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/31783555-e2ca-49d6-884b-1463f332591f/agent/trajectory.jsonl) |
| test:6751 | completed | 1 | 17.95 | 0.00 | complete / not-produced | — | [result](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/a06b19fe-a8fb-47de-8961-a94182de1b06/result.json) · [文件清单](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/a06b19fe-a8fb-47de-8961-a94182de1b06/files.json) · [轨迹](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/a06b19fe-a8fb-47de-8961-a94182de1b06/agent/trajectory.jsonl) |
| test:6784 | completed | 1 | 15.51 | 0.00 | complete / not-produced | — | [result](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/2dae1607-3541-4c2c-906e-02086cdd7bc4/result.json) · [文件清单](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/2dae1607-3541-4c2c-906e-02086cdd7bc4/files.json) · [轨迹](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/2dae1607-3541-4c2c-906e-02086cdd7bc4/agent/trajectory.jsonl) |
| test:6792 | completed | 1 | 12.91 | 0.00 | complete / not-produced | — | [result](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/bc963d4d-5c70-4e38-ba50-878db137ef0b/result.json) · [文件清单](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/bc963d4d-5c70-4e38-ba50-878db137ef0b/files.json) · [轨迹](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/bc963d4d-5c70-4e38-ba50-878db137ef0b/agent/trajectory.jsonl) |
| test:6900 | completed | 1 | 12.47 | 0.00 | complete / not-produced | — | [result](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/4b1a009a-2c32-4faf-bd00-b11e90fa5f09/result.json) · [文件清单](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/4b1a009a-2c32-4faf-bd00-b11e90fa5f09/files.json) · [轨迹](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/4b1a009a-2c32-4faf-bd00-b11e90fa5f09/agent/trajectory.jsonl) |
| test:6928 | completed | 1 | 14.37 | 0.00 | complete / not-produced | — | [result](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/8c344d2e-e970-47ef-9ee0-1c1a8de353a6/result.json) · [文件清单](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/8c344d2e-e970-47ef-9ee0-1c1a8de353a6/files.json) · [轨迹](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/8c344d2e-e970-47ef-9ee0-1c1a8de353a6/agent/trajectory.jsonl) |
| test:6929 | completed | 1 | 13.24 | 0.00 | complete / not-produced | — | [result](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/6baafa42-d248-4067-8abe-daff8243eb4c/result.json) · [文件清单](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/6baafa42-d248-4067-8abe-daff8243eb4c/files.json) · [轨迹](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/6baafa42-d248-4067-8abe-daff8243eb4c/agent/trajectory.jsonl) |
| test:7161 | completed | 1 | 165.50 | 0.00 | complete / not-produced | — | [result](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/bf2a6072-fca4-422e-922e-3243197996fd/result.json) · [文件清单](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/bf2a6072-fca4-422e-922e-3243197996fd/files.json) · [轨迹](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/bf2a6072-fca4-422e-922e-3243197996fd/agent/trajectory.jsonl) |
| test:7181 | completed | 1 | 14.32 | 0.00 | complete / not-produced | — | [result](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/9606f0de-4b98-4933-b761-b9fc326acaad/result.json) · [文件清单](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/9606f0de-4b98-4933-b761-b9fc326acaad/files.json) · [轨迹](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/9606f0de-4b98-4933-b761-b9fc326acaad/agent/trajectory.jsonl) |
| test:7217 | completed | 1 | 13.65 | 0.00 | complete / not-produced | — | [result](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/5b3d6724-3f89-4e89-bcf9-1629b769893e/result.json) · [文件清单](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/5b3d6724-3f89-4e89-bcf9-1629b769893e/files.json) · [轨迹](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/5b3d6724-3f89-4e89-bcf9-1629b769893e/agent/trajectory.jsonl) |
| test:7290 | completed | 1 | 10.79 | 0.00 | complete / not-produced | — | [result](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/3d873993-cc3f-48b4-a1d7-a6d92395f8c1/result.json) · [文件清单](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/3d873993-cc3f-48b4-a1d7-a6d92395f8c1/files.json) · [轨迹](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/3d873993-cc3f-48b4-a1d7-a6d92395f8c1/agent/trajectory.jsonl) |
| test:7304 | completed | 1 | 12.20 | 0.00 | complete / not-produced | — | [result](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/aa407ada-db18-414f-8298-254f87cc7d2d/result.json) · [文件清单](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/aa407ada-db18-414f-8298-254f87cc7d2d/files.json) · [轨迹](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/aa407ada-db18-414f-8298-254f87cc7d2d/agent/trajectory.jsonl) |
| test:7312 | completed | 1 | 14.79 | 0.00 | complete / not-produced | — | [result](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/f297a09f-dab9-44cb-a447-a1a13704b3c0/result.json) · [文件清单](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/f297a09f-dab9-44cb-a447-a1a13704b3c0/files.json) · [轨迹](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/f297a09f-dab9-44cb-a447-a1a13704b3c0/agent/trajectory.jsonl) |
| test:7448 | completed | 1 | 16.48 | 0.00 | complete / not-produced | — | [result](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/b52ae5f6-a4ae-4ec0-9ef3-8456ae36c3a1/result.json) · [文件清单](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/b52ae5f6-a4ae-4ec0-9ef3-8456ae36c3a1/files.json) · [轨迹](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/b52ae5f6-a4ae-4ec0-9ef3-8456ae36c3a1/agent/trajectory.jsonl) |
| test:7462 | completed | 1 | 10.86 | 0.00 | complete / not-produced | — | [result](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/b232db51-540e-4078-a000-a2f7f0445ec7/result.json) · [文件清单](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/b232db51-540e-4078-a000-a2f7f0445ec7/files.json) · [轨迹](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/b232db51-540e-4078-a000-a2f7f0445ec7/agent/trajectory.jsonl) |
| test:7526 | completed | 1 | 14.04 | 0.00 | complete / not-produced | — | [result](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/6be2b05f-0f9b-4267-8dd3-42848c039267/result.json) · [文件清单](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/6be2b05f-0f9b-4267-8dd3-42848c039267/files.json) · [轨迹](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/6be2b05f-0f9b-4267-8dd3-42848c039267/agent/trajectory.jsonl) |
| test:7727 | completed | 1 | 14.23 | 0.00 | complete / not-produced | — | [result](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/ab9e6a25-43f3-463d-ba8a-937c32121df0/result.json) · [文件清单](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/ab9e6a25-43f3-463d-ba8a-937c32121df0/files.json) · [轨迹](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/ab9e6a25-43f3-463d-ba8a-937c32121df0/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

