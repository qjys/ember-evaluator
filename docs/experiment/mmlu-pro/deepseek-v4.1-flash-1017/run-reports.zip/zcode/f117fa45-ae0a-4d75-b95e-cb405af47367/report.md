<!-- snapshotDigest: a5859e76497974bc1f8e625f88a449beadc76c0507e0b5f0178c632617db9451 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 91.67%（22/24）**

Run: f117fa45-ae0a-4d75-b95e-cb405af47367 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:04:47.822Z / 2026-11-12T08:09:33.678Z |
| 总耗时 | 4 分 36 秒 |
| 答对 / 答错 / 解题超时 | 22 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 22 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 91.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 4 分 36 秒 |
| 环境准备耗时 | 2 分 52 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 40 秒 | 29 秒 | 49 秒 | 24 |
| 任务准备 | 0.7 毫秒 | 0.27 毫秒 | 6.16 毫秒 | 24 |
| 环境启动 | 15 秒 | 10 秒 | 21 秒 | 24 |
| 解题 | 16 秒 | 11 秒 | 22 秒 | 24 |
| 产物传输 | 2 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 6 秒 | 5 秒 | 8 秒 | 24 |
| 评分 | 0.86 毫秒 | 0.23 毫秒 | 7.15 毫秒 | 24 |
| 证据收集 | 18.35 毫秒 | 6.44 毫秒 | 62.62 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 820421aa-ec70-40d8-ae9a-30625bf97616 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 64,996 | 9,225 | 74,221 | 24 / 24 | — |
| 运行累计 | 64,996 | 9,225 | 74,221 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4021 | completed | 1 | 19.34 | 0.00 | complete / not-produced | — | [result](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/8450242f-8dc4-409f-87b3-c45becc3142f/result.json) · [文件清单](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/8450242f-8dc4-409f-87b3-c45becc3142f/files.json) · [轨迹](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/8450242f-8dc4-409f-87b3-c45becc3142f/agent/trajectory.jsonl) |
| test:4034 | completed | 1 | 16.00 | 0.00 | complete / not-produced | — | [result](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/89bdfbd0-aa42-4f50-8c43-a1e626131014/result.json) · [文件清单](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/89bdfbd0-aa42-4f50-8c43-a1e626131014/files.json) · [轨迹](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/89bdfbd0-aa42-4f50-8c43-a1e626131014/agent/trajectory.jsonl) |
| test:4058 | completed | 1 | 19.52 | 0.00 | complete / not-produced | — | [result](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/239a8957-6e89-4bf6-84cd-3a4d62c6d538/result.json) · [文件清单](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/239a8957-6e89-4bf6-84cd-3a4d62c6d538/files.json) · [轨迹](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/239a8957-6e89-4bf6-84cd-3a4d62c6d538/agent/trajectory.jsonl) |
| test:4075 | completed | 1 | 21.06 | 0.00 | complete / not-produced | — | [result](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/4a9b1739-ab48-4542-bec3-d8a01734e67f/result.json) · [文件清单](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/4a9b1739-ab48-4542-bec3-d8a01734e67f/files.json) · [轨迹](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/4a9b1739-ab48-4542-bec3-d8a01734e67f/agent/trajectory.jsonl) |
| test:4142 | completed | 1 | 18.47 | 0.00 | complete / not-produced | — | [result](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/54b9c247-83cf-43f1-8f43-b8599dfd2af9/result.json) · [文件清单](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/54b9c247-83cf-43f1-8f43-b8599dfd2af9/files.json) · [轨迹](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/54b9c247-83cf-43f1-8f43-b8599dfd2af9/agent/trajectory.jsonl) |
| test:4208 | completed | 1 | 16.51 | 0.00 | complete / not-produced | — | [result](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/de3ae1b7-50bb-4248-a82e-47681c0cfc1f/result.json) · [文件清单](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/de3ae1b7-50bb-4248-a82e-47681c0cfc1f/files.json) · [轨迹](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/de3ae1b7-50bb-4248-a82e-47681c0cfc1f/agent/trajectory.jsonl) |
| test:4298 | completed | 1 | 14.20 | 0.00 | complete / not-produced | — | [result](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/c6bb4d98-42b8-46cf-a680-a563dd7f164a/result.json) · [文件清单](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/c6bb4d98-42b8-46cf-a680-a563dd7f164a/files.json) · [轨迹](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/c6bb4d98-42b8-46cf-a680-a563dd7f164a/agent/trajectory.jsonl) |
| test:4337 | completed | 1 | 18.76 | 0.00 | complete / not-produced | — | [result](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/59612b61-9523-4864-ba97-ab73fee0d1e3/result.json) · [文件清单](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/59612b61-9523-4864-ba97-ab73fee0d1e3/files.json) · [轨迹](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/59612b61-9523-4864-ba97-ab73fee0d1e3/agent/trajectory.jsonl) |
| test:4376 | completed | 1 | 11.72 | 0.00 | complete / not-produced | — | [result](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/bbd73f20-6fd7-4d71-86b8-6557b1446a67/result.json) · [文件清单](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/bbd73f20-6fd7-4d71-86b8-6557b1446a67/files.json) · [轨迹](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/bbd73f20-6fd7-4d71-86b8-6557b1446a67/agent/trajectory.jsonl) |
| test:4405 | completed | 1 | 12.72 | 0.00 | complete / not-produced | — | [result](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/24cd9243-c52f-42b9-95e0-52d98b21d561/result.json) · [文件清单](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/24cd9243-c52f-42b9-95e0-52d98b21d561/files.json) · [轨迹](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/24cd9243-c52f-42b9-95e0-52d98b21d561/agent/trajectory.jsonl) |
| test:4552 | completed | 1 | 13.03 | 0.00 | complete / not-produced | — | [result](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/1107da03-b64c-4afc-b42b-acc230281f62/result.json) · [文件清单](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/1107da03-b64c-4afc-b42b-acc230281f62/files.json) · [轨迹](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/1107da03-b64c-4afc-b42b-acc230281f62/agent/trajectory.jsonl) |
| test:4560 | completed | 1 | 11.25 | 0.00 | complete / not-produced | — | [result](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/d936238e-1534-451d-9322-de8b7a12146b/result.json) · [文件清单](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/d936238e-1534-451d-9322-de8b7a12146b/files.json) · [轨迹](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/d936238e-1534-451d-9322-de8b7a12146b/agent/trajectory.jsonl) |
| test:4568 | completed | 1 | 11.66 | 0.00 | complete / not-produced | — | [result](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/e855ff3b-dc49-4d8b-8b1d-89bc706c3864/result.json) · [文件清单](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/e855ff3b-dc49-4d8b-8b1d-89bc706c3864/files.json) · [轨迹](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/e855ff3b-dc49-4d8b-8b1d-89bc706c3864/agent/trajectory.jsonl) |
| test:4580 | completed | 1 | 21.81 | 0.00 | complete / not-produced | — | [result](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/0f405b57-024f-4cc0-8083-088765a21805/result.json) · [文件清单](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/0f405b57-024f-4cc0-8083-088765a21805/files.json) · [轨迹](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/0f405b57-024f-4cc0-8083-088765a21805/agent/trajectory.jsonl) |
| test:4603 | completed | 1 | 13.17 | 0.01 | complete / not-produced | — | [result](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/f24e73d6-dfb1-4464-9365-5e8030d33b4a/result.json) · [文件清单](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/f24e73d6-dfb1-4464-9365-5e8030d33b4a/files.json) · [轨迹](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/f24e73d6-dfb1-4464-9365-5e8030d33b4a/agent/trajectory.jsonl) |
| test:4625 | completed | 1 | 11.78 | 0.00 | complete / not-produced | — | [result](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/947c62b3-cc05-4d88-8a77-efcbfa7d4066/result.json) · [文件清单](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/947c62b3-cc05-4d88-8a77-efcbfa7d4066/files.json) · [轨迹](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/947c62b3-cc05-4d88-8a77-efcbfa7d4066/agent/trajectory.jsonl) |
| test:4627 | completed | 1 | 10.90 | 0.00 | complete / not-produced | — | [result](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/cfce1ce6-dc4c-4c45-a4c1-e38a002b3150/result.json) · [文件清单](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/cfce1ce6-dc4c-4c45-a4c1-e38a002b3150/files.json) · [轨迹](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/cfce1ce6-dc4c-4c45-a4c1-e38a002b3150/agent/trajectory.jsonl) |
| test:4651 | completed | 1 | 12.84 | 0.00 | complete / not-produced | — | [result](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/ce810f79-3703-4a17-9744-a67771dbbe79/result.json) · [文件清单](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/ce810f79-3703-4a17-9744-a67771dbbe79/files.json) · [轨迹](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/ce810f79-3703-4a17-9744-a67771dbbe79/agent/trajectory.jsonl) |
| test:4670 | completed | 1 | 17.03 | 0.00 | complete / not-produced | — | [result](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/4816d16b-013c-448a-a387-5a7663126c2b/result.json) · [文件清单](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/4816d16b-013c-448a-a387-5a7663126c2b/files.json) · [轨迹](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/4816d16b-013c-448a-a387-5a7663126c2b/agent/trajectory.jsonl) |
| test:4700 | completed | 1 | 14.06 | 0.00 | complete / not-produced | — | [result](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/2006ec7c-ccd4-49d6-aba6-347703b240d6/result.json) · [文件清单](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/2006ec7c-ccd4-49d6-aba6-347703b240d6/files.json) · [轨迹](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/2006ec7c-ccd4-49d6-aba6-347703b240d6/agent/trajectory.jsonl) |
| test:4709 | completed | 0 | 19.52 | 0.00 | complete / not-produced | — | [result](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/21637f19-9977-44f4-8738-18342bffb5c5/result.json) · [文件清单](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/21637f19-9977-44f4-8738-18342bffb5c5/files.json) · [轨迹](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/21637f19-9977-44f4-8738-18342bffb5c5/agent/trajectory.jsonl) |
| test:4763 | completed | 0 | 18.13 | 0.00 | complete / not-produced | — | [result](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/24fc8e1f-6dc7-4708-8cbf-6b6f223ab471/result.json) · [文件清单](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/24fc8e1f-6dc7-4708-8cbf-6b6f223ab471/files.json) · [轨迹](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/24fc8e1f-6dc7-4708-8cbf-6b6f223ab471/agent/trajectory.jsonl) |
| test:4770 | completed | 1 | 18.68 | 0.00 | complete / not-produced | — | [result](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/02fe6c71-a7ba-4edd-b2d3-8ac8095eda11/result.json) · [文件清单](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/02fe6c71-a7ba-4edd-b2d3-8ac8095eda11/files.json) · [轨迹](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/02fe6c71-a7ba-4edd-b2d3-8ac8095eda11/agent/trajectory.jsonl) |
| test:4786 | completed | 1 | 20.39 | 0.00 | complete / not-produced | — | [result](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/c87e07a1-4a3b-4bcb-a75a-d09141e1798e/result.json) · [文件清单](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/c87e07a1-4a3b-4bcb-a75a-d09141e1798e/files.json) · [轨迹](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/c87e07a1-4a3b-4bcb-a75a-d09141e1798e/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

