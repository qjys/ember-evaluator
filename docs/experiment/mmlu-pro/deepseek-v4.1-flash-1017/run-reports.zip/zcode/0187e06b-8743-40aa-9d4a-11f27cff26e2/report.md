<!-- snapshotDigest: 041d4b4184f54425aa3ee4fb90fd16c8720582ce358e7aa1858a2a3d15a519e4 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: 0187e06b-8743-40aa-9d4a-11f27cff26e2 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:21:23.144Z / 2026-11-12T08:26:44.892Z |
| 总耗时 | 5 分 11 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 11 秒 |
| 环境准备耗时 | 2 分 46 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 45 秒 | 35 秒 | 56 秒 | 24 |
| 任务准备 | 1.1 毫秒 | 0.29 毫秒 | 7.38 毫秒 | 24 |
| 环境启动 | 17 秒 | 13 秒 | 22 秒 | 24 |
| 解题 | 18 秒 | 12 秒 | 31 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 7 秒 | 4 秒 | 11 秒 | 24 |
| 评分 | 0.5 毫秒 | 0.26 毫秒 | 2.72 毫秒 | 24 |
| 证据收集 | 27.32 毫秒 | 6.77 毫秒 | 93.88 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 9c5ad98d-4c64-45ed-b1cb-01a962084300 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 55,399 | 10,665 | 66,064 | 24 / 24 | — |
| 运行累计 | 55,399 | 10,665 | 66,064 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:7752 | completed | 0 | 17.74 | 0.00 | complete / not-produced | — | [result](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/4e2176c6-df57-4015-accd-f9ea0ff5d181/result.json) · [文件清单](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/4e2176c6-df57-4015-accd-f9ea0ff5d181/files.json) · [轨迹](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/4e2176c6-df57-4015-accd-f9ea0ff5d181/agent/trajectory.jsonl) |
| test:7838 | completed | 1 | 16.75 | 0.00 | complete / not-produced | — | [result](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/e657630d-3022-4c95-a09d-2833a03a2f0c/result.json) · [文件清单](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/e657630d-3022-4c95-a09d-2833a03a2f0c/files.json) · [轨迹](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/e657630d-3022-4c95-a09d-2833a03a2f0c/agent/trajectory.jsonl) |
| test:7954 | completed | 1 | 17.31 | 0.00 | complete / not-produced | — | [result](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/eeade66e-a139-4db9-81ed-3a4e698f10d4/result.json) · [文件清单](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/eeade66e-a139-4db9-81ed-3a4e698f10d4/files.json) · [轨迹](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/eeade66e-a139-4db9-81ed-3a4e698f10d4/agent/trajectory.jsonl) |
| test:7976 | completed | 1 | 18.92 | 0.00 | complete / not-produced | — | [result](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/39950929-5b0b-43e5-b6e9-03d44392597d/result.json) · [文件清单](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/39950929-5b0b-43e5-b6e9-03d44392597d/files.json) · [轨迹](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/39950929-5b0b-43e5-b6e9-03d44392597d/agent/trajectory.jsonl) |
| test:8199 | completed | 1 | 13.77 | 0.00 | complete / not-produced | — | [result](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/fc1b1547-4ff3-40e5-be1b-4cc2d4e7395b/result.json) · [文件清单](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/fc1b1547-4ff3-40e5-be1b-4cc2d4e7395b/files.json) · [轨迹](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/fc1b1547-4ff3-40e5-be1b-4cc2d4e7395b/agent/trajectory.jsonl) |
| test:8207 | completed | 1 | 12.79 | 0.00 | complete / not-produced | — | [result](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/ba300f82-dc7a-465e-974f-67430833f630/result.json) · [文件清单](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/ba300f82-dc7a-465e-974f-67430833f630/files.json) · [轨迹](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/ba300f82-dc7a-465e-974f-67430833f630/agent/trajectory.jsonl) |
| test:8304 | completed | 1 | 11.76 | 0.00 | complete / not-produced | — | [result](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/6a34fa79-8c47-42e6-bb1f-217fc184cb0f/result.json) · [文件清单](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/6a34fa79-8c47-42e6-bb1f-217fc184cb0f/files.json) · [轨迹](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/6a34fa79-8c47-42e6-bb1f-217fc184cb0f/agent/trajectory.jsonl) |
| test:8366 | completed | 1 | 16.37 | 0.00 | complete / not-produced | — | [result](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/c512ecbc-1b83-421d-a5e6-d76d72dd948d/result.json) · [文件清单](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/c512ecbc-1b83-421d-a5e6-d76d72dd948d/files.json) · [轨迹](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/c512ecbc-1b83-421d-a5e6-d76d72dd948d/agent/trajectory.jsonl) |
| test:8511 | completed | 1 | 15.12 | 0.00 | complete / not-produced | — | [result](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/c3064316-f49a-4fc7-84ab-aa5a8bc0422b/result.json) · [文件清单](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/c3064316-f49a-4fc7-84ab-aa5a8bc0422b/files.json) · [轨迹](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/c3064316-f49a-4fc7-84ab-aa5a8bc0422b/agent/trajectory.jsonl) |
| test:8525 | completed | 1 | 16.85 | 0.00 | complete / not-produced | — | [result](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/36729c55-ee81-42fe-b030-df3bfb129248/result.json) · [文件清单](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/36729c55-ee81-42fe-b030-df3bfb129248/files.json) · [轨迹](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/36729c55-ee81-42fe-b030-df3bfb129248/agent/trajectory.jsonl) |
| test:8604 | completed | 1 | 14.71 | 0.00 | complete / not-produced | — | [result](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/11270201-4f5a-426b-9643-35d9be3af371/result.json) · [文件清单](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/11270201-4f5a-426b-9643-35d9be3af371/files.json) · [轨迹](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/11270201-4f5a-426b-9643-35d9be3af371/agent/trajectory.jsonl) |
| test:8740 | completed | 1 | 13.95 | 0.00 | complete / not-produced | — | [result](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/191a47df-1bea-4097-a621-0bb7b7558c02/result.json) · [文件清单](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/191a47df-1bea-4097-a621-0bb7b7558c02/files.json) · [轨迹](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/191a47df-1bea-4097-a621-0bb7b7558c02/agent/trajectory.jsonl) |
| test:8839 | completed | 1 | 16.77 | 0.00 | complete / not-produced | — | [result](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/6734efa7-88b2-4b0f-8781-29f29b724287/result.json) · [文件清单](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/6734efa7-88b2-4b0f-8781-29f29b724287/files.json) · [轨迹](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/6734efa7-88b2-4b0f-8781-29f29b724287/agent/trajectory.jsonl) |
| test:8939 | completed | 1 | 18.44 | 0.00 | complete / not-produced | — | [result](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/3d90eec5-f528-494a-8374-1ef584fb79c7/result.json) · [文件清单](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/3d90eec5-f528-494a-8374-1ef584fb79c7/files.json) · [轨迹](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/3d90eec5-f528-494a-8374-1ef584fb79c7/agent/trajectory.jsonl) |
| test:8967 | completed | 1 | 20.67 | 0.00 | complete / not-produced | — | [result](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/02e892ac-ce67-4425-8ee6-9119bd7a05a0/result.json) · [文件清单](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/02e892ac-ce67-4425-8ee6-9119bd7a05a0/files.json) · [轨迹](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/02e892ac-ce67-4425-8ee6-9119bd7a05a0/agent/trajectory.jsonl) |
| test:8989 | completed | 1 | 20.95 | 0.00 | complete / not-produced | — | [result](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/0bae0f9c-1c31-4da4-949b-4e8a2c060656/result.json) · [文件清单](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/0bae0f9c-1c31-4da4-949b-4e8a2c060656/files.json) · [轨迹](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/0bae0f9c-1c31-4da4-949b-4e8a2c060656/agent/trajectory.jsonl) |
| test:9136 | completed | 1 | 14.77 | 0.00 | complete / not-produced | — | [result](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/79657154-86c2-4456-9d4b-ed967f3c7fa4/result.json) · [文件清单](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/79657154-86c2-4456-9d4b-ed967f3c7fa4/files.json) · [轨迹](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/79657154-86c2-4456-9d4b-ed967f3c7fa4/agent/trajectory.jsonl) |
| test:9222 | completed | 1 | 15.81 | 0.00 | complete / not-produced | — | [result](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/e1231cb0-9875-423d-b1f9-84adda4fcc5b/result.json) · [文件清单](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/e1231cb0-9875-423d-b1f9-84adda4fcc5b/files.json) · [轨迹](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/e1231cb0-9875-423d-b1f9-84adda4fcc5b/agent/trajectory.jsonl) |
| test:9391 | completed | 1 | 17.66 | 0.00 | complete / not-produced | — | [result](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/da4e626f-9ce5-4f9c-8823-97ee31e1d06c/result.json) · [文件清单](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/da4e626f-9ce5-4f9c-8823-97ee31e1d06c/files.json) · [轨迹](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/da4e626f-9ce5-4f9c-8823-97ee31e1d06c/agent/trajectory.jsonl) |
| test:9395 | completed | 1 | 24.39 | 0.00 | complete / not-produced | — | [result](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/0e351f7d-9f03-4ec0-a8e5-556cf45bcc92/result.json) · [文件清单](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/0e351f7d-9f03-4ec0-a8e5-556cf45bcc92/files.json) · [轨迹](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/0e351f7d-9f03-4ec0-a8e5-556cf45bcc92/agent/trajectory.jsonl) |
| test:9405 | completed | 1 | 21.27 | 0.00 | complete / not-produced | — | [result](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/b9a53ea9-71ab-4162-92e1-824ef2e35c51/result.json) · [文件清单](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/b9a53ea9-71ab-4162-92e1-824ef2e35c51/files.json) · [轨迹](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/b9a53ea9-71ab-4162-92e1-824ef2e35c51/agent/trajectory.jsonl) |
| test:9769 | completed | 1 | 15.41 | 0.00 | complete / not-produced | — | [result](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/024b3b1c-86aa-475e-8db9-01cf20c96f0c/result.json) · [文件清单](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/024b3b1c-86aa-475e-8db9-01cf20c96f0c/files.json) · [轨迹](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/024b3b1c-86aa-475e-8db9-01cf20c96f0c/agent/trajectory.jsonl) |
| test:9843 | completed | 1 | 30.54 | 0.00 | complete / not-produced | — | [result](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/7c497498-298f-4bdd-bfea-d6b31dde6f73/result.json) · [文件清单](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/7c497498-298f-4bdd-bfea-d6b31dde6f73/files.json) · [轨迹](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/7c497498-298f-4bdd-bfea-d6b31dde6f73/agent/trajectory.jsonl) |
| test:9864 | completed | 1 | 23.00 | 0.00 | complete / not-produced | — | [result](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/617945f2-4aad-46e5-84db-2a3812554505/result.json) · [文件清单](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/617945f2-4aad-46e5-84db-2a3812554505/files.json) · [轨迹](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/617945f2-4aad-46e5-84db-2a3812554505/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

