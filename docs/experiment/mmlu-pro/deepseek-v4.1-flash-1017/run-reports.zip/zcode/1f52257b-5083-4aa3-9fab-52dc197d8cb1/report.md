<!-- snapshotDigest: 5c7419217b174f4c23eba46d31a95bb22c3e1ff64842bbdf426ca5975b3315be -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 91.67%（22/24）**

Run: 1f52257b-5083-4aa3-9fab-52dc197d8cb1 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:56:49.387Z / 2026-11-12T08:04:42.406Z |
| 总耗时 | 7 分 38 秒 |
| 答对 / 答错 / 解题超时 | 22 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 22 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 91.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 7 分 38 秒 |
| 环境准备耗时 | 2 分 28 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 49 秒 | 18 秒 | 4 分 18 秒 | 24 |
| 任务准备 | 0.43 毫秒 | 0.2 毫秒 | 0.89 毫秒 | 24 |
| 环境启动 | 13 秒 | 5 秒 | 22 秒 | 24 |
| 解题 | 29 秒 | 8 秒 | 4 分 0 秒 | 24 |
| 产物传输 | 2 秒 | 1 秒 | 4 秒 | 24 |
| 资源清理 | 4 秒 | 3 秒 | 8 秒 | 24 |
| 评分 | 0.66 毫秒 | 0.27 毫秒 | 3.1 毫秒 | 24 |
| 证据收集 | 42.38 毫秒 | 6.1 毫秒 | 369.03 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 5b9ea878-67f5-47f7-a5c8-6bb9e0ebaf6b | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 50,168 | 26,814 | 76,982 | 23 / 24 | — |
| 运行累计 | 50,168 | 26,814 | 76,982 | 23 / 24 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:2400 | completed | 1 | 16.28 | 0.00 | complete / not-produced | — | [result](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/e5ac77fa-f728-4007-a37c-729351b1463e/result.json) · [文件清单](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/e5ac77fa-f728-4007-a37c-729351b1463e/files.json) · [轨迹](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/e5ac77fa-f728-4007-a37c-729351b1463e/agent/trajectory.jsonl) |
| test:2527 | completed | 1 | 14.95 | 0.00 | complete / not-produced | — | [result](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/9535f22c-2d1c-4cba-88a9-fa87d3e54041/result.json) · [文件清单](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/9535f22c-2d1c-4cba-88a9-fa87d3e54041/files.json) · [轨迹](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/9535f22c-2d1c-4cba-88a9-fa87d3e54041/agent/trajectory.jsonl) |
| test:2636 | completed | 1 | 19.49 | 0.00 | complete / not-produced | — | [result](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/443485f5-e87b-4dc4-8ace-459c2f6ff9b0/result.json) · [文件清单](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/443485f5-e87b-4dc4-8ace-459c2f6ff9b0/files.json) · [轨迹](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/443485f5-e87b-4dc4-8ace-459c2f6ff9b0/agent/trajectory.jsonl) |
| test:2641 | completed | 1 | 17.73 | 0.00 | complete / not-produced | — | [result](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/539f8adc-37f7-4a91-8562-80774d6e8702/result.json) · [文件清单](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/539f8adc-37f7-4a91-8562-80774d6e8702/files.json) · [轨迹](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/539f8adc-37f7-4a91-8562-80774d6e8702/agent/trajectory.jsonl) |
| test:2714 | completed | 1 | 13.57 | 0.00 | complete / not-produced | — | [result](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/7ef93368-90a0-4677-a4e1-afa39d9c0d28/result.json) · [文件清单](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/7ef93368-90a0-4677-a4e1-afa39d9c0d28/files.json) · [轨迹](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/7ef93368-90a0-4677-a4e1-afa39d9c0d28/agent/trajectory.jsonl) |
| test:2716 | completed | 1 | 24.01 | 0.00 | complete / not-produced | — | [result](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/151e895f-203c-49d7-bfff-729de1810c43/result.json) · [文件清单](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/151e895f-203c-49d7-bfff-729de1810c43/files.json) · [轨迹](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/151e895f-203c-49d7-bfff-729de1810c43/agent/trajectory.jsonl) |
| test:2747 | completed | 1 | 14.01 | 0.00 | complete / not-produced | — | [result](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/e5d38dd0-ece1-4dfe-a88b-6e7e2ed1655b/result.json) · [文件清单](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/e5d38dd0-ece1-4dfe-a88b-6e7e2ed1655b/files.json) · [轨迹](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/e5d38dd0-ece1-4dfe-a88b-6e7e2ed1655b/agent/trajectory.jsonl) |
| test:2882 | completed | 0 | 15.02 | 0.00 | complete / not-produced | — | [result](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/97eaab00-2e61-46f9-b51b-42ba22b7c47f/result.json) · [文件清单](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/97eaab00-2e61-46f9-b51b-42ba22b7c47f/files.json) · [轨迹](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/97eaab00-2e61-46f9-b51b-42ba22b7c47f/agent/trajectory.jsonl) |
| test:2951 | completed | 1 | 14.43 | 0.00 | complete / not-produced | — | [result](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/5a2ee408-428d-4d09-9d25-5d84ec0e7362/result.json) · [文件清单](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/5a2ee408-428d-4d09-9d25-5d84ec0e7362/files.json) · [轨迹](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/5a2ee408-428d-4d09-9d25-5d84ec0e7362/agent/trajectory.jsonl) |
| test:3037 | completed | 1 | 12.88 | 0.00 | complete / not-produced | — | [result](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/f28e889a-cff0-46e7-98e3-6aa2d8c165e0/result.json) · [文件清单](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/f28e889a-cff0-46e7-98e3-6aa2d8c165e0/files.json) · [轨迹](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/f28e889a-cff0-46e7-98e3-6aa2d8c165e0/agent/trajectory.jsonl) |
| test:3053 | completed | 1 | 163.13 | 0.00 | complete / not-produced | — | [result](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/3d2031fc-c043-42d7-9816-d760f284f1b0/result.json) · [文件清单](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/3d2031fc-c043-42d7-9816-d760f284f1b0/files.json) · [轨迹](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/3d2031fc-c043-42d7-9816-d760f284f1b0/agent/trajectory.jsonl) |
| test:3136 | completed | 1 | 11.70 | 0.00 | complete / not-produced | — | [result](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/8ebd1278-5852-409a-8669-a08fa1124bf0/result.json) · [文件清单](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/8ebd1278-5852-409a-8669-a08fa1124bf0/files.json) · [轨迹](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/8ebd1278-5852-409a-8669-a08fa1124bf0/agent/trajectory.jsonl) |
| test:3165 | completed | 1 | 12.45 | 0.00 | complete / not-produced | — | [result](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/fe27b809-2f07-4a04-b69e-eb68d6ba6532/result.json) · [文件清单](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/fe27b809-2f07-4a04-b69e-eb68d6ba6532/files.json) · [轨迹](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/fe27b809-2f07-4a04-b69e-eb68d6ba6532/agent/trajectory.jsonl) |
| test:3196 | completed | 1 | 12.52 | 0.00 | complete / not-produced | — | [result](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/cefa772f-2b44-434e-99a0-fcdf8040ba6a/result.json) · [文件清单](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/cefa772f-2b44-434e-99a0-fcdf8040ba6a/files.json) · [轨迹](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/cefa772f-2b44-434e-99a0-fcdf8040ba6a/agent/trajectory.jsonl) |
| test:3231 | completed | 1 | 11.37 | 0.00 | complete / not-produced | — | [result](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/d5b30b80-29c2-45ae-a4c4-39658ebee6bd/result.json) · [文件清单](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/d5b30b80-29c2-45ae-a4c4-39658ebee6bd/files.json) · [轨迹](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/d5b30b80-29c2-45ae-a4c4-39658ebee6bd/agent/trajectory.jsonl) |
| test:3236 | completed | 1 | 9.73 | 0.00 | complete / not-produced | — | [result](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/2aba75c1-ed1b-4a98-ad32-9683cb5829c3/result.json) · [文件清单](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/2aba75c1-ed1b-4a98-ad32-9683cb5829c3/files.json) · [轨迹](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/2aba75c1-ed1b-4a98-ad32-9683cb5829c3/agent/trajectory.jsonl) |
| test:3270 | completed | 1 | 10.55 | 0.00 | complete / not-produced | — | [result](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/177dc89c-32e9-4a65-84a1-5d751460a4da/result.json) · [文件清单](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/177dc89c-32e9-4a65-84a1-5d751460a4da/files.json) · [轨迹](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/177dc89c-32e9-4a65-84a1-5d751460a4da/agent/trajectory.jsonl) |
| test:3293 | completed | 1 | 10.09 | 0.00 | complete / not-produced | — | [result](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/cbfa743d-d0e4-463c-a4ac-6b3eaba84d71/result.json) · [文件清单](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/cbfa743d-d0e4-463c-a4ac-6b3eaba84d71/files.json) · [轨迹](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/cbfa743d-d0e4-463c-a4ac-6b3eaba84d71/agent/trajectory.jsonl) |
| test:3331 | completed | 1 | 10.77 | 0.00 | complete / not-produced | — | [result](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/43b88ea7-253e-43a7-b3ca-874878f9cc7b/result.json) · [文件清单](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/43b88ea7-253e-43a7-b3ca-874878f9cc7b/files.json) · [轨迹](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/43b88ea7-253e-43a7-b3ca-874878f9cc7b/agent/trajectory.jsonl) |
| test:3488 | completed | 1 | 19.23 | 0.00 | complete / not-produced | — | [result](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/304510bd-8167-4008-a1cb-4bdddc365ede/result.json) · [文件清单](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/304510bd-8167-4008-a1cb-4bdddc365ede/files.json) · [轨迹](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/304510bd-8167-4008-a1cb-4bdddc365ede/agent/trajectory.jsonl) |
| test:3491 | completed | 0 | 240.03 | 0.00 | partial / not-produced | SOLVER\_AGENT\_TIMEOUT | [result](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/4f52944f-32d9-452c-a5f8-f0b4bbf7265c/result.json) · [文件清单](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/4f52944f-32d9-452c-a5f8-f0b4bbf7265c/files.json) · [轨迹](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/4f52944f-32d9-452c-a5f8-f0b4bbf7265c/agent/trajectory.jsonl) |
| test:3552 | completed | 1 | 9.80 | 0.00 | complete / not-produced | — | [result](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/642434cf-3f29-4ab8-99c4-b8e7267afd0e/result.json) · [文件清单](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/642434cf-3f29-4ab8-99c4-b8e7267afd0e/files.json) · [轨迹](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/642434cf-3f29-4ab8-99c4-b8e7267afd0e/agent/trajectory.jsonl) |
| test:3599 | completed | 1 | 8.09 | 0.00 | complete / not-produced | — | [result](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/d90674c1-2583-4b15-891c-2aa0f4f0cbd7/result.json) · [文件清单](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/d90674c1-2583-4b15-891c-2aa0f4f0cbd7/files.json) · [轨迹](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/d90674c1-2583-4b15-891c-2aa0f4f0cbd7/agent/trajectory.jsonl) |
| test:3626 | completed | 1 | 12.82 | 0.00 | complete / not-produced | — | [result](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/2e536895-97e5-44f1-9380-67cfe321e22e/result.json) · [文件清单](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/2e536895-97e5-44f1-9380-67cfe321e22e/files.json) · [轨迹](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/2e536895-97e5-44f1-9380-67cfe321e22e/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 1（主流程 1；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| test:3491 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

