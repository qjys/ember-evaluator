<!-- snapshotDigest: eab665d0008e0fed622212e2fdf0b9c76a300917e17e60fb5f416f3978c53f51 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 100.00%（24/24）**

Run: 87b9bf0f-fa19-4a6d-acb9-fdd364fa5929 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:26:53.068Z / 2026-11-12T08:33:13.909Z |
| 总耗时 | 6 分 8 秒 |
| 答对 / 答错 / 解题超时 | 24 / 0 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 24 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 100.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 6 分 8 秒 |
| 环境准备耗时 | 4 分 13 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 55 秒 | 40 秒 | 3 分 36 秒 | 24 |
| 任务准备 | 0.47 毫秒 | 0.29 毫秒 | 1.08 毫秒 | 24 |
| 环境启动 | 19 秒 | 15 秒 | 25 秒 | 24 |
| 解题 | 25 秒 | 12 秒 | 3 分 6 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 8 秒 | 5 秒 | 10 秒 | 24 |
| 评分 | 0.76 毫秒 | 0.23 毫秒 | 7.57 毫秒 | 24 |
| 证据收集 | 29.33 毫秒 | 6.44 毫秒 | 399.72 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 4fe4c1d8-c321-4d8d-b78d-913cbd63fbda | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 53,147 | 32,824 | 85,971 | 24 / 24 | — |
| 运行累计 | 53,147 | 32,824 | 85,971 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:9901 | completed | 1 | 19.32 | 0.00 | complete / not-produced | — | [result](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/bd3ed21e-dbec-4952-9735-de02f2bf9e46/result.json) · [文件清单](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/bd3ed21e-dbec-4952-9735-de02f2bf9e46/files.json) · [轨迹](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/bd3ed21e-dbec-4952-9735-de02f2bf9e46/agent/trajectory.jsonl) |
| test:9931 | completed | 1 | 186.17 | 0.00 | complete / not-produced | — | [result](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/457abeb6-944c-4311-b042-767f3b23c1f4/result.json) · [文件清单](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/457abeb6-944c-4311-b042-767f3b23c1f4/files.json) · [轨迹](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/457abeb6-944c-4311-b042-767f3b23c1f4/agent/trajectory.jsonl) |
| test:10127 | completed | 1 | 19.08 | 0.00 | complete / not-produced | — | [result](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/274a3d19-dc03-43aa-82c3-d2dd0d912b82/result.json) · [文件清单](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/274a3d19-dc03-43aa-82c3-d2dd0d912b82/files.json) · [轨迹](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/274a3d19-dc03-43aa-82c3-d2dd0d912b82/agent/trajectory.jsonl) |
| test:10140 | completed | 1 | 14.79 | 0.01 | complete / not-produced | — | [result](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/a85d83a2-3065-4432-8bc6-1bf3dc3bbe6f/result.json) · [文件清单](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/a85d83a2-3065-4432-8bc6-1bf3dc3bbe6f/files.json) · [轨迹](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/a85d83a2-3065-4432-8bc6-1bf3dc3bbe6f/agent/trajectory.jsonl) |
| test:10174 | completed | 1 | 14.47 | 0.00 | complete / not-produced | — | [result](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/4dcce1f9-9c4e-42a1-968b-820f85e17e39/result.json) · [文件清单](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/4dcce1f9-9c4e-42a1-968b-820f85e17e39/files.json) · [轨迹](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/4dcce1f9-9c4e-42a1-968b-820f85e17e39/agent/trajectory.jsonl) |
| test:10184 | completed | 1 | 15.92 | 0.00 | complete / not-produced | — | [result](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/bb2de743-87bf-4fdd-b344-98f77f66382c/result.json) · [文件清单](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/bb2de743-87bf-4fdd-b344-98f77f66382c/files.json) · [轨迹](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/bb2de743-87bf-4fdd-b344-98f77f66382c/agent/trajectory.jsonl) |
| test:10189 | completed | 1 | 17.96 | 0.00 | complete / not-produced | — | [result](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/cecb83cf-937d-4d59-b82c-f712e3eadea1/result.json) · [文件清单](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/cecb83cf-937d-4d59-b82c-f712e3eadea1/files.json) · [轨迹](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/cecb83cf-937d-4d59-b82c-f712e3eadea1/agent/trajectory.jsonl) |
| test:10294 | completed | 1 | 15.81 | 0.00 | complete / not-produced | — | [result](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/58de2b34-a7f6-4d7d-851e-1c4379cc6d9b/result.json) · [文件清单](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/58de2b34-a7f6-4d7d-851e-1c4379cc6d9b/files.json) · [轨迹](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/58de2b34-a7f6-4d7d-851e-1c4379cc6d9b/agent/trajectory.jsonl) |
| test:10318 | completed | 1 | 16.31 | 0.00 | complete / not-produced | — | [result](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/95288afe-4d86-4aa8-a2e4-a938bd14b6f4/result.json) · [文件清单](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/95288afe-4d86-4aa8-a2e4-a938bd14b6f4/files.json) · [轨迹](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/95288afe-4d86-4aa8-a2e4-a938bd14b6f4/agent/trajectory.jsonl) |
| test:10362 | completed | 1 | 27.56 | 0.00 | complete / not-produced | — | [result](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/232577a0-a9d8-4d0b-8363-460ca375fa1a/result.json) · [文件清单](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/232577a0-a9d8-4d0b-8363-460ca375fa1a/files.json) · [轨迹](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/232577a0-a9d8-4d0b-8363-460ca375fa1a/agent/trajectory.jsonl) |
| test:10396 | completed | 1 | 16.39 | 0.00 | complete / not-produced | — | [result](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/31ee4e0b-e3e4-4073-8ba3-6abda9abf885/result.json) · [文件清单](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/31ee4e0b-e3e4-4073-8ba3-6abda9abf885/files.json) · [轨迹](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/31ee4e0b-e3e4-4073-8ba3-6abda9abf885/agent/trajectory.jsonl) |
| test:10401 | completed | 1 | 21.80 | 0.00 | complete / not-produced | — | [result](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/3ad941d4-8665-471e-87d7-b5b7498867da/result.json) · [文件清单](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/3ad941d4-8665-471e-87d7-b5b7498867da/files.json) · [轨迹](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/3ad941d4-8665-471e-87d7-b5b7498867da/agent/trajectory.jsonl) |
| test:10403 | completed | 1 | 21.29 | 0.00 | complete / not-produced | — | [result](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/db6302a6-412c-4be8-bb83-69322b9bcf38/result.json) · [文件清单](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/db6302a6-412c-4be8-bb83-69322b9bcf38/files.json) · [轨迹](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/db6302a6-412c-4be8-bb83-69322b9bcf38/agent/trajectory.jsonl) |
| test:10412 | completed | 1 | 14.16 | 0.00 | complete / not-produced | — | [result](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/35066f8c-f5ee-43b1-ace2-a39ecf875aa6/result.json) · [文件清单](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/35066f8c-f5ee-43b1-ace2-a39ecf875aa6/files.json) · [轨迹](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/35066f8c-f5ee-43b1-ace2-a39ecf875aa6/agent/trajectory.jsonl) |
| test:10421 | completed | 1 | 19.47 | 0.00 | complete / not-produced | — | [result](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/a090c23b-b0d5-41db-b555-f1197f60ed40/result.json) · [文件清单](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/a090c23b-b0d5-41db-b555-f1197f60ed40/files.json) · [轨迹](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/a090c23b-b0d5-41db-b555-f1197f60ed40/agent/trajectory.jsonl) |
| test:10424 | completed | 1 | 15.93 | 0.00 | complete / not-produced | — | [result](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/522581e7-0702-4171-866e-e2c259cf6fbb/result.json) · [文件清单](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/522581e7-0702-4171-866e-e2c259cf6fbb/files.json) · [轨迹](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/522581e7-0702-4171-866e-e2c259cf6fbb/agent/trajectory.jsonl) |
| test:10471 | completed | 1 | 15.93 | 0.00 | complete / not-produced | — | [result](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/f8412a82-99a0-456f-9cdb-0254623d9ea5/result.json) · [文件清单](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/f8412a82-99a0-456f-9cdb-0254623d9ea5/files.json) · [轨迹](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/f8412a82-99a0-456f-9cdb-0254623d9ea5/agent/trajectory.jsonl) |
| test:10479 | completed | 1 | 19.42 | 0.00 | complete / not-produced | — | [result](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/c4354b50-625c-4fb8-9c32-2a757abaaae5/result.json) · [文件清单](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/c4354b50-625c-4fb8-9c32-2a757abaaae5/files.json) · [轨迹](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/c4354b50-625c-4fb8-9c32-2a757abaaae5/agent/trajectory.jsonl) |
| test:10524 | completed | 1 | 18.31 | 0.00 | complete / not-produced | — | [result](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/1dbac38e-57b8-4208-bdb3-4240f165e425/result.json) · [文件清单](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/1dbac38e-57b8-4208-bdb3-4240f165e425/files.json) · [轨迹](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/1dbac38e-57b8-4208-bdb3-4240f165e425/agent/trajectory.jsonl) |
| test:10607 | completed | 1 | 18.21 | 0.00 | complete / not-produced | — | [result](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/e19c837f-45bb-4b5c-acfb-5be44a8266c1/result.json) · [文件清单](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/e19c837f-45bb-4b5c-acfb-5be44a8266c1/files.json) · [轨迹](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/e19c837f-45bb-4b5c-acfb-5be44a8266c1/agent/trajectory.jsonl) |
| test:10656 | completed | 1 | 19.71 | 0.00 | complete / not-produced | — | [result](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/a1b4a425-8bd9-4535-85e6-b870b3f976af/result.json) · [文件清单](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/a1b4a425-8bd9-4535-85e6-b870b3f976af/files.json) · [轨迹](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/a1b4a425-8bd9-4535-85e6-b870b3f976af/agent/trajectory.jsonl) |
| test:10674 | completed | 1 | 17.10 | 0.00 | complete / not-produced | — | [result](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/ea4641de-a667-48bf-8b2c-ba305e080173/result.json) · [文件清单](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/ea4641de-a667-48bf-8b2c-ba305e080173/files.json) · [轨迹](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/ea4641de-a667-48bf-8b2c-ba305e080173/agent/trajectory.jsonl) |
| test:10683 | completed | 1 | 17.81 | 0.00 | complete / not-produced | — | [result](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/44928da1-657b-43aa-a4bf-b8bd20535431/result.json) · [文件清单](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/44928da1-657b-43aa-a4bf-b8bd20535431/files.json) · [轨迹](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/44928da1-657b-43aa-a4bf-b8bd20535431/agent/trajectory.jsonl) |
| test:10690 | completed | 1 | 12.49 | 0.00 | complete / not-produced | — | [result](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/4d793b95-04fa-4194-bf68-ae1f06ac6515/result.json) · [文件清单](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/4d793b95-04fa-4194-bf68-ae1f06ac6515/files.json) · [轨迹](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/4d793b95-04fa-4194-bf68-ae1f06ac6515/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

