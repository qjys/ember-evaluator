<!-- snapshotDigest: 796e4389f014be305598061e2e2ceecde1c30904720af1441a6dec7ce4fbed7f -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 66.67%（16/24）**

Run: 8ac8b1fd-be65-41d4-8645-8570b7e12ac7 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:33:19.836Z / 2026-11-12T08:41:25.694Z |
| 总耗时 | 7 分 49 秒 |
| 答对 / 答错 / 解题超时 | 16 / 8 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 16 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 66.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 7 分 49 秒 |
| 环境准备耗时 | 3 分 19 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 9 秒 | 38 秒 | 3 分 53 秒 | 24 |
| 任务准备 | 0.47 毫秒 | 0.3 毫秒 | 1.73 毫秒 | 24 |
| 环境启动 | 18 秒 | 14 秒 | 22 秒 | 24 |
| 解题 | 39 秒 | 11 秒 | 3 分 25 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 8 秒 | 5 秒 | 11 秒 | 24 |
| 评分 | 0.78 毫秒 | 0.28 毫秒 | 6.51 毫秒 | 24 |
| 证据收集 | 49.36 毫秒 | 4.89 毫秒 | 311.86 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| bbd21b79-0b8a-4ec4-8be6-a4ec87a8a242 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 47,963 | 80,741 | 128,704 | 24 / 24 | — |
| 运行累计 | 47,963 | 80,741 | 128,704 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:10765 | completed | 1 | 20.36 | 0.00 | complete / not-produced | — | [result](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/2c727278-7924-4237-93fe-1d7f716b4a63/result.json) · [文件清单](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/2c727278-7924-4237-93fe-1d7f716b4a63/files.json) · [轨迹](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/2c727278-7924-4237-93fe-1d7f716b4a63/agent/trajectory.jsonl) |
| test:10770 | completed | 1 | 20.97 | 0.00 | complete / not-produced | — | [result](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/6458c329-1e65-4e65-95c3-eb49e71d6d8b/result.json) · [文件清单](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/6458c329-1e65-4e65-95c3-eb49e71d6d8b/files.json) · [轨迹](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/6458c329-1e65-4e65-95c3-eb49e71d6d8b/agent/trajectory.jsonl) |
| test:10815 | completed | 1 | 15.89 | 0.01 | complete / not-produced | — | [result](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/eccc3373-161f-47cc-b3bd-ae7615bc0514/result.json) · [文件清单](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/eccc3373-161f-47cc-b3bd-ae7615bc0514/files.json) · [轨迹](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/eccc3373-161f-47cc-b3bd-ae7615bc0514/agent/trajectory.jsonl) |
| test:10846 | completed | 0 | 51.66 | 0.00 | complete / not-produced | — | [result](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/b9f2239e-714d-47af-b7ea-11d61a8bcaec/result.json) · [文件清单](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/b9f2239e-714d-47af-b7ea-11d61a8bcaec/files.json) · [轨迹](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/b9f2239e-714d-47af-b7ea-11d61a8bcaec/agent/trajectory.jsonl) |
| test:10898 | completed | 1 | 18.25 | 0.00 | complete / not-produced | — | [result](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/fd9f564c-df31-4c84-be57-ff110cdfa1f6/result.json) · [文件清单](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/fd9f564c-df31-4c84-be57-ff110cdfa1f6/files.json) · [轨迹](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/fd9f564c-df31-4c84-be57-ff110cdfa1f6/agent/trajectory.jsonl) |
| test:10940 | completed | 1 | 17.71 | 0.00 | complete / not-produced | — | [result](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/4340d061-66be-4ead-9d6d-08e67937292c/result.json) · [文件清单](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/4340d061-66be-4ead-9d6d-08e67937292c/files.json) · [轨迹](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/4340d061-66be-4ead-9d6d-08e67937292c/agent/trajectory.jsonl) |
| test:10966 | completed | 1 | 16.32 | 0.00 | complete / not-produced | — | [result](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/368df29b-3893-44fb-a3e9-5a94994feefd/result.json) · [文件清单](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/368df29b-3893-44fb-a3e9-5a94994feefd/files.json) · [轨迹](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/368df29b-3893-44fb-a3e9-5a94994feefd/agent/trajectory.jsonl) |
| test:11045 | completed | 0 | 17.49 | 0.00 | complete / not-produced | — | [result](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/bd7c1b86-2570-457a-bdd8-3750c5e07e98/result.json) · [文件清单](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/bd7c1b86-2570-457a-bdd8-3750c5e07e98/files.json) · [轨迹](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/bd7c1b86-2570-457a-bdd8-3750c5e07e98/agent/trajectory.jsonl) |
| test:11050 | completed | 1 | 65.75 | 0.00 | complete / not-produced | — | [result](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/34464e03-5fae-49db-815b-66f35f9eafad/result.json) · [文件清单](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/34464e03-5fae-49db-815b-66f35f9eafad/files.json) · [轨迹](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/34464e03-5fae-49db-815b-66f35f9eafad/agent/trajectory.jsonl) |
| test:11060 | completed | 1 | 11.36 | 0.00 | complete / not-produced | — | [result](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/c4a41041-1997-4410-8356-3f48ae4d9d1f/result.json) · [文件清单](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/c4a41041-1997-4410-8356-3f48ae4d9d1f/files.json) · [轨迹](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/c4a41041-1997-4410-8356-3f48ae4d9d1f/agent/trajectory.jsonl) |
| test:11093 | completed | 0 | 18.30 | 0.00 | complete / not-produced | — | [result](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/daefb602-6b75-465a-8251-02d981c93f2e/result.json) · [文件清单](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/daefb602-6b75-465a-8251-02d981c93f2e/files.json) · [轨迹](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/daefb602-6b75-465a-8251-02d981c93f2e/agent/trajectory.jsonl) |
| test:11210 | completed | 1 | 12.75 | 0.00 | complete / not-produced | — | [result](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/33f913f0-4dea-4718-b409-175da3ca554c/result.json) · [文件清单](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/33f913f0-4dea-4718-b409-175da3ca554c/files.json) · [轨迹](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/33f913f0-4dea-4718-b409-175da3ca554c/agent/trajectory.jsonl) |
| test:11354 | completed | 0 | 13.06 | 0.00 | complete / not-produced | — | [result](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/fb105899-fe56-45d3-b2d0-9e077cf39aaa/result.json) · [文件清单](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/fb105899-fe56-45d3-b2d0-9e077cf39aaa/files.json) · [轨迹](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/fb105899-fe56-45d3-b2d0-9e077cf39aaa/agent/trajectory.jsonl) |
| test:11491 | completed | 0 | 160.60 | 0.00 | complete / not-produced | — | [result](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/b277bd6f-60a0-4e34-9296-8694598d2002/result.json) · [文件清单](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/b277bd6f-60a0-4e34-9296-8694598d2002/files.json) · [轨迹](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/b277bd6f-60a0-4e34-9296-8694598d2002/agent/trajectory.jsonl) |
| test:11496 | completed | 0 | 85.71 | 0.00 | complete / not-produced | — | [result](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/ab16d3bf-2682-4330-a24b-6390ddce9a74/result.json) · [文件清单](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/ab16d3bf-2682-4330-a24b-6390ddce9a74/files.json) · [轨迹](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/ab16d3bf-2682-4330-a24b-6390ddce9a74/agent/trajectory.jsonl) |
| test:11506 | completed | 0 | 205.00 | 0.00 | complete / not-produced | — | [result](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/0a2abf79-d227-4637-87a8-937290107609/result.json) · [文件清单](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/0a2abf79-d227-4637-87a8-937290107609/files.json) · [轨迹](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/0a2abf79-d227-4637-87a8-937290107609/agent/trajectory.jsonl) |
| test:11559 | completed | 1 | 14.19 | 0.00 | complete / not-produced | — | [result](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/d620f881-9fb0-4301-bb71-06cd6be9d64c/result.json) · [文件清单](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/d620f881-9fb0-4301-bb71-06cd6be9d64c/files.json) · [轨迹](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/d620f881-9fb0-4301-bb71-06cd6be9d64c/agent/trajectory.jsonl) |
| test:11576 | completed | 0 | 31.48 | 0.00 | complete / not-produced | — | [result](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/943b284a-6ac0-41f8-a483-c65bd1bf3853/result.json) · [文件清单](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/943b284a-6ac0-41f8-a483-c65bd1bf3853/files.json) · [轨迹](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/943b284a-6ac0-41f8-a483-c65bd1bf3853/agent/trajectory.jsonl) |
| test:11629 | completed | 1 | 26.47 | 0.00 | complete / not-produced | — | [result](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/3034c273-5b65-4a7a-840c-90e5f20aa05b/result.json) · [文件清单](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/3034c273-5b65-4a7a-840c-90e5f20aa05b/files.json) · [轨迹](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/3034c273-5b65-4a7a-840c-90e5f20aa05b/agent/trajectory.jsonl) |
| test:11660 | completed | 1 | 39.53 | 0.00 | complete / not-produced | — | [result](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/da63649c-5a01-43eb-82b3-567ed5221b82/result.json) · [文件清单](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/da63649c-5a01-43eb-82b3-567ed5221b82/files.json) · [轨迹](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/da63649c-5a01-43eb-82b3-567ed5221b82/agent/trajectory.jsonl) |
| test:11802 | completed | 1 | 16.50 | 0.00 | complete / not-produced | — | [result](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/50346857-4a47-4301-b5ad-f0be22132db9/result.json) · [文件清单](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/50346857-4a47-4301-b5ad-f0be22132db9/files.json) · [轨迹](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/50346857-4a47-4301-b5ad-f0be22132db9/agent/trajectory.jsonl) |
| test:11808 | completed | 1 | 20.12 | 0.00 | complete / not-produced | — | [result](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/3767bbe9-2331-42ba-9a74-742d13ab6ca7/result.json) · [文件清单](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/3767bbe9-2331-42ba-9a74-742d13ab6ca7/files.json) · [轨迹](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/3767bbe9-2331-42ba-9a74-742d13ab6ca7/agent/trajectory.jsonl) |
| test:11824 | completed | 1 | 18.53 | 0.00 | complete / not-produced | — | [result](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/64536c6f-1859-4622-8202-5e6c3b39b375/result.json) · [文件清单](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/64536c6f-1859-4622-8202-5e6c3b39b375/files.json) · [轨迹](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/64536c6f-1859-4622-8202-5e6c3b39b375/agent/trajectory.jsonl) |
| test:11925 | completed | 1 | 29.00 | 0.00 | complete / not-produced | — | [result](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/43432b9b-06ee-424e-9cb3-667e110061de/result.json) · [文件清单](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/43432b9b-06ee-424e-9cb3-667e110061de/files.json) · [轨迹](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/43432b9b-06ee-424e-9cb3-667e110061de/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

