<!-- snapshotDigest: 5c97f10cd8713105ea9953c47874d8fd6bf682bc9dae7fe3c7c825d5e2c21575 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 66.67%（16/24）**

Run: 29c0a153-18a5-41fc-b58f-d48e5302db4d · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:09:38.913Z / 2026-11-12T08:15:07.515Z |
| 总耗时 | 5 分 17 秒 |
| 答对 / 答错 / 解题超时 | 16 / 8 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 16 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 66.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 17 秒 |
| 环境准备耗时 | 2 分 46 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 47 秒 | 30 秒 | 1 分 31 秒 | 24 |
| 任务准备 | 0.77 毫秒 | 0.29 毫秒 | 4.53 毫秒 | 24 |
| 环境启动 | 16 秒 | 10 秒 | 20 秒 | 24 |
| 解题 | 22 秒 | 11 秒 | 1 分 4 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 6 秒 | 4 秒 | 8 秒 | 24 |
| 评分 | 0.55 毫秒 | 0.26 毫秒 | 2.05 毫秒 | 24 |
| 证据收集 | 25.24 毫秒 | 7.37 毫秒 | 79.34 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 0c386351-4215-4e52-af6a-6c3b3606b2a0 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 45,309 | 23,818 | 69,127 | 24 / 24 | — |
| 运行累计 | 45,309 | 23,818 | 69,127 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4879 | completed | 1 | 24.84 | 0.00 | complete / not-produced | — | [result](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/fa5d6f3d-bb99-4d8c-8044-eaec101b917a/result.json) · [文件清单](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/fa5d6f3d-bb99-4d8c-8044-eaec101b917a/files.json) · [轨迹](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/fa5d6f3d-bb99-4d8c-8044-eaec101b917a/agent/trajectory.jsonl) |
| test:5078 | completed | 0 | 42.44 | 0.00 | complete / not-produced | — | [result](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/a83a1f75-84c4-4830-84ae-59c73c596d64/result.json) · [文件清单](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/a83a1f75-84c4-4830-84ae-59c73c596d64/files.json) · [轨迹](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/a83a1f75-84c4-4830-84ae-59c73c596d64/agent/trajectory.jsonl) |
| test:5123 | completed | 1 | 14.91 | 0.00 | complete / not-produced | — | [result](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/49915302-da6d-4835-b1e6-5ca0bd0a53b1/result.json) · [文件清单](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/49915302-da6d-4835-b1e6-5ca0bd0a53b1/files.json) · [轨迹](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/49915302-da6d-4835-b1e6-5ca0bd0a53b1/agent/trajectory.jsonl) |
| test:5174 | completed | 1 | 14.76 | 0.00 | complete / not-produced | — | [result](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/a08be119-6b80-41bb-a980-85bf9f4117cc/result.json) · [文件清单](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/a08be119-6b80-41bb-a980-85bf9f4117cc/files.json) · [轨迹](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/a08be119-6b80-41bb-a980-85bf9f4117cc/agent/trajectory.jsonl) |
| test:5198 | completed | 1 | 12.04 | 0.00 | complete / not-produced | — | [result](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/865698e7-d230-458a-8345-d88a8db9b4a0/result.json) · [文件清单](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/865698e7-d230-458a-8345-d88a8db9b4a0/files.json) · [轨迹](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/865698e7-d230-458a-8345-d88a8db9b4a0/agent/trajectory.jsonl) |
| test:5243 | completed | 1 | 12.41 | 0.00 | complete / not-produced | — | [result](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/d6f00a60-13b3-4248-99d3-e456ef51442e/result.json) · [文件清单](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/d6f00a60-13b3-4248-99d3-e456ef51442e/files.json) · [轨迹](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/d6f00a60-13b3-4248-99d3-e456ef51442e/agent/trajectory.jsonl) |
| test:5309 | completed | 1 | 11.03 | 0.00 | complete / not-produced | — | [result](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/782a3718-8833-4e27-ac0d-e9623b6d7f18/result.json) · [文件清单](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/782a3718-8833-4e27-ac0d-e9623b6d7f18/files.json) · [轨迹](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/782a3718-8833-4e27-ac0d-e9623b6d7f18/agent/trajectory.jsonl) |
| test:5319 | completed | 1 | 15.51 | 0.00 | complete / not-produced | — | [result](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/509944e5-0092-4451-88b9-bbc3d7fa4375/result.json) · [文件清单](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/509944e5-0092-4451-88b9-bbc3d7fa4375/files.json) · [轨迹](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/509944e5-0092-4451-88b9-bbc3d7fa4375/agent/trajectory.jsonl) |
| test:5328 | completed | 0 | 14.31 | 0.00 | complete / not-produced | — | [result](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/6a17e85a-bd6c-4e64-9cdd-61c1db3726a4/result.json) · [文件清单](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/6a17e85a-bd6c-4e64-9cdd-61c1db3726a4/files.json) · [轨迹](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/6a17e85a-bd6c-4e64-9cdd-61c1db3726a4/agent/trajectory.jsonl) |
| test:5361 | completed | 0 | 63.90 | 0.00 | complete / not-produced | — | [result](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/86a0bf4b-72b8-4555-b216-284aabf5ede6/result.json) · [文件清单](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/86a0bf4b-72b8-4555-b216-284aabf5ede6/files.json) · [轨迹](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/86a0bf4b-72b8-4555-b216-284aabf5ede6/agent/trajectory.jsonl) |
| test:5457 | completed | 1 | 13.80 | 0.00 | complete / not-produced | — | [result](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/f70c73ac-8863-4fc0-b4ef-3b0f2a212bbd/result.json) · [文件清单](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/f70c73ac-8863-4fc0-b4ef-3b0f2a212bbd/files.json) · [轨迹](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/f70c73ac-8863-4fc0-b4ef-3b0f2a212bbd/agent/trajectory.jsonl) |
| test:5461 | completed | 1 | 14.80 | 0.00 | complete / not-produced | — | [result](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/02d04dce-3430-4172-bf58-ccce09dac002/result.json) · [文件清单](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/02d04dce-3430-4172-bf58-ccce09dac002/files.json) · [轨迹](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/02d04dce-3430-4172-bf58-ccce09dac002/agent/trajectory.jsonl) |
| test:5530 | completed | 0 | 41.91 | 0.00 | complete / not-produced | — | [result](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/6ca17429-b26f-419e-93d4-f66a9c0f5ec6/result.json) · [文件清单](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/6ca17429-b26f-419e-93d4-f66a9c0f5ec6/files.json) · [轨迹](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/6ca17429-b26f-419e-93d4-f66a9c0f5ec6/agent/trajectory.jsonl) |
| test:5578 | completed | 1 | 15.53 | 0.00 | complete / not-produced | — | [result](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/b918e06c-d040-48b6-b80a-6f8351ec2966/result.json) · [文件清单](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/b918e06c-d040-48b6-b80a-6f8351ec2966/files.json) · [轨迹](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/b918e06c-d040-48b6-b80a-6f8351ec2966/agent/trajectory.jsonl) |
| test:5580 | completed | 1 | 16.99 | 0.00 | complete / not-produced | — | [result](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/77694697-3271-4944-bbf6-b1c207713e0d/result.json) · [文件清单](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/77694697-3271-4944-bbf6-b1c207713e0d/files.json) · [轨迹](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/77694697-3271-4944-bbf6-b1c207713e0d/agent/trajectory.jsonl) |
| test:5795 | completed | 1 | 13.22 | 0.00 | complete / not-produced | — | [result](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/16171bf5-3981-4342-a96b-e5ec1abb518c/result.json) · [文件清单](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/16171bf5-3981-4342-a96b-e5ec1abb518c/files.json) · [轨迹](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/16171bf5-3981-4342-a96b-e5ec1abb518c/agent/trajectory.jsonl) |
| test:5919 | completed | 0 | 48.05 | 0.00 | complete / not-produced | — | [result](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/930d69bf-0657-4ef3-89de-8fdc6cbda7a5/result.json) · [文件清单](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/930d69bf-0657-4ef3-89de-8fdc6cbda7a5/files.json) · [轨迹](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/930d69bf-0657-4ef3-89de-8fdc6cbda7a5/agent/trajectory.jsonl) |
| test:5940 | completed | 1 | 14.91 | 0.00 | complete / not-produced | — | [result](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/614c1806-5b4f-479f-b5da-080ec29af9e2/result.json) · [文件清单](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/614c1806-5b4f-479f-b5da-080ec29af9e2/files.json) · [轨迹](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/614c1806-5b4f-479f-b5da-080ec29af9e2/agent/trajectory.jsonl) |
| test:6055 | completed | 1 | 13.82 | 0.00 | complete / not-produced | — | [result](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/68398393-5dc9-43ce-98e7-9f9d98ac6204/result.json) · [文件清单](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/68398393-5dc9-43ce-98e7-9f9d98ac6204/files.json) · [轨迹](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/68398393-5dc9-43ce-98e7-9f9d98ac6204/agent/trajectory.jsonl) |
| test:6095 | completed | 1 | 15.08 | 0.00 | complete / not-produced | — | [result](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/f8b9e320-ca3c-477c-bede-95c84b465e9b/result.json) · [文件清单](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/f8b9e320-ca3c-477c-bede-95c84b465e9b/files.json) · [轨迹](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/f8b9e320-ca3c-477c-bede-95c84b465e9b/agent/trajectory.jsonl) |
| test:6120 | completed | 1 | 13.33 | 0.00 | complete / not-produced | — | [result](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/396208cc-25b2-4930-b59b-e15d71e423ce/result.json) · [文件清单](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/396208cc-25b2-4930-b59b-e15d71e423ce/files.json) · [轨迹](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/396208cc-25b2-4930-b59b-e15d71e423ce/agent/trajectory.jsonl) |
| test:6123 | completed | 0 | 21.05 | 0.00 | complete / not-produced | — | [result](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/b0ebf05a-9d3d-4d6a-a878-6858d52c3c68/result.json) · [文件清单](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/b0ebf05a-9d3d-4d6a-a878-6858d52c3c68/files.json) · [轨迹](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/b0ebf05a-9d3d-4d6a-a878-6858d52c3c68/agent/trajectory.jsonl) |
| test:6147 | completed | 0 | 31.63 | 0.00 | complete / not-produced | — | [result](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/4cc3285f-72b6-4e2a-b580-1f03ba714766/result.json) · [文件清单](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/4cc3285f-72b6-4e2a-b580-1f03ba714766/files.json) · [轨迹](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/4cc3285f-72b6-4e2a-b580-1f03ba714766/agent/trajectory.jsonl) |
| test:6198 | completed | 0 | 23.19 | 0.00 | complete / not-produced | — | [result](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/4f580f33-7294-4f8d-831f-ead86d267c59/result.json) · [文件清单](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/4f580f33-7294-4f8d-831f-ead86d267c59/files.json) · [轨迹](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/4f580f33-7294-4f8d-831f-ead86d267c59/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

