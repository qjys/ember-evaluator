<!-- snapshotDigest: b084ee9fd0c309dc1f2461c92d7f4514e4caa80109c492e834968c65367d7aaf -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 75.00%（18/24）**

Run: 39dfd342-cd12-43ad-91c6-bd657ee7430f · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:17:11.207Z / 2026-11-12T08:22:54.281Z |
| 总耗时 | 5 分 32 秒 |
| 答对 / 答错 / 解题超时 | 18 / 6 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 18 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 75.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 32 秒 |
| 环境准备耗时 | 3 分 6 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 36 秒 | 27 秒 | 1 分 10 秒 | 24 |
| 任务准备 | 0.49 毫秒 | 0.31 毫秒 | 2.34 毫秒 | 24 |
| 环境启动 | 15 秒 | 12 秒 | 19 秒 | 24 |
| 解题 | 12 秒 | 6 秒 | 48 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 6 秒 | 4 秒 | 9 秒 | 24 |
| 评分 | 0.59 毫秒 | 0.19 毫秒 | 2.23 毫秒 | 24 |
| 证据收集 | 10.99 毫秒 | 3.76 毫秒 | 30.59 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 0286d102-7d92-42f5-a45a-5b039e564aa3 | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 66,762 | 17,557 | 84,319 | 24 / 24 | — |
| 运行累计 | 66,762 | 17,557 | 84,319 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:5309 | completed | 1 | 7.39 | 0.00 | complete / not-produced | — | [result](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/21467857-da3c-4c1c-b019-d3b87c4ee3dc/result.json) · [文件清单](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/21467857-da3c-4c1c-b019-d3b87c4ee3dc/files.json) · [轨迹](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/21467857-da3c-4c1c-b019-d3b87c4ee3dc/agent/trajectory.jsonl) |
| test:5319 | completed | 1 | 12.81 | 0.00 | complete / not-produced | — | [result](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/1ab928bf-83d6-4b7d-b801-1bcd1b67957d/result.json) · [文件清单](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/1ab928bf-83d6-4b7d-b801-1bcd1b67957d/files.json) · [轨迹](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/1ab928bf-83d6-4b7d-b801-1bcd1b67957d/agent/trajectory.jsonl) |
| test:5328 | completed | 0 | 11.43 | 0.00 | complete / not-produced | — | [result](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/36be8960-e581-4fa0-8765-169119a0ad93/result.json) · [文件清单](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/36be8960-e581-4fa0-8765-169119a0ad93/files.json) · [轨迹](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/36be8960-e581-4fa0-8765-169119a0ad93/agent/trajectory.jsonl) |
| test:5361 | completed | 0 | 11.30 | 0.00 | complete / not-produced | — | [result](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/c9ee87d3-af72-4809-86ee-ea69f8b6797d/result.json) · [文件清单](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/c9ee87d3-af72-4809-86ee-ea69f8b6797d/files.json) · [轨迹](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/c9ee87d3-af72-4809-86ee-ea69f8b6797d/agent/trajectory.jsonl) |
| test:5457 | completed | 1 | 7.91 | 0.00 | complete / not-produced | — | [result](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/9f2fffc0-6ca7-418b-96b6-a0c2a3fbe3ef/result.json) · [文件清单](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/9f2fffc0-6ca7-418b-96b6-a0c2a3fbe3ef/files.json) · [轨迹](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/9f2fffc0-6ca7-418b-96b6-a0c2a3fbe3ef/agent/trajectory.jsonl) |
| test:5461 | completed | 1 | 5.83 | 0.00 | complete / not-produced | — | [result](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/661094a1-51ca-4109-a6a3-d0ab4e8c322d/result.json) · [文件清单](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/661094a1-51ca-4109-a6a3-d0ab4e8c322d/files.json) · [轨迹](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/661094a1-51ca-4109-a6a3-d0ab4e8c322d/agent/trajectory.jsonl) |
| test:5530 | completed | 1 | 8.95 | 0.00 | complete / not-produced | — | [result](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/9f6064f1-282f-47bf-a563-4fc46bb13ea1/result.json) · [文件清单](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/9f6064f1-282f-47bf-a563-4fc46bb13ea1/files.json) · [轨迹](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/9f6064f1-282f-47bf-a563-4fc46bb13ea1/agent/trajectory.jsonl) |
| test:5578 | completed | 1 | 5.60 | 0.00 | complete / not-produced | — | [result](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/25ba488e-6f4a-423c-a752-b13c1da717f5/result.json) · [文件清单](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/25ba488e-6f4a-423c-a752-b13c1da717f5/files.json) · [轨迹](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/25ba488e-6f4a-423c-a752-b13c1da717f5/agent/trajectory.jsonl) |
| test:5580 | completed | 1 | 6.84 | 0.00 | complete / not-produced | — | [result](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/ebfc66a6-6308-44be-921e-26b0154ee935/result.json) · [文件清单](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/ebfc66a6-6308-44be-921e-26b0154ee935/files.json) · [轨迹](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/ebfc66a6-6308-44be-921e-26b0154ee935/agent/trajectory.jsonl) |
| test:5795 | completed | 1 | 6.30 | 0.00 | complete / not-produced | — | [result](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/9fa083fb-84dd-47b3-8804-ce078c494526/result.json) · [文件清单](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/9fa083fb-84dd-47b3-8804-ce078c494526/files.json) · [轨迹](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/9fa083fb-84dd-47b3-8804-ce078c494526/agent/trajectory.jsonl) |
| test:5919 | completed | 0 | 11.38 | 0.00 | complete / not-produced | — | [result](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/d6836cac-5c97-4971-8950-5c07ad8ebe27/result.json) · [文件清单](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/d6836cac-5c97-4971-8950-5c07ad8ebe27/files.json) · [轨迹](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/d6836cac-5c97-4971-8950-5c07ad8ebe27/agent/trajectory.jsonl) |
| test:5940 | completed | 1 | 6.40 | 0.00 | complete / not-produced | — | [result](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/e6b27875-6c0d-470b-8799-9aa9899d53b3/result.json) · [文件清单](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/e6b27875-6c0d-470b-8799-9aa9899d53b3/files.json) · [轨迹](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/e6b27875-6c0d-470b-8799-9aa9899d53b3/agent/trajectory.jsonl) |
| test:6055 | completed | 1 | 6.03 | 0.00 | complete / not-produced | — | [result](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/cc75bb78-3bf8-4cc1-ab18-3db80a5a405e/result.json) · [文件清单](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/cc75bb78-3bf8-4cc1-ab18-3db80a5a405e/files.json) · [轨迹](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/cc75bb78-3bf8-4cc1-ab18-3db80a5a405e/agent/trajectory.jsonl) |
| test:6095 | completed | 1 | 8.41 | 0.00 | complete / not-produced | — | [result](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/65ebf475-a6db-44d3-aa98-7ee6254040b0/result.json) · [文件清单](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/65ebf475-a6db-44d3-aa98-7ee6254040b0/files.json) · [轨迹](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/65ebf475-a6db-44d3-aa98-7ee6254040b0/agent/trajectory.jsonl) |
| test:6120 | completed | 1 | 6.97 | 0.00 | complete / not-produced | — | [result](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/734d7752-c370-4838-86ea-72ba5b37af2f/result.json) · [文件清单](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/734d7752-c370-4838-86ea-72ba5b37af2f/files.json) · [轨迹](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/734d7752-c370-4838-86ea-72ba5b37af2f/agent/trajectory.jsonl) |
| test:6123 | completed | 0 | 34.43 | 0.00 | complete / not-produced | — | [result](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/487f47e6-52cb-42ae-b37a-425fd323187b/result.json) · [文件清单](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/487f47e6-52cb-42ae-b37a-425fd323187b/files.json) · [轨迹](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/487f47e6-52cb-42ae-b37a-425fd323187b/agent/trajectory.jsonl) |
| test:6147 | completed | 0 | 47.74 | 0.00 | complete / not-produced | — | [result](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/7b4adfd3-6b8b-4413-a16a-6529d335089f/result.json) · [文件清单](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/7b4adfd3-6b8b-4413-a16a-6529d335089f/files.json) · [轨迹](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/7b4adfd3-6b8b-4413-a16a-6529d335089f/agent/trajectory.jsonl) |
| test:6198 | completed | 0 | 10.89 | 0.00 | complete / not-produced | — | [result](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/0af0521e-6113-485f-8888-c38acaa8af53/result.json) · [文件清单](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/0af0521e-6113-485f-8888-c38acaa8af53/files.json) · [轨迹](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/0af0521e-6113-485f-8888-c38acaa8af53/agent/trajectory.jsonl) |
| test:6223 | completed | 1 | 8.95 | 0.00 | complete / not-produced | — | [result](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/ae422f11-4bf6-4931-961c-82b016797072/result.json) · [文件清单](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/ae422f11-4bf6-4931-961c-82b016797072/files.json) · [轨迹](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/ae422f11-4bf6-4931-961c-82b016797072/agent/trajectory.jsonl) |
| test:6235 | completed | 1 | 9.06 | 0.00 | complete / not-produced | — | [result](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/cb2c49ae-3c9c-4293-b899-ae18ffacb307/result.json) · [文件清单](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/cb2c49ae-3c9c-4293-b899-ae18ffacb307/files.json) · [轨迹](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/cb2c49ae-3c9c-4293-b899-ae18ffacb307/agent/trajectory.jsonl) |
| test:6403 | completed | 1 | 21.74 | 0.00 | complete / not-produced | — | [result](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/223d3660-eb49-4ae3-bbbe-ff425f3abffc/result.json) · [文件清单](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/223d3660-eb49-4ae3-bbbe-ff425f3abffc/files.json) · [轨迹](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/223d3660-eb49-4ae3-bbbe-ff425f3abffc/agent/trajectory.jsonl) |
| test:6436 | completed | 1 | 7.83 | 0.00 | complete / not-produced | — | [result](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/e4552cbf-f06e-4e30-893d-5d28e665ef00/result.json) · [文件清单](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/e4552cbf-f06e-4e30-893d-5d28e665ef00/files.json) · [轨迹](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/e4552cbf-f06e-4e30-893d-5d28e665ef00/agent/trajectory.jsonl) |
| test:6508 | completed | 1 | 20.92 | 0.00 | complete / not-produced | — | [result](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/ac9c3768-99de-438d-b6ad-5efa56917ab6/result.json) · [文件清单](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/ac9c3768-99de-438d-b6ad-5efa56917ab6/files.json) · [轨迹](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/ac9c3768-99de-438d-b6ad-5efa56917ab6/agent/trajectory.jsonl) |
| test:6593 | completed | 1 | 9.54 | 0.00 | complete / not-produced | — | [result](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/ba382996-ae71-43c1-a998-5528d6d661a1/result.json) · [文件清单](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/ba382996-ae71-43c1-a998-5528d6d661a1/files.json) · [轨迹](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/ba382996-ae71-43c1-a998-5528d6d661a1/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

