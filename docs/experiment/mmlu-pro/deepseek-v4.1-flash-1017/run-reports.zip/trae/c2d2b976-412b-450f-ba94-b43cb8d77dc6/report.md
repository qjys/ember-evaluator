<!-- snapshotDigest: bb19ee926fd969dd16147e8c60398fe50641f754e3018f53bf5a6a2618d7ae79 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 83.33%（20/24）**

Run: c2d2b976-412b-450f-ba94-b43cb8d77dc6 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:11:20.556Z / 2026-11-12T08:17:06.962Z |
| 总耗时 | 5 分 35 秒 |
| 答对 / 答错 / 解题超时 | 20 / 4 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 20 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 83.33% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 35 秒 |
| 环境准备耗时 | 3 分 31 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 37 秒 | 26 秒 | 1 分 33 秒 | 24 |
| 任务准备 | 0.54 毫秒 | 0.31 毫秒 | 1.3 毫秒 | 24 |
| 环境启动 | 16 秒 | 11 秒 | 20 秒 | 24 |
| 解题 | 12 秒 | 6 秒 | 1 分 13 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 6 秒 | 5 秒 | 9 秒 | 24 |
| 评分 | 0.77 毫秒 | 0.25 毫秒 | 6.62 毫秒 | 24 |
| 证据收集 | 10.03 毫秒 | 4.73 毫秒 | 26.88 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| fc6b1fa9-7247-4e82-b888-b4c6b85cfcb9 | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 83,962 | 14,554 | 98,516 | 24 / 24 | — |
| 运行累计 | 83,962 | 14,554 | 98,516 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4298 | completed | 1 | 9.61 | 0.00 | complete / not-produced | — | [result](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/f333068e-3173-4639-a246-17f138eabd64/result.json) · [文件清单](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/f333068e-3173-4639-a246-17f138eabd64/files.json) · [轨迹](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/f333068e-3173-4639-a246-17f138eabd64/agent/trajectory.jsonl) |
| test:4337 | completed | 1 | 16.78 | 0.00 | complete / not-produced | — | [result](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/53072842-337b-4afa-847b-3ecc2fda07cf/result.json) · [文件清单](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/53072842-337b-4afa-847b-3ecc2fda07cf/files.json) · [轨迹](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/53072842-337b-4afa-847b-3ecc2fda07cf/agent/trajectory.jsonl) |
| test:4376 | completed | 1 | 11.66 | 0.00 | complete / not-produced | — | [result](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/7ad2593f-a17c-40ff-be45-eefd1fa0057a/result.json) · [文件清单](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/7ad2593f-a17c-40ff-be45-eefd1fa0057a/files.json) · [轨迹](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/7ad2593f-a17c-40ff-be45-eefd1fa0057a/agent/trajectory.jsonl) |
| test:4405 | completed | 1 | 9.94 | 0.00 | complete / not-produced | — | [result](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/4a53ed70-4083-4020-994d-6f3b4a18a360/result.json) · [文件清单](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/4a53ed70-4083-4020-994d-6f3b4a18a360/files.json) · [轨迹](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/4a53ed70-4083-4020-994d-6f3b4a18a360/agent/trajectory.jsonl) |
| test:4552 | completed | 0 | 11.63 | 0.00 | complete / not-produced | — | [result](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/2ef7f66f-526b-49ee-9b80-ff334ea80334/result.json) · [文件清单](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/2ef7f66f-526b-49ee-9b80-ff334ea80334/files.json) · [轨迹](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/2ef7f66f-526b-49ee-9b80-ff334ea80334/agent/trajectory.jsonl) |
| test:4560 | completed | 1 | 10.28 | 0.00 | complete / not-produced | — | [result](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/4d08fef7-82da-440e-95f0-36d459cb7e9e/result.json) · [文件清单](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/4d08fef7-82da-440e-95f0-36d459cb7e9e/files.json) · [轨迹](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/4d08fef7-82da-440e-95f0-36d459cb7e9e/agent/trajectory.jsonl) |
| test:4568 | completed | 1 | 6.94 | 0.00 | complete / not-produced | — | [result](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/8a49bb91-13ee-41aa-a623-6c8b6622459f/result.json) · [文件清单](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/8a49bb91-13ee-41aa-a623-6c8b6622459f/files.json) · [轨迹](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/8a49bb91-13ee-41aa-a623-6c8b6622459f/agent/trajectory.jsonl) |
| test:4580 | completed | 1 | 12.74 | 0.00 | complete / not-produced | — | [result](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/9e91ae67-a893-42e8-9a65-f400ea4e3e73/result.json) · [文件清单](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/9e91ae67-a893-42e8-9a65-f400ea4e3e73/files.json) · [轨迹](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/9e91ae67-a893-42e8-9a65-f400ea4e3e73/agent/trajectory.jsonl) |
| test:4603 | completed | 1 | 7.74 | 0.00 | complete / not-produced | — | [result](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/a6b5f721-4531-46cb-b495-2e289d2935de/result.json) · [文件清单](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/a6b5f721-4531-46cb-b495-2e289d2935de/files.json) · [轨迹](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/a6b5f721-4531-46cb-b495-2e289d2935de/agent/trajectory.jsonl) |
| test:4625 | completed | 1 | 8.07 | 0.00 | complete / not-produced | — | [result](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/250e6ae9-9fe5-4671-a7ae-1a4b1b65d9db/result.json) · [文件清单](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/250e6ae9-9fe5-4671-a7ae-1a4b1b65d9db/files.json) · [轨迹](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/250e6ae9-9fe5-4671-a7ae-1a4b1b65d9db/agent/trajectory.jsonl) |
| test:4627 | completed | 1 | 7.74 | 0.00 | complete / not-produced | — | [result](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/15995cbb-c58d-4ae3-8354-4fbd464796f6/result.json) · [文件清单](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/15995cbb-c58d-4ae3-8354-4fbd464796f6/files.json) · [轨迹](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/15995cbb-c58d-4ae3-8354-4fbd464796f6/agent/trajectory.jsonl) |
| test:4651 | completed | 1 | 7.61 | 0.00 | complete / not-produced | — | [result](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/723da069-e696-4d9e-b8a6-00beb8d99381/result.json) · [文件清单](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/723da069-e696-4d9e-b8a6-00beb8d99381/files.json) · [轨迹](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/723da069-e696-4d9e-b8a6-00beb8d99381/agent/trajectory.jsonl) |
| test:4670 | completed | 1 | 12.99 | 0.00 | complete / not-produced | — | [result](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/5c9a512a-3c42-4931-86db-0f3c9dddd1d3/result.json) · [文件清单](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/5c9a512a-3c42-4931-86db-0f3c9dddd1d3/files.json) · [轨迹](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/5c9a512a-3c42-4931-86db-0f3c9dddd1d3/agent/trajectory.jsonl) |
| test:4700 | completed | 1 | 7.95 | 0.01 | complete / not-produced | — | [result](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/a0888c76-1768-4d03-a3de-90a1e39b00bb/result.json) · [文件清单](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/a0888c76-1768-4d03-a3de-90a1e39b00bb/files.json) · [轨迹](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/a0888c76-1768-4d03-a3de-90a1e39b00bb/agent/trajectory.jsonl) |
| test:4709 | completed | 0 | 10.54 | 0.00 | complete / not-produced | — | [result](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/556068eb-6e4b-4999-9750-cbe25b484871/result.json) · [文件清单](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/556068eb-6e4b-4999-9750-cbe25b484871/files.json) · [轨迹](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/556068eb-6e4b-4999-9750-cbe25b484871/agent/trajectory.jsonl) |
| test:4763 | completed | 0 | 6.98 | 0.00 | complete / not-produced | — | [result](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/4bd5bd5a-e602-457a-b18b-0a4133679b3d/result.json) · [文件清单](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/4bd5bd5a-e602-457a-b18b-0a4133679b3d/files.json) · [轨迹](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/4bd5bd5a-e602-457a-b18b-0a4133679b3d/agent/trajectory.jsonl) |
| test:4770 | completed | 1 | 6.45 | 0.00 | complete / not-produced | — | [result](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/5fe1e25c-bdaa-40be-9fbf-e044887d1184/result.json) · [文件清单](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/5fe1e25c-bdaa-40be-9fbf-e044887d1184/files.json) · [轨迹](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/5fe1e25c-bdaa-40be-9fbf-e044887d1184/agent/trajectory.jsonl) |
| test:4786 | completed | 1 | 7.32 | 0.00 | complete / not-produced | — | [result](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/e832a176-7179-435b-98f9-4d68ff1a2ac0/result.json) · [文件清单](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/e832a176-7179-435b-98f9-4d68ff1a2ac0/files.json) · [轨迹](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/e832a176-7179-435b-98f9-4d68ff1a2ac0/agent/trajectory.jsonl) |
| test:4879 | completed | 0 | 72.54 | 0.00 | complete / not-produced | — | [result](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/cbee94a6-f710-49e1-a7c4-64440107de11/result.json) · [文件清单](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/cbee94a6-f710-49e1-a7c4-64440107de11/files.json) · [轨迹](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/cbee94a6-f710-49e1-a7c4-64440107de11/agent/trajectory.jsonl) |
| test:5078 | completed | 1 | 8.23 | 0.00 | complete / not-produced | — | [result](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/e7107784-883c-4af7-b133-69a721a90786/result.json) · [文件清单](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/e7107784-883c-4af7-b133-69a721a90786/files.json) · [轨迹](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/e7107784-883c-4af7-b133-69a721a90786/agent/trajectory.jsonl) |
| test:5123 | completed | 1 | 6.54 | 0.00 | complete / not-produced | — | [result](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/977cc76b-813c-4e60-b387-02d3daafdd80/result.json) · [文件清单](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/977cc76b-813c-4e60-b387-02d3daafdd80/files.json) · [轨迹](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/977cc76b-813c-4e60-b387-02d3daafdd80/agent/trajectory.jsonl) |
| test:5174 | completed | 1 | 7.28 | 0.00 | complete / not-produced | — | [result](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/ccf79c32-8639-49c7-bdc5-f1cd8c013890/result.json) · [文件清单](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/ccf79c32-8639-49c7-bdc5-f1cd8c013890/files.json) · [轨迹](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/ccf79c32-8639-49c7-bdc5-f1cd8c013890/agent/trajectory.jsonl) |
| test:5198 | completed | 1 | 6.00 | 0.00 | complete / not-produced | — | [result](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/4ef3fb62-a5fc-4fe5-9baf-bccafa8e4adc/result.json) · [文件清单](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/4ef3fb62-a5fc-4fe5-9baf-bccafa8e4adc/files.json) · [轨迹](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/4ef3fb62-a5fc-4fe5-9baf-bccafa8e4adc/agent/trajectory.jsonl) |
| test:5243 | completed | 1 | 5.79 | 0.00 | complete / not-produced | — | [result](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/183cbb01-5763-401d-93f0-6b6bbaaa10e0/result.json) · [文件清单](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/183cbb01-5763-401d-93f0-6b6bbaaa10e0/files.json) · [轨迹](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/183cbb01-5763-401d-93f0-6b6bbaaa10e0/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

