<!-- snapshotDigest: 7e29bb2a7cd357c271ab6f4fbf15efab625ccc42f11c633dbf5c323097291f49 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 91.67%（22/24）**

Run: 97c26c6e-bb5b-4899-bdc9-a606ac45fb07 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:22:58.627Z / 2026-11-12T08:29:05.437Z |
| 总耗时 | 5 分 54 秒 |
| 答对 / 答错 / 解题超时 | 22 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 22 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 91.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 54 秒 |
| 环境准备耗时 | 3 分 55 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 40 秒 | 31 秒 | 1 分 23 秒 | 24 |
| 任务准备 | 0.46 毫秒 | 0.32 毫秒 | 1.41 毫秒 | 24 |
| 环境启动 | 19 秒 | 13 秒 | 23 秒 | 24 |
| 解题 | 10 秒 | 5 秒 | 51 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 8 秒 | 5 秒 | 11 秒 | 24 |
| 评分 | 0.71 毫秒 | 0.26 毫秒 | 5.34 毫秒 | 24 |
| 证据收集 | 9.43 毫秒 | 3.05 毫秒 | 23.61 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 520e6368-b7af-4a84-8e9b-8c1dce734bed | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 74,745 | 12,983 | 87,728 | 24 / 24 | — |
| 运行累计 | 74,745 | 12,983 | 87,728 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:6655 | completed | 0 | 29.92 | 0.00 | complete / not-produced | — | [result](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/1d03abae-e4fa-401f-917e-bd6c45664b9f/result.json) · [文件清单](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/1d03abae-e4fa-401f-917e-bd6c45664b9f/files.json) · [轨迹](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/1d03abae-e4fa-401f-917e-bd6c45664b9f/agent/trajectory.jsonl) |
| test:6738 | completed | 1 | 8.11 | 0.00 | complete / not-produced | — | [result](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/7d131d3e-fa38-49bb-babb-edbc6abc9f9d/result.json) · [文件清单](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/7d131d3e-fa38-49bb-babb-edbc6abc9f9d/files.json) · [轨迹](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/7d131d3e-fa38-49bb-babb-edbc6abc9f9d/agent/trajectory.jsonl) |
| test:6751 | completed | 1 | 7.81 | 0.01 | complete / not-produced | — | [result](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/485cf9d7-4994-41d8-9949-c3b40c9c4ed0/result.json) · [文件清单](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/485cf9d7-4994-41d8-9949-c3b40c9c4ed0/files.json) · [轨迹](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/485cf9d7-4994-41d8-9949-c3b40c9c4ed0/agent/trajectory.jsonl) |
| test:6784 | completed | 1 | 7.66 | 0.00 | complete / not-produced | — | [result](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/4189f11e-d606-4fbc-a382-15ded84ce6fd/result.json) · [文件清单](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/4189f11e-d606-4fbc-a382-15ded84ce6fd/files.json) · [轨迹](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/4189f11e-d606-4fbc-a382-15ded84ce6fd/agent/trajectory.jsonl) |
| test:6792 | completed | 1 | 7.11 | 0.00 | complete / not-produced | — | [result](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/9996a1f0-5693-4e93-ad62-a3feae6ed80a/result.json) · [文件清单](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/9996a1f0-5693-4e93-ad62-a3feae6ed80a/files.json) · [轨迹](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/9996a1f0-5693-4e93-ad62-a3feae6ed80a/agent/trajectory.jsonl) |
| test:6900 | completed | 1 | 5.42 | 0.00 | complete / not-produced | — | [result](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/1a3ddbdd-a12a-4259-95b6-0c99cc28d6c1/result.json) · [文件清单](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/1a3ddbdd-a12a-4259-95b6-0c99cc28d6c1/files.json) · [轨迹](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/1a3ddbdd-a12a-4259-95b6-0c99cc28d6c1/agent/trajectory.jsonl) |
| test:6928 | completed | 1 | 6.85 | 0.00 | complete / not-produced | — | [result](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/3f34f30b-b8fd-45ea-8891-57566c5f8187/result.json) · [文件清单](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/3f34f30b-b8fd-45ea-8891-57566c5f8187/files.json) · [轨迹](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/3f34f30b-b8fd-45ea-8891-57566c5f8187/agent/trajectory.jsonl) |
| test:6929 | completed | 1 | 7.50 | 0.00 | complete / not-produced | — | [result](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/d5a35d12-ef84-4a45-8514-8de385f31825/result.json) · [文件清单](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/d5a35d12-ef84-4a45-8514-8de385f31825/files.json) · [轨迹](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/d5a35d12-ef84-4a45-8514-8de385f31825/agent/trajectory.jsonl) |
| test:7161 | completed | 1 | 50.88 | 0.00 | complete / not-produced | — | [result](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/83c00cbe-870d-40fb-8133-011aadab1d65/result.json) · [文件清单](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/83c00cbe-870d-40fb-8133-011aadab1d65/files.json) · [轨迹](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/83c00cbe-870d-40fb-8133-011aadab1d65/agent/trajectory.jsonl) |
| test:7181 | completed | 1 | 8.57 | 0.00 | complete / not-produced | — | [result](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/2d685362-ad3e-422a-97d1-f187e1a65f71/result.json) · [文件清单](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/2d685362-ad3e-422a-97d1-f187e1a65f71/files.json) · [轨迹](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/2d685362-ad3e-422a-97d1-f187e1a65f71/agent/trajectory.jsonl) |
| test:7217 | completed | 1 | 8.51 | 0.00 | complete / not-produced | — | [result](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/a68882ec-42d6-4f4d-9081-0c40aa951c70/result.json) · [文件清单](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/a68882ec-42d6-4f4d-9081-0c40aa951c70/files.json) · [轨迹](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/a68882ec-42d6-4f4d-9081-0c40aa951c70/agent/trajectory.jsonl) |
| test:7290 | completed | 1 | 10.68 | 0.00 | complete / not-produced | — | [result](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/f4120349-85d8-403d-89fd-a25207c633c8/result.json) · [文件清单](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/f4120349-85d8-403d-89fd-a25207c633c8/files.json) · [轨迹](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/f4120349-85d8-403d-89fd-a25207c633c8/agent/trajectory.jsonl) |
| test:7304 | completed | 1 | 11.48 | 0.00 | complete / not-produced | — | [result](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/903da32a-2c9b-4074-959b-241ce835190a/result.json) · [文件清单](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/903da32a-2c9b-4074-959b-241ce835190a/files.json) · [轨迹](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/903da32a-2c9b-4074-959b-241ce835190a/agent/trajectory.jsonl) |
| test:7312 | completed | 1 | 7.51 | 0.00 | complete / not-produced | — | [result](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/dd17e4bd-f4a2-4756-9715-957c34c26bf5/result.json) · [文件清单](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/dd17e4bd-f4a2-4756-9715-957c34c26bf5/files.json) · [轨迹](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/dd17e4bd-f4a2-4756-9715-957c34c26bf5/agent/trajectory.jsonl) |
| test:7448 | completed | 1 | 8.58 | 0.00 | complete / not-produced | — | [result](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/09903e2e-2578-4c72-8f5b-1a231eae7d4c/result.json) · [文件清单](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/09903e2e-2578-4c72-8f5b-1a231eae7d4c/files.json) · [轨迹](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/09903e2e-2578-4c72-8f5b-1a231eae7d4c/agent/trajectory.jsonl) |
| test:7462 | completed | 1 | 5.75 | 0.00 | complete / not-produced | — | [result](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/4d41ecd4-4c3f-45af-9be0-4a40b9dfa858/result.json) · [文件清单](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/4d41ecd4-4c3f-45af-9be0-4a40b9dfa858/files.json) · [轨迹](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/4d41ecd4-4c3f-45af-9be0-4a40b9dfa858/agent/trajectory.jsonl) |
| test:7526 | completed | 1 | 7.68 | 0.00 | complete / not-produced | — | [result](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/cb8f880c-7d3b-44f2-95ce-982f4331e591/result.json) · [文件清单](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/cb8f880c-7d3b-44f2-95ce-982f4331e591/files.json) · [轨迹](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/cb8f880c-7d3b-44f2-95ce-982f4331e591/agent/trajectory.jsonl) |
| test:7727 | completed | 1 | 6.60 | 0.00 | complete / not-produced | — | [result](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/e7c5f6ca-5075-4fab-a518-339b3f7f4f9a/result.json) · [文件清单](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/e7c5f6ca-5075-4fab-a518-339b3f7f4f9a/files.json) · [轨迹](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/e7c5f6ca-5075-4fab-a518-339b3f7f4f9a/agent/trajectory.jsonl) |
| test:7752 | completed | 0 | 6.53 | 0.00 | complete / not-produced | — | [result](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/fcdc99fd-969e-4e55-9c2b-31fe04ec2c24/result.json) · [文件清单](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/fcdc99fd-969e-4e55-9c2b-31fe04ec2c24/files.json) · [轨迹](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/fcdc99fd-969e-4e55-9c2b-31fe04ec2c24/agent/trajectory.jsonl) |
| test:7838 | completed | 1 | 6.87 | 0.00 | complete / not-produced | — | [result](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/3bb6b809-b87f-4e4b-8977-2723033e7d37/result.json) · [文件清单](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/3bb6b809-b87f-4e4b-8977-2723033e7d37/files.json) · [轨迹](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/3bb6b809-b87f-4e4b-8977-2723033e7d37/agent/trajectory.jsonl) |
| test:7954 | completed | 1 | 7.59 | 0.00 | complete / not-produced | — | [result](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/8efbbb08-b6d7-4b68-bd28-1f589dc1102f/result.json) · [文件清单](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/8efbbb08-b6d7-4b68-bd28-1f589dc1102f/files.json) · [轨迹](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/8efbbb08-b6d7-4b68-bd28-1f589dc1102f/agent/trajectory.jsonl) |
| test:7976 | completed | 1 | 8.18 | 0.00 | complete / not-produced | — | [result](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/32fcd8ab-59f4-41a0-8236-6021a1865634/result.json) · [文件清单](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/32fcd8ab-59f4-41a0-8236-6021a1865634/files.json) · [轨迹](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/32fcd8ab-59f4-41a0-8236-6021a1865634/agent/trajectory.jsonl) |
| test:8199 | completed | 1 | 6.95 | 0.00 | complete / not-produced | — | [result](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/2fa6b679-60a9-40e2-a874-15dc76e0e0b0/result.json) · [文件清单](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/2fa6b679-60a9-40e2-a874-15dc76e0e0b0/files.json) · [轨迹](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/2fa6b679-60a9-40e2-a874-15dc76e0e0b0/agent/trajectory.jsonl) |
| test:8207 | completed | 1 | 5.64 | 0.00 | complete / not-produced | — | [result](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/fa7e7d35-4412-4a89-aec9-40d88ca761b4/result.json) · [文件清单](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/fa7e7d35-4412-4a89-aec9-40d88ca761b4/files.json) · [轨迹](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/fa7e7d35-4412-4a89-aec9-40d88ca761b4/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

