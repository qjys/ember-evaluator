<!-- snapshotDigest: 436635c690e240eab4531bc86443a090e1fc9a8ff5b50a60f3449b3535c75590 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: 2e721029-03d8-456a-a15b-60df440a37ad · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:29:11.465Z / 2026-11-12T08:35:55.624Z |
| 总耗时 | 6 分 30 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 6 分 30 秒 |
| 环境准备耗时 | 3 分 36 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 44 秒 | 27 秒 | 2 分 12 秒 | 24 |
| 任务准备 | 0.54 毫秒 | 0.29 毫秒 | 3.15 毫秒 | 24 |
| 环境启动 | 19 秒 | 12 秒 | 25 秒 | 24 |
| 解题 | 14 秒 | 6 秒 | 1 分 44 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 8 秒 | 6 秒 | 10 秒 | 24 |
| 评分 | 0.61 毫秒 | 0.26 毫秒 | 2.5 毫秒 | 24 |
| 证据收集 | 10.98 毫秒 | 3.41 毫秒 | 19.72 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| c56c8823-2c5d-422a-a657-e156dc5bfb8d | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 75,064 | 27,369 | 102,433 | 24 / 24 | — |
| 运行累计 | 75,064 | 27,369 | 102,433 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:8304 | completed | 1 | 10.43 | 0.00 | complete / not-produced | — | [result](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/14c88bb1-c37d-4f00-a787-fa0d24f0047f/result.json) · [文件清单](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/14c88bb1-c37d-4f00-a787-fa0d24f0047f/files.json) · [轨迹](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/14c88bb1-c37d-4f00-a787-fa0d24f0047f/agent/trajectory.jsonl) |
| test:8366 | completed | 1 | 9.30 | 0.00 | complete / not-produced | — | [result](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/6a1eb48f-86e1-4763-b449-b2d6497fd6f5/result.json) · [文件清单](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/6a1eb48f-86e1-4763-b449-b2d6497fd6f5/files.json) · [轨迹](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/6a1eb48f-86e1-4763-b449-b2d6497fd6f5/agent/trajectory.jsonl) |
| test:8511 | completed | 1 | 8.84 | 0.00 | complete / not-produced | — | [result](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/f2d2484a-72f5-4a30-9147-e4e39df530c0/result.json) · [文件清单](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/f2d2484a-72f5-4a30-9147-e4e39df530c0/files.json) · [轨迹](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/f2d2484a-72f5-4a30-9147-e4e39df530c0/agent/trajectory.jsonl) |
| test:8525 | completed | 1 | 8.83 | 0.00 | complete / not-produced | — | [result](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/9e18a5e0-b5e4-4ea8-84e6-9464de31165d/result.json) · [文件清单](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/9e18a5e0-b5e4-4ea8-84e6-9464de31165d/files.json) · [轨迹](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/9e18a5e0-b5e4-4ea8-84e6-9464de31165d/agent/trajectory.jsonl) |
| test:8604 | completed | 1 | 6.27 | 0.00 | complete / not-produced | — | [result](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/2a929459-8535-4609-afc0-64a8c76bd9e0/result.json) · [文件清单](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/2a929459-8535-4609-afc0-64a8c76bd9e0/files.json) · [轨迹](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/2a929459-8535-4609-afc0-64a8c76bd9e0/agent/trajectory.jsonl) |
| test:8740 | completed | 1 | 10.15 | 0.00 | complete / not-produced | — | [result](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/073cbff2-3766-4cc4-9ac6-251fcb6f4576/result.json) · [文件清单](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/073cbff2-3766-4cc4-9ac6-251fcb6f4576/files.json) · [轨迹](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/073cbff2-3766-4cc4-9ac6-251fcb6f4576/agent/trajectory.jsonl) |
| test:8839 | completed | 1 | 5.98 | 0.00 | complete / not-produced | — | [result](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/018a00f1-ee64-42b3-9664-944fc4c65daa/result.json) · [文件清单](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/018a00f1-ee64-42b3-9664-944fc4c65daa/files.json) · [轨迹](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/018a00f1-ee64-42b3-9664-944fc4c65daa/agent/trajectory.jsonl) |
| test:8939 | completed | 1 | 9.92 | 0.00 | complete / not-produced | — | [result](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/b0f3a70e-f582-4cb8-97db-875796801950/result.json) · [文件清单](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/b0f3a70e-f582-4cb8-97db-875796801950/files.json) · [轨迹](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/b0f3a70e-f582-4cb8-97db-875796801950/agent/trajectory.jsonl) |
| test:8967 | completed | 1 | 7.80 | 0.00 | complete / not-produced | — | [result](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/825ee388-78b3-4d0f-8f19-4c44aa9afc70/result.json) · [文件清单](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/825ee388-78b3-4d0f-8f19-4c44aa9afc70/files.json) · [轨迹](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/825ee388-78b3-4d0f-8f19-4c44aa9afc70/agent/trajectory.jsonl) |
| test:8989 | completed | 1 | 11.17 | 0.00 | complete / not-produced | — | [result](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/51b18eaf-3d1f-45b2-8407-ac35bc6d199a/result.json) · [文件清单](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/51b18eaf-3d1f-45b2-8407-ac35bc6d199a/files.json) · [轨迹](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/51b18eaf-3d1f-45b2-8407-ac35bc6d199a/agent/trajectory.jsonl) |
| test:9136 | completed | 1 | 7.93 | 0.00 | complete / not-produced | — | [result](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/2d0ca7f2-45b7-414d-99e5-be4139563fa6/result.json) · [文件清单](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/2d0ca7f2-45b7-414d-99e5-be4139563fa6/files.json) · [轨迹](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/2d0ca7f2-45b7-414d-99e5-be4139563fa6/agent/trajectory.jsonl) |
| test:9222 | completed | 1 | 9.25 | 0.00 | complete / not-produced | — | [result](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/ee0eeaba-aa59-471c-8439-9761704626ce/result.json) · [文件清单](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/ee0eeaba-aa59-471c-8439-9761704626ce/files.json) · [轨迹](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/ee0eeaba-aa59-471c-8439-9761704626ce/agent/trajectory.jsonl) |
| test:9391 | completed | 1 | 7.43 | 0.00 | complete / not-produced | — | [result](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/73a6b061-22a6-45ea-aa62-b970fe683b27/result.json) · [文件清单](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/73a6b061-22a6-45ea-aa62-b970fe683b27/files.json) · [轨迹](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/73a6b061-22a6-45ea-aa62-b970fe683b27/agent/trajectory.jsonl) |
| test:9395 | completed | 1 | 15.07 | 0.00 | complete / not-produced | — | [result](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/ebb6eb21-aa6a-48ee-9185-5d8e8c57b5b5/result.json) · [文件清单](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/ebb6eb21-aa6a-48ee-9185-5d8e8c57b5b5/files.json) · [轨迹](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/ebb6eb21-aa6a-48ee-9185-5d8e8c57b5b5/agent/trajectory.jsonl) |
| test:9405 | completed | 1 | 30.93 | 0.00 | complete / not-produced | — | [result](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/f341cf09-e5ff-4c4c-bf62-a328f527c8ae/result.json) · [文件清单](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/f341cf09-e5ff-4c4c-bf62-a328f527c8ae/files.json) · [轨迹](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/f341cf09-e5ff-4c4c-bf62-a328f527c8ae/agent/trajectory.jsonl) |
| test:9769 | completed | 1 | 6.48 | 0.00 | complete / not-produced | — | [result](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/cb2d2269-b4eb-4dfa-99ab-8112ee848431/result.json) · [文件清单](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/cb2d2269-b4eb-4dfa-99ab-8112ee848431/files.json) · [轨迹](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/cb2d2269-b4eb-4dfa-99ab-8112ee848431/agent/trajectory.jsonl) |
| test:9843 | completed | 1 | 15.94 | 0.00 | complete / not-produced | — | [result](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/92d505a1-8a43-4723-bcf5-666f02e595b8/result.json) · [文件清单](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/92d505a1-8a43-4723-bcf5-666f02e595b8/files.json) · [轨迹](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/92d505a1-8a43-4723-bcf5-666f02e595b8/agent/trajectory.jsonl) |
| test:9864 | completed | 1 | 5.88 | 0.00 | complete / not-produced | — | [result](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/31975797-3eff-4cbd-8fee-895ca5d27ff9/result.json) · [文件清单](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/31975797-3eff-4cbd-8fee-895ca5d27ff9/files.json) · [轨迹](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/31975797-3eff-4cbd-8fee-895ca5d27ff9/agent/trajectory.jsonl) |
| test:9901 | completed | 1 | 6.72 | 0.00 | complete / not-produced | — | [result](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/5c6148aa-f887-492a-b810-748a0a1fa194/result.json) · [文件清单](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/5c6148aa-f887-492a-b810-748a0a1fa194/files.json) · [轨迹](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/5c6148aa-f887-492a-b810-748a0a1fa194/agent/trajectory.jsonl) |
| test:9931 | completed | 0 | 104.04 | 0.00 | complete / not-produced | — | [result](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/f7975f10-3f25-483c-b68a-2bb7cb62cbf4/result.json) · [文件清单](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/f7975f10-3f25-483c-b68a-2bb7cb62cbf4/files.json) · [轨迹](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/f7975f10-3f25-483c-b68a-2bb7cb62cbf4/agent/trajectory.jsonl) |
| test:10127 | completed | 1 | 7.47 | 0.00 | complete / not-produced | — | [result](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/4d6c2fb5-c47f-4301-8923-41954682fe83/result.json) · [文件清单](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/4d6c2fb5-c47f-4301-8923-41954682fe83/files.json) · [轨迹](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/4d6c2fb5-c47f-4301-8923-41954682fe83/agent/trajectory.jsonl) |
| test:10140 | completed | 1 | 6.66 | 0.00 | complete / not-produced | — | [result](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/343b2932-bd33-48f3-91a7-1c42940619e4/result.json) · [文件清单](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/343b2932-bd33-48f3-91a7-1c42940619e4/files.json) · [轨迹](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/343b2932-bd33-48f3-91a7-1c42940619e4/agent/trajectory.jsonl) |
| test:10174 | completed | 1 | 8.15 | 0.00 | complete / not-produced | — | [result](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/6bb82bc3-1cec-4bc5-8fbf-6f84c98e7d15/result.json) · [文件清单](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/6bb82bc3-1cec-4bc5-8fbf-6f84c98e7d15/files.json) · [轨迹](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/6bb82bc3-1cec-4bc5-8fbf-6f84c98e7d15/agent/trajectory.jsonl) |
| test:10184 | completed | 1 | 6.63 | 0.00 | complete / not-produced | — | [result](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/70cfe63d-fcd2-4bac-8ed8-b994bad65e18/result.json) · [文件清单](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/70cfe63d-fcd2-4bac-8ed8-b994bad65e18/files.json) · [轨迹](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/70cfe63d-fcd2-4bac-8ed8-b994bad65e18/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

