<!-- snapshotDigest: bba5a23c40fcf40ae9b277492e6d7d9403fda6c9ed45091714eab97fdae949aa -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 87.50%（21/24）**

Run: b8303e2b-e7f9-4d9f-8fbe-74717d68a732 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:03:58.434Z / 2026-11-12T08:11:13.307Z |
| 总耗时 | 7 分 0 秒 |
| 答对 / 答错 / 解题超时 | 21 / 3 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 21 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 87.50% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 7 分 0 秒 |
| 环境准备耗时 | 3 分 1 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 43 秒 | 24 秒 | 4 分 25 秒 | 24 |
| 任务准备 | 0.86 毫秒 | 0.31 毫秒 | 4.76 毫秒 | 24 |
| 环境启动 | 15 秒 | 10 秒 | 21 秒 | 24 |
| 解题 | 20 秒 | 6 秒 | 4 分 0 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 6 秒 | 4 秒 | 8 秒 | 24 |
| 评分 | 0.55 毫秒 | 0.21 毫秒 | 2.58 毫秒 | 24 |
| 证据收集 | 9.04 毫秒 | 3.25 毫秒 | 19.46 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 7b0b726f-5f8a-4549-80c3-298187d55358 | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 73,110 | 12,044 | 85,154 | 23 / 24 | — |
| 运行累计 | 73,110 | 12,044 | 85,154 | 23 / 24 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:2716 | completed | 1 | 15.69 | 0.00 | complete / not-produced | — | [result](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/0e5c0957-f3d3-4d28-83b3-3be14202fbe5/result.json) · [文件清单](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/0e5c0957-f3d3-4d28-83b3-3be14202fbe5/files.json) · [轨迹](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/0e5c0957-f3d3-4d28-83b3-3be14202fbe5/agent/trajectory.jsonl) |
| test:2882 | completed | 0 | 11.20 | 0.00 | complete / not-produced | — | [result](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/44733f2b-ea90-4c05-9e89-0a55e643d593/result.json) · [文件清单](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/44733f2b-ea90-4c05-9e89-0a55e643d593/files.json) · [轨迹](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/44733f2b-ea90-4c05-9e89-0a55e643d593/agent/trajectory.jsonl) |
| test:2951 | completed | 1 | 11.35 | 0.00 | complete / not-produced | — | [result](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/25116ffc-36f2-43ea-b08f-e2b1468c6ce1/result.json) · [文件清单](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/25116ffc-36f2-43ea-b08f-e2b1468c6ce1/files.json) · [轨迹](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/25116ffc-36f2-43ea-b08f-e2b1468c6ce1/agent/trajectory.jsonl) |
| test:3037 | completed | 1 | 6.94 | 0.00 | complete / not-produced | — | [result](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/8ccb9254-753f-496f-903c-f8efa02cdb12/result.json) · [文件清单](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/8ccb9254-753f-496f-903c-f8efa02cdb12/files.json) · [轨迹](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/8ccb9254-753f-496f-903c-f8efa02cdb12/agent/trajectory.jsonl) |
| test:3053 | completed | 1 | 34.58 | 0.00 | complete / not-produced | — | [result](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/00c36ef4-6e73-4a98-99d3-6b6cd7fdbbf2/result.json) · [文件清单](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/00c36ef4-6e73-4a98-99d3-6b6cd7fdbbf2/files.json) · [轨迹](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/00c36ef4-6e73-4a98-99d3-6b6cd7fdbbf2/agent/trajectory.jsonl) |
| test:3136 | completed | 0 | 9.41 | 0.00 | complete / not-produced | — | [result](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/2818972e-12dc-4064-9112-2079952dcf36/result.json) · [文件清单](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/2818972e-12dc-4064-9112-2079952dcf36/files.json) · [轨迹](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/2818972e-12dc-4064-9112-2079952dcf36/agent/trajectory.jsonl) |
| test:3165 | completed | 1 | 9.89 | 0.00 | complete / not-produced | — | [result](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/ba75039e-3859-4ef2-8d14-0b9b5cc90bcb/result.json) · [文件清单](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/ba75039e-3859-4ef2-8d14-0b9b5cc90bcb/files.json) · [轨迹](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/ba75039e-3859-4ef2-8d14-0b9b5cc90bcb/agent/trajectory.jsonl) |
| test:3196 | completed | 1 | 8.10 | 0.00 | complete / not-produced | — | [result](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/f175c288-7d75-464b-86a0-561649029c95/result.json) · [文件清单](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/f175c288-7d75-464b-86a0-561649029c95/files.json) · [轨迹](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/f175c288-7d75-464b-86a0-561649029c95/agent/trajectory.jsonl) |
| test:3231 | completed | 1 | 8.05 | 0.00 | complete / not-produced | — | [result](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/a513664a-b54d-402c-be77-a68b2c28a57f/result.json) · [文件清单](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/a513664a-b54d-402c-be77-a68b2c28a57f/files.json) · [轨迹](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/a513664a-b54d-402c-be77-a68b2c28a57f/agent/trajectory.jsonl) |
| test:3236 | completed | 1 | 9.63 | 0.00 | complete / not-produced | — | [result](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/bb2714e9-53f6-4a6a-b085-22fc77046013/result.json) · [文件清单](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/bb2714e9-53f6-4a6a-b085-22fc77046013/files.json) · [轨迹](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/bb2714e9-53f6-4a6a-b085-22fc77046013/agent/trajectory.jsonl) |
| test:3270 | completed | 1 | 9.06 | 0.00 | complete / not-produced | — | [result](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/b096a201-86b1-42ef-a861-1b04f0681639/result.json) · [文件清单](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/b096a201-86b1-42ef-a861-1b04f0681639/files.json) · [轨迹](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/b096a201-86b1-42ef-a861-1b04f0681639/agent/trajectory.jsonl) |
| test:3293 | completed | 1 | 9.30 | 0.00 | complete / not-produced | — | [result](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/29a7c8d2-efd6-4cdd-955d-c28ee8c8b53d/result.json) · [文件清单](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/29a7c8d2-efd6-4cdd-955d-c28ee8c8b53d/files.json) · [轨迹](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/29a7c8d2-efd6-4cdd-955d-c28ee8c8b53d/agent/trajectory.jsonl) |
| test:3331 | completed | 1 | 6.78 | 0.00 | complete / not-produced | — | [result](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/97480e19-8953-4b20-8ca7-0f8d13407f75/result.json) · [文件清单](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/97480e19-8953-4b20-8ca7-0f8d13407f75/files.json) · [轨迹](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/97480e19-8953-4b20-8ca7-0f8d13407f75/agent/trajectory.jsonl) |
| test:3488 | completed | 1 | 11.55 | 0.00 | complete / not-produced | — | [result](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/2031044c-0728-4018-92b9-6cf2e6ee98c4/result.json) · [文件清单](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/2031044c-0728-4018-92b9-6cf2e6ee98c4/files.json) · [轨迹](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/2031044c-0728-4018-92b9-6cf2e6ee98c4/agent/trajectory.jsonl) |
| test:3491 | completed | 0 | 240.02 | 0.00 | partial / not-produced | SOLVER\_AGENT\_TIMEOUT | [result](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/30ad9c9c-a1f2-4561-8c9c-43c9df658391/result.json) · [文件清单](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/30ad9c9c-a1f2-4561-8c9c-43c9df658391/files.json) · [轨迹](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/30ad9c9c-a1f2-4561-8c9c-43c9df658391/agent/trajectory.jsonl) |
| test:3552 | completed | 1 | 10.25 | 0.00 | complete / not-produced | — | [result](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/0df0c386-f45a-4cf0-b7b5-6e826dd2553a/result.json) · [文件清单](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/0df0c386-f45a-4cf0-b7b5-6e826dd2553a/files.json) · [轨迹](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/0df0c386-f45a-4cf0-b7b5-6e826dd2553a/agent/trajectory.jsonl) |
| test:3599 | completed | 1 | 6.29 | 0.00 | complete / not-produced | — | [result](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/d17b813b-5727-4038-90fd-0a7a5d741a51/result.json) · [文件清单](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/d17b813b-5727-4038-90fd-0a7a5d741a51/files.json) · [轨迹](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/d17b813b-5727-4038-90fd-0a7a5d741a51/agent/trajectory.jsonl) |
| test:3626 | completed | 1 | 7.88 | 0.00 | complete / not-produced | — | [result](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/e872a3bc-4c03-433d-8835-5cbeec411bb9/result.json) · [文件清单](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/e872a3bc-4c03-433d-8835-5cbeec411bb9/files.json) · [轨迹](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/e872a3bc-4c03-433d-8835-5cbeec411bb9/agent/trajectory.jsonl) |
| test:4021 | completed | 1 | 9.34 | 0.00 | complete / not-produced | — | [result](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/cae42a07-9d44-4acf-9e85-6a2253c6732f/result.json) · [文件清单](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/cae42a07-9d44-4acf-9e85-6a2253c6732f/files.json) · [轨迹](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/cae42a07-9d44-4acf-9e85-6a2253c6732f/agent/trajectory.jsonl) |
| test:4034 | completed | 1 | 6.64 | 0.00 | complete / not-produced | — | [result](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/3cac04bb-8311-4a04-8645-c884e1a3f31c/result.json) · [文件清单](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/3cac04bb-8311-4a04-8645-c884e1a3f31c/files.json) · [轨迹](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/3cac04bb-8311-4a04-8645-c884e1a3f31c/agent/trajectory.jsonl) |
| test:4058 | completed | 1 | 7.50 | 0.00 | complete / not-produced | — | [result](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/d207bb91-914b-42e5-8d17-5d9668faca59/result.json) · [文件清单](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/d207bb91-914b-42e5-8d17-5d9668faca59/files.json) · [轨迹](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/d207bb91-914b-42e5-8d17-5d9668faca59/agent/trajectory.jsonl) |
| test:4075 | completed | 1 | 8.31 | 0.00 | complete / not-produced | — | [result](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/90b13046-c4d6-4ab2-aa34-e7608d5c6065/result.json) · [文件清单](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/90b13046-c4d6-4ab2-aa34-e7608d5c6065/files.json) · [轨迹](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/90b13046-c4d6-4ab2-aa34-e7608d5c6065/agent/trajectory.jsonl) |
| test:4142 | completed | 1 | 13.06 | 0.00 | complete / not-produced | — | [result](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/c21da59e-36f0-419f-9827-fb438c12dbad/result.json) · [文件清单](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/c21da59e-36f0-419f-9827-fb438c12dbad/files.json) · [轨迹](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/c21da59e-36f0-419f-9827-fb438c12dbad/agent/trajectory.jsonl) |
| test:4208 | completed | 1 | 9.36 | 0.00 | complete / not-produced | — | [result](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/cf93f844-bdf8-4d19-9090-daf7f3ebd7b2/result.json) · [文件清单](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/cf93f844-bdf8-4d19-9090-daf7f3ebd7b2/files.json) · [轨迹](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/cf93f844-bdf8-4d19-9090-daf7f3ebd7b2/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 1（主流程 1；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| test:3491 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

