<!-- snapshotDigest: 2ea3c0223937774a1b28e908664dcca81712e8c6bc8c6992788e0390e32fa440 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 3.01%（5/166）**

Run: ef5d3071-a24f-4f77-ab89-15479f2c133d · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:50:28.353Z / 2026-11-12T07:56:00.364Z |
| 总耗时 | 5 分 21 秒 |
| 答对 / 答错 / 解题超时 | 5 / 0 / 0 |
| 清理未确认 | 1 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 168 题；已保存 7 条记录；待运行 161 题。
有效评分覆盖率：5/168（2.98%）。
执行失败 2；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 2。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 168 |
| 计分题数 | 166 |
| 正常评分题数 | 5 |
| 答对题数 | 5 |
| 无效评测 | 2 |
| 待运行 | 161 |
| 正确率 | 3.01% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 21 秒 |
| 环境准备耗时 | 5 分 20 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 40 秒 | 56.06 毫秒 | 1 分 12 秒 | 7 |
| 任务准备 | 0.62 毫秒 | 0.39 毫秒 | 1.04 毫秒 | 6 |
| 环境启动 | 28 秒 | 19 秒 | 1 分 0 秒 | 6 |
| 解题 | 8 秒 | 4 秒 | 20 秒 | 6 |
| 产物传输 | 1 秒 | 955.09 毫秒 | 3 秒 | 6 |
| 资源清理 | 9 秒 | 6 秒 | 15 秒 | 6 |
| 评分 | 1.89 毫秒 | 0.44 毫秒 | 2.88 毫秒 | 5 |
| 证据收集 | 20.61 毫秒 | 11.28 毫秒 | 34.75 毫秒 | 7 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 0ae3fdef-ca49-4e31-9703-4285886c637e | 未设置 | 600 | 2 | 2 | 1200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 17,634 | 859 | 18,493 | 6 / 168 | — |
| 运行累计 | 17,634 | 859 | 18,493 | 6 / 7 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:2527 | completed | 1 | 5.02 | 0.00 | complete / not-produced | — | [result](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/2bdfe04f-71ea-4760-b44e-0a8c66e422c9/result.json) · [文件清单](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/2bdfe04f-71ea-4760-b44e-0a8c66e422c9/files.json) · [轨迹](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/2bdfe04f-71ea-4760-b44e-0a8c66e422c9/agent/trajectory.jsonl) |
| test:2636 | completed | 1 | 20.16 | 0.00 | complete / not-produced | — | [result](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/21a7e20c-0a2d-45f9-bd58-85dce515b64b/result.json) · [文件清单](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/21a7e20c-0a2d-45f9-bd58-85dce515b64b/files.json) · [轨迹](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/21a7e20c-0a2d-45f9-bd58-85dce515b64b/agent/trajectory.jsonl) |
| test:2641 | completed | 1 | 4.12 | 0.00 | complete / not-produced | — | [result](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/8226fd33-f04d-4082-b1e6-43b478dcfdb2/result.json) · [文件清单](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/8226fd33-f04d-4082-b1e6-43b478dcfdb2/files.json) · [轨迹](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/8226fd33-f04d-4082-b1e6-43b478dcfdb2/agent/trajectory.jsonl) |
| test:2714 | completed | 1 | 6.29 | 0.00 | complete / not-produced | — | [result](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/e1b22eac-8206-4624-85e9-241b4cd6f6ce/result.json) · [文件清单](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/e1b22eac-8206-4624-85e9-241b4cd6f6ce/files.json) · [轨迹](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/e1b22eac-8206-4624-85e9-241b4cd6f6ce/agent/trajectory.jsonl) |
| test:2716 | invalid (infrastructure) | — | — | — | not-produced / not-produced | ENV\_PREPARATION\_TIMEOUT | [result](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/ce4e465f-25f3-4382-a80c-659dd37d023f/result.json) · [文件清单](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/ce4e465f-25f3-4382-a80c-659dd37d023f/files.json) |
| test:2747 | completed | 1 | 6.14 | 0.00 | complete / not-produced | — | [result](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/a9d20525-0949-4f73-aaa5-efd253dcf961/result.json) · [文件清单](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/a9d20525-0949-4f73-aaa5-efd253dcf961/files.json) · [轨迹](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/a9d20525-0949-4f73-aaa5-efd253dcf961/agent/trajectory.jsonl) |
| test:2882 | invalid | — | 8.09 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/d38c844a-c7e4-413e-b81a-d0de2adcb9fe/result.json) · [文件清单](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/d38c844a-c7e4-413e-b81a-d0de2adcb9fe/files.json) · [轨迹](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/d38c844a-c7e4-413e-b81a-d0de2adcb9fe/agent/trajectory.jsonl) |
| test:2951 | pending | — | — | — | — | — | — |
| test:3037 | pending | — | — | — | — | — | — |
| test:3053 | pending | — | — | — | — | — | — |
| test:3136 | pending | — | — | — | — | — | — |
| test:3165 | pending | — | — | — | — | — | — |
| test:3196 | pending | — | — | — | — | — | — |
| test:3231 | pending | — | — | — | — | — | — |
| test:3236 | pending | — | — | — | — | — | — |
| test:3270 | pending | — | — | — | — | — | — |
| test:3293 | pending | — | — | — | — | — | — |
| test:3331 | pending | — | — | — | — | — | — |
| test:3488 | pending | — | — | — | — | — | — |
| test:3491 | pending | — | — | — | — | — | — |
| test:3552 | pending | — | — | — | — | — | — |
| test:3599 | pending | — | — | — | — | — | — |
| test:3626 | pending | — | — | — | — | — | — |
| test:4021 | pending | — | — | — | — | — | — |
| test:4034 | pending | — | — | — | — | — | — |
| test:4058 | pending | — | — | — | — | — | — |
| test:4075 | pending | — | — | — | — | — | — |
| test:4142 | pending | — | — | — | — | — | — |
| test:4208 | pending | — | — | — | — | — | — |
| test:4298 | pending | — | — | — | — | — | — |
| test:4337 | pending | — | — | — | — | — | — |
| test:4376 | pending | — | — | — | — | — | — |
| test:4405 | pending | — | — | — | — | — | — |
| test:4552 | pending | — | — | — | — | — | — |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 2；错误记录 3（主流程 1；证据收集 0；资源清理 2）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| prepare | ENV_PREPARATION_TIMEOUT | 1 | 1 |
| cleanup | CLEANUP_FAILED | 1 | 2 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

