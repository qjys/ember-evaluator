<!-- snapshotDigest: 7abae27b46155551345afb6d6ba4390fa175582225040fb8054cb8df1ded20a6 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 100.00%（24/24）**

Run: 6a7a7674-3ded-4045-96f5-13499d0b5e0b · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:35:59.816Z / 2026-11-12T08:41:58.548Z |
| 总耗时 | 5 分 46 秒 |
| 答对 / 答错 / 解题超时 | 24 / 0 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 24 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 100.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 46 秒 |
| 环境准备耗时 | 3 分 21 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 40 秒 | 31 秒 | 59 秒 | 24 |
| 任务准备 | 0.61 毫秒 | 0.31 毫秒 | 2.86 毫秒 | 24 |
| 环境启动 | 18 秒 | 14 秒 | 21 秒 | 24 |
| 解题 | 10 秒 | 6 秒 | 32 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 8 秒 | 6 秒 | 13 秒 | 24 |
| 评分 | 0.69 毫秒 | 0.26 毫秒 | 2.93 毫秒 | 24 |
| 证据收集 | 9.27 毫秒 | 3.41 毫秒 | 21.58 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 724d75b0-5e04-44cf-8acd-d9193045c862 | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 72,747 | 12,265 | 85,012 | 24 / 24 | — |
| 运行累计 | 72,747 | 12,265 | 85,012 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:10189 | completed | 1 | 6.33 | 0.00 | complete / not-produced | — | [result](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/e28f73d8-a0af-45a0-8057-be97699098c8/result.json) · [文件清单](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/e28f73d8-a0af-45a0-8057-be97699098c8/files.json) · [轨迹](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/e28f73d8-a0af-45a0-8057-be97699098c8/agent/trajectory.jsonl) |
| test:10294 | completed | 1 | 6.78 | 0.00 | complete / not-produced | — | [result](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/a36ea386-162c-446a-8b32-00b1ca7bd1b5/result.json) · [文件清单](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/a36ea386-162c-446a-8b32-00b1ca7bd1b5/files.json) · [轨迹](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/a36ea386-162c-446a-8b32-00b1ca7bd1b5/agent/trajectory.jsonl) |
| test:10318 | completed | 1 | 7.35 | 0.00 | complete / not-produced | — | [result](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/865d6c08-accd-4e49-a5ee-7629b1b5a76f/result.json) · [文件清单](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/865d6c08-accd-4e49-a5ee-7629b1b5a76f/files.json) · [轨迹](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/865d6c08-accd-4e49-a5ee-7629b1b5a76f/agent/trajectory.jsonl) |
| test:10362 | completed | 1 | 6.84 | 0.00 | complete / not-produced | — | [result](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/c61dece0-ff04-4d04-be27-4b36e992dd5a/result.json) · [文件清单](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/c61dece0-ff04-4d04-be27-4b36e992dd5a/files.json) · [轨迹](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/c61dece0-ff04-4d04-be27-4b36e992dd5a/agent/trajectory.jsonl) |
| test:10396 | completed | 1 | 6.97 | 0.00 | complete / not-produced | — | [result](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/cb6f321f-b97a-4a28-bae0-bc4783725c10/result.json) · [文件清单](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/cb6f321f-b97a-4a28-bae0-bc4783725c10/files.json) · [轨迹](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/cb6f321f-b97a-4a28-bae0-bc4783725c10/agent/trajectory.jsonl) |
| test:10401 | completed | 1 | 10.43 | 0.00 | complete / not-produced | — | [result](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/d68dc9ad-5254-4098-af4f-8f6c1b30b9b5/result.json) · [文件清单](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/d68dc9ad-5254-4098-af4f-8f6c1b30b9b5/files.json) · [轨迹](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/d68dc9ad-5254-4098-af4f-8f6c1b30b9b5/agent/trajectory.jsonl) |
| test:10403 | completed | 1 | 9.09 | 0.00 | complete / not-produced | — | [result](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/9092ed04-aa89-4ec1-9fe7-9962940cd091/result.json) · [文件清单](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/9092ed04-aa89-4ec1-9fe7-9962940cd091/files.json) · [轨迹](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/9092ed04-aa89-4ec1-9fe7-9962940cd091/agent/trajectory.jsonl) |
| test:10412 | completed | 1 | 6.99 | 0.00 | complete / not-produced | — | [result](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/0120aae5-6118-4ac5-8c33-ba295a7ece6c/result.json) · [文件清单](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/0120aae5-6118-4ac5-8c33-ba295a7ece6c/files.json) · [轨迹](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/0120aae5-6118-4ac5-8c33-ba295a7ece6c/agent/trajectory.jsonl) |
| test:10421 | completed | 1 | 13.78 | 0.00 | complete / not-produced | — | [result](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/4cd91813-d6f6-4f62-afb3-cec58a520e0c/result.json) · [文件清单](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/4cd91813-d6f6-4f62-afb3-cec58a520e0c/files.json) · [轨迹](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/4cd91813-d6f6-4f62-afb3-cec58a520e0c/agent/trajectory.jsonl) |
| test:10424 | completed | 1 | 8.10 | 0.00 | complete / not-produced | — | [result](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/41f407ba-5dda-4e3c-9a9e-267c12d6d6e7/result.json) · [文件清单](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/41f407ba-5dda-4e3c-9a9e-267c12d6d6e7/files.json) · [轨迹](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/41f407ba-5dda-4e3c-9a9e-267c12d6d6e7/agent/trajectory.jsonl) |
| test:10471 | completed | 1 | 6.05 | 0.00 | complete / not-produced | — | [result](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/88078849-a8fe-4bb6-8c2f-f08ea45642a6/result.json) · [文件清单](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/88078849-a8fe-4bb6-8c2f-f08ea45642a6/files.json) · [轨迹](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/88078849-a8fe-4bb6-8c2f-f08ea45642a6/agent/trajectory.jsonl) |
| test:10479 | completed | 1 | 6.76 | 0.00 | complete / not-produced | — | [result](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/094d2a99-bbcd-402f-993e-f2cef4a18dec/result.json) · [文件清单](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/094d2a99-bbcd-402f-993e-f2cef4a18dec/files.json) · [轨迹](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/094d2a99-bbcd-402f-993e-f2cef4a18dec/agent/trajectory.jsonl) |
| test:10524 | completed | 1 | 8.29 | 0.00 | complete / not-produced | — | [result](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/82c9a1f6-8268-49bb-9a14-736191436e09/result.json) · [文件清单](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/82c9a1f6-8268-49bb-9a14-736191436e09/files.json) · [轨迹](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/82c9a1f6-8268-49bb-9a14-736191436e09/agent/trajectory.jsonl) |
| test:10607 | completed | 1 | 8.33 | 0.00 | complete / not-produced | — | [result](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/00262b42-3314-4489-a471-0d287bbb97aa/result.json) · [文件清单](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/00262b42-3314-4489-a471-0d287bbb97aa/files.json) · [轨迹](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/00262b42-3314-4489-a471-0d287bbb97aa/agent/trajectory.jsonl) |
| test:10656 | completed | 1 | 6.07 | 0.00 | complete / not-produced | — | [result](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/bce83089-a979-4f9e-8da2-78e07f1c1412/result.json) · [文件清单](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/bce83089-a979-4f9e-8da2-78e07f1c1412/files.json) · [轨迹](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/bce83089-a979-4f9e-8da2-78e07f1c1412/agent/trajectory.jsonl) |
| test:10674 | completed | 1 | 9.27 | 0.00 | complete / not-produced | — | [result](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/bf0b210d-e5af-43d4-8ed1-e326c04eec0c/result.json) · [文件清单](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/bf0b210d-e5af-43d4-8ed1-e326c04eec0c/files.json) · [轨迹](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/bf0b210d-e5af-43d4-8ed1-e326c04eec0c/agent/trajectory.jsonl) |
| test:10683 | completed | 1 | 7.46 | 0.00 | complete / not-produced | — | [result](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/1c84e713-946e-4bd7-a379-bb742be5bfe6/result.json) · [文件清单](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/1c84e713-946e-4bd7-a379-bb742be5bfe6/files.json) · [轨迹](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/1c84e713-946e-4bd7-a379-bb742be5bfe6/agent/trajectory.jsonl) |
| test:10690 | completed | 1 | 10.91 | 0.00 | complete / not-produced | — | [result](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/4e2dbedb-e997-44d0-b28b-de240a08bcfe/result.json) · [文件清单](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/4e2dbedb-e997-44d0-b28b-de240a08bcfe/files.json) · [轨迹](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/4e2dbedb-e997-44d0-b28b-de240a08bcfe/agent/trajectory.jsonl) |
| test:10765 | completed | 1 | 9.45 | 0.00 | complete / not-produced | — | [result](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/99b27866-6875-4b3d-a20a-601dcd3b076a/result.json) · [文件清单](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/99b27866-6875-4b3d-a20a-601dcd3b076a/files.json) · [轨迹](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/99b27866-6875-4b3d-a20a-601dcd3b076a/agent/trajectory.jsonl) |
| test:10770 | completed | 1 | 18.46 | 0.00 | complete / not-produced | — | [result](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/b25c8302-dc75-40f4-886f-db1c53e8d56c/result.json) · [文件清单](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/b25c8302-dc75-40f4-886f-db1c53e8d56c/files.json) · [轨迹](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/b25c8302-dc75-40f4-886f-db1c53e8d56c/agent/trajectory.jsonl) |
| test:10815 | completed | 1 | 22.97 | 0.00 | complete / not-produced | — | [result](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/f018a884-eeaa-4bf6-ad28-fda7201253af/result.json) · [文件清单](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/f018a884-eeaa-4bf6-ad28-fda7201253af/files.json) · [轨迹](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/f018a884-eeaa-4bf6-ad28-fda7201253af/agent/trajectory.jsonl) |
| test:10846 | completed | 1 | 32.29 | 0.00 | complete / not-produced | — | [result](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/235b42a2-23b5-4b0b-85ee-d20d1998dd71/result.json) · [文件清单](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/235b42a2-23b5-4b0b-85ee-d20d1998dd71/files.json) · [轨迹](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/235b42a2-23b5-4b0b-85ee-d20d1998dd71/agent/trajectory.jsonl) |
| test:10898 | completed | 1 | 8.89 | 0.00 | complete / not-produced | — | [result](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/4a749dfa-e1a9-4689-8118-26136a418cc9/result.json) · [文件清单](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/4a749dfa-e1a9-4689-8118-26136a418cc9/files.json) · [轨迹](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/4a749dfa-e1a9-4689-8118-26136a418cc9/agent/trajectory.jsonl) |
| test:10940 | completed | 1 | 7.78 | 0.00 | complete / not-produced | — | [result](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/6e97b56f-0adf-464e-a2b4-61baa7e6f394/result.json) · [文件清单](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/6e97b56f-0adf-464e-a2b4-61baa7e6f394/files.json) · [轨迹](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/6e97b56f-0adf-464e-a2b4-61baa7e6f394/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

