<!-- snapshotDigest: cef753a1ee27439d85414e736bb7d3c89f1c81bff03bd26fd45d0ead60b03444 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 57.89%（11/19）**

Run: 50d2c1af-2be5-4594-9405-b3739c68f245 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:42:05.219Z / 2026-11-12T08:49:50.996Z |
| 总耗时 | 7 分 30 秒 |
| 答对 / 答错 / 解题超时 | 11 / 8 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 19 题；已保存 19 条记录；待运行 0 题。
有效评分覆盖率：19/19（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 19 |
| 计分题数 | 19 |
| 正常评分题数 | 19 |
| 答对题数 | 11 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 57.89% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 7 分 30 秒 |
| 环境准备耗时 | 3 分 24 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 4 秒 | 26 秒 | 3 分 26 秒 | 19 |
| 任务准备 | 0.67 毫秒 | 0.31 毫秒 | 2.67 毫秒 | 19 |
| 环境启动 | 19 秒 | 11 秒 | 28 秒 | 19 |
| 解题 | 32 秒 | 5 秒 | 2 分 57 秒 | 19 |
| 产物传输 | 4 秒 | 2 秒 | 6 秒 | 19 |
| 资源清理 | 9 秒 | 6 秒 | 13 秒 | 19 |
| 评分 | 1.06 毫秒 | 0.21 毫秒 | 7.06 毫秒 | 19 |
| 证据收集 | 12.01 毫秒 | 3.48 毫秒 | 20.57 毫秒 | 19 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 8827352e-6263-4079-a939-03763264ecb1 | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 55,505 | 68,428 | 123,933 | 19 / 19 | — |
| 运行累计 | 55,505 | 68,428 | 123,933 | 19 / 19 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:10966 | completed | 1 | 6.95 | 0.00 | complete / not-produced | — | [result](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/30923fa9-b6d4-4b79-a4c8-90dbff4303ef/result.json) · [文件清单](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/30923fa9-b6d4-4b79-a4c8-90dbff4303ef/files.json) · [轨迹](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/30923fa9-b6d4-4b79-a4c8-90dbff4303ef/agent/trajectory.jsonl) |
| test:11045 | completed | 0 | 9.41 | 0.00 | complete / not-produced | — | [result](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/4dba4b8f-c762-4e70-bd43-8a899ad28e68/result.json) · [文件清单](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/4dba4b8f-c762-4e70-bd43-8a899ad28e68/files.json) · [轨迹](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/4dba4b8f-c762-4e70-bd43-8a899ad28e68/agent/trajectory.jsonl) |
| test:11050 | completed | 1 | 15.52 | 0.00 | complete / not-produced | — | [result](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/1b1b152a-ff36-4802-a083-5540d34a0c0d/result.json) · [文件清单](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/1b1b152a-ff36-4802-a083-5540d34a0c0d/files.json) · [轨迹](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/1b1b152a-ff36-4802-a083-5540d34a0c0d/agent/trajectory.jsonl) |
| test:11060 | completed | 1 | 7.02 | 0.01 | complete / not-produced | — | [result](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/35ce2767-cf32-4ab9-b807-d3102d1c76da/result.json) · [文件清单](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/35ce2767-cf32-4ab9-b807-d3102d1c76da/files.json) · [轨迹](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/35ce2767-cf32-4ab9-b807-d3102d1c76da/agent/trajectory.jsonl) |
| test:11093 | completed | 0 | 25.75 | 0.00 | complete / not-produced | — | [result](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/ecc209eb-1c4c-41b8-8ed9-f603b92057d5/result.json) · [文件清单](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/ecc209eb-1c4c-41b8-8ed9-f603b92057d5/files.json) · [轨迹](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/ecc209eb-1c4c-41b8-8ed9-f603b92057d5/agent/trajectory.jsonl) |
| test:11210 | completed | 1 | 8.66 | 0.00 | complete / not-produced | — | [result](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/b22d4000-708a-436d-9870-c4dd16cb7466/result.json) · [文件清单](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/b22d4000-708a-436d-9870-c4dd16cb7466/files.json) · [轨迹](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/b22d4000-708a-436d-9870-c4dd16cb7466/agent/trajectory.jsonl) |
| test:11354 | completed | 0 | 8.12 | 0.00 | complete / not-produced | — | [result](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/5e4860f4-c316-44e7-b50b-9cdd11ae092e/result.json) · [文件清单](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/5e4860f4-c316-44e7-b50b-9cdd11ae092e/files.json) · [轨迹](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/5e4860f4-c316-44e7-b50b-9cdd11ae092e/agent/trajectory.jsonl) |
| test:11491 | completed | 0 | 26.22 | 0.00 | complete / not-produced | — | [result](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/cfdd4ed6-8b96-4e13-a969-f79cde6af748/result.json) · [文件清单](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/cfdd4ed6-8b96-4e13-a969-f79cde6af748/files.json) · [轨迹](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/cfdd4ed6-8b96-4e13-a969-f79cde6af748/agent/trajectory.jsonl) |
| test:11496 | completed | 0 | 35.31 | 0.00 | complete / not-produced | — | [result](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/1e908b98-5c41-4b7a-990b-ef53a55093b7/result.json) · [文件清单](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/1e908b98-5c41-4b7a-990b-ef53a55093b7/files.json) · [轨迹](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/1e908b98-5c41-4b7a-990b-ef53a55093b7/agent/trajectory.jsonl) |
| test:11506 | completed | 0 | 177.08 | 0.00 | complete / not-produced | — | [result](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/1663fb01-cf2c-4487-a389-7585ec30bf3a/result.json) · [文件清单](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/1663fb01-cf2c-4487-a389-7585ec30bf3a/files.json) · [轨迹](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/1663fb01-cf2c-4487-a389-7585ec30bf3a/agent/trajectory.jsonl) |
| test:11559 | completed | 1 | 9.41 | 0.00 | complete / not-produced | — | [result](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/b6dc8dc7-424a-4a1d-8a07-dedfcd9c1a59/result.json) · [文件清单](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/b6dc8dc7-424a-4a1d-8a07-dedfcd9c1a59/files.json) · [轨迹](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/b6dc8dc7-424a-4a1d-8a07-dedfcd9c1a59/agent/trajectory.jsonl) |
| test:11576 | completed | 0 | 21.51 | 0.00 | complete / not-produced | — | [result](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/9ada32ab-ab4d-4c6a-aff4-a762945c414d/result.json) · [文件清单](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/9ada32ab-ab4d-4c6a-aff4-a762945c414d/files.json) · [轨迹](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/9ada32ab-ab4d-4c6a-aff4-a762945c414d/agent/trajectory.jsonl) |
| test:11629 | completed | 1 | 20.63 | 0.00 | complete / not-produced | — | [result](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/47351780-337f-459b-b4d2-ec809744d6d8/result.json) · [文件清单](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/47351780-337f-459b-b4d2-ec809744d6d8/files.json) · [轨迹](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/47351780-337f-459b-b4d2-ec809744d6d8/agent/trajectory.jsonl) |
| test:11660 | completed | 0 | 163.97 | 0.00 | complete / not-produced | — | [result](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/fd36befe-d2b2-46c3-bb49-18b86149d2ce/result.json) · [文件清单](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/fd36befe-d2b2-46c3-bb49-18b86149d2ce/files.json) · [轨迹](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/fd36befe-d2b2-46c3-bb49-18b86149d2ce/agent/trajectory.jsonl) |
| test:11802 | completed | 1 | 6.13 | 0.00 | complete / not-produced | — | [result](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/3ad7f8f0-837e-4dcd-9225-26e4a50273b6/result.json) · [文件清单](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/3ad7f8f0-837e-4dcd-9225-26e4a50273b6/files.json) · [轨迹](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/3ad7f8f0-837e-4dcd-9225-26e4a50273b6/agent/trajectory.jsonl) |
| test:11808 | completed | 1 | 10.27 | 0.00 | complete / not-produced | — | [result](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/383ea9d6-4244-4774-ac2e-0dc5a3679562/result.json) · [文件清单](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/383ea9d6-4244-4774-ac2e-0dc5a3679562/files.json) · [轨迹](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/383ea9d6-4244-4774-ac2e-0dc5a3679562/agent/trajectory.jsonl) |
| test:11824 | completed | 1 | 5.40 | 0.00 | complete / not-produced | — | [result](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/9a9a3be8-d5f3-4704-bc30-6f0b9951c3fc/result.json) · [文件清单](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/9a9a3be8-d5f3-4704-bc30-6f0b9951c3fc/files.json) · [轨迹](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/9a9a3be8-d5f3-4704-bc30-6f0b9951c3fc/agent/trajectory.jsonl) |
| test:11925 | completed | 1 | 26.63 | 0.00 | complete / not-produced | — | [result](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/75b1aa09-25ea-4f29-b5aa-71846de79db2/result.json) · [文件清单](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/75b1aa09-25ea-4f29-b5aa-71846de79db2/files.json) · [轨迹](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/75b1aa09-25ea-4f29-b5aa-71846de79db2/agent/trajectory.jsonl) |
| test:12002 | completed | 1 | 14.64 | 0.00 | complete / not-produced | — | [result](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/d334c386-0575-4da8-879a-20dd4ea83c8c/result.json) · [文件清单](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/d334c386-0575-4da8-879a-20dd4ea83c8c/files.json) · [轨迹](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/d334c386-0575-4da8-879a-20dd4ea83c8c/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

