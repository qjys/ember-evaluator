<!-- snapshotDigest: ab364a33f3bb63d37123a3580e98acbd51360da28848bada9a8dff3e910c8748 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 16.50%（34/206）**

Run: 69af3204-3abf-4cc2-9ba8-84cb1dccf7b3 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:02:50.344Z / 2026-11-12T07:20:10.231Z |
| 总耗时 | 16 分 45 秒 |
| 答对 / 答错 / 解题超时 | 34 / 8 / 0 |
| 清理未确认 | 1 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 210 题；已保存 46 条记录；待运行 167 题。
有效评分覆盖率：42/210（20.00%）。
执行失败 1；超时 0；取消 3；不支持 0。
Agent 解题超时 0（计 0 分）；无效 4。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 210 |
| 计分题数 | 206 |
| 正常评分题数 | 42 |
| 答对题数 | 34 |
| 无效评测 | 4 |
| 待运行 | 167 |
| 正确率 | 16.50% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 16 分 45 秒 |
| 环境准备耗时 | 17 分 17 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 47 秒 | 3 秒 | 2 分 18 秒 | 46 |
| 任务准备 | 0.57 毫秒 | 0.27 毫秒 | 2.99 毫秒 | 46 |
| 环境启动 | 23 秒 | 3 秒 | 53 秒 | 46 |
| 解题 | 14 秒 | 5 秒 | 1 分 40 秒 | 44 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 43 |
| 资源清理 | 8 秒 | 5 秒 | 15 秒 | 44 |
| 评分 | 0.8 毫秒 | 0.21 毫秒 | 6.8 毫秒 | 42 |
| 证据收集 | 10.6 毫秒 | 2.33 毫秒 | 33.68 毫秒 | 46 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| afde185e-0aec-44d0-aca7-092626fa1613 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 127,574 | 35,421 | 162,995 | 43 / 210 | — |
| 运行累计 | 127,574 | 35,421 | 162,995 | 43 / 46 | 3 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:41 | completed | 1 | 13.88 | 0.00 | complete / not-produced | — | [result](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/4d4f1cba-75a8-40bc-9fa8-79c66ecdb38b/result.json) · [文件清单](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/4d4f1cba-75a8-40bc-9fa8-79c66ecdb38b/files.json) · [轨迹](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/4d4f1cba-75a8-40bc-9fa8-79c66ecdb38b/agent/trajectory.jsonl) |
| test:61 | completed | 0 | 38.63 | 0.00 | complete / not-produced | — | [result](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/e0d36160-5d6c-459b-aa96-db46329bbe57/result.json) · [文件清单](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/e0d36160-5d6c-459b-aa96-db46329bbe57/files.json) · [轨迹](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/e0d36160-5d6c-459b-aa96-db46329bbe57/agent/trajectory.jsonl) |
| test:97 | completed | 1 | 27.48 | 0.00 | complete / not-produced | — | [result](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/e3abc5d2-967a-4b11-9632-089d43429d8a/result.json) · [文件清单](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/e3abc5d2-967a-4b11-9632-089d43429d8a/files.json) · [轨迹](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/e3abc5d2-967a-4b11-9632-089d43429d8a/agent/trajectory.jsonl) |
| test:209 | completed | 1 | 15.06 | 0.00 | complete / not-produced | — | [result](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/ee9af1a6-032d-4a6c-96b4-a4679dfe5505/result.json) · [文件清单](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/ee9af1a6-032d-4a6c-96b4-a4679dfe5505/files.json) · [轨迹](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/ee9af1a6-032d-4a6c-96b4-a4679dfe5505/agent/trajectory.jsonl) |
| test:286 | completed | 1 | 8.57 | 0.00 | complete / not-produced | — | [result](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/e9ae7ebf-9cf4-4994-87b2-35aca9e29572/result.json) · [文件清单](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/e9ae7ebf-9cf4-4994-87b2-35aca9e29572/files.json) · [轨迹](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/e9ae7ebf-9cf4-4994-87b2-35aca9e29572/agent/trajectory.jsonl) |
| test:299 | completed | 1 | 10.72 | 0.00 | complete / not-produced | — | [result](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/548b153a-1dcb-4a38-a363-c1e33e29d8ba/result.json) · [文件清单](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/548b153a-1dcb-4a38-a363-c1e33e29d8ba/files.json) · [轨迹](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/548b153a-1dcb-4a38-a363-c1e33e29d8ba/agent/trajectory.jsonl) |
| test:311 | completed | 1 | 13.58 | 0.00 | complete / not-produced | — | [result](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/283e4d1b-c029-4e7d-bd45-73c4672ecb5c/result.json) · [文件清单](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/283e4d1b-c029-4e7d-bd45-73c4672ecb5c/files.json) · [轨迹](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/283e4d1b-c029-4e7d-bd45-73c4672ecb5c/agent/trajectory.jsonl) |
| test:352 | completed | 1 | 6.63 | 0.00 | complete / not-produced | — | [result](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/88b79d63-35a4-498c-ad39-7480dc622f62/result.json) · [文件清单](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/88b79d63-35a4-498c-ad39-7480dc622f62/files.json) · [轨迹](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/88b79d63-35a4-498c-ad39-7480dc622f62/agent/trajectory.jsonl) |
| test:355 | completed | 1 | 7.12 | 0.00 | complete / not-produced | — | [result](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/399be7c6-2947-4494-badd-974ea5453be2/result.json) · [文件清单](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/399be7c6-2947-4494-badd-974ea5453be2/files.json) · [轨迹](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/399be7c6-2947-4494-badd-974ea5453be2/agent/trajectory.jsonl) |
| test:476 | completed | 1 | 10.75 | 0.00 | complete / not-produced | — | [result](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/80f165ad-8129-40c4-88a0-8899ea014611/result.json) · [文件清单](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/80f165ad-8129-40c4-88a0-8899ea014611/files.json) · [轨迹](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/80f165ad-8129-40c4-88a0-8899ea014611/agent/trajectory.jsonl) |
| test:511 | completed | 1 | 9.10 | 0.01 | complete / not-produced | — | [result](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/497bc604-7784-4cc0-b2d9-a3610a658f16/result.json) · [文件清单](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/497bc604-7784-4cc0-b2d9-a3610a658f16/files.json) · [轨迹](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/497bc604-7784-4cc0-b2d9-a3610a658f16/agent/trajectory.jsonl) |
| test:552 | completed | 1 | 6.95 | 0.00 | complete / not-produced | — | [result](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/8ee30e96-0eff-42b1-b7d5-7146d5be7149/result.json) · [文件清单](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/8ee30e96-0eff-42b1-b7d5-7146d5be7149/files.json) · [轨迹](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/8ee30e96-0eff-42b1-b7d5-7146d5be7149/agent/trajectory.jsonl) |
| test:624 | completed | 1 | 12.80 | 0.00 | complete / not-produced | — | [result](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/09f58e0d-5caa-42d9-838b-04b909861544/result.json) · [文件清单](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/09f58e0d-5caa-42d9-838b-04b909861544/files.json) · [轨迹](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/09f58e0d-5caa-42d9-838b-04b909861544/agent/trajectory.jsonl) |
| test:669 | completed | 1 | 14.30 | 0.00 | complete / not-produced | — | [result](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/ce2a3e35-6433-4963-a96a-265e710746b3/result.json) · [文件清单](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/ce2a3e35-6433-4963-a96a-265e710746b3/files.json) · [轨迹](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/ce2a3e35-6433-4963-a96a-265e710746b3/agent/trajectory.jsonl) |
| test:670 | completed | 1 | 13.71 | 0.00 | complete / not-produced | — | [result](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/edf38689-a163-42a6-b720-e9a4cc1c5891/result.json) · [文件清单](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/edf38689-a163-42a6-b720-e9a4cc1c5891/files.json) · [轨迹](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/edf38689-a163-42a6-b720-e9a4cc1c5891/agent/trajectory.jsonl) |
| test:796 | completed | 1 | 9.60 | 0.00 | complete / not-produced | — | [result](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/1e8ac777-2a61-472b-9a0f-9451735dc4f8/result.json) · [文件清单](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/1e8ac777-2a61-472b-9a0f-9451735dc4f8/files.json) · [轨迹](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/1e8ac777-2a61-472b-9a0f-9451735dc4f8/agent/trajectory.jsonl) |
| test:828 | completed | 1 | 15.89 | 0.00 | complete / not-produced | — | [result](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/801938cb-1f0d-489b-962d-36e380de833c/result.json) · [文件清单](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/801938cb-1f0d-489b-962d-36e380de833c/files.json) · [轨迹](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/801938cb-1f0d-489b-962d-36e380de833c/agent/trajectory.jsonl) |
| test:841 | completed | 1 | 20.93 | 0.00 | complete / not-produced | — | [result](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/01e1d0af-ce23-4e06-bf09-d2455009f1b6/result.json) · [文件清单](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/01e1d0af-ce23-4e06-bf09-d2455009f1b6/files.json) · [轨迹](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/01e1d0af-ce23-4e06-bf09-d2455009f1b6/agent/trajectory.jsonl) |
| test:883 | completed | 1 | 9.46 | 0.00 | complete / not-produced | — | [result](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/89910839-ea12-4743-bbb7-a59a89abe37d/result.json) · [文件清单](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/89910839-ea12-4743-bbb7-a59a89abe37d/files.json) · [轨迹](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/89910839-ea12-4743-bbb7-a59a89abe37d/agent/trajectory.jsonl) |
| test:938 | completed | 1 | 20.62 | 0.00 | complete / not-produced | — | [result](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/37164a3f-d11e-4acf-8137-a7ad22d4b35d/result.json) · [文件清单](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/37164a3f-d11e-4acf-8137-a7ad22d4b35d/files.json) · [轨迹](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/37164a3f-d11e-4acf-8137-a7ad22d4b35d/agent/trajectory.jsonl) |
| test:1026 | completed | 0 | 15.42 | 0.00 | complete / not-produced | — | [result](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/d945a3f7-2144-4b27-a0ac-246e1f33dfc7/result.json) · [文件清单](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/d945a3f7-2144-4b27-a0ac-246e1f33dfc7/files.json) · [轨迹](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/d945a3f7-2144-4b27-a0ac-246e1f33dfc7/agent/trajectory.jsonl) |
| test:1229 | completed | 1 | 12.77 | 0.00 | complete / not-produced | — | [result](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/cd5dde95-8957-42ec-b2b9-7c92870fa968/result.json) · [文件清单](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/cd5dde95-8957-42ec-b2b9-7c92870fa968/files.json) · [轨迹](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/cd5dde95-8957-42ec-b2b9-7c92870fa968/agent/trajectory.jsonl) |
| test:1252 | completed | 1 | 7.71 | 0.00 | complete / not-produced | — | [result](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/547287d7-0f21-44dd-bed5-e0a8dba2103a/result.json) · [文件清单](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/547287d7-0f21-44dd-bed5-e0a8dba2103a/files.json) · [轨迹](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/547287d7-0f21-44dd-bed5-e0a8dba2103a/agent/trajectory.jsonl) |
| test:1399 | completed | 0 | 9.82 | 0.00 | complete / not-produced | — | [result](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/c3b3b6b7-2dfe-4b05-9303-72afccb7bbfd/result.json) · [文件清单](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/c3b3b6b7-2dfe-4b05-9303-72afccb7bbfd/files.json) · [轨迹](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/c3b3b6b7-2dfe-4b05-9303-72afccb7bbfd/agent/trajectory.jsonl) |
| test:1454 | completed | 1 | 36.89 | 0.00 | complete / not-produced | — | [result](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/023b1bc8-65d3-4410-8cd1-78623c1eebc6/result.json) · [文件清单](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/023b1bc8-65d3-4410-8cd1-78623c1eebc6/files.json) · [轨迹](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/023b1bc8-65d3-4410-8cd1-78623c1eebc6/agent/trajectory.jsonl) |
| test:1514 | completed | 0 | 99.53 | 0.00 | complete / not-produced | — | [result](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/cbabee54-df8e-49eb-a7af-b35c30def99a/result.json) · [文件清单](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/cbabee54-df8e-49eb-a7af-b35c30def99a/files.json) · [轨迹](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/cbabee54-df8e-49eb-a7af-b35c30def99a/agent/trajectory.jsonl) |
| test:1531 | completed | 0 | 13.17 | 0.00 | complete / not-produced | — | [result](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/a25c7599-0457-4a58-ab6b-9212019c04d0/result.json) · [文件清单](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/a25c7599-0457-4a58-ab6b-9212019c04d0/files.json) · [轨迹](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/a25c7599-0457-4a58-ab6b-9212019c04d0/agent/trajectory.jsonl) |
| test:1785 | completed | 0 | 18.77 | 0.00 | complete / not-produced | — | [result](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/e2208816-5946-4674-828e-5020ad72b273/result.json) · [文件清单](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/e2208816-5946-4674-828e-5020ad72b273/files.json) · [轨迹](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/e2208816-5946-4674-828e-5020ad72b273/agent/trajectory.jsonl) |
| test:1806 | completed | 0 | 11.13 | 0.00 | complete / not-produced | — | [result](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/afb4cce5-f1e3-4a31-9fde-db5a17d7dd62/result.json) · [文件清单](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/afb4cce5-f1e3-4a31-9fde-db5a17d7dd62/files.json) · [轨迹](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/afb4cce5-f1e3-4a31-9fde-db5a17d7dd62/agent/trajectory.jsonl) |
| test:1827 | completed | 1 | 11.95 | 0.00 | complete / not-produced | — | [result](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/11745d9d-0027-44ae-8408-fe96644c651d/result.json) · [文件清单](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/11745d9d-0027-44ae-8408-fe96644c651d/files.json) · [轨迹](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/11745d9d-0027-44ae-8408-fe96644c651d/agent/trajectory.jsonl) |
| test:1904 | completed | 1 | 6.64 | 0.00 | complete / not-produced | — | [result](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/875ff42e-6b19-46e9-9f9e-de44d7b72940/result.json) · [文件清单](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/875ff42e-6b19-46e9-9f9e-de44d7b72940/files.json) · [轨迹](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/875ff42e-6b19-46e9-9f9e-de44d7b72940/agent/trajectory.jsonl) |
| test:1943 | completed | 1 | 6.44 | 0.00 | complete / not-produced | — | [result](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/fad75d5e-c10e-442d-9cbd-bdf9030464e3/result.json) · [文件清单](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/fad75d5e-c10e-442d-9cbd-bdf9030464e3/files.json) · [轨迹](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/fad75d5e-c10e-442d-9cbd-bdf9030464e3/agent/trajectory.jsonl) |
| test:1998 | completed | 1 | 7.98 | 0.00 | complete / not-produced | — | [result](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/167cafa2-4ca9-4d9b-a133-baad9173b8dd/result.json) · [文件清单](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/167cafa2-4ca9-4d9b-a133-baad9173b8dd/files.json) · [轨迹](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/167cafa2-4ca9-4d9b-a133-baad9173b8dd/agent/trajectory.jsonl) |
| test:2023 | completed | 1 | 6.34 | 0.00 | complete / not-produced | — | [result](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/202cfbe6-79a2-44ca-99dc-71335f4c7315/result.json) · [文件清单](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/202cfbe6-79a2-44ca-99dc-71335f4c7315/files.json) · [轨迹](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/202cfbe6-79a2-44ca-99dc-71335f4c7315/agent/trajectory.jsonl) |
| test:2096 | completed | 0 | 8.26 | 0.00 | complete / not-produced | — | [result](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/7c54a1c8-4db7-400a-89d1-914f8f4a67c4/result.json) · [文件清单](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/7c54a1c8-4db7-400a-89d1-914f8f4a67c4/files.json) · [轨迹](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/7c54a1c8-4db7-400a-89d1-914f8f4a67c4/agent/trajectory.jsonl) |
| test:2152 | completed | 1 | 7.30 | 0.00 | complete / not-produced | — | [result](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/8e4ca134-a20e-4ff8-a27f-e71652a2b83d/result.json) · [文件清单](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/8e4ca134-a20e-4ff8-a27f-e71652a2b83d/files.json) · [轨迹](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/8e4ca134-a20e-4ff8-a27f-e71652a2b83d/agent/trajectory.jsonl) |
| test:2175 | completed | 1 | 10.83 | 0.00 | complete / not-produced | — | [result](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/a4ee5b8f-0728-4ce0-b880-d1a820b22843/result.json) · [文件清单](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/a4ee5b8f-0728-4ce0-b880-d1a820b22843/files.json) · [轨迹](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/a4ee5b8f-0728-4ce0-b880-d1a820b22843/agent/trajectory.jsonl) |
| test:2177 | completed | 1 | 6.21 | 0.00 | complete / not-produced | — | [result](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/6474b2cc-6a1e-4d50-8c14-9e4b2b454dd9/result.json) · [文件清单](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/6474b2cc-6a1e-4d50-8c14-9e4b2b454dd9/files.json) · [轨迹](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/6474b2cc-6a1e-4d50-8c14-9e4b2b454dd9/agent/trajectory.jsonl) |
| test:2206 | completed | 1 | 6.49 | 0.00 | complete / not-produced | — | [result](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/776dd82a-6c86-49b3-be35-089a528ba999/result.json) · [文件清单](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/776dd82a-6c86-49b3-be35-089a528ba999/files.json) · [轨迹](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/776dd82a-6c86-49b3-be35-089a528ba999/agent/trajectory.jsonl) |
| test:2280 | completed | 1 | 5.76 | 0.00 | complete / not-produced | — | [result](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/5fb351ba-0540-4495-a25c-a81a48ab10f7/result.json) · [文件清单](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/5fb351ba-0540-4495-a25c-a81a48ab10f7/files.json) · [轨迹](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/5fb351ba-0540-4495-a25c-a81a48ab10f7/agent/trajectory.jsonl) |
| test:2347 | completed | 1 | 11.87 | 0.00 | complete / not-produced | — | [result](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/e14e0c46-c53b-4e3e-ae82-aaa455effcf6/result.json) · [文件清单](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/e14e0c46-c53b-4e3e-ae82-aaa455effcf6/files.json) · [轨迹](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/e14e0c46-c53b-4e3e-ae82-aaa455effcf6/agent/trajectory.jsonl) |
| test:2400 | completed | 1 | 9.20 | 0.00 | complete / not-produced | — | [result](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/5b8baf68-0895-4fb0-b455-e4b71a224957/result.json) · [文件清单](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/5b8baf68-0895-4fb0-b455-e4b71a224957/files.json) · [轨迹](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/5b8baf68-0895-4fb0-b455-e4b71a224957/agent/trajectory.jsonl) |
| test:2527 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/0c7555b0-669b-4575-9d62-d7ba05887d27/result.json) · [文件清单](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/0c7555b0-669b-4575-9d62-d7ba05887d27/files.json) |
| test:2636 | cancelled | — | 5.02 | — | partial / not-produced | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/00937c17-15d7-413a-a59d-2e687b538863/result.json) · [文件清单](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/00937c17-15d7-413a-a59d-2e687b538863/files.json) · [轨迹](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/00937c17-15d7-413a-a59d-2e687b538863/agent/trajectory.jsonl) |
| test:2641 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/4858e58d-023e-4d89-b3f7-5c78b3711765/result.json) · [文件清单](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/4858e58d-023e-4d89-b3f7-5c78b3711765/files.json) |
| test:2714 | invalid | — | 9.57 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/2eac2941-1633-4327-8686-e5e0b7416e01/result.json) · [文件清单](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/2eac2941-1633-4327-8686-e5e0b7416e01/files.json) · [轨迹](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/2eac2941-1633-4327-8686-e5e0b7416e01/agent/trajectory.jsonl) |
| test:2716 | pending | — | — | — | — | — | — |
| test:2747 | pending | — | — | — | — | — | — |
| test:2882 | pending | — | — | — | — | — | — |
| test:2951 | pending | — | — | — | — | — | — |
| test:3037 | pending | — | — | — | — | — | — |
| test:3053 | pending | — | — | — | — | — | — |
| test:3136 | pending | — | — | — | — | — | — |
| test:3165 | pending | — | — | — | — | — | — |
| test:3196 | pending | — | — | — | — | — | — |
| test:3231 | pending | — | — | — | — | — | — |
| test:3236 | pending | — | — | — | — | — | — |
| test:3270 | pending | — | — | — | — | — | — |
| test:3293 | pending | — | — | — | — | — | — |
| test:3331 | pending | — | — | — | — | — | — |
| test:3488 | pending | — | — | — | — | — | — |
| test:3491 | pending | — | — | — | — | — | — |
| test:3552 | pending | — | — | — | — | — | — |
| test:3599 | pending | — | — | — | — | — | — |
| test:3626 | pending | — | — | — | — | — | — |
| test:4021 | pending | — | — | — | — | — | — |
| test:4034 | pending | — | — | — | — | — | — |
| test:4058 | pending | — | — | — | — | — | — |
| test:4075 | pending | — | — | — | — | — | — |
| test:4142 | pending | — | — | — | — | — | — |
| test:4208 | pending | — | — | — | — | — | — |
| test:4298 | pending | — | — | — | — | — | — |
| test:4337 | pending | — | — | — | — | — | — |
| test:4376 | pending | — | — | — | — | — | — |
| test:4405 | pending | — | — | — | — | — | — |
| test:4552 | pending | — | — | — | — | — | — |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 4；错误记录 6（主流程 3；证据收集 1；资源清理 2）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| environment | RUN_CANCELLED | 2 | 2 |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |
| cleanup | CLEANUP_FAILED | 1 | 2 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

