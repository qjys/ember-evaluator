<!-- snapshotDigest: 24ff86239fab2e0da85d05d9b9cb7adb5311757494774c8c546c13d41a766043 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 87.50%（21/24）**

Run: b7d4a8eb-35f7-458d-abb1-15eb617e7718 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T11:29:01.211Z / 2026-11-12T11:32:09.888Z |
| 总耗时 | 3 分 2 秒 |
| 答对 / 答错 / 解题超时 | 21 / 3 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 21 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 87.50% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 3 分 2 秒 |
| 环境准备耗时 | 2 分 14 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 27 秒 | 15 秒 | 1 分 48 秒 | 24 |
| 任务准备 | 0.38 毫秒 | 0.17 毫秒 | 0.84 毫秒 | 24 |
| 环境启动 | 10 秒 | 5 秒 | 14 秒 | 24 |
| 解题 | 10 秒 | 6 秒 | 1 分 29 秒 | 24 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 24 |
| 资源清理 | 5 秒 | 3 秒 | 7 秒 | 24 |
| 评分 | 0.71 毫秒 | 0.22 毫秒 | 3.22 毫秒 | 24 |
| 证据收集 | 10.05 毫秒 | 4.28 毫秒 | 23.2 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| a3b6fda4-f2aa-462f-b325-8e4a949bffa3 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 241,868 | 18,274 | 260,142 | 24 / 24 | — |
| 运行累计 | 241,868 | 18,274 | 260,142 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:1454 | completed | 1 | 13.41 | 0.00 | complete / not-produced | — | [result](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/c64134f2-2516-41d3-b5b6-39d10e3f9f0d/result.json) · [文件清单](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/c64134f2-2516-41d3-b5b6-39d10e3f9f0d/files.json) · [轨迹](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/c64134f2-2516-41d3-b5b6-39d10e3f9f0d/agent/trajectory.jsonl) |
| test:1514 | completed | 0 | 89.16 | 0.00 | complete / not-produced | — | [result](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/4e23a79b-4fd9-485a-b2a7-26e8a88c1341/result.json) · [文件清单](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/4e23a79b-4fd9-485a-b2a7-26e8a88c1341/files.json) · [轨迹](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/4e23a79b-4fd9-485a-b2a7-26e8a88c1341/agent/trajectory.jsonl) |
| test:1531 | completed | 1 | 7.89 | 0.00 | complete / not-produced | — | [result](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/dfd79f21-18ac-43ac-85d6-fc8a748d8f56/result.json) · [文件清单](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/dfd79f21-18ac-43ac-85d6-fc8a748d8f56/files.json) · [轨迹](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/dfd79f21-18ac-43ac-85d6-fc8a748d8f56/agent/trajectory.jsonl) |
| test:1785 | completed | 1 | 6.53 | 0.00 | complete / not-produced | — | [result](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/ae7cd92a-07bb-4a8d-be57-9f0b0c3eaa01/result.json) · [文件清单](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/ae7cd92a-07bb-4a8d-be57-9f0b0c3eaa01/files.json) · [轨迹](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/ae7cd92a-07bb-4a8d-be57-9f0b0c3eaa01/agent/trajectory.jsonl) |
| test:1806 | completed | 0 | 15.04 | 0.00 | complete / not-produced | — | [result](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/2a5b0c87-f3af-4c30-9441-ff2f222c77d8/result.json) · [文件清单](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/2a5b0c87-f3af-4c30-9441-ff2f222c77d8/files.json) · [轨迹](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/2a5b0c87-f3af-4c30-9441-ff2f222c77d8/agent/trajectory.jsonl) |
| test:1827 | completed | 1 | 6.81 | 0.00 | complete / not-produced | — | [result](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/4603d3b6-437a-49e2-bf0e-869a52fbee8f/result.json) · [文件清单](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/4603d3b6-437a-49e2-bf0e-869a52fbee8f/files.json) · [轨迹](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/4603d3b6-437a-49e2-bf0e-869a52fbee8f/agent/trajectory.jsonl) |
| test:1904 | completed | 1 | 6.43 | 0.00 | complete / not-produced | — | [result](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/8e0cb02e-a2e3-4c91-9c66-7b5c24939719/result.json) · [文件清单](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/8e0cb02e-a2e3-4c91-9c66-7b5c24939719/files.json) · [轨迹](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/8e0cb02e-a2e3-4c91-9c66-7b5c24939719/agent/trajectory.jsonl) |
| test:1943 | completed | 1 | 6.28 | 0.00 | complete / not-produced | — | [result](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/b13a7cc3-cd79-4f65-80ff-6f12b4a06aa2/result.json) · [文件清单](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/b13a7cc3-cd79-4f65-80ff-6f12b4a06aa2/files.json) · [轨迹](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/b13a7cc3-cd79-4f65-80ff-6f12b4a06aa2/agent/trajectory.jsonl) |
| test:1998 | completed | 1 | 6.09 | 0.00 | complete / not-produced | — | [result](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/8e30138b-cde5-4984-a899-59147693eae9/result.json) · [文件清单](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/8e30138b-cde5-4984-a899-59147693eae9/files.json) · [轨迹](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/8e30138b-cde5-4984-a899-59147693eae9/agent/trajectory.jsonl) |
| test:2023 | completed | 1 | 6.30 | 0.00 | complete / not-produced | — | [result](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/d3f86b71-6065-4bfe-a9e4-fa7abecb242e/result.json) · [文件清单](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/d3f86b71-6065-4bfe-a9e4-fa7abecb242e/files.json) · [轨迹](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/d3f86b71-6065-4bfe-a9e4-fa7abecb242e/agent/trajectory.jsonl) |
| test:2096 | completed | 0 | 6.72 | 0.00 | complete / not-produced | — | [result](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/3c066286-4448-42e1-99dc-c2888a1e1d98/result.json) · [文件清单](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/3c066286-4448-42e1-99dc-c2888a1e1d98/files.json) · [轨迹](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/3c066286-4448-42e1-99dc-c2888a1e1d98/agent/trajectory.jsonl) |
| test:2152 | completed | 1 | 6.06 | 0.00 | complete / not-produced | — | [result](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/424e6052-7b11-4d37-a535-cddde53e1f81/result.json) · [文件清单](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/424e6052-7b11-4d37-a535-cddde53e1f81/files.json) · [轨迹](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/424e6052-7b11-4d37-a535-cddde53e1f81/agent/trajectory.jsonl) |
| test:2175 | completed | 1 | 6.26 | 0.00 | complete / not-produced | — | [result](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/87cfc3d7-5531-4fae-8d5f-566a4d3c7594/result.json) · [文件清单](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/87cfc3d7-5531-4fae-8d5f-566a4d3c7594/files.json) · [轨迹](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/87cfc3d7-5531-4fae-8d5f-566a4d3c7594/agent/trajectory.jsonl) |
| test:2177 | completed | 1 | 6.49 | 0.00 | complete / not-produced | — | [result](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/af2e9cf0-c562-48a1-a2d9-128efb967d31/result.json) · [文件清单](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/af2e9cf0-c562-48a1-a2d9-128efb967d31/files.json) · [轨迹](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/af2e9cf0-c562-48a1-a2d9-128efb967d31/agent/trajectory.jsonl) |
| test:2206 | completed | 1 | 6.47 | 0.00 | complete / not-produced | — | [result](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/0df22f89-aa19-4587-9acd-1634ca1fdaa1/result.json) · [文件清单](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/0df22f89-aa19-4587-9acd-1634ca1fdaa1/files.json) · [轨迹](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/0df22f89-aa19-4587-9acd-1634ca1fdaa1/agent/trajectory.jsonl) |
| test:2280 | completed | 1 | 6.22 | 0.00 | complete / not-produced | — | [result](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/e8b92f2d-d5f1-47ff-b0dc-aef2f770cb9b/result.json) · [文件清单](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/e8b92f2d-d5f1-47ff-b0dc-aef2f770cb9b/files.json) · [轨迹](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/e8b92f2d-d5f1-47ff-b0dc-aef2f770cb9b/agent/trajectory.jsonl) |
| test:2347 | completed | 1 | 6.26 | 0.00 | complete / not-produced | — | [result](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/8db169cf-acfb-42bd-808d-cc9c0ddb4771/result.json) · [文件清单](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/8db169cf-acfb-42bd-808d-cc9c0ddb4771/files.json) · [轨迹](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/8db169cf-acfb-42bd-808d-cc9c0ddb4771/agent/trajectory.jsonl) |
| test:2400 | completed | 1 | 6.14 | 0.00 | complete / not-produced | — | [result](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/6df7ae6c-29f0-42fe-9499-0f176fd37ef9/result.json) · [文件清单](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/6df7ae6c-29f0-42fe-9499-0f176fd37ef9/files.json) · [轨迹](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/6df7ae6c-29f0-42fe-9499-0f176fd37ef9/agent/trajectory.jsonl) |
| test:2527 | completed | 1 | 6.14 | 0.00 | complete / not-produced | — | [result](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/86c9852c-ac83-42e2-abce-154ef1c15061/result.json) · [文件清单](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/86c9852c-ac83-42e2-abce-154ef1c15061/files.json) · [轨迹](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/86c9852c-ac83-42e2-abce-154ef1c15061/agent/trajectory.jsonl) |
| test:2636 | completed | 1 | 6.27 | 0.00 | complete / not-produced | — | [result](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/d9d12d74-bffc-436c-b3f6-4a2dfd029a11/result.json) · [文件清单](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/d9d12d74-bffc-436c-b3f6-4a2dfd029a11/files.json) · [轨迹](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/d9d12d74-bffc-436c-b3f6-4a2dfd029a11/agent/trajectory.jsonl) |
| test:2641 | completed | 1 | 6.00 | 0.00 | complete / not-produced | — | [result](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/832ea253-efe8-47ad-acad-8ceebf2fdd6c/result.json) · [文件清单](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/832ea253-efe8-47ad-acad-8ceebf2fdd6c/files.json) · [轨迹](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/832ea253-efe8-47ad-acad-8ceebf2fdd6c/agent/trajectory.jsonl) |
| test:2714 | completed | 1 | 6.00 | 0.00 | complete / not-produced | — | [result](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/b5ec9241-b8f9-40c5-99db-36f1178fb57a/result.json) · [文件清单](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/b5ec9241-b8f9-40c5-99db-36f1178fb57a/files.json) · [轨迹](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/b5ec9241-b8f9-40c5-99db-36f1178fb57a/agent/trajectory.jsonl) |
| test:2716 | completed | 1 | 6.41 | 0.00 | complete / not-produced | — | [result](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/d4b4bf81-8303-4c4c-9856-6b4d76f1848a/result.json) · [文件清单](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/d4b4bf81-8303-4c4c-9856-6b4d76f1848a/files.json) · [轨迹](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/d4b4bf81-8303-4c4c-9856-6b4d76f1848a/agent/trajectory.jsonl) |
| test:2747 | completed | 1 | 5.80 | 0.00 | complete / not-produced | — | [result](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/49a6d11e-93e0-41a0-9abc-2fe6e0da4e77/result.json) · [文件清单](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/49a6d11e-93e0-41a0-9abc-2fe6e0da4e77/files.json) · [轨迹](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/49a6d11e-93e0-41a0-9abc-2fe6e0da4e77/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

