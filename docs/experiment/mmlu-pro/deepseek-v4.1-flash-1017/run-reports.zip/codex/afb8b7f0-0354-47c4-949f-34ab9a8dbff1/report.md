<!-- snapshotDigest: 5a202da5e80f32b879b9043d49deee4bc7f584cdce8d1b1547f8c41b8c6d326a -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: afb8b7f0-0354-47c4-949f-34ab9a8dbff1 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T11:35:23.378Z / 2026-11-12T11:38:48.258Z |
| 总耗时 | 3 分 18 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 3 分 18 秒 |
| 环境准备耗时 | 1 分 49 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 26 秒 | 16 秒 | 1 分 13 秒 | 24 |
| 任务准备 | 0.39 毫秒 | 0.18 毫秒 | 1.24 毫秒 | 24 |
| 环境启动 | 10 秒 | 5 秒 | 13 秒 | 24 |
| 解题 | 9 秒 | 6 秒 | 1 分 6 秒 | 24 |
| 产物传输 | 2 秒 | 782.02 毫秒 | 3 秒 | 24 |
| 资源清理 | 5 秒 | 2 秒 | 6 秒 | 24 |
| 评分 | 0.48 毫秒 | 0.14 毫秒 | 1.8 毫秒 | 24 |
| 证据收集 | 9.34 毫秒 | 2.64 毫秒 | 46.26 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 5b18b0c0-c4fb-4709-b9e7-851b533f7e6e | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 237,233 | 15,168 | 252,401 | 24 / 24 | — |
| 运行累计 | 237,233 | 15,168 | 252,401 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:10318 | completed | 1 | 6.29 | 0.00 | complete / not-produced | — | [result](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/76e53da6-08a7-4559-b5f8-ca213d659b14/result.json) · [文件清单](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/76e53da6-08a7-4559-b5f8-ca213d659b14/files.json) · [轨迹](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/76e53da6-08a7-4559-b5f8-ca213d659b14/agent/trajectory.jsonl) |
| test:10362 | completed | 1 | 6.16 | 0.00 | complete / not-produced | — | [result](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/7af643ef-1cd9-44fe-be0f-0ba9e1323eb9/result.json) · [文件清单](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/7af643ef-1cd9-44fe-be0f-0ba9e1323eb9/files.json) · [轨迹](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/7af643ef-1cd9-44fe-be0f-0ba9e1323eb9/agent/trajectory.jsonl) |
| test:10396 | completed | 1 | 6.29 | 0.00 | complete / not-produced | — | [result](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/ff9c3bdf-1483-47b5-be14-fc0b178743cb/result.json) · [文件清单](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/ff9c3bdf-1483-47b5-be14-fc0b178743cb/files.json) · [轨迹](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/ff9c3bdf-1483-47b5-be14-fc0b178743cb/agent/trajectory.jsonl) |
| test:10401 | completed | 1 | 6.36 | 0.00 | complete / not-produced | — | [result](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/0d0f98ce-341f-4751-b18a-503230435c8e/result.json) · [文件清单](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/0d0f98ce-341f-4751-b18a-503230435c8e/files.json) · [轨迹](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/0d0f98ce-341f-4751-b18a-503230435c8e/agent/trajectory.jsonl) |
| test:10403 | completed | 1 | 6.32 | 0.00 | complete / not-produced | — | [result](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/9e0669eb-236b-4cc9-8077-b3802c32159b/result.json) · [文件清单](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/9e0669eb-236b-4cc9-8077-b3802c32159b/files.json) · [轨迹](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/9e0669eb-236b-4cc9-8077-b3802c32159b/agent/trajectory.jsonl) |
| test:10412 | completed | 1 | 6.27 | 0.00 | complete / not-produced | — | [result](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/d4cafa3f-ae61-4abc-8aa1-fc429b4cc8b4/result.json) · [文件清单](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/d4cafa3f-ae61-4abc-8aa1-fc429b4cc8b4/files.json) · [轨迹](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/d4cafa3f-ae61-4abc-8aa1-fc429b4cc8b4/agent/trajectory.jsonl) |
| test:10421 | completed | 1 | 19.21 | 0.00 | complete / not-produced | — | [result](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/c9cb67c4-84a8-4947-9847-15c08795c898/result.json) · [文件清单](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/c9cb67c4-84a8-4947-9847-15c08795c898/files.json) · [轨迹](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/c9cb67c4-84a8-4947-9847-15c08795c898/agent/trajectory.jsonl) |
| test:10424 | completed | 1 | 6.11 | 0.00 | complete / not-produced | — | [result](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/756214f0-8a3b-476a-82f4-7c7e549f5af2/result.json) · [文件清单](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/756214f0-8a3b-476a-82f4-7c7e549f5af2/files.json) · [轨迹](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/756214f0-8a3b-476a-82f4-7c7e549f5af2/agent/trajectory.jsonl) |
| test:10471 | completed | 1 | 6.45 | 0.00 | complete / not-produced | — | [result](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/664c224f-6400-42cd-9a92-fbcbb2148197/result.json) · [文件清单](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/664c224f-6400-42cd-9a92-fbcbb2148197/files.json) · [轨迹](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/664c224f-6400-42cd-9a92-fbcbb2148197/agent/trajectory.jsonl) |
| test:10479 | completed | 1 | 5.98 | 0.00 | complete / not-produced | — | [result](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/d8b9f41c-7fc3-4bfb-8f44-431d7f4f7efd/result.json) · [文件清单](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/d8b9f41c-7fc3-4bfb-8f44-431d7f4f7efd/files.json) · [轨迹](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/d8b9f41c-7fc3-4bfb-8f44-431d7f4f7efd/agent/trajectory.jsonl) |
| test:10524 | completed | 1 | 6.11 | 0.00 | complete / not-produced | — | [result](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/46091706-66f2-4b9a-8ac9-1a9ddbf382e2/result.json) · [文件清单](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/46091706-66f2-4b9a-8ac9-1a9ddbf382e2/files.json) · [轨迹](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/46091706-66f2-4b9a-8ac9-1a9ddbf382e2/agent/trajectory.jsonl) |
| test:10607 | completed | 1 | 6.06 | 0.00 | complete / not-produced | — | [result](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/abb0bcf8-7226-4532-8f04-456102d2a5c3/result.json) · [文件清单](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/abb0bcf8-7226-4532-8f04-456102d2a5c3/files.json) · [轨迹](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/abb0bcf8-7226-4532-8f04-456102d2a5c3/agent/trajectory.jsonl) |
| test:10656 | completed | 1 | 6.31 | 0.00 | complete / not-produced | — | [result](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/1693968d-f632-41b7-b3ce-b503d2df4852/result.json) · [文件清单](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/1693968d-f632-41b7-b3ce-b503d2df4852/files.json) · [轨迹](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/1693968d-f632-41b7-b3ce-b503d2df4852/agent/trajectory.jsonl) |
| test:10674 | completed | 1 | 6.06 | 0.00 | complete / not-produced | — | [result](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/26a3b3b7-fd10-44d9-bebe-69d6a99b5fce/result.json) · [文件清单](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/26a3b3b7-fd10-44d9-bebe-69d6a99b5fce/files.json) · [轨迹](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/26a3b3b7-fd10-44d9-bebe-69d6a99b5fce/agent/trajectory.jsonl) |
| test:10683 | completed | 1 | 6.04 | 0.00 | complete / not-produced | — | [result](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/3067d0d0-8767-47c9-b494-0ab80b324d11/result.json) · [文件清单](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/3067d0d0-8767-47c9-b494-0ab80b324d11/files.json) · [轨迹](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/3067d0d0-8767-47c9-b494-0ab80b324d11/agent/trajectory.jsonl) |
| test:10690 | completed | 1 | 6.03 | 0.00 | complete / not-produced | — | [result](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/0789bf70-709a-4c22-90f8-22663df5e833/result.json) · [文件清单](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/0789bf70-709a-4c22-90f8-22663df5e833/files.json) · [轨迹](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/0789bf70-709a-4c22-90f8-22663df5e833/agent/trajectory.jsonl) |
| test:10765 | completed | 1 | 5.91 | 0.00 | complete / not-produced | — | [result](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/6c926552-d8d0-4858-b6e1-513a406c46fe/result.json) · [文件清单](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/6c926552-d8d0-4858-b6e1-513a406c46fe/files.json) · [轨迹](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/6c926552-d8d0-4858-b6e1-513a406c46fe/agent/trajectory.jsonl) |
| test:10770 | completed | 1 | 8.91 | 0.00 | complete / not-produced | — | [result](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/75f8d88d-0a05-43c9-a4a9-b691f4dce5ff/result.json) · [文件清单](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/75f8d88d-0a05-43c9-a4a9-b691f4dce5ff/files.json) · [轨迹](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/75f8d88d-0a05-43c9-a4a9-b691f4dce5ff/agent/trajectory.jsonl) |
| test:10815 | completed | 1 | 5.76 | 0.00 | complete / not-produced | — | [result](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/d5ccbd89-7978-4fd8-b5d5-2d6b06af4461/result.json) · [文件清单](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/d5ccbd89-7978-4fd8-b5d5-2d6b06af4461/files.json) · [轨迹](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/d5ccbd89-7978-4fd8-b5d5-2d6b06af4461/agent/trajectory.jsonl) |
| test:10846 | completed | 1 | 65.59 | 0.00 | complete / not-produced | — | [result](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/ae5cef5f-8f3d-4467-a0a6-98e5604b388c/result.json) · [文件清单](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/ae5cef5f-8f3d-4467-a0a6-98e5604b388c/files.json) · [轨迹](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/ae5cef5f-8f3d-4467-a0a6-98e5604b388c/agent/trajectory.jsonl) |
| test:10898 | completed | 1 | 6.19 | 0.00 | complete / not-produced | — | [result](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/4969a81d-51e5-40d7-bfca-20ba3ec3c8d0/result.json) · [文件清单](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/4969a81d-51e5-40d7-bfca-20ba3ec3c8d0/files.json) · [轨迹](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/4969a81d-51e5-40d7-bfca-20ba3ec3c8d0/agent/trajectory.jsonl) |
| test:10940 | completed | 1 | 6.03 | 0.00 | complete / not-produced | — | [result](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/8c292e76-7dfe-40c4-a207-5833fddbc161/result.json) · [文件清单](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/8c292e76-7dfe-40c4-a207-5833fddbc161/files.json) · [轨迹](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/8c292e76-7dfe-40c4-a207-5833fddbc161/agent/trajectory.jsonl) |
| test:10966 | completed | 1 | 5.84 | 0.00 | complete / not-produced | — | [result](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/fb39d9c3-40f1-4da7-b22f-9f730c95ed44/result.json) · [文件清单](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/fb39d9c3-40f1-4da7-b22f-9f730c95ed44/files.json) · [轨迹](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/fb39d9c3-40f1-4da7-b22f-9f730c95ed44/agent/trajectory.jsonl) |
| test:11045 | completed | 0 | 6.03 | 0.00 | complete / not-produced | — | [result](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/9c0bf4f6-0466-4d6f-b45c-22e7fabf43f8/result.json) · [文件清单](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/9c0bf4f6-0466-4d6f-b45c-22e7fabf43f8/files.json) · [轨迹](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/9c0bf4f6-0466-4d6f-b45c-22e7fabf43f8/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

