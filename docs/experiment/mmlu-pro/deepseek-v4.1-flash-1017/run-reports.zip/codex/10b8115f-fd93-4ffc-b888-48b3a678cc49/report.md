<!-- snapshotDigest: da2959ecf55b0335aa0d88a22f48c684006a63aa85d5fd596d5293d62f3d4a77 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 91.67%（22/24）**

Run: 10b8115f-fd93-4ffc-b888-48b3a678cc49 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T11:31:59.192Z / 2026-11-12T11:34:25.343Z |
| 总耗时 | 2 分 21 秒 |
| 答对 / 答错 / 解题超时 | 22 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 22 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 91.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 分 21 秒 |
| 环境准备耗时 | 1 分 29 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 21 秒 | 14 秒 | 47 秒 | 24 |
| 任务准备 | 0.39 毫秒 | 0.17 毫秒 | 0.94 毫秒 | 24 |
| 环境启动 | 9 秒 | 4 秒 | 12 秒 | 24 |
| 解题 | 7 秒 | 6 秒 | 29 秒 | 24 |
| 产物传输 | 1 秒 | 936.03 毫秒 | 2 秒 | 24 |
| 资源清理 | 4 秒 | 2 秒 | 5 秒 | 24 |
| 评分 | 0.45 毫秒 | 0.15 毫秒 | 1.87 毫秒 | 24 |
| 证据收集 | 8.81 毫秒 | 2.88 毫秒 | 22.55 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 31d28026-00f1-48ba-951f-89af41bdbc49 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 247,580 | 9,442 | 257,022 | 24 / 24 | — |
| 运行累计 | 247,580 | 9,442 | 257,022 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4376 | completed | 1 | 6.04 | 0.00 | complete / not-produced | — | [result](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/77d0c0fe-4091-4b12-9fe0-025d1c2f4585/result.json) · [文件清单](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/77d0c0fe-4091-4b12-9fe0-025d1c2f4585/files.json) · [轨迹](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/77d0c0fe-4091-4b12-9fe0-025d1c2f4585/agent/trajectory.jsonl) |
| test:4405 | completed | 1 | 6.08 | 0.00 | complete / not-produced | — | [result](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/6a134107-8827-436a-a045-d0893b551ae4/result.json) · [文件清单](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/6a134107-8827-436a-a045-d0893b551ae4/files.json) · [轨迹](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/6a134107-8827-436a-a045-d0893b551ae4/agent/trajectory.jsonl) |
| test:4552 | completed | 1 | 6.08 | 0.00 | complete / not-produced | — | [result](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/4c55ff96-d995-442a-9283-80607e16470b/result.json) · [文件清单](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/4c55ff96-d995-442a-9283-80607e16470b/files.json) · [轨迹](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/4c55ff96-d995-442a-9283-80607e16470b/agent/trajectory.jsonl) |
| test:4560 | completed | 1 | 6.01 | 0.00 | complete / not-produced | — | [result](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/1a1388b8-77d6-4f31-a215-86f3c3a1ffa5/result.json) · [文件清单](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/1a1388b8-77d6-4f31-a215-86f3c3a1ffa5/files.json) · [轨迹](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/1a1388b8-77d6-4f31-a215-86f3c3a1ffa5/agent/trajectory.jsonl) |
| test:4568 | completed | 1 | 6.17 | 0.00 | complete / not-produced | — | [result](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/e23e92fc-a362-40cf-bcbf-deceb76c675b/result.json) · [文件清单](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/e23e92fc-a362-40cf-bcbf-deceb76c675b/files.json) · [轨迹](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/e23e92fc-a362-40cf-bcbf-deceb76c675b/agent/trajectory.jsonl) |
| test:4580 | completed | 1 | 6.22 | 0.00 | complete / not-produced | — | [result](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/b5abc0b6-df38-4ab3-9d3e-91f90e63b0d8/result.json) · [文件清单](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/b5abc0b6-df38-4ab3-9d3e-91f90e63b0d8/files.json) · [轨迹](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/b5abc0b6-df38-4ab3-9d3e-91f90e63b0d8/agent/trajectory.jsonl) |
| test:4603 | completed | 1 | 6.23 | 0.00 | complete / not-produced | — | [result](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/d39a9dc5-abf2-432c-85be-63f7a1220c8e/result.json) · [文件清单](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/d39a9dc5-abf2-432c-85be-63f7a1220c8e/files.json) · [轨迹](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/d39a9dc5-abf2-432c-85be-63f7a1220c8e/agent/trajectory.jsonl) |
| test:4625 | completed | 1 | 6.26 | 0.00 | complete / not-produced | — | [result](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/d94e801e-981d-4308-b525-c1f1c2dc734a/result.json) · [文件清单](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/d94e801e-981d-4308-b525-c1f1c2dc734a/files.json) · [轨迹](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/d94e801e-981d-4308-b525-c1f1c2dc734a/agent/trajectory.jsonl) |
| test:4627 | completed | 1 | 6.28 | 0.00 | complete / not-produced | — | [result](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/81fce72b-05a3-4350-8170-73b4d213451f/result.json) · [文件清单](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/81fce72b-05a3-4350-8170-73b4d213451f/files.json) · [轨迹](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/81fce72b-05a3-4350-8170-73b4d213451f/agent/trajectory.jsonl) |
| test:4651 | completed | 1 | 6.01 | 0.00 | complete / not-produced | — | [result](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/b7d846c1-cd68-40d5-8671-97b4fa71dbed/result.json) · [文件清单](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/b7d846c1-cd68-40d5-8671-97b4fa71dbed/files.json) · [轨迹](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/b7d846c1-cd68-40d5-8671-97b4fa71dbed/agent/trajectory.jsonl) |
| test:4670 | completed | 1 | 29.05 | 0.00 | complete / not-produced | — | [result](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/923a5826-eafe-4102-abcc-b339be921af9/result.json) · [文件清单](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/923a5826-eafe-4102-abcc-b339be921af9/files.json) · [轨迹](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/923a5826-eafe-4102-abcc-b339be921af9/agent/trajectory.jsonl) |
| test:4700 | completed | 1 | 6.24 | 0.00 | complete / not-produced | — | [result](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/e2ad7514-96d1-4df7-8903-0e10ddfc5a16/result.json) · [文件清单](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/e2ad7514-96d1-4df7-8903-0e10ddfc5a16/files.json) · [轨迹](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/e2ad7514-96d1-4df7-8903-0e10ddfc5a16/agent/trajectory.jsonl) |
| test:4709 | completed | 0 | 6.07 | 0.00 | complete / not-produced | — | [result](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/7c9eb3ec-8b2e-4964-b303-9cf6d823764b/result.json) · [文件清单](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/7c9eb3ec-8b2e-4964-b303-9cf6d823764b/files.json) · [轨迹](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/7c9eb3ec-8b2e-4964-b303-9cf6d823764b/agent/trajectory.jsonl) |
| test:4763 | completed | 0 | 6.15 | 0.00 | complete / not-produced | — | [result](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/678a1d4e-df1c-4b32-aadb-37e75952b43a/result.json) · [文件清单](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/678a1d4e-df1c-4b32-aadb-37e75952b43a/files.json) · [轨迹](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/678a1d4e-df1c-4b32-aadb-37e75952b43a/agent/trajectory.jsonl) |
| test:4770 | completed | 1 | 6.18 | 0.00 | complete / not-produced | — | [result](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/ac55d9ba-8cef-4237-b21b-cf7c9da25e60/result.json) · [文件清单](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/ac55d9ba-8cef-4237-b21b-cf7c9da25e60/files.json) · [轨迹](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/ac55d9ba-8cef-4237-b21b-cf7c9da25e60/agent/trajectory.jsonl) |
| test:4786 | completed | 1 | 7.58 | 0.00 | complete / not-produced | — | [result](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/dc00ac09-c555-4743-925c-173696d4a33f/result.json) · [文件清单](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/dc00ac09-c555-4743-925c-173696d4a33f/files.json) · [轨迹](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/dc00ac09-c555-4743-925c-173696d4a33f/agent/trajectory.jsonl) |
| test:4879 | completed | 1 | 10.42 | 0.00 | complete / not-produced | — | [result](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/e9926598-a67f-4880-be6a-cdf5898c116d/result.json) · [文件清单](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/e9926598-a67f-4880-be6a-cdf5898c116d/files.json) · [轨迹](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/e9926598-a67f-4880-be6a-cdf5898c116d/agent/trajectory.jsonl) |
| test:5078 | completed | 1 | 10.29 | 0.00 | complete / not-produced | — | [result](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/e4e17efe-b6c8-4b0d-b50d-62bba2ffea25/result.json) · [文件清单](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/e4e17efe-b6c8-4b0d-b50d-62bba2ffea25/files.json) · [轨迹](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/e4e17efe-b6c8-4b0d-b50d-62bba2ffea25/agent/trajectory.jsonl) |
| test:5123 | completed | 1 | 5.88 | 0.00 | complete / not-produced | — | [result](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/301ab04f-c4de-4f55-8d93-5c458e6be18a/result.json) · [文件清单](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/301ab04f-c4de-4f55-8d93-5c458e6be18a/files.json) · [轨迹](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/301ab04f-c4de-4f55-8d93-5c458e6be18a/agent/trajectory.jsonl) |
| test:5174 | completed | 1 | 5.90 | 0.00 | complete / not-produced | — | [result](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/403e2fa4-a8a5-409c-80bb-6cfddf7b16cc/result.json) · [文件清单](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/403e2fa4-a8a5-409c-80bb-6cfddf7b16cc/files.json) · [轨迹](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/403e2fa4-a8a5-409c-80bb-6cfddf7b16cc/agent/trajectory.jsonl) |
| test:5198 | completed | 1 | 5.97 | 0.00 | complete / not-produced | — | [result](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/06c32032-134d-4e9c-b45f-5e38544836e3/result.json) · [文件清单](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/06c32032-134d-4e9c-b45f-5e38544836e3/files.json) · [轨迹](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/06c32032-134d-4e9c-b45f-5e38544836e3/agent/trajectory.jsonl) |
| test:5243 | completed | 1 | 5.85 | 0.00 | complete / not-produced | — | [result](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/f8cc64ab-9213-4fb7-bfa2-7611645dd687/result.json) · [文件清单](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/f8cc64ab-9213-4fb7-bfa2-7611645dd687/files.json) · [轨迹](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/f8cc64ab-9213-4fb7-bfa2-7611645dd687/agent/trajectory.jsonl) |
| test:5309 | completed | 1 | 5.78 | 0.00 | complete / not-produced | — | [result](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/23f288ee-5894-43ac-804b-5ec00887ef27/result.json) · [文件清单](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/23f288ee-5894-43ac-804b-5ec00887ef27/files.json) · [轨迹](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/23f288ee-5894-43ac-804b-5ec00887ef27/agent/trajectory.jsonl) |
| test:5319 | completed | 1 | 5.75 | 0.00 | complete / not-produced | — | [result](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/d369334e-57e7-4e23-8592-5185917b149d/result.json) · [文件清单](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/d369334e-57e7-4e23-8592-5185917b149d/files.json) · [轨迹](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/d369334e-57e7-4e23-8592-5185917b149d/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

