<!-- snapshotDigest: 4585a2153be776d4e3c720c308886b83ae08eaf64d650ad9b8a269c2d79f884f -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: 1b979436-ad11-4faa-be96-cc2cb09f2d33 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T11:34:29.110Z / 2026-11-12T11:39:29.449Z |
| 总耗时 | 4 分 50 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 4 分 50 秒 |
| 环境准备耗时 | 1 分 49 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 32 秒 | 17 秒 | 2 分 55 秒 | 24 |
| 任务准备 | 0.55 毫秒 | 0.29 毫秒 | 2.5 毫秒 | 24 |
| 环境启动 | 11 秒 | 7 秒 | 13 秒 | 24 |
| 解题 | 13 秒 | 6 秒 | 2 分 43 秒 | 24 |
| 产物传输 | 2 秒 | 751.98 毫秒 | 3 秒 | 24 |
| 资源清理 | 6 秒 | 2 秒 | 8 秒 | 24 |
| 评分 | 0.46 毫秒 | 0.15 毫秒 | 2.01 毫秒 | 24 |
| 证据收集 | 9.6 毫秒 | 3.99 毫秒 | 37.28 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| bb2af404-b219-4a74-81c5-ed336c79eb8a | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 231,560 | 29,736 | 261,296 | 24 / 24 | — |
| 运行累计 | 231,560 | 29,736 | 261,296 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:8511 | completed | 1 | 6.44 | 0.00 | complete / not-produced | — | [result](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/fbdd655b-1264-4f88-8eea-d7223a6ff924/result.json) · [文件清单](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/fbdd655b-1264-4f88-8eea-d7223a6ff924/files.json) · [轨迹](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/fbdd655b-1264-4f88-8eea-d7223a6ff924/agent/trajectory.jsonl) |
| test:8525 | completed | 1 | 6.56 | 0.00 | complete / not-produced | — | [result](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/9e381683-d1f9-42ff-8a28-78e48a94ab54/result.json) · [文件清单](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/9e381683-d1f9-42ff-8a28-78e48a94ab54/files.json) · [轨迹](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/9e381683-d1f9-42ff-8a28-78e48a94ab54/agent/trajectory.jsonl) |
| test:8604 | completed | 1 | 6.33 | 0.00 | complete / not-produced | — | [result](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/2682390d-1976-42c2-a557-f0b4c0797845/result.json) · [文件清单](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/2682390d-1976-42c2-a557-f0b4c0797845/files.json) · [轨迹](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/2682390d-1976-42c2-a557-f0b4c0797845/agent/trajectory.jsonl) |
| test:8740 | completed | 1 | 6.41 | 0.00 | complete / not-produced | — | [result](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/c747750c-55c3-4cd9-b63a-8adeda9b6e45/result.json) · [文件清单](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/c747750c-55c3-4cd9-b63a-8adeda9b6e45/files.json) · [轨迹](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/c747750c-55c3-4cd9-b63a-8adeda9b6e45/agent/trajectory.jsonl) |
| test:8839 | completed | 1 | 6.49 | 0.00 | complete / not-produced | — | [result](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/60014e60-c7e4-4b98-aab2-17486d7afd1d/result.json) · [文件清单](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/60014e60-c7e4-4b98-aab2-17486d7afd1d/files.json) · [轨迹](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/60014e60-c7e4-4b98-aab2-17486d7afd1d/agent/trajectory.jsonl) |
| test:8939 | completed | 1 | 6.30 | 0.00 | complete / not-produced | — | [result](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/012445a5-37f0-49e8-92ad-e34266651a26/result.json) · [文件清单](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/012445a5-37f0-49e8-92ad-e34266651a26/files.json) · [轨迹](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/012445a5-37f0-49e8-92ad-e34266651a26/agent/trajectory.jsonl) |
| test:8967 | completed | 1 | 6.16 | 0.00 | complete / not-produced | — | [result](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/38ce5f46-f248-498e-991a-59730d6b7f2d/result.json) · [文件清单](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/38ce5f46-f248-498e-991a-59730d6b7f2d/files.json) · [轨迹](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/38ce5f46-f248-498e-991a-59730d6b7f2d/agent/trajectory.jsonl) |
| test:8989 | completed | 1 | 6.61 | 0.00 | complete / not-produced | — | [result](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/22550920-4827-4ad5-a6dd-b59905713e9f/result.json) · [文件清单](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/22550920-4827-4ad5-a6dd-b59905713e9f/files.json) · [轨迹](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/22550920-4827-4ad5-a6dd-b59905713e9f/agent/trajectory.jsonl) |
| test:9136 | completed | 1 | 6.47 | 0.00 | complete / not-produced | — | [result](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/18f1f08b-2425-493e-bbc8-b7bc1963fa9b/result.json) · [文件清单](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/18f1f08b-2425-493e-bbc8-b7bc1963fa9b/files.json) · [轨迹](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/18f1f08b-2425-493e-bbc8-b7bc1963fa9b/agent/trajectory.jsonl) |
| test:9222 | completed | 1 | 6.29 | 0.00 | complete / not-produced | — | [result](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/f1b04ae8-4708-44df-b810-791733e68ebe/result.json) · [文件清单](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/f1b04ae8-4708-44df-b810-791733e68ebe/files.json) · [轨迹](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/f1b04ae8-4708-44df-b810-791733e68ebe/agent/trajectory.jsonl) |
| test:9391 | completed | 1 | 6.43 | 0.00 | complete / not-produced | — | [result](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/d0c68327-9380-4fdc-b703-9560949e47fe/result.json) · [文件清单](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/d0c68327-9380-4fdc-b703-9560949e47fe/files.json) · [轨迹](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/d0c68327-9380-4fdc-b703-9560949e47fe/agent/trajectory.jsonl) |
| test:9395 | completed | 1 | 7.74 | 0.00 | complete / not-produced | — | [result](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b9ca3431-c02f-4241-be09-efcac3596e2f/result.json) · [文件清单](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b9ca3431-c02f-4241-be09-efcac3596e2f/files.json) · [轨迹](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/b9ca3431-c02f-4241-be09-efcac3596e2f/agent/trajectory.jsonl) |
| test:9405 | completed | 1 | 6.50 | 0.00 | complete / not-produced | — | [result](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/da36de13-be65-42f8-ad92-3499b79cefb6/result.json) · [文件清单](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/da36de13-be65-42f8-ad92-3499b79cefb6/files.json) · [轨迹](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/da36de13-be65-42f8-ad92-3499b79cefb6/agent/trajectory.jsonl) |
| test:9769 | completed | 1 | 6.44 | 0.00 | complete / not-produced | — | [result](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/3a864364-f01c-4318-a128-3e3143cfe901/result.json) · [文件清单](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/3a864364-f01c-4318-a128-3e3143cfe901/files.json) · [轨迹](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/3a864364-f01c-4318-a128-3e3143cfe901/agent/trajectory.jsonl) |
| test:9843 | completed | 1 | 7.17 | 0.00 | complete / not-produced | — | [result](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/d2da3d45-1c98-4b88-96f5-166e0f6d6e06/result.json) · [文件清单](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/d2da3d45-1c98-4b88-96f5-166e0f6d6e06/files.json) · [轨迹](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/d2da3d45-1c98-4b88-96f5-166e0f6d6e06/agent/trajectory.jsonl) |
| test:9864 | completed | 1 | 6.46 | 0.00 | complete / not-produced | — | [result](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/05522f35-3cad-494b-8fb9-998ab239c14b/result.json) · [文件清单](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/05522f35-3cad-494b-8fb9-998ab239c14b/files.json) · [轨迹](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/05522f35-3cad-494b-8fb9-998ab239c14b/agent/trajectory.jsonl) |
| test:9901 | completed | 1 | 6.43 | 0.00 | complete / not-produced | — | [result](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/dccc0338-6f48-4ab6-a022-0fd4b661f0cf/result.json) · [文件清单](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/dccc0338-6f48-4ab6-a022-0fd4b661f0cf/files.json) · [轨迹](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/dccc0338-6f48-4ab6-a022-0fd4b661f0cf/agent/trajectory.jsonl) |
| test:9931 | completed | 0 | 162.61 | 0.00 | complete / not-produced | — | [result](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/1f8e5464-2436-4dd1-a558-8f18b70307d6/result.json) · [文件清单](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/1f8e5464-2436-4dd1-a558-8f18b70307d6/files.json) · [轨迹](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/1f8e5464-2436-4dd1-a558-8f18b70307d6/agent/trajectory.jsonl) |
| test:10127 | completed | 1 | 6.41 | 0.00 | complete / not-produced | — | [result](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/090ac7eb-271c-48cd-912a-8261e7e260d2/result.json) · [文件清单](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/090ac7eb-271c-48cd-912a-8261e7e260d2/files.json) · [轨迹](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/090ac7eb-271c-48cd-912a-8261e7e260d2/agent/trajectory.jsonl) |
| test:10140 | completed | 1 | 6.37 | 0.00 | complete / not-produced | — | [result](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/26dc6b97-1a19-4dcb-a490-0a8ae03d90cb/result.json) · [文件清单](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/26dc6b97-1a19-4dcb-a490-0a8ae03d90cb/files.json) · [轨迹](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/26dc6b97-1a19-4dcb-a490-0a8ae03d90cb/agent/trajectory.jsonl) |
| test:10174 | completed | 1 | 6.45 | 0.00 | complete / not-produced | — | [result](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/25fa48f6-4304-43de-8cce-a05e5aa010e4/result.json) · [文件清单](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/25fa48f6-4304-43de-8cce-a05e5aa010e4/files.json) · [轨迹](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/25fa48f6-4304-43de-8cce-a05e5aa010e4/agent/trajectory.jsonl) |
| test:10184 | completed | 1 | 6.44 | 0.00 | complete / not-produced | — | [result](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/dd4a5951-bff6-41fb-a2d4-6d105deec883/result.json) · [文件清单](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/dd4a5951-bff6-41fb-a2d4-6d105deec883/files.json) · [轨迹](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/dd4a5951-bff6-41fb-a2d4-6d105deec883/agent/trajectory.jsonl) |
| test:10189 | completed | 1 | 6.35 | 0.00 | complete / not-produced | — | [result](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/b4e67796-95cf-46bd-a88c-1c87277bd561/result.json) · [文件清单](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/b4e67796-95cf-46bd-a88c-1c87277bd561/files.json) · [轨迹](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/b4e67796-95cf-46bd-a88c-1c87277bd561/agent/trajectory.jsonl) |
| test:10294 | completed | 1 | 6.01 | 0.00 | complete / not-produced | — | [result](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/54c3e6dd-8fee-4bee-84ae-af8b58df4110/result.json) · [文件清单](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/54c3e6dd-8fee-4bee-84ae-af8b58df4110/files.json) · [轨迹](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/54c3e6dd-8fee-4bee-84ae-af8b58df4110/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

