<!-- snapshotDigest: b4d2dcbf1f5c4ae49345c4515c5252da19d228bc247af558ea3de851bb21d452 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 70.59%（12/17）**

Run: 4a4558a2-ffba-458b-b562-ae386f9e00ab · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T11:37:34.389Z / 2026-11-12T11:40:28.754Z |
| 总耗时 | 2 分 48 秒 |
| 答对 / 答错 / 解题超时 | 12 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 17 题；已保存 17 条记录；待运行 0 题。
有效评分覆盖率：17/17（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 17 |
| 计分题数 | 17 |
| 正常评分题数 | 17 |
| 答对题数 | 12 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 70.59% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 分 48 秒 |
| 环境准备耗时 | 48 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 36 秒 | 12 秒 | 2 分 7 秒 | 17 |
| 任务准备 | 0.33 毫秒 | 0.12 毫秒 | 0.96 毫秒 | 17 |
| 环境启动 | 6 秒 | 3 秒 | 10 秒 | 17 |
| 解题 | 27 秒 | 6 秒 | 1 分 56 秒 | 17 |
| 产物传输 | 1 秒 | 705.24 毫秒 | 2 秒 | 17 |
| 资源清理 | 3 秒 | 2 秒 | 5 秒 | 17 |
| 评分 | 0.35 毫秒 | 0.15 毫秒 | 2.04 毫秒 | 17 |
| 证据收集 | 6.35 毫秒 | 3.87 毫秒 | 19.31 毫秒 | 17 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| ba50d6e2-b0e7-4471-9549-23e2e1beb3bf | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 187,121 | 57,248 | 244,369 | 17 / 17 | — |
| 运行累计 | 187,121 | 57,248 | 244,369 | 17 / 17 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:11050 | completed | 1 | 18.18 | 0.00 | complete / not-produced | — | [result](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/cd4a41e6-4b69-4616-8232-b46bc24868be/result.json) · [文件清单](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/cd4a41e6-4b69-4616-8232-b46bc24868be/files.json) · [轨迹](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/cd4a41e6-4b69-4616-8232-b46bc24868be/agent/trajectory.jsonl) |
| test:11060 | completed | 1 | 6.10 | 0.00 | complete / not-produced | — | [result](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/4493bab1-a8df-45a9-a652-cbfc9052e351/result.json) · [文件清单](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/4493bab1-a8df-45a9-a652-cbfc9052e351/files.json) · [轨迹](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/4493bab1-a8df-45a9-a652-cbfc9052e351/agent/trajectory.jsonl) |
| test:11093 | completed | 0 | 20.79 | 0.00 | complete / not-produced | — | [result](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/889737b9-33ac-4fb9-991e-02c4e1d72bc5/result.json) · [文件清单](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/889737b9-33ac-4fb9-991e-02c4e1d72bc5/files.json) · [轨迹](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/889737b9-33ac-4fb9-991e-02c4e1d72bc5/agent/trajectory.jsonl) |
| test:11210 | completed | 1 | 6.09 | 0.00 | complete / not-produced | — | [result](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/1fda2aa4-2a18-4f1d-b0ab-c67de5347836/result.json) · [文件清单](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/1fda2aa4-2a18-4f1d-b0ab-c67de5347836/files.json) · [轨迹](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/1fda2aa4-2a18-4f1d-b0ab-c67de5347836/agent/trajectory.jsonl) |
| test:11354 | completed | 0 | 5.96 | 0.00 | complete / not-produced | — | [result](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/c84fc4b8-2f31-4b86-9aaa-2cc33a04d479/result.json) · [文件清单](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/c84fc4b8-2f31-4b86-9aaa-2cc33a04d479/files.json) · [轨迹](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/c84fc4b8-2f31-4b86-9aaa-2cc33a04d479/agent/trajectory.jsonl) |
| test:11491 | completed | 0 | 116.12 | 0.00 | complete / not-produced | — | [result](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/9e1d93d4-ba95-4f78-be80-4b3bf731c760/result.json) · [文件清单](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/9e1d93d4-ba95-4f78-be80-4b3bf731c760/files.json) · [轨迹](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/9e1d93d4-ba95-4f78-be80-4b3bf731c760/agent/trajectory.jsonl) |
| test:11496 | completed | 1 | 85.59 | 0.00 | complete / not-produced | — | [result](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/4031114f-9429-4897-9d00-5e0f796a86cf/result.json) · [文件清单](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/4031114f-9429-4897-9d00-5e0f796a86cf/files.json) · [轨迹](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/4031114f-9429-4897-9d00-5e0f796a86cf/agent/trajectory.jsonl) |
| test:11506 | completed | 0 | 80.22 | 0.00 | complete / not-produced | — | [result](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/b251a547-ae07-4d44-8560-ac32419c8f26/result.json) · [文件清单](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/b251a547-ae07-4d44-8560-ac32419c8f26/files.json) · [轨迹](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/b251a547-ae07-4d44-8560-ac32419c8f26/agent/trajectory.jsonl) |
| test:11559 | completed | 1 | 5.79 | 0.00 | complete / not-produced | — | [result](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/3499e70c-eed5-4282-bc0d-fd3c5c73c509/result.json) · [文件清单](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/3499e70c-eed5-4282-bc0d-fd3c5c73c509/files.json) · [轨迹](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/3499e70c-eed5-4282-bc0d-fd3c5c73c509/agent/trajectory.jsonl) |
| test:11576 | completed | 0 | 13.81 | 0.00 | complete / not-produced | — | [result](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/c58eeceb-54f5-4616-a04f-f7482eda19b4/result.json) · [文件清单](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/c58eeceb-54f5-4616-a04f-f7482eda19b4/files.json) · [轨迹](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/c58eeceb-54f5-4616-a04f-f7482eda19b4/agent/trajectory.jsonl) |
| test:11629 | completed | 1 | 7.29 | 0.00 | complete / not-produced | — | [result](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/5763544c-e024-4ad8-b73f-f4aad4a45cf0/result.json) · [文件清单](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/5763544c-e024-4ad8-b73f-f4aad4a45cf0/files.json) · [轨迹](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/5763544c-e024-4ad8-b73f-f4aad4a45cf0/agent/trajectory.jsonl) |
| test:11660 | completed | 1 | 55.70 | 0.00 | complete / not-produced | — | [result](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/a7ea39df-de77-4d27-a9ae-52620d34aa05/result.json) · [文件清单](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/a7ea39df-de77-4d27-a9ae-52620d34aa05/files.json) · [轨迹](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/a7ea39df-de77-4d27-a9ae-52620d34aa05/agent/trajectory.jsonl) |
| test:11802 | completed | 1 | 5.64 | 0.00 | complete / not-produced | — | [result](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/ced17821-08c6-4c32-99c8-f28acf77be73/result.json) · [文件清单](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/ced17821-08c6-4c32-99c8-f28acf77be73/files.json) · [轨迹](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/ced17821-08c6-4c32-99c8-f28acf77be73/agent/trajectory.jsonl) |
| test:11808 | completed | 1 | 5.95 | 0.00 | complete / not-produced | — | [result](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/1060f467-8bda-4236-8f86-efeb938033e2/result.json) · [文件清单](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/1060f467-8bda-4236-8f86-efeb938033e2/files.json) · [轨迹](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/1060f467-8bda-4236-8f86-efeb938033e2/agent/trajectory.jsonl) |
| test:11824 | completed | 1 | 5.62 | 0.00 | complete / not-produced | — | [result](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/8a1b41db-6f31-470d-8c3f-3d61dd33aafa/result.json) · [文件清单](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/8a1b41db-6f31-470d-8c3f-3d61dd33aafa/files.json) · [轨迹](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/8a1b41db-6f31-470d-8c3f-3d61dd33aafa/agent/trajectory.jsonl) |
| test:11925 | completed | 1 | 10.52 | 0.00 | complete / not-produced | — | [result](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/21cf43ab-07d7-482a-9541-0032a8824da8/result.json) · [文件清单](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/21cf43ab-07d7-482a-9541-0032a8824da8/files.json) · [轨迹](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/21cf43ab-07d7-482a-9541-0032a8824da8/agent/trajectory.jsonl) |
| test:12002 | completed | 1 | 5.59 | 0.00 | complete / not-produced | — | [result](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/bedb1128-7c07-4e0c-a490-900380040e57/result.json) · [文件清单](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/bedb1128-7c07-4e0c-a490-900380040e57/files.json) · [轨迹](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/bedb1128-7c07-4e0c-a490-900380040e57/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

