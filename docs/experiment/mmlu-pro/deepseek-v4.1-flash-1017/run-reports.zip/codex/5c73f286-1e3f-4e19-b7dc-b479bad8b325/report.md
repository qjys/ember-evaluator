<!-- snapshotDigest: 46ca0e741705f17b24f9dcac7954f69a535c21d385a02ba272b744fb23264f97 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 87.50%（21/24）**

Run: 5c73f286-1e3f-4e19-b7dc-b479bad8b325 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T11:29:01.806Z / 2026-11-12T11:31:55.527Z |
| 总耗时 | 2 分 47 秒 |
| 答对 / 答错 / 解题超时 | 21 / 3 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 21 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 87.50% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 分 47 秒 |
| 环境准备耗时 | 1 分 52 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 25 秒 | 18 秒 | 36 秒 | 24 |
| 任务准备 | 0.41 毫秒 | 0.22 毫秒 | 1.03 毫秒 | 24 |
| 环境启动 | 11 秒 | 7 秒 | 15 秒 | 24 |
| 解题 | 7 秒 | 6 秒 | 13 秒 | 24 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 24 |
| 资源清理 | 5 秒 | 3 秒 | 6 秒 | 24 |
| 评分 | 0.47 毫秒 | 0.23 毫秒 | 2.13 毫秒 | 24 |
| 证据收集 | 10.8 毫秒 | 3.33 毫秒 | 55.27 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 3aaa5853-8f6d-423d-9344-dd33f2179156 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 216,766 | 9,395 | 226,161 | 24 / 24 | — |
| 运行累计 | 216,766 | 9,395 | 226,161 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:41 | completed | 1 | 6.56 | 0.00 | complete / not-produced | — | [result](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/6ab78e29-5960-4915-b14c-da601e8e87a8/result.json) · [文件清单](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/6ab78e29-5960-4915-b14c-da601e8e87a8/files.json) · [轨迹](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/6ab78e29-5960-4915-b14c-da601e8e87a8/agent/trajectory.jsonl) |
| test:61 | completed | 0 | 6.60 | 0.00 | complete / not-produced | — | [result](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/d5de2dd3-0045-468a-9c01-1a7fc7340829/result.json) · [文件清单](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/d5de2dd3-0045-468a-9c01-1a7fc7340829/files.json) · [轨迹](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/d5de2dd3-0045-468a-9c01-1a7fc7340829/agent/trajectory.jsonl) |
| test:97 | completed | 1 | 12.58 | 0.00 | complete / not-produced | — | [result](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/7b9b446c-c6a7-485d-ac93-16af8ab333a2/result.json) · [文件清单](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/7b9b446c-c6a7-485d-ac93-16af8ab333a2/files.json) · [轨迹](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/7b9b446c-c6a7-485d-ac93-16af8ab333a2/agent/trajectory.jsonl) |
| test:209 | completed | 1 | 6.42 | 0.00 | complete / not-produced | — | [result](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/5f1d3585-1e9b-403d-bff2-4872cc120796/result.json) · [文件清单](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/5f1d3585-1e9b-403d-bff2-4872cc120796/files.json) · [轨迹](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/5f1d3585-1e9b-403d-bff2-4872cc120796/agent/trajectory.jsonl) |
| test:286 | completed | 1 | 6.52 | 0.00 | complete / not-produced | — | [result](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/f128f507-2faf-45d9-8037-e2352d1cc3af/result.json) · [文件清单](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/f128f507-2faf-45d9-8037-e2352d1cc3af/files.json) · [轨迹](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/f128f507-2faf-45d9-8037-e2352d1cc3af/agent/trajectory.jsonl) |
| test:299 | completed | 1 | 6.46 | 0.00 | complete / not-produced | — | [result](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/62a4020a-2bcd-4d5e-b4f6-f2e05b6c6e70/result.json) · [文件清单](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/62a4020a-2bcd-4d5e-b4f6-f2e05b6c6e70/files.json) · [轨迹](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/62a4020a-2bcd-4d5e-b4f6-f2e05b6c6e70/agent/trajectory.jsonl) |
| test:311 | completed | 1 | 8.46 | 0.00 | complete / not-produced | — | [result](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/9b15b6b7-e3be-46e1-a397-631c1f79c214/result.json) · [文件清单](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/9b15b6b7-e3be-46e1-a397-631c1f79c214/files.json) · [轨迹](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/9b15b6b7-e3be-46e1-a397-631c1f79c214/agent/trajectory.jsonl) |
| test:352 | completed | 1 | 6.66 | 0.00 | complete / not-produced | — | [result](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/07f20694-e47d-45c7-8399-895802dc5798/result.json) · [文件清单](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/07f20694-e47d-45c7-8399-895802dc5798/files.json) · [轨迹](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/07f20694-e47d-45c7-8399-895802dc5798/agent/trajectory.jsonl) |
| test:355 | completed | 1 | 6.51 | 0.00 | complete / not-produced | — | [result](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/fe5a48f8-6350-4392-a559-f999b77845c4/result.json) · [文件清单](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/fe5a48f8-6350-4392-a559-f999b77845c4/files.json) · [轨迹](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/fe5a48f8-6350-4392-a559-f999b77845c4/agent/trajectory.jsonl) |
| test:476 | completed | 0 | 9.14 | 0.00 | complete / not-produced | — | [result](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/6aa025b3-8c82-4b51-b648-c479b4aa9ade/result.json) · [文件清单](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/6aa025b3-8c82-4b51-b648-c479b4aa9ade/files.json) · [轨迹](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/6aa025b3-8c82-4b51-b648-c479b4aa9ade/agent/trajectory.jsonl) |
| test:511 | completed | 1 | 6.41 | 0.00 | complete / not-produced | — | [result](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/85a94d2d-500e-43cf-9ca1-2e6a436a0e38/result.json) · [文件清单](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/85a94d2d-500e-43cf-9ca1-2e6a436a0e38/files.json) · [轨迹](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/85a94d2d-500e-43cf-9ca1-2e6a436a0e38/agent/trajectory.jsonl) |
| test:552 | completed | 1 | 6.17 | 0.00 | complete / not-produced | — | [result](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/9ec51358-4240-497c-aa5d-ece57cfbd1b2/result.json) · [文件清单](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/9ec51358-4240-497c-aa5d-ece57cfbd1b2/files.json) · [轨迹](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/9ec51358-4240-497c-aa5d-ece57cfbd1b2/agent/trajectory.jsonl) |
| test:624 | completed | 1 | 6.35 | 0.00 | complete / not-produced | — | [result](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/8b51bb8f-573d-41ab-bfbb-01dd4234a705/result.json) · [文件清单](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/8b51bb8f-573d-41ab-bfbb-01dd4234a705/files.json) · [轨迹](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/8b51bb8f-573d-41ab-bfbb-01dd4234a705/agent/trajectory.jsonl) |
| test:669 | completed | 1 | 6.34 | 0.00 | complete / not-produced | — | [result](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/ddf49a74-cd0e-4edc-8da1-74590ebc757f/result.json) · [文件清单](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/ddf49a74-cd0e-4edc-8da1-74590ebc757f/files.json) · [轨迹](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/ddf49a74-cd0e-4edc-8da1-74590ebc757f/agent/trajectory.jsonl) |
| test:670 | completed | 1 | 6.29 | 0.00 | complete / not-produced | — | [result](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/6b0a1e36-9661-4772-b76e-393b5b55ea63/result.json) · [文件清单](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/6b0a1e36-9661-4772-b76e-393b5b55ea63/files.json) · [轨迹](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/6b0a1e36-9661-4772-b76e-393b5b55ea63/agent/trajectory.jsonl) |
| test:796 | completed | 1 | 7.57 | 0.00 | complete / not-produced | — | [result](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/b0260ffb-ed1a-45db-ac5b-1d8014ae01a9/result.json) · [文件清单](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/b0260ffb-ed1a-45db-ac5b-1d8014ae01a9/files.json) · [轨迹](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/b0260ffb-ed1a-45db-ac5b-1d8014ae01a9/agent/trajectory.jsonl) |
| test:828 | completed | 1 | 6.26 | 0.00 | complete / not-produced | — | [result](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/3d25243d-d9d0-4fda-82ef-9f7643ac5231/result.json) · [文件清单](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/3d25243d-d9d0-4fda-82ef-9f7643ac5231/files.json) · [轨迹](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/3d25243d-d9d0-4fda-82ef-9f7643ac5231/agent/trajectory.jsonl) |
| test:841 | completed | 1 | 7.71 | 0.00 | complete / not-produced | — | [result](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/35daf56d-b3b2-4b1a-aa5b-0cf54928f506/result.json) · [文件清单](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/35daf56d-b3b2-4b1a-aa5b-0cf54928f506/files.json) · [轨迹](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/35daf56d-b3b2-4b1a-aa5b-0cf54928f506/agent/trajectory.jsonl) |
| test:883 | completed | 1 | 6.32 | 0.00 | complete / not-produced | — | [result](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/d8c917a5-8321-4495-aae5-e01248e02e72/result.json) · [文件清单](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/d8c917a5-8321-4495-aae5-e01248e02e72/files.json) · [轨迹](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/d8c917a5-8321-4495-aae5-e01248e02e72/agent/trajectory.jsonl) |
| test:938 | completed | 1 | 6.47 | 0.00 | complete / not-produced | — | [result](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/e138a4ac-9a01-4b17-a6d2-e869c878ea42/result.json) · [文件清单](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/e138a4ac-9a01-4b17-a6d2-e869c878ea42/files.json) · [轨迹](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/e138a4ac-9a01-4b17-a6d2-e869c878ea42/agent/trajectory.jsonl) |
| test:1026 | completed | 0 | 6.12 | 0.00 | complete / not-produced | — | [result](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/0526ef48-0881-42f9-819b-f144024648d8/result.json) · [文件清单](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/0526ef48-0881-42f9-819b-f144024648d8/files.json) · [轨迹](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/0526ef48-0881-42f9-819b-f144024648d8/agent/trajectory.jsonl) |
| test:1229 | completed | 1 | 6.24 | 0.00 | complete / not-produced | — | [result](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/6ea6307b-46dd-4927-840c-cb1dd90a3fc8/result.json) · [文件清单](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/6ea6307b-46dd-4927-840c-cb1dd90a3fc8/files.json) · [轨迹](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/6ea6307b-46dd-4927-840c-cb1dd90a3fc8/agent/trajectory.jsonl) |
| test:1252 | completed | 1 | 6.12 | 0.00 | complete / not-produced | — | [result](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/800b01d5-2366-4e2f-9cc1-b7f3923cedb4/result.json) · [文件清单](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/800b01d5-2366-4e2f-9cc1-b7f3923cedb4/files.json) · [轨迹](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/800b01d5-2366-4e2f-9cc1-b7f3923cedb4/agent/trajectory.jsonl) |
| test:1399 | completed | 1 | 6.09 | 0.00 | complete / not-produced | — | [result](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/32e21e6c-1445-4079-abe7-4fb83000669c/result.json) · [文件清单](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/32e21e6c-1445-4079-abe7-4fb83000669c/files.json) · [轨迹](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/32e21e6c-1445-4079-abe7-4fb83000669c/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

