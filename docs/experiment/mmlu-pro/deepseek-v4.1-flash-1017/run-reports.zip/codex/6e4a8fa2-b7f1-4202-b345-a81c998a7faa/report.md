<!-- snapshotDigest: 0bc872fff4eb1ba8029fdc8ac03c7d63c088d2a0f19dbb73c907af135764b912 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: 6e4a8fa2-b7f1-4202-b345-a81c998a7faa · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T11:34:25.763Z / 2026-11-12T11:37:31.669Z |
| 总耗时 | 2 分 59 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 分 59 秒 |
| 环境准备耗时 | 1 分 52 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 27 秒 | 19 秒 | 1 分 17 秒 | 24 |
| 任务准备 | 0.55 毫秒 | 0.23 毫秒 | 4.04 毫秒 | 24 |
| 环境启动 | 10 秒 | 8 秒 | 12 秒 | 24 |
| 解题 | 8 秒 | 6 秒 | 57 秒 | 24 |
| 产物传输 | 2 秒 | 2 秒 | 3 秒 | 24 |
| 资源清理 | 6 秒 | 4 秒 | 8 秒 | 24 |
| 评分 | 0.52 毫秒 | 0.17 毫秒 | 2.53 毫秒 | 24 |
| 证据收集 | 10.45 毫秒 | 2.95 毫秒 | 34.39 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| ac8d7b24-972c-4134-9601-1f52455a0116 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 244,502 | 11,354 | 255,856 | 24 / 24 | — |
| 运行累计 | 244,502 | 11,354 | 255,856 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:6751 | completed | 1 | 6.46 | 0.00 | complete / not-produced | — | [result](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/312b8a22-1ebd-44af-af3f-206095eb324c/result.json) · [文件清单](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/312b8a22-1ebd-44af-af3f-206095eb324c/files.json) · [轨迹](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/312b8a22-1ebd-44af-af3f-206095eb324c/agent/trajectory.jsonl) |
| test:6784 | completed | 1 | 6.25 | 0.00 | complete / not-produced | — | [result](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/fabf49ce-268e-45fa-bcdc-1e358bdd6394/result.json) · [文件清单](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/fabf49ce-268e-45fa-bcdc-1e358bdd6394/files.json) · [轨迹](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/fabf49ce-268e-45fa-bcdc-1e358bdd6394/agent/trajectory.jsonl) |
| test:6792 | completed | 1 | 6.49 | 0.00 | complete / not-produced | — | [result](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/65ae33af-1d39-4a1f-9895-5e2e45fca4cf/result.json) · [文件清单](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/65ae33af-1d39-4a1f-9895-5e2e45fca4cf/files.json) · [轨迹](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/65ae33af-1d39-4a1f-9895-5e2e45fca4cf/agent/trajectory.jsonl) |
| test:6900 | completed | 1 | 6.62 | 0.00 | complete / not-produced | — | [result](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/588e3523-71cf-459b-a20a-4896733e6ae1/result.json) · [文件清单](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/588e3523-71cf-459b-a20a-4896733e6ae1/files.json) · [轨迹](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/588e3523-71cf-459b-a20a-4896733e6ae1/agent/trajectory.jsonl) |
| test:6928 | completed | 1 | 6.51 | 0.00 | complete / not-produced | — | [result](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/50a6ea52-b316-42c0-ada4-9c8e244c19e5/result.json) · [文件清单](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/50a6ea52-b316-42c0-ada4-9c8e244c19e5/files.json) · [轨迹](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/50a6ea52-b316-42c0-ada4-9c8e244c19e5/agent/trajectory.jsonl) |
| test:6929 | completed | 1 | 6.33 | 0.00 | complete / not-produced | — | [result](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/fab0c12f-145e-4710-8ee1-37eca4dbadd4/result.json) · [文件清单](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/fab0c12f-145e-4710-8ee1-37eca4dbadd4/files.json) · [轨迹](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/fab0c12f-145e-4710-8ee1-37eca4dbadd4/agent/trajectory.jsonl) |
| test:7161 | completed | 1 | 56.68 | 0.00 | complete / not-produced | — | [result](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/8ac4db46-7816-4837-97b3-a6de71244081/result.json) · [文件清单](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/8ac4db46-7816-4837-97b3-a6de71244081/files.json) · [轨迹](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/8ac4db46-7816-4837-97b3-a6de71244081/agent/trajectory.jsonl) |
| test:7181 | completed | 1 | 6.40 | 0.00 | complete / not-produced | — | [result](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/c62951e9-5648-40d6-a75f-d6500295d312/result.json) · [文件清单](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/c62951e9-5648-40d6-a75f-d6500295d312/files.json) · [轨迹](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/c62951e9-5648-40d6-a75f-d6500295d312/agent/trajectory.jsonl) |
| test:7217 | completed | 1 | 6.26 | 0.00 | complete / not-produced | — | [result](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/6ddf936a-c72f-4b56-a282-ff04fba6b987/result.json) · [文件清单](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/6ddf936a-c72f-4b56-a282-ff04fba6b987/files.json) · [轨迹](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/6ddf936a-c72f-4b56-a282-ff04fba6b987/agent/trajectory.jsonl) |
| test:7290 | completed | 1 | 6.11 | 0.00 | complete / not-produced | — | [result](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/30916747-35ac-4ec3-b9d6-1c01a1426871/result.json) · [文件清单](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/30916747-35ac-4ec3-b9d6-1c01a1426871/files.json) · [轨迹](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/30916747-35ac-4ec3-b9d6-1c01a1426871/agent/trajectory.jsonl) |
| test:7304 | completed | 1 | 6.18 | 0.00 | complete / not-produced | — | [result](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/d9e9f535-0935-46c5-adcf-636bbfe789a7/result.json) · [文件清单](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/d9e9f535-0935-46c5-adcf-636bbfe789a7/files.json) · [轨迹](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/d9e9f535-0935-46c5-adcf-636bbfe789a7/agent/trajectory.jsonl) |
| test:7312 | completed | 1 | 6.42 | 0.00 | complete / not-produced | — | [result](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/63b92f50-a32a-4d8c-b958-c4faf34fa3ce/result.json) · [文件清单](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/63b92f50-a32a-4d8c-b958-c4faf34fa3ce/files.json) · [轨迹](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/63b92f50-a32a-4d8c-b958-c4faf34fa3ce/agent/trajectory.jsonl) |
| test:7448 | completed | 1 | 6.31 | 0.00 | complete / not-produced | — | [result](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/97487119-5af4-4534-a0b1-87225d5f1360/result.json) · [文件清单](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/97487119-5af4-4534-a0b1-87225d5f1360/files.json) · [轨迹](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/97487119-5af4-4534-a0b1-87225d5f1360/agent/trajectory.jsonl) |
| test:7462 | completed | 1 | 6.33 | 0.00 | complete / not-produced | — | [result](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/96075cf9-65fc-45a4-ac3c-b8126fe1ba50/result.json) · [文件清单](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/96075cf9-65fc-45a4-ac3c-b8126fe1ba50/files.json) · [轨迹](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/96075cf9-65fc-45a4-ac3c-b8126fe1ba50/agent/trajectory.jsonl) |
| test:7526 | completed | 1 | 6.27 | 0.00 | complete / not-produced | — | [result](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/9f221920-71f9-4592-a483-8223db28f49f/result.json) · [文件清单](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/9f221920-71f9-4592-a483-8223db28f49f/files.json) · [轨迹](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/9f221920-71f9-4592-a483-8223db28f49f/agent/trajectory.jsonl) |
| test:7727 | completed | 1 | 6.42 | 0.00 | complete / not-produced | — | [result](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/a5bb510e-545a-49b9-905e-c717c53a417f/result.json) · [文件清单](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/a5bb510e-545a-49b9-905e-c717c53a417f/files.json) · [轨迹](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/a5bb510e-545a-49b9-905e-c717c53a417f/agent/trajectory.jsonl) |
| test:7752 | completed | 0 | 6.40 | 0.00 | complete / not-produced | — | [result](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/a2d16a0e-ec4f-4ffd-8f6f-46778bf0af55/result.json) · [文件清单](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/a2d16a0e-ec4f-4ffd-8f6f-46778bf0af55/files.json) · [轨迹](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/a2d16a0e-ec4f-4ffd-8f6f-46778bf0af55/agent/trajectory.jsonl) |
| test:7838 | completed | 1 | 6.35 | 0.00 | complete / not-produced | — | [result](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/21756e23-05c1-4d09-9165-11b66f17c9ba/result.json) · [文件清单](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/21756e23-05c1-4d09-9165-11b66f17c9ba/files.json) · [轨迹](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/21756e23-05c1-4d09-9165-11b66f17c9ba/agent/trajectory.jsonl) |
| test:7954 | completed | 1 | 6.17 | 0.00 | complete / not-produced | — | [result](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/a6c73e26-f17c-4847-a452-13385ab4e253/result.json) · [文件清单](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/a6c73e26-f17c-4847-a452-13385ab4e253/files.json) · [轨迹](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/a6c73e26-f17c-4847-a452-13385ab4e253/agent/trajectory.jsonl) |
| test:7976 | completed | 1 | 6.28 | 0.00 | complete / not-produced | — | [result](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/449c7556-4028-4d84-9cc1-875277a50eae/result.json) · [文件清单](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/449c7556-4028-4d84-9cc1-875277a50eae/files.json) · [轨迹](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/449c7556-4028-4d84-9cc1-875277a50eae/agent/trajectory.jsonl) |
| test:8199 | completed | 1 | 6.28 | 0.00 | complete / not-produced | — | [result](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/a46d0162-5a57-42aa-b324-f6dc81d6b693/result.json) · [文件清单](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/a46d0162-5a57-42aa-b324-f6dc81d6b693/files.json) · [轨迹](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/a46d0162-5a57-42aa-b324-f6dc81d6b693/agent/trajectory.jsonl) |
| test:8207 | completed | 1 | 6.09 | 0.00 | complete / not-produced | — | [result](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/5b259109-e9e2-4d73-9f88-0991b958146f/result.json) · [文件清单](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/5b259109-e9e2-4d73-9f88-0991b958146f/files.json) · [轨迹](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/5b259109-e9e2-4d73-9f88-0991b958146f/agent/trajectory.jsonl) |
| test:8304 | completed | 1 | 6.12 | 0.00 | complete / not-produced | — | [result](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/487a6fc6-b006-4e8b-8e4f-793d25c03588/result.json) · [文件清单](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/487a6fc6-b006-4e8b-8e4f-793d25c03588/files.json) · [轨迹](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/487a6fc6-b006-4e8b-8e4f-793d25c03588/agent/trajectory.jsonl) |
| test:8366 | completed | 1 | 6.26 | 0.00 | complete / not-produced | — | [result](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/f43d2394-4788-40f8-98f1-1a78561f68f8/result.json) · [文件清单](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/f43d2394-4788-40f8-98f1-1a78561f68f8/files.json) · [轨迹](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/f43d2394-4788-40f8-98f1-1a78561f68f8/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

