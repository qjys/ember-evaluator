<!-- snapshotDigest: 73066b84a7819c66d8ed661df8642ac7afa483ca4412bbc418ee417c8118100c -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 66.67%（16/24）**

Run: fe79c109-3884-49db-95f6-90a2cf03c74e · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T11:32:16.122Z / 2026-11-12T11:35:17.918Z |
| 总耗时 | 2 分 55 秒 |
| 答对 / 答错 / 解题超时 | 16 / 8 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 16 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 66.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 分 55 秒 |
| 环境准备耗时 | 1 分 31 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 26 秒 | 13 秒 | 1 分 1 秒 | 24 |
| 任务准备 | 0.37 毫秒 | 0.2 毫秒 | 0.75 毫秒 | 24 |
| 环境启动 | 9 秒 | 4 秒 | 13 秒 | 24 |
| 解题 | 11 秒 | 6 秒 | 45 秒 | 24 |
| 产物传输 | 2 秒 | 780.44 毫秒 | 3 秒 | 24 |
| 资源清理 | 5 秒 | 2 秒 | 7 秒 | 24 |
| 评分 | 0.46 毫秒 | 0.15 毫秒 | 2.66 毫秒 | 24 |
| 证据收集 | 8.09 毫秒 | 3.14 毫秒 | 18.92 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 41e26f9a-f276-4893-a848-4262c2267079 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 281,846 | 19,952 | 301,798 | 24 / 24 | — |
| 运行累计 | 281,846 | 19,952 | 301,798 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:5328 | completed | 0 | 6.23 | 0.00 | complete / not-produced | — | [result](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/8bf1d96c-87ac-438e-a4ec-4408ad51bdcb/result.json) · [文件清单](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/8bf1d96c-87ac-438e-a4ec-4408ad51bdcb/files.json) · [轨迹](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/8bf1d96c-87ac-438e-a4ec-4408ad51bdcb/agent/trajectory.jsonl) |
| test:5361 | completed | 0 | 9.13 | 0.00 | complete / not-produced | — | [result](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/26815f3a-86a3-455b-a0cd-26de5d10f31f/result.json) · [文件清单](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/26815f3a-86a3-455b-a0cd-26de5d10f31f/files.json) · [轨迹](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/26815f3a-86a3-455b-a0cd-26de5d10f31f/agent/trajectory.jsonl) |
| test:5457 | completed | 1 | 6.36 | 0.00 | complete / not-produced | — | [result](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/916ac49a-fcfa-43e1-bfe4-3eb123f9977b/result.json) · [文件清单](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/916ac49a-fcfa-43e1-bfe4-3eb123f9977b/files.json) · [轨迹](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/916ac49a-fcfa-43e1-bfe4-3eb123f9977b/agent/trajectory.jsonl) |
| test:5461 | completed | 1 | 6.24 | 0.00 | complete / not-produced | — | [result](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/6def6316-8e9b-47bc-b23e-5aa6c39af6b0/result.json) · [文件清单](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/6def6316-8e9b-47bc-b23e-5aa6c39af6b0/files.json) · [轨迹](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/6def6316-8e9b-47bc-b23e-5aa6c39af6b0/agent/trajectory.jsonl) |
| test:5530 | completed | 0 | 11.43 | 0.00 | complete / not-produced | — | [result](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/7c845677-3916-41e5-9490-5ed8a29e162b/result.json) · [文件清单](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/7c845677-3916-41e5-9490-5ed8a29e162b/files.json) · [轨迹](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/7c845677-3916-41e5-9490-5ed8a29e162b/agent/trajectory.jsonl) |
| test:5578 | completed | 1 | 6.08 | 0.00 | complete / not-produced | — | [result](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/988bbfdb-d199-4416-9386-7f848c0527ea/result.json) · [文件清单](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/988bbfdb-d199-4416-9386-7f848c0527ea/files.json) · [轨迹](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/988bbfdb-d199-4416-9386-7f848c0527ea/agent/trajectory.jsonl) |
| test:5580 | completed | 1 | 6.22 | 0.00 | complete / not-produced | — | [result](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/506dd096-c9c4-4cab-8931-af3f26f740c7/result.json) · [文件清单](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/506dd096-c9c4-4cab-8931-af3f26f740c7/files.json) · [轨迹](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/506dd096-c9c4-4cab-8931-af3f26f740c7/agent/trajectory.jsonl) |
| test:5795 | completed | 1 | 6.29 | 0.00 | complete / not-produced | — | [result](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/fd250cd8-665b-4725-a933-86bba5e450b5/result.json) · [文件清单](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/fd250cd8-665b-4725-a933-86bba5e450b5/files.json) · [轨迹](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/fd250cd8-665b-4725-a933-86bba5e450b5/agent/trajectory.jsonl) |
| test:5919 | completed | 0 | 6.11 | 0.00 | complete / not-produced | — | [result](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/e4743e2c-ac6c-4fe7-b06f-b9a20f828304/result.json) · [文件清单](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/e4743e2c-ac6c-4fe7-b06f-b9a20f828304/files.json) · [轨迹](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/e4743e2c-ac6c-4fe7-b06f-b9a20f828304/agent/trajectory.jsonl) |
| test:5940 | completed | 1 | 5.89 | 0.00 | complete / not-produced | — | [result](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/0e51e8ef-144d-45e2-97a2-c14cc2b8d85e/result.json) · [文件清单](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/0e51e8ef-144d-45e2-97a2-c14cc2b8d85e/files.json) · [轨迹](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/0e51e8ef-144d-45e2-97a2-c14cc2b8d85e/agent/trajectory.jsonl) |
| test:6055 | completed | 1 | 6.14 | 0.00 | complete / not-produced | — | [result](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/2e1623e8-e9ee-4245-a2c7-1131ade63ceb/result.json) · [文件清单](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/2e1623e8-e9ee-4245-a2c7-1131ade63ceb/files.json) · [轨迹](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/2e1623e8-e9ee-4245-a2c7-1131ade63ceb/agent/trajectory.jsonl) |
| test:6095 | completed | 1 | 6.05 | 0.00 | complete / not-produced | — | [result](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/73844096-34a3-4146-8717-861154c50ffd/result.json) · [文件清单](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/73844096-34a3-4146-8717-861154c50ffd/files.json) · [轨迹](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/73844096-34a3-4146-8717-861154c50ffd/agent/trajectory.jsonl) |
| test:6120 | completed | 1 | 6.29 | 0.00 | complete / not-produced | — | [result](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/c46c6add-7040-45b4-9be7-0ba313029738/result.json) · [文件清单](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/c46c6add-7040-45b4-9be7-0ba313029738/files.json) · [轨迹](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/c46c6add-7040-45b4-9be7-0ba313029738/agent/trajectory.jsonl) |
| test:6123 | completed | 0 | 33.05 | 0.00 | complete / not-produced | — | [result](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/452a2a3c-b380-4744-80ae-147bc10faef3/result.json) · [文件清单](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/452a2a3c-b380-4744-80ae-147bc10faef3/files.json) · [轨迹](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/452a2a3c-b380-4744-80ae-147bc10faef3/agent/trajectory.jsonl) |
| test:6147 | completed | 0 | 44.75 | 0.00 | complete / not-produced | — | [result](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/50187575-8269-46b8-9699-121eed82b96b/result.json) · [文件清单](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/50187575-8269-46b8-9699-121eed82b96b/files.json) · [轨迹](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/50187575-8269-46b8-9699-121eed82b96b/agent/trajectory.jsonl) |
| test:6198 | completed | 1 | 27.07 | 0.00 | complete / not-produced | — | [result](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/484ca25d-e0f3-407c-8994-3394af6d8cea/result.json) · [文件清单](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/484ca25d-e0f3-407c-8994-3394af6d8cea/files.json) · [轨迹](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/484ca25d-e0f3-407c-8994-3394af6d8cea/agent/trajectory.jsonl) |
| test:6223 | completed | 1 | 5.71 | 0.00 | complete / not-produced | — | [result](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/49f1d0fa-37d9-4d48-a09f-73a72e5b22bc/result.json) · [文件清单](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/49f1d0fa-37d9-4d48-a09f-73a72e5b22bc/files.json) · [轨迹](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/49f1d0fa-37d9-4d48-a09f-73a72e5b22bc/agent/trajectory.jsonl) |
| test:6235 | completed | 1 | 5.74 | 0.00 | complete / not-produced | — | [result](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/08ed925b-9ab9-4124-95cd-b63e5f8f4f84/result.json) · [文件清单](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/08ed925b-9ab9-4124-95cd-b63e5f8f4f84/files.json) · [轨迹](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/08ed925b-9ab9-4124-95cd-b63e5f8f4f84/agent/trajectory.jsonl) |
| test:6403 | completed | 1 | 23.36 | 0.00 | complete / not-produced | — | [result](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/e3f6f2df-2a69-4b20-8389-83f4a9646d20/result.json) · [文件清单](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/e3f6f2df-2a69-4b20-8389-83f4a9646d20/files.json) · [轨迹](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/e3f6f2df-2a69-4b20-8389-83f4a9646d20/agent/trajectory.jsonl) |
| test:6436 | completed | 1 | 5.97 | 0.00 | complete / not-produced | — | [result](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/e30df449-ed6a-461f-8930-b47ca082bbe9/result.json) · [文件清单](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/e30df449-ed6a-461f-8930-b47ca082bbe9/files.json) · [轨迹](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/e30df449-ed6a-461f-8930-b47ca082bbe9/agent/trajectory.jsonl) |
| test:6508 | completed | 1 | 5.87 | 0.00 | complete / not-produced | — | [result](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/beb88427-15ab-4bbe-a1ca-f2cbb9970448/result.json) · [文件清单](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/beb88427-15ab-4bbe-a1ca-f2cbb9970448/files.json) · [轨迹](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/beb88427-15ab-4bbe-a1ca-f2cbb9970448/agent/trajectory.jsonl) |
| test:6593 | completed | 1 | 6.24 | 0.00 | complete / not-produced | — | [result](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/cd225357-356a-41d8-bc64-bf748286d4e1/result.json) · [文件清单](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/cd225357-356a-41d8-bc64-bf748286d4e1/files.json) · [轨迹](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/cd225357-356a-41d8-bc64-bf748286d4e1/agent/trajectory.jsonl) |
| test:6655 | completed | 0 | 10.40 | 0.00 | complete / not-produced | — | [result](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/0f9efafe-77d0-49e1-90b3-7c6926bf11d8/result.json) · [文件清单](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/0f9efafe-77d0-49e1-90b3-7c6926bf11d8/files.json) · [轨迹](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/0f9efafe-77d0-49e1-90b3-7c6926bf11d8/agent/trajectory.jsonl) |
| test:6738 | completed | 0 | 6.29 | 0.00 | complete / not-produced | — | [result](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/da996389-050f-4264-864e-958ea8df7797/result.json) · [文件清单](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/da996389-050f-4264-864e-958ea8df7797/files.json) · [轨迹](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/da996389-050f-4264-864e-958ea8df7797/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

