<!-- snapshotDigest: 3619b0169807eee02a4e017783151a4af6797abb5f138290490e1de28caa79cd -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 91.67%（22/24）**

Run: 9f91a139-2d18-4c86-b41b-c4d20dbc970d · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T11:29:02.649Z / 2026-11-12T11:34:22.017Z |
| 总耗时 | 5 分 8 秒 |
| 答对 / 答错 / 解题超时 | 22 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 22 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 91.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 8 秒 |
| 环境准备耗时 | 1 分 53 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 33 秒 | 15 秒 | 3 分 34 秒 | 24 |
| 任务准备 | 0.49 毫秒 | 0.26 毫秒 | 1.96 毫秒 | 24 |
| 环境启动 | 11 秒 | 5 秒 | 14 秒 | 24 |
| 解题 | 16 秒 | 6 秒 | 3 分 18 秒 | 24 |
| 产物传输 | 2 秒 | 820.6 毫秒 | 3 秒 | 24 |
| 资源清理 | 5 秒 | 2 秒 | 7 秒 | 24 |
| 评分 | 0.56 毫秒 | 0.18 毫秒 | 3.87 毫秒 | 24 |
| 证据收集 | 12.36 毫秒 | 3.72 毫秒 | 37.98 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| f0640306-a4ee-4855-b5c0-5bb631d1c773 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 237,790 | 39,630 | 277,420 | 24 / 24 | — |
| 运行累计 | 237,790 | 39,630 | 277,420 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:2882 | completed | 0 | 6.39 | 0.00 | complete / not-produced | — | [result](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/20a56dbe-2788-4e85-8b5f-de89d8115fcf/result.json) · [文件清单](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/20a56dbe-2788-4e85-8b5f-de89d8115fcf/files.json) · [轨迹](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/20a56dbe-2788-4e85-8b5f-de89d8115fcf/agent/trajectory.jsonl) |
| test:2951 | completed | 1 | 6.47 | 0.00 | complete / not-produced | — | [result](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/c6f75337-1fc4-4ab1-85d9-f0ed28a4e3ae/result.json) · [文件清单](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/c6f75337-1fc4-4ab1-85d9-f0ed28a4e3ae/files.json) · [轨迹](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/c6f75337-1fc4-4ab1-85d9-f0ed28a4e3ae/agent/trajectory.jsonl) |
| test:3037 | completed | 1 | 6.67 | 0.00 | complete / not-produced | — | [result](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/94acb64f-268f-46e7-9236-4378c7290934/result.json) · [文件清单](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/94acb64f-268f-46e7-9236-4378c7290934/files.json) · [轨迹](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/94acb64f-268f-46e7-9236-4378c7290934/agent/trajectory.jsonl) |
| test:3053 | completed | 0 | 20.06 | 0.00 | complete / not-produced | — | [result](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/8d696ce8-7f8d-4ff2-af48-2a26e8049fe7/result.json) · [文件清单](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/8d696ce8-7f8d-4ff2-af48-2a26e8049fe7/files.json) · [轨迹](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/8d696ce8-7f8d-4ff2-af48-2a26e8049fe7/agent/trajectory.jsonl) |
| test:3136 | completed | 1 | 7.13 | 0.00 | complete / not-produced | — | [result](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/f2f20950-9a06-4577-a07b-c70ac707b32c/result.json) · [文件清单](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/f2f20950-9a06-4577-a07b-c70ac707b32c/files.json) · [轨迹](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/f2f20950-9a06-4577-a07b-c70ac707b32c/agent/trajectory.jsonl) |
| test:3165 | completed | 1 | 6.31 | 0.00 | complete / not-produced | — | [result](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/a1c9b24b-5bdc-4b57-95b2-3bb1c65129e6/result.json) · [文件清单](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/a1c9b24b-5bdc-4b57-95b2-3bb1c65129e6/files.json) · [轨迹](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/a1c9b24b-5bdc-4b57-95b2-3bb1c65129e6/agent/trajectory.jsonl) |
| test:3196 | completed | 1 | 6.28 | 0.00 | complete / not-produced | — | [result](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/ad8e4a6c-7a8a-47eb-b003-60675b439574/result.json) · [文件清单](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/ad8e4a6c-7a8a-47eb-b003-60675b439574/files.json) · [轨迹](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/ad8e4a6c-7a8a-47eb-b003-60675b439574/agent/trajectory.jsonl) |
| test:3231 | completed | 1 | 6.18 | 0.00 | complete / not-produced | — | [result](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/3e4dd2c5-a668-4958-83b7-9357e53585e1/result.json) · [文件清单](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/3e4dd2c5-a668-4958-83b7-9357e53585e1/files.json) · [轨迹](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/3e4dd2c5-a668-4958-83b7-9357e53585e1/agent/trajectory.jsonl) |
| test:3236 | completed | 1 | 6.58 | 0.00 | complete / not-produced | — | [result](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/f0f2b44f-afdd-49aa-a13f-e8166c1eead1/result.json) · [文件清单](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/f0f2b44f-afdd-49aa-a13f-e8166c1eead1/files.json) · [轨迹](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/f0f2b44f-afdd-49aa-a13f-e8166c1eead1/agent/trajectory.jsonl) |
| test:3270 | completed | 1 | 6.24 | 0.00 | complete / not-produced | — | [result](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/0a73e679-2728-4bb2-a1d7-555fca12d75a/result.json) · [文件清单](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/0a73e679-2728-4bb2-a1d7-555fca12d75a/files.json) · [轨迹](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/0a73e679-2728-4bb2-a1d7-555fca12d75a/agent/trajectory.jsonl) |
| test:3331 | completed | 1 | 6.21 | 0.00 | complete / not-produced | — | [result](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/2c2b4984-4511-4c4c-93c0-98168d11d1df/result.json) · [文件清单](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/2c2b4984-4511-4c4c-93c0-98168d11d1df/files.json) · [轨迹](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/2c2b4984-4511-4c4c-93c0-98168d11d1df/agent/trajectory.jsonl) |
| test:3488 | completed | 1 | 7.57 | 0.00 | complete / not-produced | — | [result](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/2a18a203-a6d9-4ac6-8396-968ef5e00ffc/result.json) · [文件清单](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/2a18a203-a6d9-4ac6-8396-968ef5e00ffc/files.json) · [轨迹](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/2a18a203-a6d9-4ac6-8396-968ef5e00ffc/agent/trajectory.jsonl) |
| test:3491 | completed | 1 | 198.36 | 0.00 | complete / not-produced | — | [result](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/d7d3cf98-84ac-4529-836b-b2533f52f773/result.json) · [文件清单](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/d7d3cf98-84ac-4529-836b-b2533f52f773/files.json) · [轨迹](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/d7d3cf98-84ac-4529-836b-b2533f52f773/agent/trajectory.jsonl) |
| test:3552 | completed | 1 | 6.12 | 0.00 | complete / not-produced | — | [result](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/46eae718-c0cc-4ac0-a3b5-4f5fac121978/result.json) · [文件清单](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/46eae718-c0cc-4ac0-a3b5-4f5fac121978/files.json) · [轨迹](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/46eae718-c0cc-4ac0-a3b5-4f5fac121978/agent/trajectory.jsonl) |
| test:3599 | completed | 1 | 6.69 | 0.00 | complete / not-produced | — | [result](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/d758218d-f947-4f6e-9233-255392011eaf/result.json) · [文件清单](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/d758218d-f947-4f6e-9233-255392011eaf/files.json) · [轨迹](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/d758218d-f947-4f6e-9233-255392011eaf/agent/trajectory.jsonl) |
| test:3626 | completed | 1 | 6.28 | 0.00 | complete / not-produced | — | [result](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/ce44f3ef-9ff6-4f75-9d19-b587e9bda200/result.json) · [文件清单](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/ce44f3ef-9ff6-4f75-9d19-b587e9bda200/files.json) · [轨迹](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/ce44f3ef-9ff6-4f75-9d19-b587e9bda200/agent/trajectory.jsonl) |
| test:4021 | completed | 1 | 9.95 | 0.00 | complete / not-produced | — | [result](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/80f39c86-6bf1-4378-8725-f978d60b49fb/result.json) · [文件清单](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/80f39c86-6bf1-4378-8725-f978d60b49fb/files.json) · [轨迹](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/80f39c86-6bf1-4378-8725-f978d60b49fb/agent/trajectory.jsonl) |
| test:4034 | completed | 1 | 6.09 | 0.00 | complete / not-produced | — | [result](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/6465193f-7a10-40b6-b71e-c36c845a22c9/result.json) · [文件清单](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/6465193f-7a10-40b6-b71e-c36c845a22c9/files.json) · [轨迹](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/6465193f-7a10-40b6-b71e-c36c845a22c9/agent/trajectory.jsonl) |
| test:4058 | completed | 1 | 6.13 | 0.00 | complete / not-produced | — | [result](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/6d73b5ed-30ea-4024-8244-3fbe5d7a07d0/result.json) · [文件清单](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/6d73b5ed-30ea-4024-8244-3fbe5d7a07d0/files.json) · [轨迹](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/6d73b5ed-30ea-4024-8244-3fbe5d7a07d0/agent/trajectory.jsonl) |
| test:4075 | completed | 1 | 5.80 | 0.00 | complete / not-produced | — | [result](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/1917e5cc-4b81-454b-a3f8-7ccc6a603191/result.json) · [文件清单](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/1917e5cc-4b81-454b-a3f8-7ccc6a603191/files.json) · [轨迹](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/1917e5cc-4b81-454b-a3f8-7ccc6a603191/agent/trajectory.jsonl) |
| test:4142 | completed | 1 | 6.21 | 0.00 | complete / not-produced | — | [result](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/48312c12-f124-418b-92d6-5563997a340e/result.json) · [文件清单](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/48312c12-f124-418b-92d6-5563997a340e/files.json) · [轨迹](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/48312c12-f124-418b-92d6-5563997a340e/agent/trajectory.jsonl) |
| test:4208 | completed | 1 | 5.84 | 0.00 | complete / not-produced | — | [result](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/34d0cc24-be86-4b4d-877b-e523a44a49d1/result.json) · [文件清单](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/34d0cc24-be86-4b4d-877b-e523a44a49d1/files.json) · [轨迹](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/34d0cc24-be86-4b4d-877b-e523a44a49d1/agent/trajectory.jsonl) |
| test:4298 | completed | 1 | 5.87 | 0.00 | complete / not-produced | — | [result](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/0b504f3b-2c57-4219-8f2c-6da5d4c2e718/result.json) · [文件清单](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/0b504f3b-2c57-4219-8f2c-6da5d4c2e718/files.json) · [轨迹](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/0b504f3b-2c57-4219-8f2c-6da5d4c2e718/agent/trajectory.jsonl) |
| test:4337 | completed | 1 | 19.11 | 0.00 | complete / not-produced | — | [result](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/24791d25-96fd-4527-8893-24a9960fd145/result.json) · [文件清单](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/24791d25-96fd-4527-8893-24a9960fd145/files.json) · [轨迹](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/24791d25-96fd-4527-8893-24a9960fd145/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

