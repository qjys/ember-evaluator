<!-- snapshotDigest: 7593f0c9636c67fe5d95313bb9b3d515598d94397ade88d1d9b8a32a8587217f -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 91.67%（22/24）**

Run: 0febb109-d42f-4eb5-a79a-12b14333f435 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:25:18.366Z / 2026-11-12T08:33:35.666Z |
| 总耗时 | 8 分 1 秒 |
| 答对 / 答错 / 解题超时 | 22 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 22 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 91.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 8 分 1 秒 |
| 环境准备耗时 | 5 分 11 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 55 秒 | 38 秒 | 2 分 33 秒 | 24 |
| 任务准备 | 0.48 毫秒 | 0.29 毫秒 | 1.98 毫秒 | 24 |
| 环境启动 | 19 秒 | 15 秒 | 22 秒 | 24 |
| 解题 | 26 秒 | 13 秒 | 2 分 0 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 8 秒 | 5 秒 | 10 秒 | 24 |
| 评分 | 0.7 毫秒 | 0.26 毫秒 | 5.37 毫秒 | 24 |
| 证据收集 | 13.26 毫秒 | 3.66 毫秒 | 61.5 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 6c95fde5-d6b0-41a7-bc90-4291fa729b11 | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 125,261 | 25,386 | 150,647 | 24 / 24 | — |
| 运行累计 | 125,261 | 25,386 | 150,647 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:6508 | completed | 0 | 119.83 | 0.00 | complete / not-produced | — | [result](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/c4bb0d8d-8aa5-4bad-8aed-ca01eaddce37/result.json) · [文件清单](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/c4bb0d8d-8aa5-4bad-8aed-ca01eaddce37/files.json) · [轨迹](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/c4bb0d8d-8aa5-4bad-8aed-ca01eaddce37/agent/trajectory.jsonl) |
| test:6593 | completed | 1 | 25.27 | 0.00 | complete / not-produced | — | [result](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/908cb165-1de6-40f3-b366-226d8bd73af4/result.json) · [文件清单](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/908cb165-1de6-40f3-b366-226d8bd73af4/files.json) · [轨迹](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/908cb165-1de6-40f3-b366-226d8bd73af4/agent/trajectory.jsonl) |
| test:6655 | completed | 1 | 27.38 | 0.00 | complete / not-produced | — | [result](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/9b619c43-f559-4848-b311-18807909e75a/result.json) · [文件清单](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/9b619c43-f559-4848-b311-18807909e75a/files.json) · [轨迹](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/9b619c43-f559-4848-b311-18807909e75a/agent/trajectory.jsonl) |
| test:6738 | completed | 1 | 21.23 | 0.00 | complete / not-produced | — | [result](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/9ef573c4-4652-4ad6-b34c-b344dc2d656c/result.json) · [文件清单](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/9ef573c4-4652-4ad6-b34c-b344dc2d656c/files.json) · [轨迹](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/9ef573c4-4652-4ad6-b34c-b344dc2d656c/agent/trajectory.jsonl) |
| test:6751 | completed | 1 | 17.53 | 0.00 | complete / not-produced | — | [result](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/b31ac3cb-dc6f-4b05-bf0c-83f88cf4ec53/result.json) · [文件清单](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/b31ac3cb-dc6f-4b05-bf0c-83f88cf4ec53/files.json) · [轨迹](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/b31ac3cb-dc6f-4b05-bf0c-83f88cf4ec53/agent/trajectory.jsonl) |
| test:6784 | completed | 1 | 12.56 | 0.00 | complete / not-produced | — | [result](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/d80dd50e-e5c3-4e19-a0a6-ce26dc237d23/result.json) · [文件清单](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/d80dd50e-e5c3-4e19-a0a6-ce26dc237d23/files.json) · [轨迹](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/d80dd50e-e5c3-4e19-a0a6-ce26dc237d23/agent/trajectory.jsonl) |
| test:6792 | completed | 1 | 16.26 | 0.00 | complete / not-produced | — | [result](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/fef97852-7afc-4a82-80ee-0aec21799bf7/result.json) · [文件清单](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/fef97852-7afc-4a82-80ee-0aec21799bf7/files.json) · [轨迹](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/fef97852-7afc-4a82-80ee-0aec21799bf7/agent/trajectory.jsonl) |
| test:6900 | completed | 1 | 17.74 | 0.00 | complete / not-produced | — | [result](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/05ef0483-7763-4862-98c3-7c90b4c00826/result.json) · [文件清单](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/05ef0483-7763-4862-98c3-7c90b4c00826/files.json) · [轨迹](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/05ef0483-7763-4862-98c3-7c90b4c00826/agent/trajectory.jsonl) |
| test:6928 | completed | 1 | 18.67 | 0.00 | complete / not-produced | — | [result](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/dde6ce2a-556e-4156-83c1-3c927df2e415/result.json) · [文件清单](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/dde6ce2a-556e-4156-83c1-3c927df2e415/files.json) · [轨迹](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/dde6ce2a-556e-4156-83c1-3c927df2e415/agent/trajectory.jsonl) |
| test:6929 | completed | 1 | 24.82 | 0.00 | complete / not-produced | — | [result](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/0afd2bbd-8dab-4f91-9735-022bd41d7d58/result.json) · [文件清单](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/0afd2bbd-8dab-4f91-9735-022bd41d7d58/files.json) · [轨迹](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/0afd2bbd-8dab-4f91-9735-022bd41d7d58/agent/trajectory.jsonl) |
| test:7161 | completed | 1 | 59.55 | 0.00 | complete / not-produced | — | [result](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/5b571fdb-5935-48d1-996b-a9eab2198c65/result.json) · [文件清单](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/5b571fdb-5935-48d1-996b-a9eab2198c65/files.json) · [轨迹](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/5b571fdb-5935-48d1-996b-a9eab2198c65/agent/trajectory.jsonl) |
| test:7181 | completed | 1 | 21.24 | 0.01 | complete / not-produced | — | [result](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/a9ceb572-dddf-41fd-a7a6-abb1fd16d1cb/result.json) · [文件清单](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/a9ceb572-dddf-41fd-a7a6-abb1fd16d1cb/files.json) · [轨迹](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/a9ceb572-dddf-41fd-a7a6-abb1fd16d1cb/agent/trajectory.jsonl) |
| test:7217 | completed | 1 | 23.65 | 0.00 | complete / not-produced | — | [result](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/213de247-4eb1-4ce2-9e10-cb7a3b08c087/result.json) · [文件清单](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/213de247-4eb1-4ce2-9e10-cb7a3b08c087/files.json) · [轨迹](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/213de247-4eb1-4ce2-9e10-cb7a3b08c087/agent/trajectory.jsonl) |
| test:7290 | completed | 1 | 18.47 | 0.00 | complete / not-produced | — | [result](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/e32b2211-4b5b-4039-90b7-9a4f3fa437a4/result.json) · [文件清单](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/e32b2211-4b5b-4039-90b7-9a4f3fa437a4/files.json) · [轨迹](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/e32b2211-4b5b-4039-90b7-9a4f3fa437a4/agent/trajectory.jsonl) |
| test:7304 | completed | 1 | 16.37 | 0.00 | complete / not-produced | — | [result](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/a39ea1a5-aeda-4fb9-a158-8d35ab7d9dcf/result.json) · [文件清单](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/a39ea1a5-aeda-4fb9-a158-8d35ab7d9dcf/files.json) · [轨迹](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/a39ea1a5-aeda-4fb9-a158-8d35ab7d9dcf/agent/trajectory.jsonl) |
| test:7312 | completed | 1 | 16.29 | 0.00 | complete / not-produced | — | [result](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/be30a53f-e4c6-4d87-aff4-a75d1acb39b9/result.json) · [文件清单](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/be30a53f-e4c6-4d87-aff4-a75d1acb39b9/files.json) · [轨迹](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/be30a53f-e4c6-4d87-aff4-a75d1acb39b9/agent/trajectory.jsonl) |
| test:7448 | completed | 1 | 34.44 | 0.00 | complete / not-produced | — | [result](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/b137f4c0-ca0d-4a68-b2f1-16a688f3f1a5/result.json) · [文件清单](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/b137f4c0-ca0d-4a68-b2f1-16a688f3f1a5/files.json) · [轨迹](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/b137f4c0-ca0d-4a68-b2f1-16a688f3f1a5/agent/trajectory.jsonl) |
| test:7462 | completed | 1 | 18.84 | 0.00 | complete / not-produced | — | [result](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/ac0fc3df-5768-47ac-b798-82c7ddd4709e/result.json) · [文件清单](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/ac0fc3df-5768-47ac-b798-82c7ddd4709e/files.json) · [轨迹](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/ac0fc3df-5768-47ac-b798-82c7ddd4709e/agent/trajectory.jsonl) |
| test:7526 | completed | 1 | 23.22 | 0.00 | complete / not-produced | — | [result](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/31b41cba-03cd-4e9b-a385-f1c0bbd9c9a6/result.json) · [文件清单](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/31b41cba-03cd-4e9b-a385-f1c0bbd9c9a6/files.json) · [轨迹](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/31b41cba-03cd-4e9b-a385-f1c0bbd9c9a6/agent/trajectory.jsonl) |
| test:7727 | completed | 1 | 16.42 | 0.00 | complete / not-produced | — | [result](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/e1b8ebf5-0d99-4baf-b862-202fb93e2cce/result.json) · [文件清单](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/e1b8ebf5-0d99-4baf-b862-202fb93e2cce/files.json) · [轨迹](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/e1b8ebf5-0d99-4baf-b862-202fb93e2cce/agent/trajectory.jsonl) |
| test:7752 | completed | 0 | 18.70 | 0.00 | complete / not-produced | — | [result](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/43f1a105-41b6-4873-ab09-a2ca1d550e24/result.json) · [文件清单](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/43f1a105-41b6-4873-ab09-a2ca1d550e24/files.json) · [轨迹](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/43f1a105-41b6-4873-ab09-a2ca1d550e24/agent/trajectory.jsonl) |
| test:7838 | completed | 1 | 17.05 | 0.00 | complete / not-produced | — | [result](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/c9cb077e-eb97-4ec6-9bf1-d3ed643cc840/result.json) · [文件清单](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/c9cb077e-eb97-4ec6-9bf1-d3ed643cc840/files.json) · [轨迹](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/c9cb077e-eb97-4ec6-9bf1-d3ed643cc840/agent/trajectory.jsonl) |
| test:7954 | completed | 1 | 14.14 | 0.00 | complete / not-produced | — | [result](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/cf8c0bff-394c-40e0-9dc7-be52aeb13817/result.json) · [文件清单](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/cf8c0bff-394c-40e0-9dc7-be52aeb13817/files.json) · [轨迹](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/cf8c0bff-394c-40e0-9dc7-be52aeb13817/agent/trajectory.jsonl) |
| test:7976 | completed | 1 | 14.32 | 0.00 | complete / not-produced | — | [result](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/6013a227-a15c-4be4-b431-1dc54708dc93/result.json) · [文件清单](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/6013a227-a15c-4be4-b431-1dc54708dc93/files.json) · [轨迹](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/6013a227-a15c-4be4-b431-1dc54708dc93/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

