<!-- snapshotDigest: 724e7bab04dd489d85c58d0b15b57fda22b9430498944dd0a7e9556615b7f8da -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 87.50%（21/24）**

Run: e3248433-2fc1-4e80-997d-78cbdfa47e8d · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:11:00.215Z / 2026-11-12T08:17:44.098Z |
| 总耗时 | 6 分 31 秒 |
| 答对 / 答错 / 解题超时 | 21 / 3 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 21 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 87.50% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 6 分 31 秒 |
| 环境准备耗时 | 4 分 1 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 44 秒 | 33 秒 | 1 分 1 秒 | 24 |
| 任务准备 | 0.51 毫秒 | 0.25 毫秒 | 1.46 毫秒 | 24 |
| 环境启动 | 16 秒 | 11 秒 | 20 秒 | 24 |
| 解题 | 20 秒 | 14 秒 | 37 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 3 秒 | 24 |
| 资源清理 | 6 秒 | 5 秒 | 8 秒 | 24 |
| 评分 | 1.02 毫秒 | 0.29 毫秒 | 6.17 毫秒 | 24 |
| 证据收集 | 12.47 毫秒 | 4.37 毫秒 | 33.15 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| d9160697-0f4f-4712-84e1-0c2400b0fb04 | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 136,915 | 10,286 | 147,201 | 24 / 24 | — |
| 运行累计 | 136,915 | 10,286 | 147,201 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4142 | completed | 0 | 17.26 | 0.00 | complete / not-produced | — | [result](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/e99314ea-8787-40a5-af1c-5a4ef183adbe/result.json) · [文件清单](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/e99314ea-8787-40a5-af1c-5a4ef183adbe/files.json) · [轨迹](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/e99314ea-8787-40a5-af1c-5a4ef183adbe/agent/trajectory.jsonl) |
| test:4208 | completed | 1 | 15.48 | 0.00 | complete / not-produced | — | [result](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/89b768f5-ef63-4505-97fa-03d1e7915214/result.json) · [文件清单](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/89b768f5-ef63-4505-97fa-03d1e7915214/files.json) · [轨迹](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/89b768f5-ef63-4505-97fa-03d1e7915214/agent/trajectory.jsonl) |
| test:4298 | completed | 1 | 15.01 | 0.00 | complete / not-produced | — | [result](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/0cc4b811-b961-4b92-b926-69b7e2a507c9/result.json) · [文件清单](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/0cc4b811-b961-4b92-b926-69b7e2a507c9/files.json) · [轨迹](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/0cc4b811-b961-4b92-b926-69b7e2a507c9/agent/trajectory.jsonl) |
| test:4337 | completed | 1 | 27.37 | 0.01 | complete / not-produced | — | [result](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/c20b8d64-9b0d-4477-9784-99fee31a71af/result.json) · [文件清单](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/c20b8d64-9b0d-4477-9784-99fee31a71af/files.json) · [轨迹](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/c20b8d64-9b0d-4477-9784-99fee31a71af/agent/trajectory.jsonl) |
| test:4376 | completed | 1 | 20.91 | 0.00 | complete / not-produced | — | [result](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/4e58a66b-5ea1-4428-b5d1-e22c93752177/result.json) · [文件清单](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/4e58a66b-5ea1-4428-b5d1-e22c93752177/files.json) · [轨迹](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/4e58a66b-5ea1-4428-b5d1-e22c93752177/agent/trajectory.jsonl) |
| test:4405 | completed | 1 | 20.84 | 0.00 | complete / not-produced | — | [result](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/c77f6b10-9947-469b-8d4c-2cd2abc96e50/result.json) · [文件清单](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/c77f6b10-9947-469b-8d4c-2cd2abc96e50/files.json) · [轨迹](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/c77f6b10-9947-469b-8d4c-2cd2abc96e50/agent/trajectory.jsonl) |
| test:4552 | completed | 1 | 20.53 | 0.00 | complete / not-produced | — | [result](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/e9f357f7-0b0b-4e07-b5b0-07f72d1c7935/result.json) · [文件清单](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/e9f357f7-0b0b-4e07-b5b0-07f72d1c7935/files.json) · [轨迹](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/e9f357f7-0b0b-4e07-b5b0-07f72d1c7935/agent/trajectory.jsonl) |
| test:4560 | completed | 1 | 20.99 | 0.00 | complete / not-produced | — | [result](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/a95ad0c6-8e96-4c00-900e-6253441e07f5/result.json) · [文件清单](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/a95ad0c6-8e96-4c00-900e-6253441e07f5/files.json) · [轨迹](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/a95ad0c6-8e96-4c00-900e-6253441e07f5/agent/trajectory.jsonl) |
| test:4568 | completed | 1 | 21.10 | 0.00 | complete / not-produced | — | [result](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/77830ae0-8beb-43a9-9952-764e49ff8e1d/result.json) · [文件清单](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/77830ae0-8beb-43a9-9952-764e49ff8e1d/files.json) · [轨迹](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/77830ae0-8beb-43a9-9952-764e49ff8e1d/agent/trajectory.jsonl) |
| test:4580 | completed | 1 | 25.77 | 0.00 | complete / not-produced | — | [result](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/b5002efa-2663-402d-b6e5-06715e62fce5/result.json) · [文件清单](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/b5002efa-2663-402d-b6e5-06715e62fce5/files.json) · [轨迹](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/b5002efa-2663-402d-b6e5-06715e62fce5/agent/trajectory.jsonl) |
| test:4603 | completed | 1 | 21.66 | 0.00 | complete / not-produced | — | [result](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/736077ec-8138-4d9c-9346-578d8a7f2331/result.json) · [文件清单](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/736077ec-8138-4d9c-9346-578d8a7f2331/files.json) · [轨迹](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/736077ec-8138-4d9c-9346-578d8a7f2331/agent/trajectory.jsonl) |
| test:4625 | completed | 1 | 17.02 | 0.00 | complete / not-produced | — | [result](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/b800fdc1-de5c-46fc-a889-33c748dc67d7/result.json) · [文件清单](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/b800fdc1-de5c-46fc-a889-33c748dc67d7/files.json) · [轨迹](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/b800fdc1-de5c-46fc-a889-33c748dc67d7/agent/trajectory.jsonl) |
| test:4627 | completed | 1 | 15.40 | 0.00 | complete / not-produced | — | [result](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/4c3b7fc0-37bd-4ed1-9754-89984041b162/result.json) · [文件清单](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/4c3b7fc0-37bd-4ed1-9754-89984041b162/files.json) · [轨迹](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/4c3b7fc0-37bd-4ed1-9754-89984041b162/agent/trajectory.jsonl) |
| test:4651 | completed | 1 | 16.10 | 0.00 | complete / not-produced | — | [result](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/1c286d31-24a5-4ca9-8b51-9d16c96bc490/result.json) · [文件清单](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/1c286d31-24a5-4ca9-8b51-9d16c96bc490/files.json) · [轨迹](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/1c286d31-24a5-4ca9-8b51-9d16c96bc490/agent/trajectory.jsonl) |
| test:4670 | completed | 1 | 24.01 | 0.00 | complete / not-produced | — | [result](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/39fb8ea2-c9ed-4c07-9760-5374fe9ab291/result.json) · [文件清单](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/39fb8ea2-c9ed-4c07-9760-5374fe9ab291/files.json) · [轨迹](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/39fb8ea2-c9ed-4c07-9760-5374fe9ab291/agent/trajectory.jsonl) |
| test:4700 | completed | 1 | 14.16 | 0.00 | complete / not-produced | — | [result](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/5e3c8269-2fa4-4c88-afdb-f7bc8a718b53/result.json) · [文件清单](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/5e3c8269-2fa4-4c88-afdb-f7bc8a718b53/files.json) · [轨迹](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/5e3c8269-2fa4-4c88-afdb-f7bc8a718b53/agent/trajectory.jsonl) |
| test:4709 | completed | 0 | 15.98 | 0.00 | complete / not-produced | — | [result](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/f6f3e914-beef-4c6a-bc4a-2dff09c72c94/result.json) · [文件清单](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/f6f3e914-beef-4c6a-bc4a-2dff09c72c94/files.json) · [轨迹](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/f6f3e914-beef-4c6a-bc4a-2dff09c72c94/agent/trajectory.jsonl) |
| test:4763 | completed | 0 | 16.73 | 0.00 | complete / not-produced | — | [result](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/3398037f-5a35-4219-be59-02ebf6725d3a/result.json) · [文件清单](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/3398037f-5a35-4219-be59-02ebf6725d3a/files.json) · [轨迹](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/3398037f-5a35-4219-be59-02ebf6725d3a/agent/trajectory.jsonl) |
| test:4770 | completed | 1 | 16.06 | 0.00 | complete / not-produced | — | [result](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/24b4d74c-1f33-4297-aea6-0334d8d29e58/result.json) · [文件清单](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/24b4d74c-1f33-4297-aea6-0334d8d29e58/files.json) · [轨迹](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/24b4d74c-1f33-4297-aea6-0334d8d29e58/agent/trajectory.jsonl) |
| test:4786 | completed | 1 | 16.57 | 0.00 | complete / not-produced | — | [result](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/1a522e7c-4d22-488b-877d-e4149156d4b3/result.json) · [文件清单](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/1a522e7c-4d22-488b-877d-e4149156d4b3/files.json) · [轨迹](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/1a522e7c-4d22-488b-877d-e4149156d4b3/agent/trajectory.jsonl) |
| test:4879 | completed | 1 | 21.00 | 0.00 | complete / not-produced | — | [result](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/46a4dcba-3663-4861-9716-c132cfc60d8f/result.json) · [文件清单](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/46a4dcba-3663-4861-9716-c132cfc60d8f/files.json) · [轨迹](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/46a4dcba-3663-4861-9716-c132cfc60d8f/agent/trajectory.jsonl) |
| test:5078 | completed | 1 | 37.09 | 0.00 | complete / not-produced | — | [result](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/1acae37f-b4fe-4a47-87b7-dd44b2af468d/result.json) · [文件清单](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/1acae37f-b4fe-4a47-87b7-dd44b2af468d/files.json) · [轨迹](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/1acae37f-b4fe-4a47-87b7-dd44b2af468d/agent/trajectory.jsonl) |
| test:5123 | completed | 1 | 17.12 | 0.00 | complete / not-produced | — | [result](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/7b71f983-86b5-47b2-a2ec-3e85e88f4bf3/result.json) · [文件清单](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/7b71f983-86b5-47b2-a2ec-3e85e88f4bf3/files.json) · [轨迹](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/7b71f983-86b5-47b2-a2ec-3e85e88f4bf3/agent/trajectory.jsonl) |
| test:5174 | completed | 1 | 18.73 | 0.00 | complete / not-produced | — | [result](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/bad35531-b7ac-49f4-ae91-4eea957d99d8/result.json) · [文件清单](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/bad35531-b7ac-49f4-ae91-4eea957d99d8/files.json) · [轨迹](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/bad35531-b7ac-49f4-ae91-4eea957d99d8/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

