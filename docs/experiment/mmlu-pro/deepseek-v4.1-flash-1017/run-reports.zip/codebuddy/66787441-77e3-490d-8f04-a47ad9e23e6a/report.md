<!-- snapshotDigest: 9e639538891117a3e8fdef558012d5b8fd6cbf60bba12b0a2e2b2bd69c59d92c -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 75.00%（18/24）**

Run: 66787441-77e3-490d-8f04-a47ad9e23e6a · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:17:49.610Z / 2026-11-12T08:25:08.748Z |
| 总耗时 | 7 分 5 秒 |
| 答对 / 答错 / 解题超时 | 18 / 6 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 18 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 75.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 7 分 5 秒 |
| 环境准备耗时 | 3 分 33 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 48 秒 | 31 秒 | 2 分 5 秒 | 24 |
| 任务准备 | 0.55 毫秒 | 0.3 毫秒 | 1.4 毫秒 | 24 |
| 环境启动 | 16 秒 | 9 秒 | 18 秒 | 24 |
| 解题 | 24 秒 | 13 秒 | 1 分 38 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 6 秒 | 5 秒 | 9 秒 | 24 |
| 评分 | 0.52 毫秒 | 0.25 毫秒 | 1.89 毫秒 | 24 |
| 证据收集 | 12.33 毫秒 | 3.68 毫秒 | 43.3 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 44eecef1-67a0-4421-9996-730a7e6f8a47 | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 117,874 | 22,020 | 139,894 | 24 / 24 | — |
| 运行累计 | 117,874 | 22,020 | 139,894 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:5198 | completed | 1 | 13.87 | 0.00 | complete / not-produced | — | [result](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/6745a110-31be-4ab0-9c43-35e27de681e2/result.json) · [文件清单](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/6745a110-31be-4ab0-9c43-35e27de681e2/files.json) · [轨迹](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/6745a110-31be-4ab0-9c43-35e27de681e2/agent/trajectory.jsonl) |
| test:5243 | completed | 1 | 15.23 | 0.00 | complete / not-produced | — | [result](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/7ccd7ef1-c6b2-4057-b209-038b77a2b157/result.json) · [文件清单](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/7ccd7ef1-c6b2-4057-b209-038b77a2b157/files.json) · [轨迹](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/7ccd7ef1-c6b2-4057-b209-038b77a2b157/agent/trajectory.jsonl) |
| test:5309 | completed | 1 | 14.94 | 0.00 | complete / not-produced | — | [result](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/00462405-36c8-4217-9d09-7df99845d590/result.json) · [文件清单](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/00462405-36c8-4217-9d09-7df99845d590/files.json) · [轨迹](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/00462405-36c8-4217-9d09-7df99845d590/agent/trajectory.jsonl) |
| test:5319 | completed | 1 | 18.37 | 0.00 | complete / not-produced | — | [result](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/1df4f990-8ae4-48f4-86c3-60f5b10a0390/result.json) · [文件清单](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/1df4f990-8ae4-48f4-86c3-60f5b10a0390/files.json) · [轨迹](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/1df4f990-8ae4-48f4-86c3-60f5b10a0390/agent/trajectory.jsonl) |
| test:5328 | completed | 0 | 18.22 | 0.00 | complete / not-produced | — | [result](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/e90c41bc-7f6b-450d-93f1-4d9d1b110b70/result.json) · [文件清单](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/e90c41bc-7f6b-450d-93f1-4d9d1b110b70/files.json) · [轨迹](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/e90c41bc-7f6b-450d-93f1-4d9d1b110b70/agent/trajectory.jsonl) |
| test:5361 | completed | 0 | 16.35 | 0.00 | complete / not-produced | — | [result](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/95dca9ad-2557-4d92-884e-4601f0926141/result.json) · [文件清单](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/95dca9ad-2557-4d92-884e-4601f0926141/files.json) · [轨迹](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/95dca9ad-2557-4d92-884e-4601f0926141/agent/trajectory.jsonl) |
| test:5457 | completed | 1 | 18.40 | 0.00 | complete / not-produced | — | [result](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/601d8bab-8a1f-4eb5-aab6-0883857c205a/result.json) · [文件清单](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/601d8bab-8a1f-4eb5-aab6-0883857c205a/files.json) · [轨迹](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/601d8bab-8a1f-4eb5-aab6-0883857c205a/agent/trajectory.jsonl) |
| test:5461 | completed | 1 | 17.22 | 0.00 | complete / not-produced | — | [result](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/66c9c54c-0c4c-4040-9329-bbc5b67909d7/result.json) · [文件清单](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/66c9c54c-0c4c-4040-9329-bbc5b67909d7/files.json) · [轨迹](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/66c9c54c-0c4c-4040-9329-bbc5b67909d7/agent/trajectory.jsonl) |
| test:5530 | completed | 0 | 34.48 | 0.00 | complete / not-produced | — | [result](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/16f53e9a-f66b-4b38-96ff-88b90f05a9f0/result.json) · [文件清单](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/16f53e9a-f66b-4b38-96ff-88b90f05a9f0/files.json) · [轨迹](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/16f53e9a-f66b-4b38-96ff-88b90f05a9f0/agent/trajectory.jsonl) |
| test:5578 | completed | 1 | 14.12 | 0.00 | complete / not-produced | — | [result](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/037d4fc8-8038-4c78-b55f-07d7a0ba0ff3/result.json) · [文件清单](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/037d4fc8-8038-4c78-b55f-07d7a0ba0ff3/files.json) · [轨迹](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/037d4fc8-8038-4c78-b55f-07d7a0ba0ff3/agent/trajectory.jsonl) |
| test:5580 | completed | 1 | 14.24 | 0.00 | complete / not-produced | — | [result](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/9c2ed41d-2a4e-4f27-a0c5-aa2ac1f3bd41/result.json) · [文件清单](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/9c2ed41d-2a4e-4f27-a0c5-aa2ac1f3bd41/files.json) · [轨迹](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/9c2ed41d-2a4e-4f27-a0c5-aa2ac1f3bd41/agent/trajectory.jsonl) |
| test:5795 | completed | 1 | 13.85 | 0.00 | complete / not-produced | — | [result](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/12e873a3-ab29-4ceb-8c90-4f7cec5b98c8/result.json) · [文件清单](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/12e873a3-ab29-4ceb-8c90-4f7cec5b98c8/files.json) · [轨迹](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/12e873a3-ab29-4ceb-8c90-4f7cec5b98c8/agent/trajectory.jsonl) |
| test:5919 | completed | 0 | 14.46 | 0.00 | complete / not-produced | — | [result](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/d344dcfc-c610-430b-a699-a357006afd15/result.json) · [文件清单](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/d344dcfc-c610-430b-a699-a357006afd15/files.json) · [轨迹](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/d344dcfc-c610-430b-a699-a357006afd15/agent/trajectory.jsonl) |
| test:5940 | completed | 1 | 13.48 | 0.00 | complete / not-produced | — | [result](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/551cad0b-d017-4702-828f-821f8daff482/result.json) · [文件清单](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/551cad0b-d017-4702-828f-821f8daff482/files.json) · [轨迹](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/551cad0b-d017-4702-828f-821f8daff482/agent/trajectory.jsonl) |
| test:6055 | completed | 1 | 15.33 | 0.00 | complete / not-produced | — | [result](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/8fac4927-5943-4227-bc7b-68c834858d8d/result.json) · [文件清单](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/8fac4927-5943-4227-bc7b-68c834858d8d/files.json) · [轨迹](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/8fac4927-5943-4227-bc7b-68c834858d8d/agent/trajectory.jsonl) |
| test:6095 | completed | 1 | 20.42 | 0.00 | complete / not-produced | — | [result](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/15a58fcb-4233-4539-9037-143fe85b380f/result.json) · [文件清单](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/15a58fcb-4233-4539-9037-143fe85b380f/files.json) · [轨迹](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/15a58fcb-4233-4539-9037-143fe85b380f/agent/trajectory.jsonl) |
| test:6120 | completed | 1 | 18.98 | 0.00 | complete / not-produced | — | [result](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/74a64b0b-2e66-4464-bcbd-fa344450a5c4/result.json) · [文件清单](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/74a64b0b-2e66-4464-bcbd-fa344450a5c4/files.json) · [轨迹](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/74a64b0b-2e66-4464-bcbd-fa344450a5c4/agent/trajectory.jsonl) |
| test:6123 | completed | 1 | 97.63 | 0.00 | complete / not-produced | — | [result](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/6e950e49-70d7-4fc1-80a0-f5033c7d5379/result.json) · [文件清单](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/6e950e49-70d7-4fc1-80a0-f5033c7d5379/files.json) · [轨迹](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/6e950e49-70d7-4fc1-80a0-f5033c7d5379/agent/trajectory.jsonl) |
| test:6147 | completed | 0 | 17.62 | 0.00 | complete / not-produced | — | [result](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/081292f3-f7c0-4c32-88a9-8b46d469357b/result.json) · [文件清单](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/081292f3-f7c0-4c32-88a9-8b46d469357b/files.json) · [轨迹](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/081292f3-f7c0-4c32-88a9-8b46d469357b/agent/trajectory.jsonl) |
| test:6198 | completed | 0 | 63.15 | 0.00 | complete / not-produced | — | [result](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/a08104b2-5130-4cce-8f1e-48add3700543/result.json) · [文件清单](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/a08104b2-5130-4cce-8f1e-48add3700543/files.json) · [轨迹](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/a08104b2-5130-4cce-8f1e-48add3700543/agent/trajectory.jsonl) |
| test:6223 | completed | 1 | 21.75 | 0.00 | complete / not-produced | — | [result](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/ed634aa2-4b8f-4b40-a9cb-8cf3474691cf/result.json) · [文件清单](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/ed634aa2-4b8f-4b40-a9cb-8cf3474691cf/files.json) · [轨迹](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/ed634aa2-4b8f-4b40-a9cb-8cf3474691cf/agent/trajectory.jsonl) |
| test:6235 | completed | 1 | 21.62 | 0.00 | complete / not-produced | — | [result](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/b34e2508-0376-4c18-9636-086e2f114097/result.json) · [文件清单](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/b34e2508-0376-4c18-9636-086e2f114097/files.json) · [轨迹](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/b34e2508-0376-4c18-9636-086e2f114097/agent/trajectory.jsonl) |
| test:6403 | completed | 1 | 34.79 | 0.00 | complete / not-produced | — | [result](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/4303c15d-09ad-4f2a-bd12-388d7ad0dd63/result.json) · [文件清单](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/4303c15d-09ad-4f2a-bd12-388d7ad0dd63/files.json) · [轨迹](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/4303c15d-09ad-4f2a-bd12-388d7ad0dd63/agent/trajectory.jsonl) |
| test:6436 | completed | 1 | 22.43 | 0.00 | complete / not-produced | — | [result](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/df206411-4f92-494d-a6ba-d705372a5be4/result.json) · [文件清单](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/df206411-4f92-494d-a6ba-d705372a5be4/files.json) · [轨迹](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/df206411-4f92-494d-a6ba-d705372a5be4/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

