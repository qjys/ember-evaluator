<!-- snapshotDigest: 8fd55415545e24bac3ca8884d218b3db101fe763c99fbdfcd16526cb5f4b22d7 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 100.00%（24/24）**

Run: 414986d1-2a3f-4a63-b8a1-7e512518a327 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:33:40.486Z / 2026-11-12T08:42:16.610Z |
| 总耗时 | 8 分 19 秒 |
| 答对 / 答错 / 解题超时 | 24 / 0 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 24 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 100.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 8 分 19 秒 |
| 环境准备耗时 | 4 分 11 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 53 秒 | 38 秒 | 1 分 58 秒 | 24 |
| 任务准备 | 0.7 毫秒 | 0.3 毫秒 | 6.31 毫秒 | 24 |
| 环境启动 | 19 秒 | 13 秒 | 23 秒 | 24 |
| 解题 | 23 秒 | 13 秒 | 1 分 25 秒 | 24 |
| 产物传输 | 4 秒 | 2 秒 | 6 秒 | 24 |
| 资源清理 | 8 秒 | 5 秒 | 14 秒 | 24 |
| 评分 | 0.53 毫秒 | 0.19 毫秒 | 2.13 毫秒 | 24 |
| 证据收集 | 15.18 毫秒 | 5.08 毫秒 | 39.51 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 5f84cc94-b933-4b84-845a-29505021feb0 | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 126,474 | 16,615 | 143,089 | 24 / 24 | — |
| 运行累计 | 126,474 | 16,615 | 143,089 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:8199 | completed | 1 | 17.90 | 0.00 | complete / not-produced | — | [result](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/3ece909e-7aba-45bc-88fc-04734e87ac78/result.json) · [文件清单](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/3ece909e-7aba-45bc-88fc-04734e87ac78/files.json) · [轨迹](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/3ece909e-7aba-45bc-88fc-04734e87ac78/agent/trajectory.jsonl) |
| test:8207 | completed | 1 | 16.93 | 0.00 | complete / not-produced | — | [result](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/f1338be6-d1fc-4316-9dcf-583fb458ef41/result.json) · [文件清单](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/f1338be6-d1fc-4316-9dcf-583fb458ef41/files.json) · [轨迹](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/f1338be6-d1fc-4316-9dcf-583fb458ef41/agent/trajectory.jsonl) |
| test:8304 | completed | 1 | 17.83 | 0.00 | complete / not-produced | — | [result](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/de042883-441e-4bf4-8516-26f93d593738/result.json) · [文件清单](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/de042883-441e-4bf4-8516-26f93d593738/files.json) · [轨迹](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/de042883-441e-4bf4-8516-26f93d593738/agent/trajectory.jsonl) |
| test:8366 | completed | 1 | 19.48 | 0.00 | complete / not-produced | — | [result](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/79ecb7f3-a211-4f70-be83-629f1e2f506f/result.json) · [文件清单](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/79ecb7f3-a211-4f70-be83-629f1e2f506f/files.json) · [轨迹](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/79ecb7f3-a211-4f70-be83-629f1e2f506f/agent/trajectory.jsonl) |
| test:8511 | completed | 1 | 26.03 | 0.00 | complete / not-produced | — | [result](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/d9fbebfb-f17d-4314-9561-59eaeb3d8b67/result.json) · [文件清单](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/d9fbebfb-f17d-4314-9561-59eaeb3d8b67/files.json) · [轨迹](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/d9fbebfb-f17d-4314-9561-59eaeb3d8b67/agent/trajectory.jsonl) |
| test:8525 | completed | 1 | 20.01 | 0.00 | complete / not-produced | — | [result](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/38e0fee6-461e-45d3-82b6-08911d31f571/result.json) · [文件清单](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/38e0fee6-461e-45d3-82b6-08911d31f571/files.json) · [轨迹](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/38e0fee6-461e-45d3-82b6-08911d31f571/agent/trajectory.jsonl) |
| test:8604 | completed | 1 | 13.01 | 0.00 | complete / not-produced | — | [result](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/9d3a84f0-e810-4f80-9f63-abbc52f6cc3f/result.json) · [文件清单](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/9d3a84f0-e810-4f80-9f63-abbc52f6cc3f/files.json) · [轨迹](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/9d3a84f0-e810-4f80-9f63-abbc52f6cc3f/agent/trajectory.jsonl) |
| test:8740 | completed | 1 | 16.32 | 0.00 | complete / not-produced | — | [result](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/7ab971e5-5cd5-426f-90d2-f70a8c646e53/result.json) · [文件清单](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/7ab971e5-5cd5-426f-90d2-f70a8c646e53/files.json) · [轨迹](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/7ab971e5-5cd5-426f-90d2-f70a8c646e53/agent/trajectory.jsonl) |
| test:8839 | completed | 1 | 14.67 | 0.00 | complete / not-produced | — | [result](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/ca148c67-422d-4f35-881c-779c02b04944/result.json) · [文件清单](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/ca148c67-422d-4f35-881c-779c02b04944/files.json) · [轨迹](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/ca148c67-422d-4f35-881c-779c02b04944/agent/trajectory.jsonl) |
| test:8939 | completed | 1 | 17.23 | 0.00 | complete / not-produced | — | [result](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/720b5245-bcb9-46a6-a128-b9a46b7297b6/result.json) · [文件清单](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/720b5245-bcb9-46a6-a128-b9a46b7297b6/files.json) · [轨迹](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/720b5245-bcb9-46a6-a128-b9a46b7297b6/agent/trajectory.jsonl) |
| test:8967 | completed | 1 | 19.96 | 0.00 | complete / not-produced | — | [result](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/8ea721bb-2e4b-419e-9824-82c0acd11cd5/result.json) · [文件清单](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/8ea721bb-2e4b-419e-9824-82c0acd11cd5/files.json) · [轨迹](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/8ea721bb-2e4b-419e-9824-82c0acd11cd5/agent/trajectory.jsonl) |
| test:8989 | completed | 1 | 19.93 | 0.00 | complete / not-produced | — | [result](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/9898d180-2fdc-4799-84c8-ff6949785138/result.json) · [文件清单](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/9898d180-2fdc-4799-84c8-ff6949785138/files.json) · [轨迹](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/9898d180-2fdc-4799-84c8-ff6949785138/agent/trajectory.jsonl) |
| test:9136 | completed | 1 | 23.20 | 0.00 | complete / not-produced | — | [result](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/b84d586c-1207-4723-9bbb-acc5d1176dda/result.json) · [文件清单](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/b84d586c-1207-4723-9bbb-acc5d1176dda/files.json) · [轨迹](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/b84d586c-1207-4723-9bbb-acc5d1176dda/agent/trajectory.jsonl) |
| test:9222 | completed | 1 | 20.65 | 0.00 | complete / not-produced | — | [result](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/f7d88809-d76d-451a-81a4-1ba5422027c2/result.json) · [文件清单](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/f7d88809-d76d-451a-81a4-1ba5422027c2/files.json) · [轨迹](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/f7d88809-d76d-451a-81a4-1ba5422027c2/agent/trajectory.jsonl) |
| test:9391 | completed | 1 | 20.15 | 0.00 | complete / not-produced | — | [result](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/dd7d8c03-cd48-4ff0-810d-0cdf11a19e3a/result.json) · [文件清单](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/dd7d8c03-cd48-4ff0-810d-0cdf11a19e3a/files.json) · [轨迹](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/dd7d8c03-cd48-4ff0-810d-0cdf11a19e3a/agent/trajectory.jsonl) |
| test:9395 | completed | 1 | 28.12 | 0.00 | complete / not-produced | — | [result](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/2e136853-7fd2-4bcc-a8ff-78103649caf4/result.json) · [文件清单](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/2e136853-7fd2-4bcc-a8ff-78103649caf4/files.json) · [轨迹](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/2e136853-7fd2-4bcc-a8ff-78103649caf4/agent/trajectory.jsonl) |
| test:9405 | completed | 1 | 21.33 | 0.00 | complete / not-produced | — | [result](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/33c3dc3f-82c3-402c-874c-9a7b856d841f/result.json) · [文件清单](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/33c3dc3f-82c3-402c-874c-9a7b856d841f/files.json) · [轨迹](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/33c3dc3f-82c3-402c-874c-9a7b856d841f/agent/trajectory.jsonl) |
| test:9769 | completed | 1 | 18.46 | 0.00 | complete / not-produced | — | [result](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/8852bcef-8a3b-479d-aad4-be2e79ca1ff8/result.json) · [文件清单](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/8852bcef-8a3b-479d-aad4-be2e79ca1ff8/files.json) · [轨迹](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/8852bcef-8a3b-479d-aad4-be2e79ca1ff8/agent/trajectory.jsonl) |
| test:9843 | completed | 1 | 19.94 | 0.00 | complete / not-produced | — | [result](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/72c1863a-ae98-4931-a576-ba2ee49d38e0/result.json) · [文件清单](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/72c1863a-ae98-4931-a576-ba2ee49d38e0/files.json) · [轨迹](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/72c1863a-ae98-4931-a576-ba2ee49d38e0/agent/trajectory.jsonl) |
| test:9864 | completed | 1 | 19.30 | 0.00 | complete / not-produced | — | [result](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/75a8154e-828e-4a33-aa90-e79e31d43b0a/result.json) · [文件清单](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/75a8154e-828e-4a33-aa90-e79e31d43b0a/files.json) · [轨迹](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/75a8154e-828e-4a33-aa90-e79e31d43b0a/agent/trajectory.jsonl) |
| test:9901 | completed | 1 | 20.71 | 0.00 | complete / not-produced | — | [result](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/e86835a2-eb06-4af5-83ff-9e7d60f728da/result.json) · [文件清单](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/e86835a2-eb06-4af5-83ff-9e7d60f728da/files.json) · [轨迹](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/e86835a2-eb06-4af5-83ff-9e7d60f728da/agent/trajectory.jsonl) |
| test:9931 | completed | 1 | 85.29 | 0.00 | complete / not-produced | — | [result](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/0f51859c-7ac2-465b-ab96-5ca98752ebea/result.json) · [文件清单](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/0f51859c-7ac2-465b-ab96-5ca98752ebea/files.json) · [轨迹](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/0f51859c-7ac2-465b-ab96-5ca98752ebea/agent/trajectory.jsonl) |
| test:10127 | completed | 1 | 22.37 | 0.00 | complete / not-produced | — | [result](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/e35ffa95-fef4-4f17-82ee-b1abc6fc102e/result.json) · [文件清单](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/e35ffa95-fef4-4f17-82ee-b1abc6fc102e/files.json) · [轨迹](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/e35ffa95-fef4-4f17-82ee-b1abc6fc102e/agent/trajectory.jsonl) |
| test:10140 | completed | 1 | 23.09 | 0.00 | complete / not-produced | — | [result](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/3846be3a-a1f6-4afe-9879-d6526613cb01/result.json) · [文件清单](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/3846be3a-a1f6-4afe-9879-d6526613cb01/files.json) · [轨迹](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/3846be3a-a1f6-4afe-9879-d6526613cb01/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

