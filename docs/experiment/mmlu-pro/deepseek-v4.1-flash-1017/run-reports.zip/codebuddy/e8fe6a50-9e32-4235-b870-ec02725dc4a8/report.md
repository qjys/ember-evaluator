<!-- snapshotDigest: 15aa2605422d707fdb78d2ff104ad74cfe41f01c2e436fe3f58c81d04f6dd20c -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 76.19%（16/21）**

Run: e8fe6a50-9e32-4235-b870-ec02725dc4a8 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:48:19.221Z / 2026-11-12T08:57:29.470Z |
| 总耗时 | 8 分 51 秒 |
| 答对 / 答错 / 解题超时 | 16 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 21 题；已保存 21 条记录；待运行 0 题。
有效评分覆盖率：21/21（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 21 |
| 计分题数 | 21 |
| 正常评分题数 | 21 |
| 答对题数 | 16 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 76.19% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 8 分 51 秒 |
| 环境准备耗时 | 4 分 14 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 分 10 秒 | 33 秒 | 4 分 25 秒 | 21 |
| 任务准备 | 0.48 毫秒 | 0.28 毫秒 | 1.07 毫秒 | 21 |
| 环境启动 | 16 秒 | 11 秒 | 26 秒 | 21 |
| 解题 | 44 秒 | 13 秒 | 4 分 0 秒 | 21 |
| 产物传输 | 3 秒 | 1 秒 | 4 秒 | 21 |
| 资源清理 | 7 秒 | 5 秒 | 11 秒 | 21 |
| 评分 | 0.92 毫秒 | 0.28 毫秒 | 7.04 毫秒 | 21 |
| 证据收集 | 9.24 毫秒 | 3.67 毫秒 | 24.42 毫秒 | 21 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 6a2997c7-d98e-436f-81c9-bea33d664f9d | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 101,277 | 50,232 | 151,509 | 20 / 21 | — |
| 运行累计 | 101,277 | 50,232 | 151,509 | 20 / 21 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:10898 | completed | 1 | 22.69 | 0.00 | complete / not-produced | — | [result](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/bcbafed3-80a9-4210-af10-cf978b50de01/result.json) · [文件清单](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/bcbafed3-80a9-4210-af10-cf978b50de01/files.json) · [轨迹](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/bcbafed3-80a9-4210-af10-cf978b50de01/agent/trajectory.jsonl) |
| test:10940 | completed | 1 | 21.11 | 0.00 | complete / not-produced | — | [result](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/99c42666-a928-45c7-9485-b3778305d90d/result.json) · [文件清单](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/99c42666-a928-45c7-9485-b3778305d90d/files.json) · [轨迹](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/99c42666-a928-45c7-9485-b3778305d90d/agent/trajectory.jsonl) |
| test:10966 | completed | 1 | 22.03 | 0.01 | complete / not-produced | — | [result](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/b94677f7-203f-43aa-9494-5d833e3e1c08/result.json) · [文件清单](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/b94677f7-203f-43aa-9494-5d833e3e1c08/files.json) · [轨迹](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/b94677f7-203f-43aa-9494-5d833e3e1c08/agent/trajectory.jsonl) |
| test:11045 | completed | 0 | 17.74 | 0.00 | complete / not-produced | — | [result](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/a719368a-9027-4fca-916e-7f19f5d2b54d/result.json) · [文件清单](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/a719368a-9027-4fca-916e-7f19f5d2b54d/files.json) · [轨迹](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/a719368a-9027-4fca-916e-7f19f5d2b54d/agent/trajectory.jsonl) |
| test:11050 | completed | 1 | 35.57 | 0.00 | complete / not-produced | — | [result](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/f7847358-76ea-41ce-8110-255f74f4b14c/result.json) · [文件清单](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/f7847358-76ea-41ce-8110-255f74f4b14c/files.json) · [轨迹](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/f7847358-76ea-41ce-8110-255f74f4b14c/agent/trajectory.jsonl) |
| test:11060 | completed | 1 | 18.28 | 0.00 | complete / not-produced | — | [result](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/36e255fa-617c-41ff-b613-b591ad4c8649/result.json) · [文件清单](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/36e255fa-617c-41ff-b613-b591ad4c8649/files.json) · [轨迹](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/36e255fa-617c-41ff-b613-b591ad4c8649/agent/trajectory.jsonl) |
| test:11093 | completed | 1 | 90.06 | 0.00 | complete / not-produced | — | [result](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/0f413dce-ef52-4b4c-b5d1-de7c7502de40/result.json) · [文件清单](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/0f413dce-ef52-4b4c-b5d1-de7c7502de40/files.json) · [轨迹](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/0f413dce-ef52-4b4c-b5d1-de7c7502de40/agent/trajectory.jsonl) |
| test:11210 | completed | 1 | 18.97 | 0.00 | complete / not-produced | — | [result](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/e533eb7f-81fc-47b7-8df9-9cce4936b879/result.json) · [文件清单](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/e533eb7f-81fc-47b7-8df9-9cce4936b879/files.json) · [轨迹](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/e533eb7f-81fc-47b7-8df9-9cce4936b879/agent/trajectory.jsonl) |
| test:11354 | completed | 0 | 13.97 | 0.00 | complete / not-produced | — | [result](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/ebaa8334-0b0e-4ded-842c-811855288916/result.json) · [文件清单](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/ebaa8334-0b0e-4ded-842c-811855288916/files.json) · [轨迹](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/ebaa8334-0b0e-4ded-842c-811855288916/agent/trajectory.jsonl) |
| test:11491 | completed | 0 | 47.76 | 0.00 | complete / not-produced | — | [result](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/ef06929b-f1b6-499f-b611-e703ac68ea37/result.json) · [文件清单](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/ef06929b-f1b6-499f-b611-e703ac68ea37/files.json) · [轨迹](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/ef06929b-f1b6-499f-b611-e703ac68ea37/agent/trajectory.jsonl) |
| test:11496 | completed | 1 | 120.48 | 0.00 | complete / not-produced | — | [result](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/1d3fe751-c252-46b9-887f-25bb21ffeeed/result.json) · [文件清单](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/1d3fe751-c252-46b9-887f-25bb21ffeeed/files.json) · [轨迹](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/1d3fe751-c252-46b9-887f-25bb21ffeeed/agent/trajectory.jsonl) |
| test:11506 | completed | 0 | 240.01 | 0.00 | partial / not-produced | SOLVER\_AGENT\_TIMEOUT | [result](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/7de2c4f3-f439-4118-b438-77c8087f458a/result.json) · [文件清单](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/7de2c4f3-f439-4118-b438-77c8087f458a/files.json) · [轨迹](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/7de2c4f3-f439-4118-b438-77c8087f458a/agent/trajectory.jsonl) |
| test:11559 | completed | 1 | 12.85 | 0.00 | complete / not-produced | — | [result](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/05128a7a-3ed9-4d9c-ad1d-4b22c6bfbd49/result.json) · [文件清单](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/05128a7a-3ed9-4d9c-ad1d-4b22c6bfbd49/files.json) · [轨迹](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/05128a7a-3ed9-4d9c-ad1d-4b22c6bfbd49/agent/trajectory.jsonl) |
| test:11576 | completed | 0 | 24.62 | 0.00 | complete / not-produced | — | [result](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/2746d9fe-e65c-410b-8d0a-ee8088e04635/result.json) · [文件清单](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/2746d9fe-e65c-410b-8d0a-ee8088e04635/files.json) · [轨迹](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/2746d9fe-e65c-410b-8d0a-ee8088e04635/agent/trajectory.jsonl) |
| test:11629 | completed | 1 | 18.41 | 0.00 | complete / not-produced | — | [result](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/9b5993b5-3873-4aaf-bf50-2fb005a4500e/result.json) · [文件清单](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/9b5993b5-3873-4aaf-bf50-2fb005a4500e/files.json) · [轨迹](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/9b5993b5-3873-4aaf-bf50-2fb005a4500e/agent/trajectory.jsonl) |
| test:11660 | completed | 1 | 100.16 | 0.00 | complete / not-produced | — | [result](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/3129b5c6-5d23-42e9-bd61-5411d01c5864/result.json) · [文件清单](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/3129b5c6-5d23-42e9-bd61-5411d01c5864/files.json) · [轨迹](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/3129b5c6-5d23-42e9-bd61-5411d01c5864/agent/trajectory.jsonl) |
| test:11802 | completed | 1 | 13.66 | 0.00 | complete / not-produced | — | [result](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/acb302df-8b60-4c68-ac8b-55ee7511649a/result.json) · [文件清单](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/acb302df-8b60-4c68-ac8b-55ee7511649a/files.json) · [轨迹](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/acb302df-8b60-4c68-ac8b-55ee7511649a/agent/trajectory.jsonl) |
| test:11808 | completed | 1 | 25.51 | 0.00 | complete / not-produced | — | [result](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/70f3a412-8927-49fe-81c3-9e2dba2cbf78/result.json) · [文件清单](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/70f3a412-8927-49fe-81c3-9e2dba2cbf78/files.json) · [轨迹](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/70f3a412-8927-49fe-81c3-9e2dba2cbf78/agent/trajectory.jsonl) |
| test:11824 | completed | 1 | 16.10 | 0.00 | complete / not-produced | — | [result](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/515f7d81-c03a-42ae-9055-dff9d38863c1/result.json) · [文件清单](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/515f7d81-c03a-42ae-9055-dff9d38863c1/files.json) · [轨迹](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/515f7d81-c03a-42ae-9055-dff9d38863c1/agent/trajectory.jsonl) |
| test:11925 | completed | 1 | 18.97 | 0.00 | complete / not-produced | — | [result](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/4ad3a74e-09ea-4f50-b7c0-6288eb5edb3b/result.json) · [文件清单](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/4ad3a74e-09ea-4f50-b7c0-6288eb5edb3b/files.json) · [轨迹](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/4ad3a74e-09ea-4f50-b7c0-6288eb5edb3b/agent/trajectory.jsonl) |
| test:12002 | completed | 1 | 18.44 | 0.00 | complete / not-produced | — | [result](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/3ff51027-8b9e-4e7a-95ef-de36eedcc78d/result.json) · [文件清单](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/3ff51027-8b9e-4e7a-95ef-de36eedcc78d/files.json) · [轨迹](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/3ff51027-8b9e-4e7a-95ef-de36eedcc78d/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 1（主流程 1；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| test:11506 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

