<!-- snapshotDigest: 7e27e94fbe87c0d983d2b2d4da579592159452264c13ab0d92e4ce24acc6248d -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 87.50%（21/24）**

Run: d7196479-f6c0-4c50-bb64-e7170ee4ad3e · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:03:58.970Z / 2026-11-12T08:10:55.502Z |
| 总耗时 | 6 分 42 秒 |
| 答对 / 答错 / 解题超时 | 21 / 3 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 21 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 87.50% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 6 分 42 秒 |
| 环境准备耗时 | 3 分 36 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 45 秒 | 30 秒 | 2 分 15 秒 | 24 |
| 任务准备 | 0.52 毫秒 | 0.3 毫秒 | 1.42 毫秒 | 24 |
| 环境启动 | 14 秒 | 10 秒 | 19 秒 | 24 |
| 解题 | 23 秒 | 12 秒 | 1 分 54 秒 | 24 |
| 产物传输 | 2 秒 | 1 秒 | 4 秒 | 24 |
| 资源清理 | 5 秒 | 4 秒 | 8 秒 | 24 |
| 评分 | 1.12 毫秒 | 0.26 毫秒 | 14.5 毫秒 | 24 |
| 证据收集 | 14.17 毫秒 | 4.06 毫秒 | 38.11 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| ade6242e-56f9-4ff1-a991-2c99c61b948f | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 127,874 | 27,190 | 155,064 | 24 / 24 | — |
| 运行累计 | 127,874 | 27,190 | 155,064 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:2714 | completed | 1 | 17.10 | 0.00 | complete / not-produced | — | [result](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/a2ad94fe-8737-49b4-84c2-157e581428f6/result.json) · [文件清单](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/a2ad94fe-8737-49b4-84c2-157e581428f6/files.json) · [轨迹](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/a2ad94fe-8737-49b4-84c2-157e581428f6/agent/trajectory.jsonl) |
| test:2716 | completed | 1 | 17.98 | 0.00 | complete / not-produced | — | [result](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/aea70cf8-1263-4cf7-ba8f-90883c5f0d13/result.json) · [文件清单](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/aea70cf8-1263-4cf7-ba8f-90883c5f0d13/files.json) · [轨迹](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/aea70cf8-1263-4cf7-ba8f-90883c5f0d13/agent/trajectory.jsonl) |
| test:2747 | completed | 1 | 14.91 | 0.00 | complete / not-produced | — | [result](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/b48e8da7-c154-4d89-8d11-3917c835df3d/result.json) · [文件清单](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/b48e8da7-c154-4d89-8d11-3917c835df3d/files.json) · [轨迹](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/b48e8da7-c154-4d89-8d11-3917c835df3d/agent/trajectory.jsonl) |
| test:2882 | completed | 0 | 17.35 | 0.00 | complete / not-produced | — | [result](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/ec97abad-36db-4fad-a9c5-652ca5118c6f/result.json) · [文件清单](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/ec97abad-36db-4fad-a9c5-652ca5118c6f/files.json) · [轨迹](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/ec97abad-36db-4fad-a9c5-652ca5118c6f/agent/trajectory.jsonl) |
| test:2951 | completed | 1 | 20.17 | 0.00 | complete / not-produced | — | [result](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/33010d03-aa7f-4a4a-99d1-904c5d346423/result.json) · [文件清单](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/33010d03-aa7f-4a4a-99d1-904c5d346423/files.json) · [轨迹](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/33010d03-aa7f-4a4a-99d1-904c5d346423/agent/trajectory.jsonl) |
| test:3037 | completed | 1 | 16.82 | 0.01 | complete / not-produced | — | [result](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/94deaa9c-eceb-4954-abd9-b48994f7e5d3/result.json) · [文件清单](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/94deaa9c-eceb-4954-abd9-b48994f7e5d3/files.json) · [轨迹](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/94deaa9c-eceb-4954-abd9-b48994f7e5d3/agent/trajectory.jsonl) |
| test:3053 | completed | 0 | 65.40 | 0.00 | complete / not-produced | — | [result](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/ab0fbf13-3221-435c-bee0-8a153d96855f/result.json) · [文件清单](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/ab0fbf13-3221-435c-bee0-8a153d96855f/files.json) · [轨迹](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/ab0fbf13-3221-435c-bee0-8a153d96855f/agent/trajectory.jsonl) |
| test:3136 | completed | 1 | 20.80 | 0.00 | complete / not-produced | — | [result](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/37ec6e55-81ac-496e-be06-9d14d16eee27/result.json) · [文件清单](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/37ec6e55-81ac-496e-be06-9d14d16eee27/files.json) · [轨迹](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/37ec6e55-81ac-496e-be06-9d14d16eee27/agent/trajectory.jsonl) |
| test:3165 | completed | 1 | 21.18 | 0.00 | complete / not-produced | — | [result](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/6d0038f9-8ea4-407a-b446-c40aef625661/result.json) · [文件清单](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/6d0038f9-8ea4-407a-b446-c40aef625661/files.json) · [轨迹](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/6d0038f9-8ea4-407a-b446-c40aef625661/agent/trajectory.jsonl) |
| test:3196 | completed | 1 | 14.52 | 0.00 | complete / not-produced | — | [result](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/515b0168-d99a-493c-8371-30c17db03d0e/result.json) · [文件清单](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/515b0168-d99a-493c-8371-30c17db03d0e/files.json) · [轨迹](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/515b0168-d99a-493c-8371-30c17db03d0e/agent/trajectory.jsonl) |
| test:3231 | completed | 1 | 14.42 | 0.00 | complete / not-produced | — | [result](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/cc8b8319-9f1a-4f1f-9a28-3b8dde61fec3/result.json) · [文件清单](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/cc8b8319-9f1a-4f1f-9a28-3b8dde61fec3/files.json) · [轨迹](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/cc8b8319-9f1a-4f1f-9a28-3b8dde61fec3/agent/trajectory.jsonl) |
| test:3236 | completed | 1 | 12.76 | 0.00 | complete / not-produced | — | [result](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/016189fd-94f0-4f64-8135-20ebe6cba300/result.json) · [文件清单](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/016189fd-94f0-4f64-8135-20ebe6cba300/files.json) · [轨迹](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/016189fd-94f0-4f64-8135-20ebe6cba300/agent/trajectory.jsonl) |
| test:3270 | completed | 1 | 14.10 | 0.00 | complete / not-produced | — | [result](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/78bcdc44-b193-49aa-b23e-c85a40f43aea/result.json) · [文件清单](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/78bcdc44-b193-49aa-b23e-c85a40f43aea/files.json) · [轨迹](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/78bcdc44-b193-49aa-b23e-c85a40f43aea/agent/trajectory.jsonl) |
| test:3293 | completed | 1 | 16.64 | 0.00 | complete / not-produced | — | [result](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/7e79620b-20f9-48dd-8996-68fe93712992/result.json) · [文件清单](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/7e79620b-20f9-48dd-8996-68fe93712992/files.json) · [轨迹](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/7e79620b-20f9-48dd-8996-68fe93712992/agent/trajectory.jsonl) |
| test:3331 | completed | 1 | 12.09 | 0.00 | complete / not-produced | — | [result](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/29466de0-e037-4d9a-95b0-fe853b92580d/result.json) · [文件清单](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/29466de0-e037-4d9a-95b0-fe853b92580d/files.json) · [轨迹](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/29466de0-e037-4d9a-95b0-fe853b92580d/agent/trajectory.jsonl) |
| test:3488 | completed | 1 | 16.71 | 0.00 | complete / not-produced | — | [result](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/0c13a343-98e9-4da5-a03d-d6f01720e6a1/result.json) · [文件清单](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/0c13a343-98e9-4da5-a03d-d6f01720e6a1/files.json) · [轨迹](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/0c13a343-98e9-4da5-a03d-d6f01720e6a1/agent/trajectory.jsonl) |
| test:3491 | completed | 0 | 114.05 | 0.00 | complete / not-produced | — | [result](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/4bc83bb4-cd8d-4a10-8046-34fc515d5943/result.json) · [文件清单](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/4bc83bb4-cd8d-4a10-8046-34fc515d5943/files.json) · [轨迹](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/4bc83bb4-cd8d-4a10-8046-34fc515d5943/agent/trajectory.jsonl) |
| test:3552 | completed | 1 | 19.41 | 0.00 | complete / not-produced | — | [result](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/298de9a9-d673-41be-9ba4-320f33636a2a/result.json) · [文件清单](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/298de9a9-d673-41be-9ba4-320f33636a2a/files.json) · [轨迹](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/298de9a9-d673-41be-9ba4-320f33636a2a/agent/trajectory.jsonl) |
| test:3599 | completed | 1 | 17.48 | 0.00 | complete / not-produced | — | [result](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/53389538-9ee3-4165-8f3f-37ee621fe915/result.json) · [文件清单](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/53389538-9ee3-4165-8f3f-37ee621fe915/files.json) · [轨迹](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/53389538-9ee3-4165-8f3f-37ee621fe915/agent/trajectory.jsonl) |
| test:3626 | completed | 1 | 20.98 | 0.00 | complete / not-produced | — | [result](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/a64bc3ce-a945-4082-981e-37930b18e679/result.json) · [文件清单](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/a64bc3ce-a945-4082-981e-37930b18e679/files.json) · [轨迹](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/a64bc3ce-a945-4082-981e-37930b18e679/agent/trajectory.jsonl) |
| test:4021 | completed | 1 | 20.83 | 0.00 | complete / not-produced | — | [result](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/2757c04e-b447-47db-85cf-73da077f6b69/result.json) · [文件清单](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/2757c04e-b447-47db-85cf-73da077f6b69/files.json) · [轨迹](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/2757c04e-b447-47db-85cf-73da077f6b69/agent/trajectory.jsonl) |
| test:4034 | completed | 1 | 16.48 | 0.00 | complete / not-produced | — | [result](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/35875d54-3eca-413d-97ae-7f2a3b38d404/result.json) · [文件清单](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/35875d54-3eca-413d-97ae-7f2a3b38d404/files.json) · [轨迹](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/35875d54-3eca-413d-97ae-7f2a3b38d404/agent/trajectory.jsonl) |
| test:4058 | completed | 1 | 16.21 | 0.00 | complete / not-produced | — | [result](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/8ed6ee65-242a-4efb-9357-16293766c9d0/result.json) · [文件清单](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/8ed6ee65-242a-4efb-9357-16293766c9d0/files.json) · [轨迹](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/8ed6ee65-242a-4efb-9357-16293766c9d0/agent/trajectory.jsonl) |
| test:4075 | completed | 1 | 16.70 | 0.00 | complete / not-produced | — | [result](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/a5e0680a-8a07-4aa9-bd2f-d08053ebedbf/result.json) · [文件清单](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/a5e0680a-8a07-4aa9-bd2f-d08053ebedbf/files.json) · [轨迹](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/a5e0680a-8a07-4aa9-bd2f-d08053ebedbf/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

