<!-- snapshotDigest: ce31a9bc7c7a8edbf09dfb9ecd0247a9e20969709b0181a31a3d9e272b77e85c -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 16.43%（34/207）**

Run: 4ea5ddfc-ec11-49d8-8e62-c85119e3db3e · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:02:49.996Z / 2026-11-12T07:18:11.557Z |
| 总耗时 | 14 分 51 秒 |
| 答对 / 答错 / 解题超时 | 34 / 8 / 0 |
| 清理未确认 | 2 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 210 题；已保存 45 条记录；待运行 167 题。
有效评分覆盖率：42/210（20.00%）。
执行失败 1；超时 0；取消 2；不支持 0。
Agent 解题超时 0（计 0 分）；无效 3。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 210 |
| 计分题数 | 207 |
| 正常评分题数 | 42 |
| 答对题数 | 34 |
| 无效评测 | 3 |
| 待运行 | 167 |
| 正确率 | 16.43% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 14 分 51 秒 |
| 环境准备耗时 | 15 分 19 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 52 秒 | 12 秒 | 2 分 23 秒 | 45 |
| 任务准备 | 0.51 毫秒 | 0.26 毫秒 | 4.01 毫秒 | 45 |
| 环境启动 | 19 秒 | 9 秒 | 34 秒 | 45 |
| 解题 | 23 秒 | 9 秒 | 1 分 51 秒 | 44 |
| 产物传输 | 3 秒 | 2 秒 | 7 秒 | 44 |
| 资源清理 | 8 秒 | 4 秒 | 15 秒 | 44 |
| 评分 | 0.49 毫秒 | 0.24 毫秒 | 2.24 毫秒 | 42 |
| 证据收集 | 14.31 毫秒 | 1.91 毫秒 | 84.47 毫秒 | 45 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| d45f7c80-07a3-47df-8b9e-881c39953885 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 224,642 | 36,617 | 261,259 | 44 / 210 | — |
| 运行累计 | 224,642 | 36,617 | 261,259 | 44 / 45 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:41 | completed | 1 | 23.50 | 0.00 | complete / not-produced | — | [result](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/f595aff6-33f1-4213-b9fb-4bdcdaa0ebd9/result.json) · [文件清单](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/f595aff6-33f1-4213-b9fb-4bdcdaa0ebd9/files.json) · [轨迹](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/f595aff6-33f1-4213-b9fb-4bdcdaa0ebd9/agent/trajectory.jsonl) |
| test:61 | completed | 0 | 41.57 | 0.00 | complete / not-produced | — | [result](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/3cd51f47-de92-4761-ba4b-5e072383ffa7/result.json) · [文件清单](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/3cd51f47-de92-4761-ba4b-5e072383ffa7/files.json) · [轨迹](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/3cd51f47-de92-4761-ba4b-5e072383ffa7/agent/trajectory.jsonl) |
| test:97 | completed | 1 | 29.79 | 0.00 | complete / not-produced | — | [result](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/d981f357-4576-4ccc-afda-57e05463debe/result.json) · [文件清单](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/d981f357-4576-4ccc-afda-57e05463debe/files.json) · [轨迹](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/d981f357-4576-4ccc-afda-57e05463debe/agent/trajectory.jsonl) |
| test:209 | completed | 1 | 24.94 | 0.00 | complete / not-produced | — | [result](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/2869b4a5-f749-43bf-8901-9b73230634be/result.json) · [文件清单](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/2869b4a5-f749-43bf-8901-9b73230634be/files.json) · [轨迹](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/2869b4a5-f749-43bf-8901-9b73230634be/agent/trajectory.jsonl) |
| test:286 | completed | 1 | 19.43 | 0.00 | complete / not-produced | — | [result](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/266b33ed-4622-4ad7-9bdc-93ed61c6381f/result.json) · [文件清单](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/266b33ed-4622-4ad7-9bdc-93ed61c6381f/files.json) · [轨迹](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/266b33ed-4622-4ad7-9bdc-93ed61c6381f/agent/trajectory.jsonl) |
| test:299 | completed | 1 | 21.17 | 0.00 | complete / not-produced | — | [result](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/50d71491-d087-47c9-aca4-a35a32d4fd48/result.json) · [文件清单](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/50d71491-d087-47c9-aca4-a35a32d4fd48/files.json) · [轨迹](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/50d71491-d087-47c9-aca4-a35a32d4fd48/agent/trajectory.jsonl) |
| test:311 | completed | 1 | 25.67 | 0.00 | complete / not-produced | — | [result](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/791268ec-d416-450f-baf9-dc752a1dee2f/result.json) · [文件清单](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/791268ec-d416-450f-baf9-dc752a1dee2f/files.json) · [轨迹](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/791268ec-d416-450f-baf9-dc752a1dee2f/agent/trajectory.jsonl) |
| test:352 | completed | 1 | 15.05 | 0.00 | complete / not-produced | — | [result](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/f6432d05-c318-4265-b736-0eb1a22b7d8d/result.json) · [文件清单](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/f6432d05-c318-4265-b736-0eb1a22b7d8d/files.json) · [轨迹](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/f6432d05-c318-4265-b736-0eb1a22b7d8d/agent/trajectory.jsonl) |
| test:355 | completed | 1 | 13.22 | 0.00 | complete / not-produced | — | [result](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/a66ce82f-07e5-4ca3-a18a-312e604caf11/result.json) · [文件清单](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/a66ce82f-07e5-4ca3-a18a-312e604caf11/files.json) · [轨迹](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/a66ce82f-07e5-4ca3-a18a-312e604caf11/agent/trajectory.jsonl) |
| test:476 | completed | 1 | 17.34 | 0.00 | complete / not-produced | — | [result](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/7baf3280-74d7-474a-a2f9-1de374895962/result.json) · [文件清单](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/7baf3280-74d7-474a-a2f9-1de374895962/files.json) · [轨迹](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/7baf3280-74d7-474a-a2f9-1de374895962/agent/trajectory.jsonl) |
| test:511 | completed | 1 | 14.24 | 0.00 | complete / not-produced | — | [result](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/38313564-d6b5-4c5b-888e-26514dfab3f0/result.json) · [文件清单](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/38313564-d6b5-4c5b-888e-26514dfab3f0/files.json) · [轨迹](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/38313564-d6b5-4c5b-888e-26514dfab3f0/agent/trajectory.jsonl) |
| test:552 | completed | 1 | 9.12 | 0.00 | complete / not-produced | — | [result](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/ca6a585a-d99a-4415-879c-56b0e6a04f33/result.json) · [文件清单](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/ca6a585a-d99a-4415-879c-56b0e6a04f33/files.json) · [轨迹](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/ca6a585a-d99a-4415-879c-56b0e6a04f33/agent/trajectory.jsonl) |
| test:624 | completed | 1 | 10.57 | 0.00 | complete / not-produced | — | [result](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/ae29b1b1-12b7-4143-b3e1-0b93457131f2/result.json) · [文件清单](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/ae29b1b1-12b7-4143-b3e1-0b93457131f2/files.json) · [轨迹](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/ae29b1b1-12b7-4143-b3e1-0b93457131f2/agent/trajectory.jsonl) |
| test:669 | completed | 1 | 13.06 | 0.00 | complete / not-produced | — | [result](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/efabf266-fcce-4291-9411-6a2e87de49a8/result.json) · [文件清单](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/efabf266-fcce-4291-9411-6a2e87de49a8/files.json) · [轨迹](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/efabf266-fcce-4291-9411-6a2e87de49a8/agent/trajectory.jsonl) |
| test:670 | completed | 1 | 14.27 | 0.00 | complete / not-produced | — | [result](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/b5507943-a27b-4213-bf62-a1ebf61474d2/result.json) · [文件清单](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/b5507943-a27b-4213-bf62-a1ebf61474d2/files.json) · [轨迹](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/b5507943-a27b-4213-bf62-a1ebf61474d2/agent/trajectory.jsonl) |
| test:796 | completed | 1 | 25.82 | 0.00 | complete / not-produced | — | [result](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/2e1e0aa6-dc0b-4a20-8f2a-56d32eb1ca11/result.json) · [文件清单](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/2e1e0aa6-dc0b-4a20-8f2a-56d32eb1ca11/files.json) · [轨迹](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/2e1e0aa6-dc0b-4a20-8f2a-56d32eb1ca11/agent/trajectory.jsonl) |
| test:828 | completed | 1 | 12.02 | 0.00 | complete / not-produced | — | [result](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/34516b4f-1cc5-406e-82e6-4facec97e928/result.json) · [文件清单](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/34516b4f-1cc5-406e-82e6-4facec97e928/files.json) · [轨迹](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/34516b4f-1cc5-406e-82e6-4facec97e928/agent/trajectory.jsonl) |
| test:841 | completed | 1 | 19.84 | 0.00 | complete / not-produced | — | [result](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/27e41b1e-00fe-46aa-a27e-6c88c309a743/result.json) · [文件清单](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/27e41b1e-00fe-46aa-a27e-6c88c309a743/files.json) · [轨迹](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/27e41b1e-00fe-46aa-a27e-6c88c309a743/agent/trajectory.jsonl) |
| test:883 | completed | 1 | 13.85 | 0.00 | complete / not-produced | — | [result](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/72941449-78ff-4869-866c-d63788bd5dd4/result.json) · [文件清单](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/72941449-78ff-4869-866c-d63788bd5dd4/files.json) · [轨迹](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/72941449-78ff-4869-866c-d63788bd5dd4/agent/trajectory.jsonl) |
| test:938 | completed | 1 | 27.99 | 0.00 | complete / not-produced | — | [result](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/c7fe9e6c-ddd2-4693-bfcf-bc9f8f9b430d/result.json) · [文件清单](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/c7fe9e6c-ddd2-4693-bfcf-bc9f8f9b430d/files.json) · [轨迹](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/c7fe9e6c-ddd2-4693-bfcf-bc9f8f9b430d/agent/trajectory.jsonl) |
| test:1026 | completed | 0 | 21.40 | 0.00 | complete / not-produced | — | [result](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/65558bac-2596-4e1b-a1fd-2a715963b14c/result.json) · [文件清单](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/65558bac-2596-4e1b-a1fd-2a715963b14c/files.json) · [轨迹](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/65558bac-2596-4e1b-a1fd-2a715963b14c/agent/trajectory.jsonl) |
| test:1229 | completed | 1 | 13.55 | 0.00 | complete / not-produced | — | [result](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/bcc1f7fc-4312-4a8c-ba64-76faa657e2d8/result.json) · [文件清单](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/bcc1f7fc-4312-4a8c-ba64-76faa657e2d8/files.json) · [轨迹](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/bcc1f7fc-4312-4a8c-ba64-76faa657e2d8/agent/trajectory.jsonl) |
| test:1252 | completed | 1 | 11.46 | 0.00 | complete / not-produced | — | [result](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/4a18950d-7fbb-4678-8463-cf59d2bffa86/result.json) · [文件清单](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/4a18950d-7fbb-4678-8463-cf59d2bffa86/files.json) · [轨迹](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/4a18950d-7fbb-4678-8463-cf59d2bffa86/agent/trajectory.jsonl) |
| test:1399 | completed | 1 | 14.01 | 0.00 | complete / not-produced | — | [result](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/d80485a9-fa23-4548-a878-983892618247/result.json) · [文件清单](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/d80485a9-fa23-4548-a878-983892618247/files.json) · [轨迹](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/d80485a9-fa23-4548-a878-983892618247/agent/trajectory.jsonl) |
| test:1454 | completed | 0 | 99.48 | 0.00 | complete / not-produced | — | [result](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/3e5b8576-6d79-4f94-9737-914bb72e2889/result.json) · [文件清单](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/3e5b8576-6d79-4f94-9737-914bb72e2889/files.json) · [轨迹](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/3e5b8576-6d79-4f94-9737-914bb72e2889/agent/trajectory.jsonl) |
| test:1514 | completed | 0 | 40.99 | 0.00 | complete / not-produced | — | [result](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/bf01fa04-d587-4412-8d49-8d977c430637/result.json) · [文件清单](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/bf01fa04-d587-4412-8d49-8d977c430637/files.json) · [轨迹](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/bf01fa04-d587-4412-8d49-8d977c430637/agent/trajectory.jsonl) |
| test:1531 | completed | 0 | 37.18 | 0.00 | complete / not-produced | — | [result](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/091adc1c-0ff5-4d42-97cd-2550f0fcbe9d/result.json) · [文件清单](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/091adc1c-0ff5-4d42-97cd-2550f0fcbe9d/files.json) · [轨迹](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/091adc1c-0ff5-4d42-97cd-2550f0fcbe9d/agent/trajectory.jsonl) |
| test:1785 | completed | 0 | 110.84 | 0.00 | complete / not-produced | — | [result](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/23e0b97b-bb83-428f-b214-0cbb1d764657/result.json) · [文件清单](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/23e0b97b-bb83-428f-b214-0cbb1d764657/files.json) · [轨迹](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/23e0b97b-bb83-428f-b214-0cbb1d764657/agent/trajectory.jsonl) |
| test:1806 | completed | 0 | 16.38 | 0.00 | complete / not-produced | — | [result](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/60a77a15-4fd2-4717-a224-6223dc6e5075/result.json) · [文件清单](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/60a77a15-4fd2-4717-a224-6223dc6e5075/files.json) · [轨迹](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/60a77a15-4fd2-4717-a224-6223dc6e5075/agent/trajectory.jsonl) |
| test:1827 | completed | 1 | 25.77 | 0.00 | complete / not-produced | — | [result](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/87b891f6-e94f-4e3f-9eaf-53214cd14976/result.json) · [文件清单](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/87b891f6-e94f-4e3f-9eaf-53214cd14976/files.json) · [轨迹](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/87b891f6-e94f-4e3f-9eaf-53214cd14976/agent/trajectory.jsonl) |
| test:1904 | completed | 1 | 13.59 | 0.00 | complete / not-produced | — | [result](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/42445098-32d8-4bf4-a63e-c854c7c16639/result.json) · [文件清单](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/42445098-32d8-4bf4-a63e-c854c7c16639/files.json) · [轨迹](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/42445098-32d8-4bf4-a63e-c854c7c16639/agent/trajectory.jsonl) |
| test:1943 | completed | 1 | 19.64 | 0.00 | complete / not-produced | — | [result](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/fa8acb3c-6103-4104-9f62-1f75750ed92b/result.json) · [文件清单](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/fa8acb3c-6103-4104-9f62-1f75750ed92b/files.json) · [轨迹](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/fa8acb3c-6103-4104-9f62-1f75750ed92b/agent/trajectory.jsonl) |
| test:1998 | completed | 1 | 17.55 | 0.00 | complete / not-produced | — | [result](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/5019712d-cdfc-421e-9469-f611f8eb3616/result.json) · [文件清单](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/5019712d-cdfc-421e-9469-f611f8eb3616/files.json) · [轨迹](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/5019712d-cdfc-421e-9469-f611f8eb3616/agent/trajectory.jsonl) |
| test:2023 | completed | 1 | 15.30 | 0.00 | complete / not-produced | — | [result](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/8b7caede-5f33-4abe-92b6-3a064125a4a7/result.json) · [文件清单](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/8b7caede-5f33-4abe-92b6-3a064125a4a7/files.json) · [轨迹](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/8b7caede-5f33-4abe-92b6-3a064125a4a7/agent/trajectory.jsonl) |
| test:2096 | completed | 0 | 18.36 | 0.00 | complete / not-produced | — | [result](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/91f12efb-6272-478e-9f47-13c2730cdc95/result.json) · [文件清单](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/91f12efb-6272-478e-9f47-13c2730cdc95/files.json) · [轨迹](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/91f12efb-6272-478e-9f47-13c2730cdc95/agent/trajectory.jsonl) |
| test:2152 | completed | 1 | 19.68 | 0.00 | complete / not-produced | — | [result](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/02ebb89e-45c4-4045-9a53-e32c94007ad7/result.json) · [文件清单](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/02ebb89e-45c4-4045-9a53-e32c94007ad7/files.json) · [轨迹](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/02ebb89e-45c4-4045-9a53-e32c94007ad7/agent/trajectory.jsonl) |
| test:2175 | completed | 1 | 16.35 | 0.00 | complete / not-produced | — | [result](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/b59185c8-c3fc-4fd8-8709-c4fe728bd1d0/result.json) · [文件清单](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/b59185c8-c3fc-4fd8-8709-c4fe728bd1d0/files.json) · [轨迹](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/b59185c8-c3fc-4fd8-8709-c4fe728bd1d0/agent/trajectory.jsonl) |
| test:2177 | completed | 1 | 12.91 | 0.00 | complete / not-produced | — | [result](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/3fdf268e-8a0a-429b-86b8-d998e3b0d0ca/result.json) · [文件清单](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/3fdf268e-8a0a-429b-86b8-d998e3b0d0ca/files.json) · [轨迹](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/3fdf268e-8a0a-429b-86b8-d998e3b0d0ca/agent/trajectory.jsonl) |
| test:2206 | completed | 1 | 17.72 | 0.00 | complete / not-produced | — | [result](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/51cd29b7-507c-468c-b570-5745df633c2e/result.json) · [文件清单](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/51cd29b7-507c-468c-b570-5745df633c2e/files.json) · [轨迹](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/51cd29b7-507c-468c-b570-5745df633c2e/agent/trajectory.jsonl) |
| test:2280 | completed | 1 | 16.76 | 0.00 | complete / not-produced | — | [result](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/a786a48c-7b4e-4c5d-a50a-7f5a4b6ee4b5/result.json) · [文件清单](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/a786a48c-7b4e-4c5d-a50a-7f5a4b6ee4b5/files.json) · [轨迹](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/a786a48c-7b4e-4c5d-a50a-7f5a4b6ee4b5/agent/trajectory.jsonl) |
| test:2347 | completed | 1 | 16.57 | 0.00 | complete / not-produced | — | [result](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/9bc4c703-8a65-47e3-bd3e-843928da4959/result.json) · [文件清单](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/9bc4c703-8a65-47e3-bd3e-843928da4959/files.json) · [轨迹](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/9bc4c703-8a65-47e3-bd3e-843928da4959/agent/trajectory.jsonl) |
| test:2400 | completed | 1 | 15.91 | 0.00 | complete / not-produced | — | [result](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/c62909c9-9255-4a92-a270-4fc400a9a1a2/result.json) · [文件清单](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/c62909c9-9255-4a92-a270-4fc400a9a1a2/files.json) · [轨迹](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/c62909c9-9255-4a92-a270-4fc400a9a1a2/agent/trajectory.jsonl) |
| test:2527 | invalid | — | 12.31 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/0acb9dfa-22f8-4c0e-a39b-81af1761784a/result.json) · [文件清单](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/0acb9dfa-22f8-4c0e-a39b-81af1761784a/files.json) · [轨迹](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/0acb9dfa-22f8-4c0e-a39b-81af1761784a/agent/trajectory.jsonl) |
| test:2636 | cancelled | — | 12.93 | — | complete / not-produced | RUN\_CANCELLED | [result](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/e3f30f3a-6d22-4ca0-bc27-f0529bedeba9/result.json) · [文件清单](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/e3f30f3a-6d22-4ca0-bc27-f0529bedeba9/files.json) · [轨迹](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/e3f30f3a-6d22-4ca0-bc27-f0529bedeba9/agent/trajectory.jsonl) |
| test:2641 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/9f008613-2225-4af5-b110-bb9db5e56148/result.json) · [文件清单](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/9f008613-2225-4af5-b110-bb9db5e56148/files.json) |
| test:2714 | pending | — | — | — | — | — | — |
| test:2716 | pending | — | — | — | — | — | — |
| test:2747 | pending | — | — | — | — | — | — |
| test:2882 | pending | — | — | — | — | — | — |
| test:2951 | pending | — | — | — | — | — | — |
| test:3037 | pending | — | — | — | — | — | — |
| test:3053 | pending | — | — | — | — | — | — |
| test:3136 | pending | — | — | — | — | — | — |
| test:3165 | pending | — | — | — | — | — | — |
| test:3196 | pending | — | — | — | — | — | — |
| test:3231 | pending | — | — | — | — | — | — |
| test:3236 | pending | — | — | — | — | — | — |
| test:3270 | pending | — | — | — | — | — | — |
| test:3293 | pending | — | — | — | — | — | — |
| test:3331 | pending | — | — | — | — | — | — |
| test:3488 | pending | — | — | — | — | — | — |
| test:3491 | pending | — | — | — | — | — | — |
| test:3552 | pending | — | — | — | — | — | — |
| test:3599 | pending | — | — | — | — | — | — |
| test:3626 | pending | — | — | — | — | — | — |
| test:4021 | pending | — | — | — | — | — | — |
| test:4034 | pending | — | — | — | — | — | — |
| test:4058 | pending | — | — | — | — | — | — |
| test:4075 | pending | — | — | — | — | — | — |
| test:4142 | pending | — | — | — | — | — | — |
| test:4208 | pending | — | — | — | — | — | — |
| test:4298 | pending | — | — | — | — | — | — |
| test:4337 | pending | — | — | — | — | — | — |
| test:4376 | pending | — | — | — | — | — | — |
| test:4405 | pending | — | — | — | — | — | — |
| test:4552 | pending | — | — | — | — | — | — |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 3；错误记录 4（主流程 1；证据收集 0；资源清理 3）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| cleanup | CLEANUP_FAILED | 1 | 2 |
| cleanup | RUN_CANCELLED | 1 | 1 |
| environment | RUN_CANCELLED | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

