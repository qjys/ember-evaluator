<!-- snapshotDigest: 4dad91d58c5b0c8510964bca566fa10aae33d04591d530a384ef857d28419362 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 100.00%（24/24）**

Run: b968e015-6e4f-49b5-b445-7f6612e00648 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:42:21.847Z / 2026-11-12T08:48:14.636Z |
| 总耗时 | 5 分 41 秒 |
| 答对 / 答错 / 解题超时 | 24 / 0 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 24 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 100.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 41 秒 |
| 环境准备耗时 | 3 分 50 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 49 秒 | 31 秒 | 1 分 6 秒 | 24 |
| 任务准备 | 0.52 毫秒 | 0.31 毫秒 | 1.99 毫秒 | 24 |
| 环境启动 | 19 秒 | 10 秒 | 27 秒 | 24 |
| 解题 | 18 秒 | 11 秒 | 27 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 8 秒 | 5 秒 | 14 秒 | 24 |
| 评分 | 0.65 毫秒 | 0.28 毫秒 | 2.36 毫秒 | 24 |
| 证据收集 | 11.45 毫秒 | 3.87 毫秒 | 25.86 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| f91e7a74-f560-4e24-bb29-854f706a0b37 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 125,652 | 6,760 | 132,412 | 24 / 24 | — |
| 运行累计 | 125,652 | 6,760 | 132,412 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:10174 | completed | 1 | 19.95 | 0.00 | complete / not-produced | — | [result](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/fd2486c5-fb28-4943-9fef-27c656ca161c/result.json) · [文件清单](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/fd2486c5-fb28-4943-9fef-27c656ca161c/files.json) · [轨迹](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/fd2486c5-fb28-4943-9fef-27c656ca161c/agent/trajectory.jsonl) |
| test:10184 | completed | 1 | 19.66 | 0.00 | complete / not-produced | — | [result](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/d10b8d3f-616a-4546-b8ed-bba4c2a77bc5/result.json) · [文件清单](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/d10b8d3f-616a-4546-b8ed-bba4c2a77bc5/files.json) · [轨迹](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/d10b8d3f-616a-4546-b8ed-bba4c2a77bc5/agent/trajectory.jsonl) |
| test:10189 | completed | 1 | 21.57 | 0.00 | complete / not-produced | — | [result](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/8fdc8c89-3f12-4c94-8101-cafb480a5450/result.json) · [文件清单](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/8fdc8c89-3f12-4c94-8101-cafb480a5450/files.json) · [轨迹](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/8fdc8c89-3f12-4c94-8101-cafb480a5450/agent/trajectory.jsonl) |
| test:10294 | completed | 1 | 20.24 | 0.00 | complete / not-produced | — | [result](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/d9cafaf1-0eb3-46eb-b88a-5f881d0a3d82/result.json) · [文件清单](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/d9cafaf1-0eb3-46eb-b88a-5f881d0a3d82/files.json) · [轨迹](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/d9cafaf1-0eb3-46eb-b88a-5f881d0a3d82/agent/trajectory.jsonl) |
| test:10318 | completed | 1 | 21.68 | 0.00 | complete / not-produced | — | [result](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/5235fcee-bc15-41ee-9388-b5c1ad7f801b/result.json) · [文件清单](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/5235fcee-bc15-41ee-9388-b5c1ad7f801b/files.json) · [轨迹](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/5235fcee-bc15-41ee-9388-b5c1ad7f801b/agent/trajectory.jsonl) |
| test:10362 | completed | 1 | 18.98 | 0.00 | complete / not-produced | — | [result](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/56a17059-481e-4f22-81f9-646465ba0716/result.json) · [文件清单](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/56a17059-481e-4f22-81f9-646465ba0716/files.json) · [轨迹](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/56a17059-481e-4f22-81f9-646465ba0716/agent/trajectory.jsonl) |
| test:10396 | completed | 1 | 21.88 | 0.00 | complete / not-produced | — | [result](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/940719b9-6868-4505-bc6c-da7f4a62daf1/result.json) · [文件清单](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/940719b9-6868-4505-bc6c-da7f4a62daf1/files.json) · [轨迹](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/940719b9-6868-4505-bc6c-da7f4a62daf1/agent/trajectory.jsonl) |
| test:10401 | completed | 1 | 26.83 | 0.00 | complete / not-produced | — | [result](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/0080bb3d-27a6-43e8-8a39-e83c026c969f/result.json) · [文件清单](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/0080bb3d-27a6-43e8-8a39-e83c026c969f/files.json) · [轨迹](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/0080bb3d-27a6-43e8-8a39-e83c026c969f/agent/trajectory.jsonl) |
| test:10403 | completed | 1 | 19.30 | 0.00 | complete / not-produced | — | [result](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/9a22ab7c-ab95-4de6-b38a-b64895c75fce/result.json) · [文件清单](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/9a22ab7c-ab95-4de6-b38a-b64895c75fce/files.json) · [轨迹](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/9a22ab7c-ab95-4de6-b38a-b64895c75fce/agent/trajectory.jsonl) |
| test:10412 | completed | 1 | 20.40 | 0.00 | complete / not-produced | — | [result](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/d6439ef9-12f3-4713-99f1-ae3c209ca2ba/result.json) · [文件清单](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/d6439ef9-12f3-4713-99f1-ae3c209ca2ba/files.json) · [轨迹](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/d6439ef9-12f3-4713-99f1-ae3c209ca2ba/agent/trajectory.jsonl) |
| test:10421 | completed | 1 | 21.26 | 0.00 | complete / not-produced | — | [result](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/1dee83ca-1529-4cd4-97ee-61df0d089965/result.json) · [文件清单](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/1dee83ca-1529-4cd4-97ee-61df0d089965/files.json) · [轨迹](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/1dee83ca-1529-4cd4-97ee-61df0d089965/agent/trajectory.jsonl) |
| test:10424 | completed | 1 | 17.96 | 0.00 | complete / not-produced | — | [result](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/08128f30-a805-4f4f-b91b-cdaa66c50519/result.json) · [文件清单](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/08128f30-a805-4f4f-b91b-cdaa66c50519/files.json) · [轨迹](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/08128f30-a805-4f4f-b91b-cdaa66c50519/agent/trajectory.jsonl) |
| test:10471 | completed | 1 | 11.30 | 0.00 | complete / not-produced | — | [result](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/1aeeb402-938e-4399-b2ea-031fdd9dc1b4/result.json) · [文件清单](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/1aeeb402-938e-4399-b2ea-031fdd9dc1b4/files.json) · [轨迹](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/1aeeb402-938e-4399-b2ea-031fdd9dc1b4/agent/trajectory.jsonl) |
| test:10479 | completed | 1 | 12.80 | 0.00 | complete / not-produced | — | [result](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/41559263-3301-4d20-99ac-c258cb89f11a/result.json) · [文件清单](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/41559263-3301-4d20-99ac-c258cb89f11a/files.json) · [轨迹](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/41559263-3301-4d20-99ac-c258cb89f11a/agent/trajectory.jsonl) |
| test:10524 | completed | 1 | 12.75 | 0.00 | complete / not-produced | — | [result](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/c5c84dea-9a63-442b-9f42-26bd30eea5be/result.json) · [文件清单](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/c5c84dea-9a63-442b-9f42-26bd30eea5be/files.json) · [轨迹](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/c5c84dea-9a63-442b-9f42-26bd30eea5be/agent/trajectory.jsonl) |
| test:10607 | completed | 1 | 13.02 | 0.00 | complete / not-produced | — | [result](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/8b8d18e3-ac4b-4abb-8256-74db2ccba390/result.json) · [文件清单](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/8b8d18e3-ac4b-4abb-8256-74db2ccba390/files.json) · [轨迹](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/8b8d18e3-ac4b-4abb-8256-74db2ccba390/agent/trajectory.jsonl) |
| test:10656 | completed | 1 | 15.99 | 0.00 | complete / not-produced | — | [result](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/6592627a-fae2-42b2-8422-d2153a8c83cb/result.json) · [文件清单](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/6592627a-fae2-42b2-8422-d2153a8c83cb/files.json) · [轨迹](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/6592627a-fae2-42b2-8422-d2153a8c83cb/agent/trajectory.jsonl) |
| test:10674 | completed | 1 | 16.62 | 0.00 | complete / not-produced | — | [result](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/92a099c5-4451-475e-bec2-a44def537a23/result.json) · [文件清单](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/92a099c5-4451-475e-bec2-a44def537a23/files.json) · [轨迹](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/92a099c5-4451-475e-bec2-a44def537a23/agent/trajectory.jsonl) |
| test:10683 | completed | 1 | 16.85 | 0.00 | complete / not-produced | — | [result](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/84eeb257-7b59-4654-9364-b1f8504bff59/result.json) · [文件清单](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/84eeb257-7b59-4654-9364-b1f8504bff59/files.json) · [轨迹](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/84eeb257-7b59-4654-9364-b1f8504bff59/agent/trajectory.jsonl) |
| test:10690 | completed | 1 | 15.88 | 0.00 | complete / not-produced | — | [result](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/d6794bae-40c8-4930-9b31-e33ae51d07f5/result.json) · [文件清单](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/d6794bae-40c8-4930-9b31-e33ae51d07f5/files.json) · [轨迹](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/d6794bae-40c8-4930-9b31-e33ae51d07f5/agent/trajectory.jsonl) |
| test:10765 | completed | 1 | 12.98 | 0.00 | complete / not-produced | — | [result](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/03e98806-6fe8-45e8-8510-7a3cc24171e9/result.json) · [文件清单](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/03e98806-6fe8-45e8-8510-7a3cc24171e9/files.json) · [轨迹](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/03e98806-6fe8-45e8-8510-7a3cc24171e9/agent/trajectory.jsonl) |
| test:10770 | completed | 1 | 16.08 | 0.00 | complete / not-produced | — | [result](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/3b211fa4-6be1-4fa7-b435-127749dfdfee/result.json) · [文件清单](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/3b211fa4-6be1-4fa7-b435-127749dfdfee/files.json) · [轨迹](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/3b211fa4-6be1-4fa7-b435-127749dfdfee/agent/trajectory.jsonl) |
| test:10815 | completed | 1 | 14.45 | 0.00 | complete / not-produced | — | [result](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/750b095c-a0bd-4208-bade-aa2cb01c7c77/result.json) · [文件清单](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/750b095c-a0bd-4208-bade-aa2cb01c7c77/files.json) · [轨迹](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/750b095c-a0bd-4208-bade-aa2cb01c7c77/agent/trajectory.jsonl) |
| test:10846 | completed | 1 | 26.58 | 0.00 | complete / not-produced | — | [result](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/1e350b4d-7cae-4139-95eb-96712e695b3b/result.json) · [文件清单](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/1e350b4d-7cae-4139-95eb-96712e695b3b/files.json) · [轨迹](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/1e350b4d-7cae-4139-95eb-96712e695b3b/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

