<!-- snapshotDigest: fe0fe5aae024081f4b5e18d8e387fd099ab6df19ee041a229ea1fc0b30caa80b -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 20.29%（42/207）**

Run: a4dcdd41-cbbd-4102-b1fb-4eb3de76a685 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:02:53.318Z / 2026-11-12T07:20:14.533Z |
| 总耗时 | 16 分 47 秒 |
| 答对 / 答错 / 解题超时 | 42 / 7 / 0 |
| 清理未确认 | 1 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 210 题；已保存 52 条记录；待运行 160 题。
有效评分覆盖率：49/210（23.33%）。
执行失败 1；超时 0；取消 2；不支持 0。
Agent 解题超时 0（计 0 分）；无效 3。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 210 |
| 计分题数 | 207 |
| 正常评分题数 | 49 |
| 答对题数 | 42 |
| 无效评测 | 3 |
| 待运行 | 160 |
| 正确率 | 20.29% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 16 分 47 秒 |
| 环境准备耗时 | 17 分 19 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 50 秒 | 20 秒 | 2 分 43 秒 | 52 |
| 任务准备 | 0.53 毫秒 | 0.2 毫秒 | 2.21 毫秒 | 52 |
| 环境启动 | 22 秒 | 12 秒 | 42 秒 | 52 |
| 解题 | 18 秒 | 5 秒 | 2 分 6 秒 | 50 |
| 产物传输 | 3 秒 | 1 秒 | 5 秒 | 50 |
| 资源清理 | 8 秒 | 4 秒 | 17 秒 | 50 |
| 评分 | 1.04 毫秒 | 0.26 毫秒 | 11.58 毫秒 | 49 |
| 证据收集 | 23.87 毫秒 | 1.51 毫秒 | 91.22 毫秒 | 52 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| a301ca2b-e971-4fa3-a2e7-67d5c4e347de | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 67,411 | 64,167 | 131,578 | 50 / 210 | — |
| 运行累计 | 67,411 | 64,167 | 131,578 | 50 / 52 | 2 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:41 | completed | 1 | 8.20 | 0.00 | complete / not-produced | — | [result](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/3b3ecbb2-fa75-40cf-9ca5-83cf613a2c56/result.json) · [文件清单](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/3b3ecbb2-fa75-40cf-9ca5-83cf613a2c56/files.json) · [轨迹](tasks/a5ad3829fb2fb5fdd60360e01e19cbcd3d8ea757c1370fdab584cd15b9f85cfd/attempts/3b3ecbb2-fa75-40cf-9ca5-83cf613a2c56/agent/trajectory.jsonl) |
| test:61 | completed | 0 | 21.66 | 0.00 | complete / not-produced | — | [result](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/7a3ff2f2-077d-44ea-880d-7454d2466753/result.json) · [文件清单](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/7a3ff2f2-077d-44ea-880d-7454d2466753/files.json) · [轨迹](tasks/ab5954bda05da084738a5061d27de254ae171a4184fd4c5573ae904cc7599a04/attempts/7a3ff2f2-077d-44ea-880d-7454d2466753/agent/trajectory.jsonl) |
| test:97 | completed | 1 | 52.28 | 0.00 | complete / not-produced | — | [result](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/45aa721b-9c57-4f74-baa2-b10c4da16bda/result.json) · [文件清单](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/45aa721b-9c57-4f74-baa2-b10c4da16bda/files.json) · [轨迹](tasks/79794103f6c3e6e05c08edfe88c1a3534e28b4654df2d95e44ba48577c0bc353/attempts/45aa721b-9c57-4f74-baa2-b10c4da16bda/agent/trajectory.jsonl) |
| test:209 | completed | 1 | 11.52 | 0.01 | complete / not-produced | — | [result](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/43dee4d5-36ea-4d73-af7f-f0b7d865b148/result.json) · [文件清单](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/43dee4d5-36ea-4d73-af7f-f0b7d865b148/files.json) · [轨迹](tasks/5fbff685fbabd29b72d7c80908a30cee79697cda1e9fe266cb2fc933d271c749/attempts/43dee4d5-36ea-4d73-af7f-f0b7d865b148/agent/trajectory.jsonl) |
| test:286 | completed | 1 | 8.95 | 0.00 | complete / not-produced | — | [result](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/78e443eb-4104-4c12-b473-06f914142317/result.json) · [文件清单](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/78e443eb-4104-4c12-b473-06f914142317/files.json) · [轨迹](tasks/332901e1a7c54bced9f5db77b67cb622bbe45bcbbd847fb7e97104e08f9c29b6/attempts/78e443eb-4104-4c12-b473-06f914142317/agent/trajectory.jsonl) |
| test:299 | completed | 1 | 9.13 | 0.00 | complete / not-produced | — | [result](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/18e09376-3a95-4706-87c1-a520c6dacd82/result.json) · [文件清单](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/18e09376-3a95-4706-87c1-a520c6dacd82/files.json) · [轨迹](tasks/2c741bc1e9de130303962aa1073a421a047086534f8145d39fbbb2df6176ea28/attempts/18e09376-3a95-4706-87c1-a520c6dacd82/agent/trajectory.jsonl) |
| test:311 | completed | 1 | 20.37 | 0.00 | complete / not-produced | — | [result](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/44b45d4a-1183-4fbd-a020-5c60a298defc/result.json) · [文件清单](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/44b45d4a-1183-4fbd-a020-5c60a298defc/files.json) · [轨迹](tasks/dc92d055962652490affc7e2cbdf31c5f6a1df7d071e0a00c6f50350ada58782/attempts/44b45d4a-1183-4fbd-a020-5c60a298defc/agent/trajectory.jsonl) |
| test:352 | completed | 1 | 12.57 | 0.00 | complete / not-produced | — | [result](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/e90ab1b0-5ea5-4765-bdbd-b4350fedf47b/result.json) · [文件清单](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/e90ab1b0-5ea5-4765-bdbd-b4350fedf47b/files.json) · [轨迹](tasks/4393ea0ddb7a2ed2842ec86b930e051b095f828c8ef203fcb58b30c566936c8b/attempts/e90ab1b0-5ea5-4765-bdbd-b4350fedf47b/agent/trajectory.jsonl) |
| test:355 | completed | 1 | 7.27 | 0.00 | complete / not-produced | — | [result](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/d47420f1-df82-4893-88e0-291f1b71dcfb/result.json) · [文件清单](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/d47420f1-df82-4893-88e0-291f1b71dcfb/files.json) · [轨迹](tasks/039219b477bd7fae4a7dba56bc221dd43a98f456a5b11d5e66461498d5af8e5f/attempts/d47420f1-df82-4893-88e0-291f1b71dcfb/agent/trajectory.jsonl) |
| test:476 | completed | 1 | 8.94 | 0.00 | complete / not-produced | — | [result](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/df705615-d02f-4ced-961d-429ed337635b/result.json) · [文件清单](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/df705615-d02f-4ced-961d-429ed337635b/files.json) · [轨迹](tasks/a92a27743f996a09e320bf6d3796844367641a7548c65043465ba701a932bcb6/attempts/df705615-d02f-4ced-961d-429ed337635b/agent/trajectory.jsonl) |
| test:511 | completed | 1 | 7.15 | 0.00 | complete / not-produced | — | [result](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/de61bcc8-656c-4b5d-98a4-70c606459195/result.json) · [文件清单](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/de61bcc8-656c-4b5d-98a4-70c606459195/files.json) · [轨迹](tasks/d88167561bfc262c22aa7bb9e5ff2fc65d179ce95e8bc19d1f8b3261d5b8fffe/attempts/de61bcc8-656c-4b5d-98a4-70c606459195/agent/trajectory.jsonl) |
| test:552 | completed | 1 | 6.22 | 0.00 | complete / not-produced | — | [result](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/276fe440-2c2f-4923-800e-d7d4bc2d6101/result.json) · [文件清单](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/276fe440-2c2f-4923-800e-d7d4bc2d6101/files.json) · [轨迹](tasks/588b3fd932f0097f8f892a7f191438b2befc91b85185c398e55bec636c92c7ec/attempts/276fe440-2c2f-4923-800e-d7d4bc2d6101/agent/trajectory.jsonl) |
| test:624 | completed | 1 | 4.76 | 0.00 | complete / not-produced | — | [result](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/599d3f1b-ec1c-4a67-aa05-33b3f8982cc3/result.json) · [文件清单](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/599d3f1b-ec1c-4a67-aa05-33b3f8982cc3/files.json) · [轨迹](tasks/2d7aed63309f873dfb61abb44aff56fc0e05f91057e371a0745b3a0ad74b2fdf/attempts/599d3f1b-ec1c-4a67-aa05-33b3f8982cc3/agent/trajectory.jsonl) |
| test:669 | completed | 1 | 6.01 | 0.00 | complete / not-produced | — | [result](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/38948b34-8eab-4241-a66d-4beae05d2554/result.json) · [文件清单](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/38948b34-8eab-4241-a66d-4beae05d2554/files.json) · [轨迹](tasks/ff3fb9e6946fc634b3813ffcd8d8081ad2396c1181162b54e4493bb1ffb5117f/attempts/38948b34-8eab-4241-a66d-4beae05d2554/agent/trajectory.jsonl) |
| test:670 | completed | 1 | 4.93 | 0.00 | complete / not-produced | — | [result](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/4594c965-b793-447d-998c-28b25f0165e3/result.json) · [文件清单](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/4594c965-b793-447d-998c-28b25f0165e3/files.json) · [轨迹](tasks/25c5ad552840d21fa0791f154e5204554173d42b1c1c80ccd17865bc47d52347/attempts/4594c965-b793-447d-998c-28b25f0165e3/agent/trajectory.jsonl) |
| test:796 | completed | 1 | 33.55 | 0.00 | complete / not-produced | — | [result](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/6970ae16-81af-48cd-b283-28522d1be624/result.json) · [文件清单](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/6970ae16-81af-48cd-b283-28522d1be624/files.json) · [轨迹](tasks/0c23a9279e9b705c69721dc05f200303478643165a8f67c3a810b318cfc0ef7a/attempts/6970ae16-81af-48cd-b283-28522d1be624/agent/trajectory.jsonl) |
| test:828 | completed | 1 | 6.94 | 0.00 | complete / not-produced | — | [result](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/e0fe8dd7-afd2-4b04-b157-4c017ead647e/result.json) · [文件清单](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/e0fe8dd7-afd2-4b04-b157-4c017ead647e/files.json) · [轨迹](tasks/a45b81965df9e27dfff2291a92780c98e797eeac69d41736f0741de33a204c34/attempts/e0fe8dd7-afd2-4b04-b157-4c017ead647e/agent/trajectory.jsonl) |
| test:841 | completed | 1 | 7.26 | 0.00 | complete / not-produced | — | [result](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/8cde50b0-16c1-482a-9efe-262de6491d86/result.json) · [文件清单](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/8cde50b0-16c1-482a-9efe-262de6491d86/files.json) · [轨迹](tasks/119ad2f860440178d125bd6a4a0d529f867046622bcdc0da432f9f2a0f7ecd3a/attempts/8cde50b0-16c1-482a-9efe-262de6491d86/agent/trajectory.jsonl) |
| test:883 | completed | 1 | 8.17 | 0.00 | complete / not-produced | — | [result](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/adfbf410-1449-4433-9fa9-e7c7a743fbd3/result.json) · [文件清单](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/adfbf410-1449-4433-9fa9-e7c7a743fbd3/files.json) · [轨迹](tasks/86b680376452a1493e6e2294677d33c5b46004cfd476c8bd5bb29786c7c2d271/attempts/adfbf410-1449-4433-9fa9-e7c7a743fbd3/agent/trajectory.jsonl) |
| test:938 | completed | 1 | 12.88 | 0.00 | complete / not-produced | — | [result](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/1b943932-d2c5-40a6-b95d-f491014f59eb/result.json) · [文件清单](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/1b943932-d2c5-40a6-b95d-f491014f59eb/files.json) · [轨迹](tasks/a0bad859971121c63e6b515fb7101e9643f3dedfbca67b599c7df1cf6fe3a8a2/attempts/1b943932-d2c5-40a6-b95d-f491014f59eb/agent/trajectory.jsonl) |
| test:1026 | completed | 0 | 14.42 | 0.00 | complete / not-produced | — | [result](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/46908a31-acea-4a09-9341-1ecf5fe9e904/result.json) · [文件清单](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/46908a31-acea-4a09-9341-1ecf5fe9e904/files.json) · [轨迹](tasks/30418146991a5a4eaa1888fc9b60c102d0d4c4bb4f847c6ad5c5be94951d75e7/attempts/46908a31-acea-4a09-9341-1ecf5fe9e904/agent/trajectory.jsonl) |
| test:1229 | completed | 1 | 9.27 | 0.00 | complete / not-produced | — | [result](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/01f488a6-4619-4f84-b631-ef69ff2475de/result.json) · [文件清单](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/01f488a6-4619-4f84-b631-ef69ff2475de/files.json) · [轨迹](tasks/c0cedb3fc904d9d4d70bc76e161a79c8f1c63d3718787f5b4c00745b56838bf7/attempts/01f488a6-4619-4f84-b631-ef69ff2475de/agent/trajectory.jsonl) |
| test:1252 | completed | 1 | 7.56 | 0.00 | complete / not-produced | — | [result](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/38ab408a-cd6c-4d22-a72f-cdbba512a44b/result.json) · [文件清单](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/38ab408a-cd6c-4d22-a72f-cdbba512a44b/files.json) · [轨迹](tasks/5a27e29500ae15e1e6fcaf8af84c0295bbe26f517a4576e6fac973244b51138a/attempts/38ab408a-cd6c-4d22-a72f-cdbba512a44b/agent/trajectory.jsonl) |
| test:1399 | completed | 1 | 11.05 | 0.00 | complete / not-produced | — | [result](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/7748ad50-41a7-4016-a556-4d4b50a7d8e8/result.json) · [文件清单](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/7748ad50-41a7-4016-a556-4d4b50a7d8e8/files.json) · [轨迹](tasks/2fec8fc519acaeb3df89eeeb861ac20d083ac7b33821bf30835359d468bafbb5/attempts/7748ad50-41a7-4016-a556-4d4b50a7d8e8/agent/trajectory.jsonl) |
| test:1454 | completed | 1 | 65.21 | 0.00 | complete / not-produced | — | [result](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/601c4393-eb8f-4007-b609-4388a2eaa649/result.json) · [文件清单](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/601c4393-eb8f-4007-b609-4388a2eaa649/files.json) · [轨迹](tasks/afed7a9c47be42b6f4d5b392b3e1ee90a12867aaf307c2d46594b49fa10e6ac4/attempts/601c4393-eb8f-4007-b609-4388a2eaa649/agent/trajectory.jsonl) |
| test:1514 | completed | 0 | 34.91 | 0.00 | complete / not-produced | — | [result](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/bb4206c1-6a27-4e2b-b674-253b90def171/result.json) · [文件清单](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/bb4206c1-6a27-4e2b-b674-253b90def171/files.json) · [轨迹](tasks/7d78304e4c6cf95be03e3bf8252c4b43c9447a6ea8618920c1d4bcf3f6d60c62/attempts/bb4206c1-6a27-4e2b-b674-253b90def171/agent/trajectory.jsonl) |
| test:1531 | completed | 1 | 53.26 | 0.00 | complete / not-produced | — | [result](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/f7b5cdce-e3d3-409b-99d9-433a0dd705cc/result.json) · [文件清单](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/f7b5cdce-e3d3-409b-99d9-433a0dd705cc/files.json) · [轨迹](tasks/d5ac8b829a1db0a02954e494b1950286d25cff9c2192a33f363fe063ec52f636/attempts/f7b5cdce-e3d3-409b-99d9-433a0dd705cc/agent/trajectory.jsonl) |
| test:1785 | completed | 0 | 125.97 | 0.01 | complete / not-produced | — | [result](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/b5de5b63-d89f-49ec-b3d1-cfa5d1d1e34a/result.json) · [文件清单](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/b5de5b63-d89f-49ec-b3d1-cfa5d1d1e34a/files.json) · [轨迹](tasks/0c39487f4e90abd37b7260245eda7b34601570c662f3efc32ef7f879eb3397c0/attempts/b5de5b63-d89f-49ec-b3d1-cfa5d1d1e34a/agent/trajectory.jsonl) |
| test:1806 | completed | 0 | 119.64 | 0.00 | complete / not-produced | — | [result](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/d60f3cba-b65a-4646-a989-4dd51a431827/result.json) · [文件清单](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/d60f3cba-b65a-4646-a989-4dd51a431827/files.json) · [轨迹](tasks/3d0fdada01f84b7b7137931f5e3f55c804edb4d7d386a45560e093882c073451/attempts/d60f3cba-b65a-4646-a989-4dd51a431827/agent/trajectory.jsonl) |
| test:1827 | completed | 1 | 8.56 | 0.00 | complete / not-produced | — | [result](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/570e984f-36a4-4657-ab62-50661a4cd5a2/result.json) · [文件清单](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/570e984f-36a4-4657-ab62-50661a4cd5a2/files.json) · [轨迹](tasks/9d7d6919f50ae113d7af8b355b8899f4b7b75a1b95047802e28a4ad8e3b20c97/attempts/570e984f-36a4-4657-ab62-50661a4cd5a2/agent/trajectory.jsonl) |
| test:1904 | completed | 1 | 7.32 | 0.00 | complete / not-produced | — | [result](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/71dfb1fd-99d4-4811-b8ad-58a9f89182eb/result.json) · [文件清单](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/71dfb1fd-99d4-4811-b8ad-58a9f89182eb/files.json) · [轨迹](tasks/e005b8c2450036e7274d94e3f1aacdfadb40f3fd894eefccdd4eca40bcc6841f/attempts/71dfb1fd-99d4-4811-b8ad-58a9f89182eb/agent/trajectory.jsonl) |
| test:1943 | completed | 1 | 8.49 | 0.00 | complete / not-produced | — | [result](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/e2ffc96c-ea03-4df1-8167-30338a0746d8/result.json) · [文件清单](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/e2ffc96c-ea03-4df1-8167-30338a0746d8/files.json) · [轨迹](tasks/fdddeeaea23613b459b7c9755c75e327c50a0c2b4faf29fdbc41d827446d702d/attempts/e2ffc96c-ea03-4df1-8167-30338a0746d8/agent/trajectory.jsonl) |
| test:1998 | completed | 1 | 7.61 | 0.00 | complete / not-produced | — | [result](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/2b518e3f-c5ef-40fd-8e74-43010b88a21e/result.json) · [文件清单](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/2b518e3f-c5ef-40fd-8e74-43010b88a21e/files.json) · [轨迹](tasks/112b174d77756bac074b8c5c2be62354394fe5b7744eebc7aa14c3053aa63a73/attempts/2b518e3f-c5ef-40fd-8e74-43010b88a21e/agent/trajectory.jsonl) |
| test:2023 | completed | 1 | 7.34 | 0.00 | complete / not-produced | — | [result](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/3d43eaa2-0bc0-4954-a141-85b6eeefe6d0/result.json) · [文件清单](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/3d43eaa2-0bc0-4954-a141-85b6eeefe6d0/files.json) · [轨迹](tasks/bd2e5653024fb327ee07fdaa135a139cdb0f1e901a29ffc972da57e5ab299e79/attempts/3d43eaa2-0bc0-4954-a141-85b6eeefe6d0/agent/trajectory.jsonl) |
| test:2096 | completed | 0 | 10.16 | 0.00 | complete / not-produced | — | [result](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/1c0e4245-3ed5-43f1-8de6-d66205241053/result.json) · [文件清单](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/1c0e4245-3ed5-43f1-8de6-d66205241053/files.json) · [轨迹](tasks/1c3161fd2e58c502e6a33fc7b4f7f97d312c4c01cc69acca1dfc855739b42b9d/attempts/1c0e4245-3ed5-43f1-8de6-d66205241053/agent/trajectory.jsonl) |
| test:2152 | completed | 1 | 8.03 | 0.00 | complete / not-produced | — | [result](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/e8db1628-0581-4afb-84e3-4a7c311beaac/result.json) · [文件清单](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/e8db1628-0581-4afb-84e3-4a7c311beaac/files.json) · [轨迹](tasks/8194038e462420a2048abdc3265af6e3caee926aba08138e6d40698716dd4eca/attempts/e8db1628-0581-4afb-84e3-4a7c311beaac/agent/trajectory.jsonl) |
| test:2175 | completed | 1 | 7.11 | 0.00 | complete / not-produced | — | [result](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/4d63f0d2-c1d5-4226-8e9c-fbc5880ee708/result.json) · [文件清单](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/4d63f0d2-c1d5-4226-8e9c-fbc5880ee708/files.json) · [轨迹](tasks/c105d096946e5ecc06d704afa434effefc4e2f388efeebe1a451bf09ba98bd0f/attempts/4d63f0d2-c1d5-4226-8e9c-fbc5880ee708/agent/trajectory.jsonl) |
| test:2177 | completed | 1 | 8.79 | 0.00 | complete / not-produced | — | [result](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/5faf32a1-4a69-46f6-aba4-647c4db11dc3/result.json) · [文件清单](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/5faf32a1-4a69-46f6-aba4-647c4db11dc3/files.json) · [轨迹](tasks/14503c3421d934ca3fa643f5c9267fda23af6bffa0e7a90e1ace6569c50f3683/attempts/5faf32a1-4a69-46f6-aba4-647c4db11dc3/agent/trajectory.jsonl) |
| test:2206 | completed | 1 | 7.19 | 0.00 | complete / not-produced | — | [result](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/2d21eaf2-f153-4612-b65f-ebec914310f5/result.json) · [文件清单](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/2d21eaf2-f153-4612-b65f-ebec914310f5/files.json) · [轨迹](tasks/2d9853f41859ea1c0410775462b4cccdc1383b31ae04b00420f25155caacb286/attempts/2d21eaf2-f153-4612-b65f-ebec914310f5/agent/trajectory.jsonl) |
| test:2280 | completed | 1 | 7.41 | 0.00 | complete / not-produced | — | [result](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/46647786-7e08-4d43-8ca1-ebd5fcce9fe6/result.json) · [文件清单](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/46647786-7e08-4d43-8ca1-ebd5fcce9fe6/files.json) · [轨迹](tasks/dde636c808dd513ce67465a9e0da11a4691e4905e22f69d690b341b9ce6abffd/attempts/46647786-7e08-4d43-8ca1-ebd5fcce9fe6/agent/trajectory.jsonl) |
| test:2347 | completed | 1 | 24.69 | 0.00 | complete / not-produced | — | [result](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/b1ed1f46-ca60-458c-98b5-e60da36e722a/result.json) · [文件清单](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/b1ed1f46-ca60-458c-98b5-e60da36e722a/files.json) · [轨迹](tasks/6335721607088c711c8324f723a03e6cb64e3f7d8d3c6ae9898b5ed8d418f75f/attempts/b1ed1f46-ca60-458c-98b5-e60da36e722a/agent/trajectory.jsonl) |
| test:2400 | completed | 1 | 9.26 | 0.00 | complete / not-produced | — | [result](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/660ce676-5619-4b7a-a070-720a2144e148/result.json) · [文件清单](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/660ce676-5619-4b7a-a070-720a2144e148/files.json) · [轨迹](tasks/a4edde56f67479a79badd770b0788dc248568b112320021f9a84ba9d2cf269d3/attempts/660ce676-5619-4b7a-a070-720a2144e148/agent/trajectory.jsonl) |
| test:2527 | completed | 1 | 6.93 | 0.00 | complete / not-produced | — | [result](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/2bfdb32b-fc5d-4768-bc7f-e769a0229dbb/result.json) · [文件清单](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/2bfdb32b-fc5d-4768-bc7f-e769a0229dbb/files.json) · [轨迹](tasks/1433bdac5088204afb223911a88aa74f9e02737a7716de5f4612400dc091b3cc/attempts/2bfdb32b-fc5d-4768-bc7f-e769a0229dbb/agent/trajectory.jsonl) |
| test:2636 | completed | 1 | 5.46 | 0.00 | complete / not-produced | — | [result](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/a50db2ab-f993-4556-b35e-90813a470ac8/result.json) · [文件清单](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/a50db2ab-f993-4556-b35e-90813a470ac8/files.json) · [轨迹](tasks/692a170a28351eb7f888f0f6ef1d144de78ef81e326112a7e5bfe3a1b29a37fd/attempts/a50db2ab-f993-4556-b35e-90813a470ac8/agent/trajectory.jsonl) |
| test:2641 | completed | 1 | 4.87 | 0.00 | complete / not-produced | — | [result](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/098805cd-ba8a-4d49-9a19-fbc825f8a923/result.json) · [文件清单](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/098805cd-ba8a-4d49-9a19-fbc825f8a923/files.json) · [轨迹](tasks/56b6537b91fa0e9f94cea568abcf483bc5adec4a498bae126e75d0a0a3c838b0/attempts/098805cd-ba8a-4d49-9a19-fbc825f8a923/agent/trajectory.jsonl) |
| test:2714 | completed | 1 | 5.08 | 0.00 | complete / not-produced | — | [result](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/7928c512-6178-4bfe-af93-11437426c95c/result.json) · [文件清单](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/7928c512-6178-4bfe-af93-11437426c95c/files.json) · [轨迹](tasks/cdaa8e8942f53036e0098b8c978b0cb060fa13c0458a1886b3a7fe4491340843/attempts/7928c512-6178-4bfe-af93-11437426c95c/agent/trajectory.jsonl) |
| test:2716 | completed | 1 | 12.46 | 0.00 | complete / not-produced | — | [result](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/a4fc8aa0-6cb5-45ad-a3c0-4d590017596b/result.json) · [文件清单](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/a4fc8aa0-6cb5-45ad-a3c0-4d590017596b/files.json) · [轨迹](tasks/d975d3e0f11d6fb8df556f770a744adc64182cc1e66b5ef7891bd09a2d0cbe3f/attempts/a4fc8aa0-6cb5-45ad-a3c0-4d590017596b/agent/trajectory.jsonl) |
| test:2747 | completed | 1 | 5.72 | 0.00 | complete / not-produced | — | [result](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/6b8fbb17-3cb0-4618-9875-e213ff802aba/result.json) · [文件清单](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/6b8fbb17-3cb0-4618-9875-e213ff802aba/files.json) · [轨迹](tasks/0fc8f4d8130e767703696381fd5f751355e157210ee5a893478640ec6ecaf7db/attempts/6b8fbb17-3cb0-4618-9875-e213ff802aba/agent/trajectory.jsonl) |
| test:2882 | completed | 0 | 9.39 | 0.00 | complete / not-produced | — | [result](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/2bc999aa-9e48-45d4-913f-3552f3f2589b/result.json) · [文件清单](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/2bc999aa-9e48-45d4-913f-3552f3f2589b/files.json) · [轨迹](tasks/ddceb01a02e2a237de19c8be94dca9fb9b25b474a04be9e0c8f75f05e151275d/attempts/2bc999aa-9e48-45d4-913f-3552f3f2589b/agent/trajectory.jsonl) |
| test:2951 | invalid | — | 7.31 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/069619ed-3415-4f67-a74b-655ef087fe13/result.json) · [文件清单](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/069619ed-3415-4f67-a74b-655ef087fe13/files.json) · [轨迹](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/069619ed-3415-4f67-a74b-655ef087fe13/agent/trajectory.jsonl) |
| test:3037 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/67a76f9c-5ca4-4f1f-9129-7676fd43a5be/result.json) · [文件清单](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/67a76f9c-5ca4-4f1f-9129-7676fd43a5be/files.json) |
| test:3053 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/b5aa23f4-3001-4bc0-8fd8-b85dca058b5c/result.json) · [文件清单](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/b5aa23f4-3001-4bc0-8fd8-b85dca058b5c/files.json) |
| test:3136 | pending | — | — | — | — | — | — |
| test:3165 | pending | — | — | — | — | — | — |
| test:3196 | pending | — | — | — | — | — | — |
| test:3231 | pending | — | — | — | — | — | — |
| test:3236 | pending | — | — | — | — | — | — |
| test:3270 | pending | — | — | — | — | — | — |
| test:3293 | pending | — | — | — | — | — | — |
| test:3331 | pending | — | — | — | — | — | — |
| test:3488 | pending | — | — | — | — | — | — |
| test:3491 | pending | — | — | — | — | — | — |
| test:3552 | pending | — | — | — | — | — | — |
| test:3599 | pending | — | — | — | — | — | — |
| test:3626 | pending | — | — | — | — | — | — |
| test:4021 | pending | — | — | — | — | — | — |
| test:4034 | pending | — | — | — | — | — | — |
| test:4058 | pending | — | — | — | — | — | — |
| test:4075 | pending | — | — | — | — | — | — |
| test:4142 | pending | — | — | — | — | — | — |
| test:4208 | pending | — | — | — | — | — | — |
| test:4298 | pending | — | — | — | — | — | — |
| test:4337 | pending | — | — | — | — | — | — |
| test:4376 | pending | — | — | — | — | — | — |
| test:4405 | pending | — | — | — | — | — | — |
| test:4552 | pending | — | — | — | — | — | — |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 3；错误记录 4（主流程 2；证据收集 0；资源清理 2）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| cleanup | CLEANUP_FAILED | 1 | 2 |
| environment | RUN_CANCELLED | 2 | 2 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

