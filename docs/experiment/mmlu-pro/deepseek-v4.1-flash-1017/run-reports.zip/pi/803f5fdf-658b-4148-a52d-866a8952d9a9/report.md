<!-- snapshotDigest: 43a83d5b1b695326b45171df2f6193ec4da469be5f8e72a926b4ab256e64e3b6 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 95.83%（23/24）**

Run: 803f5fdf-658b-4148-a52d-866a8952d9a9 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:42:26.054Z / 2026-11-12T08:47:36.044Z |
| 总耗时 | 4 分 59 秒 |
| 答对 / 答错 / 解题超时 | 23 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 23 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 95.83% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 4 分 59 秒 |
| 环境准备耗时 | 3 分 37 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 43 秒 | 30 秒 | 1 分 1 秒 | 24 |
| 任务准备 | 0.5 毫秒 | 0.32 毫秒 | 1.72 毫秒 | 24 |
| 环境启动 | 22 秒 | 13 秒 | 30 秒 | 24 |
| 解题 | 9 秒 | 5 秒 | 15 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 6 秒 | 24 |
| 资源清理 | 9 秒 | 5 秒 | 14 秒 | 24 |
| 评分 | 0.79 毫秒 | 0.29 毫秒 | 4.66 毫秒 | 24 |
| 证据收集 | 20.8 毫秒 | 4.79 毫秒 | 121.72 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| e9ae81ee-5538-44c2-849a-488083b05c1b | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 38,861 | 7,918 | 46,779 | 24 / 24 | — |
| 运行累计 | 38,861 | 7,918 | 46,779 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:7448 | completed | 1 | 14.92 | 0.00 | complete / not-produced | — | [result](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/281c6c50-33e4-40fb-95be-b03eb114057c/result.json) · [文件清单](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/281c6c50-33e4-40fb-95be-b03eb114057c/files.json) · [轨迹](tasks/905232b07ad5659df5da5ad28ff01b5a7637dfc4cd81ccfa3395b1c77d62cc86/attempts/281c6c50-33e4-40fb-95be-b03eb114057c/agent/trajectory.jsonl) |
| test:7462 | completed | 1 | 10.32 | 0.00 | complete / not-produced | — | [result](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/f9f54f1b-154d-44a8-a987-f901762f7521/result.json) · [文件清单](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/f9f54f1b-154d-44a8-a987-f901762f7521/files.json) · [轨迹](tasks/5f97cb9518c96b6e065c39db917410b0a457ff0054035b0bc07cf45d357be1de/attempts/f9f54f1b-154d-44a8-a987-f901762f7521/agent/trajectory.jsonl) |
| test:7526 | completed | 1 | 8.95 | 0.00 | complete / not-produced | — | [result](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/98364db3-ffc3-4632-8575-ff9c8f249bbb/result.json) · [文件清单](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/98364db3-ffc3-4632-8575-ff9c8f249bbb/files.json) · [轨迹](tasks/89627a8f7c95c8caecf74cdbe1153afeeb2b30dce2a76b7aabe40235546849ef/attempts/98364db3-ffc3-4632-8575-ff9c8f249bbb/agent/trajectory.jsonl) |
| test:7727 | completed | 1 | 9.67 | 0.00 | complete / not-produced | — | [result](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/dee918ab-69b8-4682-9542-c199bafce560/result.json) · [文件清单](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/dee918ab-69b8-4682-9542-c199bafce560/files.json) · [轨迹](tasks/f0f327bd5875b6cdc04ade766101186e2bc8c2b8226a9a70a325f07ecd8f38f4/attempts/dee918ab-69b8-4682-9542-c199bafce560/agent/trajectory.jsonl) |
| test:7752 | completed | 0 | 8.77 | 0.00 | complete / not-produced | — | [result](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/ae3a7939-5c6c-44df-ae6a-15ab516bc729/result.json) · [文件清单](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/ae3a7939-5c6c-44df-ae6a-15ab516bc729/files.json) · [轨迹](tasks/a349f874be34784634a1a6122b9ee354ef2c8ebd651b68c615c8e2774e96910c/attempts/ae3a7939-5c6c-44df-ae6a-15ab516bc729/agent/trajectory.jsonl) |
| test:7838 | completed | 1 | 8.15 | 0.00 | complete / not-produced | — | [result](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/3d348ef0-9e9b-477e-9b39-54952ba074a1/result.json) · [文件清单](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/3d348ef0-9e9b-477e-9b39-54952ba074a1/files.json) · [轨迹](tasks/0648b4e0d923e6fafd3b0c45ef28952752a2664525c353dfa43cdb78b5be7c4b/attempts/3d348ef0-9e9b-477e-9b39-54952ba074a1/agent/trajectory.jsonl) |
| test:7954 | completed | 1 | 10.56 | 0.00 | complete / not-produced | — | [result](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/a3fe25b1-95ac-402c-a1e4-59f2de626240/result.json) · [文件清单](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/a3fe25b1-95ac-402c-a1e4-59f2de626240/files.json) · [轨迹](tasks/240261d5774c3a130d3ae279c67f78681b165195f289f5be69e5d33cccc0cca3/attempts/a3fe25b1-95ac-402c-a1e4-59f2de626240/agent/trajectory.jsonl) |
| test:7976 | completed | 1 | 8.20 | 0.00 | complete / not-produced | — | [result](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/b23287db-fe82-4a09-8968-8acab031836a/result.json) · [文件清单](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/b23287db-fe82-4a09-8968-8acab031836a/files.json) · [轨迹](tasks/a7bfefccb562f4aa8baf0aee58ffcc5e6e340c3f597ffd9d95fc072c1cf6cb17/attempts/b23287db-fe82-4a09-8968-8acab031836a/agent/trajectory.jsonl) |
| test:8199 | completed | 1 | 11.05 | 0.00 | complete / not-produced | — | [result](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/e05e6502-860c-4f6e-b3d8-82968137588f/result.json) · [文件清单](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/e05e6502-860c-4f6e-b3d8-82968137588f/files.json) · [轨迹](tasks/bdce02dd13cfbc68f2d7c7c5abbe6e7212f3b3601fe34322251aa115477d2682/attempts/e05e6502-860c-4f6e-b3d8-82968137588f/agent/trajectory.jsonl) |
| test:8207 | completed | 1 | 10.04 | 0.00 | complete / not-produced | — | [result](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/161e3dff-8e67-4892-9a0c-47537ab3d148/result.json) · [文件清单](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/161e3dff-8e67-4892-9a0c-47537ab3d148/files.json) · [轨迹](tasks/44df36125a0cd382ef68e65ee8741b674f7843b21c244cc0946673fa3ce34a60/attempts/161e3dff-8e67-4892-9a0c-47537ab3d148/agent/trajectory.jsonl) |
| test:8304 | completed | 1 | 7.90 | 0.00 | complete / not-produced | — | [result](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/3002b8c8-861f-4594-8aee-3a97e871aaa9/result.json) · [文件清单](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/3002b8c8-861f-4594-8aee-3a97e871aaa9/files.json) · [轨迹](tasks/96d6238b8c8d7962a9b554ddcc1f1f7d92fd0c95a6890af1dcc7ccb3ca9bf5db/attempts/3002b8c8-861f-4594-8aee-3a97e871aaa9/agent/trajectory.jsonl) |
| test:8366 | completed | 1 | 9.62 | 0.00 | complete / not-produced | — | [result](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/779320d0-cef7-4944-a0f0-16a08f94b5ae/result.json) · [文件清单](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/779320d0-cef7-4944-a0f0-16a08f94b5ae/files.json) · [轨迹](tasks/89efebbd94f706cbed2e26046702002d99c062f96b426275e102eff35c592571/attempts/779320d0-cef7-4944-a0f0-16a08f94b5ae/agent/trajectory.jsonl) |
| test:8511 | completed | 1 | 6.41 | 0.00 | complete / not-produced | — | [result](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/d2fbbdf0-3627-4243-9dab-e9c040822261/result.json) · [文件清单](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/d2fbbdf0-3627-4243-9dab-e9c040822261/files.json) · [轨迹](tasks/3703bdc467fc6b8c654013797a7d7c5baaff4010f39afe6814ecf7292fcb13ee/attempts/d2fbbdf0-3627-4243-9dab-e9c040822261/agent/trajectory.jsonl) |
| test:8525 | completed | 1 | 8.40 | 0.00 | complete / not-produced | — | [result](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/8fe2cfe8-ccb8-41d3-b4d9-3aca967d5049/result.json) · [文件清单](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/8fe2cfe8-ccb8-41d3-b4d9-3aca967d5049/files.json) · [轨迹](tasks/fe4693f14e018fc21a082d2c96f5d727adefb6589ee89faa704299c4a51066d0/attempts/8fe2cfe8-ccb8-41d3-b4d9-3aca967d5049/agent/trajectory.jsonl) |
| test:8604 | completed | 1 | 5.75 | 0.00 | complete / not-produced | — | [result](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/40c01a3b-b8ab-486d-9789-290e4df71d03/result.json) · [文件清单](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/40c01a3b-b8ab-486d-9789-290e4df71d03/files.json) · [轨迹](tasks/debdf3c4ebfa8f61a1e1d2389658d20fe3a1178a450115d66f66b3138d1217d7/attempts/40c01a3b-b8ab-486d-9789-290e4df71d03/agent/trajectory.jsonl) |
| test:8740 | completed | 1 | 7.72 | 0.00 | complete / not-produced | — | [result](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/7a5235b1-b929-4177-9b9b-97d44e94cec5/result.json) · [文件清单](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/7a5235b1-b929-4177-9b9b-97d44e94cec5/files.json) · [轨迹](tasks/5f3ece1ffdcdc271e93b41b313a678bcc0edac67f4c48f0c39dc86cfd1d9405c/attempts/7a5235b1-b929-4177-9b9b-97d44e94cec5/agent/trajectory.jsonl) |
| test:8839 | completed | 1 | 5.99 | 0.00 | complete / not-produced | — | [result](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/3d8a1df0-9254-4cc6-87b3-ea41f2c272d4/result.json) · [文件清单](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/3d8a1df0-9254-4cc6-87b3-ea41f2c272d4/files.json) · [轨迹](tasks/f36a3860347b0cd39d521bf04ca649b000b35ddca27d3477eaf221e5ac468943/attempts/3d8a1df0-9254-4cc6-87b3-ea41f2c272d4/agent/trajectory.jsonl) |
| test:8939 | completed | 1 | 6.69 | 0.00 | complete / not-produced | — | [result](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/82bc7e2c-3e12-48a2-bfdb-ae788c09a1b6/result.json) · [文件清单](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/82bc7e2c-3e12-48a2-bfdb-ae788c09a1b6/files.json) · [轨迹](tasks/c4bea4d6d5ce363907e05772d875b8611da0e9a38b63ddfd29bd71d25b864321/attempts/82bc7e2c-3e12-48a2-bfdb-ae788c09a1b6/agent/trajectory.jsonl) |
| test:8967 | completed | 1 | 6.90 | 0.00 | complete / not-produced | — | [result](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/a383b58e-30ed-4cb5-b095-66bede167cb9/result.json) · [文件清单](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/a383b58e-30ed-4cb5-b095-66bede167cb9/files.json) · [轨迹](tasks/c5a8cdb57ab18c0cafe61af6834af0af718fee170645011cdc99f7e1a457d996/attempts/a383b58e-30ed-4cb5-b095-66bede167cb9/agent/trajectory.jsonl) |
| test:8989 | completed | 1 | 10.03 | 0.00 | complete / not-produced | — | [result](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/8d56b743-91f5-4a65-931c-0cf5c00bdee3/result.json) · [文件清单](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/8d56b743-91f5-4a65-931c-0cf5c00bdee3/files.json) · [轨迹](tasks/05b7819207b09056f66bd0873ff50773f1a85302c75973558c170ff4d814d9a7/attempts/8d56b743-91f5-4a65-931c-0cf5c00bdee3/agent/trajectory.jsonl) |
| test:9136 | completed | 1 | 9.58 | 0.00 | complete / not-produced | — | [result](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/df7de3f8-4166-4de6-9272-6ea87ed63318/result.json) · [文件清单](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/df7de3f8-4166-4de6-9272-6ea87ed63318/files.json) · [轨迹](tasks/c0397c453eb6adb58204a2e03b033bcb62fbc3abb2a038bfda5f9a6ed644f290/attempts/df7de3f8-4166-4de6-9272-6ea87ed63318/agent/trajectory.jsonl) |
| test:9222 | completed | 1 | 5.23 | 0.00 | complete / not-produced | — | [result](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/4970fef4-b9fd-4866-a427-8cf39a32de87/result.json) · [文件清单](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/4970fef4-b9fd-4866-a427-8cf39a32de87/files.json) · [轨迹](tasks/0097b875da73e54548b7009c7fcdb0990034f3ab4618a1842fb859b745989c26/attempts/4970fef4-b9fd-4866-a427-8cf39a32de87/agent/trajectory.jsonl) |
| test:9391 | completed | 1 | 6.65 | 0.00 | complete / not-produced | — | [result](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/6d72c386-5421-4fe2-92fd-60e218cab196/result.json) · [文件清单](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/6d72c386-5421-4fe2-92fd-60e218cab196/files.json) · [轨迹](tasks/a0f7f3943f5eee5cb331dac0a12d81ccb0f689147e88b433fc6836e145bc025a/attempts/6d72c386-5421-4fe2-92fd-60e218cab196/agent/trajectory.jsonl) |
| test:9395 | completed | 1 | 11.56 | 0.00 | complete / not-produced | — | [result](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/307e8df2-242a-432a-a67f-55dc80bef83a/result.json) · [文件清单](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/307e8df2-242a-432a-a67f-55dc80bef83a/files.json) · [轨迹](tasks/1f0e6fb54493ddd14b0c0a370b9c6c8c2d6f17bca2198802acc01e7c52d17190/attempts/307e8df2-242a-432a-a67f-55dc80bef83a/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

