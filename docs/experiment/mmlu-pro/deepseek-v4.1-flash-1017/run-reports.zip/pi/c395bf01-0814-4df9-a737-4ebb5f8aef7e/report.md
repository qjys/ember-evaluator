<!-- snapshotDigest: 38ecc75bca86770b3a7f7848eff1b38ae462c908e87843aaffbe52cccd14860f -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 79.17%（19/24）**

Run: c395bf01-0814-4df9-a737-4ebb5f8aef7e · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:36:50.489Z / 2026-11-12T08:42:18.459Z |
| 总耗时 | 5 分 17 秒 |
| 答对 / 答错 / 解题超时 | 19 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 19 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 79.17% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 17 秒 |
| 环境准备耗时 | 3 分 23 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 47 秒 | 35 秒 | 1 分 19 秒 | 24 |
| 任务准备 | 0.54 毫秒 | 0.32 毫秒 | 2.93 毫秒 | 24 |
| 环境启动 | 21 秒 | 17 秒 | 26 秒 | 24 |
| 解题 | 14 秒 | 5 秒 | 49 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 6 秒 | 24 |
| 资源清理 | 8 秒 | 5 秒 | 14 秒 | 24 |
| 评分 | 1.03 毫秒 | 0.24 毫秒 | 7.2 毫秒 | 24 |
| 证据收集 | 12.02 毫秒 | 3.88 毫秒 | 35.8 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| f6a4d545-547d-43f5-aaf7-3a17f4b62ecb | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 31,111 | 20,073 | 51,184 | 24 / 24 | — |
| 运行累计 | 31,111 | 20,073 | 51,184 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:6120 | completed | 1 | 8.54 | 0.00 | complete / not-produced | — | [result](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/1351d9f3-7901-4a92-b1de-a336abba7907/result.json) · [文件清单](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/1351d9f3-7901-4a92-b1de-a336abba7907/files.json) · [轨迹](tasks/814008f278ea2014d7fee67586cbd03005be812cc5d428a4a3d53ae076c5399a/attempts/1351d9f3-7901-4a92-b1de-a336abba7907/agent/trajectory.jsonl) |
| test:6123 | completed | 0 | 48.62 | 0.00 | complete / not-produced | — | [result](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/f28464ef-a52c-4c73-a556-047146db1c3b/result.json) · [文件清单](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/f28464ef-a52c-4c73-a556-047146db1c3b/files.json) · [轨迹](tasks/069b174a64d1587a39c5ba3c13abf187a28a03e76ae6f6519e2015797c16970c/attempts/f28464ef-a52c-4c73-a556-047146db1c3b/agent/trajectory.jsonl) |
| test:6147 | completed | 0 | 17.61 | 0.00 | complete / not-produced | — | [result](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/b95325e6-48ac-4ce3-9391-27610ebce2af/result.json) · [文件清单](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/b95325e6-48ac-4ce3-9391-27610ebce2af/files.json) · [轨迹](tasks/70f42339aad716fef7eb6a3056ff09c6a1bd4410202cf44f2eaf42df43b1ba87/attempts/b95325e6-48ac-4ce3-9391-27610ebce2af/agent/trajectory.jsonl) |
| test:6198 | completed | 0 | 24.27 | 0.00 | complete / not-produced | — | [result](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/1254b80e-2242-41c5-a137-c802af5fb479/result.json) · [文件清单](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/1254b80e-2242-41c5-a137-c802af5fb479/files.json) · [轨迹](tasks/d78af50af8ce95cbd96fac4dbe890f397f00768b228572a9631900c6ee34dae1/attempts/1254b80e-2242-41c5-a137-c802af5fb479/agent/trajectory.jsonl) |
| test:6223 | completed | 1 | 12.49 | 0.01 | complete / not-produced | — | [result](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/13b9bfc1-484f-496d-9b8b-aee2790ba280/result.json) · [文件清单](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/13b9bfc1-484f-496d-9b8b-aee2790ba280/files.json) · [轨迹](tasks/5fb02251ba5d510f8c810d3a8736fbde137591540060bc31709034a47e51c2c8/attempts/13b9bfc1-484f-496d-9b8b-aee2790ba280/agent/trajectory.jsonl) |
| test:6235 | completed | 1 | 8.87 | 0.00 | complete / not-produced | — | [result](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/6ddd5597-6c1c-443f-8d9c-7a2a69095acb/result.json) · [文件清单](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/6ddd5597-6c1c-443f-8d9c-7a2a69095acb/files.json) · [轨迹](tasks/ace5a7b4ce18aa97cc01458da6f788fa0b450e5ed355a7cc2c5c93df009e141a/attempts/6ddd5597-6c1c-443f-8d9c-7a2a69095acb/agent/trajectory.jsonl) |
| test:6403 | completed | 1 | 17.57 | 0.00 | complete / not-produced | — | [result](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/796c7f91-9e1d-4470-919a-649fe58df00b/result.json) · [文件清单](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/796c7f91-9e1d-4470-919a-649fe58df00b/files.json) · [轨迹](tasks/2c5716206719db775a7b7f4ddcfd9368c74fc521f445cd952dee04ee8c6e46ee/attempts/796c7f91-9e1d-4470-919a-649fe58df00b/agent/trajectory.jsonl) |
| test:6436 | completed | 1 | 9.23 | 0.00 | complete / not-produced | — | [result](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/07ab06a8-c4dd-477b-8554-9cc5910ba65e/result.json) · [文件清单](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/07ab06a8-c4dd-477b-8554-9cc5910ba65e/files.json) · [轨迹](tasks/17f823c4867cf058af11304457b255f1481c83ac29d9fa423fa7ea17558baa27/attempts/07ab06a8-c4dd-477b-8554-9cc5910ba65e/agent/trajectory.jsonl) |
| test:6508 | completed | 1 | 8.96 | 0.00 | complete / not-produced | — | [result](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/ac703525-e0b6-4fbf-8621-27c2681d78a8/result.json) · [文件清单](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/ac703525-e0b6-4fbf-8621-27c2681d78a8/files.json) · [轨迹](tasks/3b9d2807d72fbf4bcb073f215791c2317be66f6201decb2615d5292e5d93e01f/attempts/ac703525-e0b6-4fbf-8621-27c2681d78a8/agent/trajectory.jsonl) |
| test:6593 | completed | 1 | 9.58 | 0.00 | complete / not-produced | — | [result](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/2a042cb1-3146-4a91-bc8f-f501d02b6fc5/result.json) · [文件清单](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/2a042cb1-3146-4a91-bc8f-f501d02b6fc5/files.json) · [轨迹](tasks/eafe15c44f52f10697c7de7c96f29b4db8bf96371b5f3431e20cb5947ccbd164/attempts/2a042cb1-3146-4a91-bc8f-f501d02b6fc5/agent/trajectory.jsonl) |
| test:6655 | completed | 0 | 28.59 | 0.00 | complete / not-produced | — | [result](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/0d11a8c5-952a-420e-b821-3cee997b198a/result.json) · [文件清单](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/0d11a8c5-952a-420e-b821-3cee997b198a/files.json) · [轨迹](tasks/33ebb3fabb49002489295125621fcd2eff4591b0db35be0d2ed8be67cb7d295c/attempts/0d11a8c5-952a-420e-b821-3cee997b198a/agent/trajectory.jsonl) |
| test:6738 | completed | 0 | 13.23 | 0.00 | complete / not-produced | — | [result](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/fe2e0bbd-d4d0-4a2f-852f-8d5555357947/result.json) · [文件清单](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/fe2e0bbd-d4d0-4a2f-852f-8d5555357947/files.json) · [轨迹](tasks/8922bf7c2252f59e22b11bc5dc4b9189f2694fdd848c23131d7e61b690478beb/attempts/fe2e0bbd-d4d0-4a2f-852f-8d5555357947/agent/trajectory.jsonl) |
| test:6751 | completed | 1 | 8.70 | 0.00 | complete / not-produced | — | [result](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/006c06ba-e661-4ff4-8bb1-5ab8417d11ae/result.json) · [文件清单](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/006c06ba-e661-4ff4-8bb1-5ab8417d11ae/files.json) · [轨迹](tasks/117070d209059ce9048a2ecba4e5e810df3889c5f26a2aaa5e047670ee9161d4/attempts/006c06ba-e661-4ff4-8bb1-5ab8417d11ae/agent/trajectory.jsonl) |
| test:6784 | completed | 1 | 7.70 | 0.00 | complete / not-produced | — | [result](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/7adcd25b-b938-4235-83b2-1fae10c1ba40/result.json) · [文件清单](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/7adcd25b-b938-4235-83b2-1fae10c1ba40/files.json) · [轨迹](tasks/3e4114dd2c1f73fb4ad8b310c7f5b9ccbbdfc186ba274d7d4fe0a75a49f5b3ea/attempts/7adcd25b-b938-4235-83b2-1fae10c1ba40/agent/trajectory.jsonl) |
| test:6792 | completed | 1 | 8.96 | 0.00 | complete / not-produced | — | [result](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/e6da212c-55b0-455d-9b91-22bdea3b68e5/result.json) · [文件清单](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/e6da212c-55b0-455d-9b91-22bdea3b68e5/files.json) · [轨迹](tasks/e6e58176e50df62eb0ef89f847030c8a754f0380df7fbeaac28975a48beebb72/attempts/e6da212c-55b0-455d-9b91-22bdea3b68e5/agent/trajectory.jsonl) |
| test:6900 | completed | 1 | 8.61 | 0.00 | complete / not-produced | — | [result](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/eb667921-1646-4285-9f6b-d7aff2c11b5a/result.json) · [文件清单](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/eb667921-1646-4285-9f6b-d7aff2c11b5a/files.json) · [轨迹](tasks/2ac4da0a5ea9bfbcd794891c0d9da99665861df820899a902204d82625a9db85/attempts/eb667921-1646-4285-9f6b-d7aff2c11b5a/agent/trajectory.jsonl) |
| test:6928 | completed | 1 | 8.96 | 0.00 | complete / not-produced | — | [result](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/d32ae562-30c3-41d3-845c-1baaba66e923/result.json) · [文件清单](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/d32ae562-30c3-41d3-845c-1baaba66e923/files.json) · [轨迹](tasks/b29ec44321e798a186dc382d300846a951e42951b87ac83c6c74275eac2745d7/attempts/d32ae562-30c3-41d3-845c-1baaba66e923/agent/trajectory.jsonl) |
| test:6929 | completed | 1 | 9.30 | 0.00 | complete / not-produced | — | [result](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/e8316a58-ce6a-4676-8cfd-ef84155e10c3/result.json) · [文件清单](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/e8316a58-ce6a-4676-8cfd-ef84155e10c3/files.json) · [轨迹](tasks/73d8e24e5d4774c9e1dad34a7b37365aca259ab53dca2c8318219e8a57c90356/attempts/e8316a58-ce6a-4676-8cfd-ef84155e10c3/agent/trajectory.jsonl) |
| test:7161 | completed | 1 | 43.60 | 0.00 | complete / not-produced | — | [result](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/116e8926-b6bc-4ab9-8d80-fbedd053fbc4/result.json) · [文件清单](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/116e8926-b6bc-4ab9-8d80-fbedd053fbc4/files.json) · [轨迹](tasks/582ac716ee329cce81d91b6aab0aa2d31e71fa3eba920701caac374156b58157/attempts/116e8926-b6bc-4ab9-8d80-fbedd053fbc4/agent/trajectory.jsonl) |
| test:7181 | completed | 1 | 7.65 | 0.00 | complete / not-produced | — | [result](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/f34b5143-9877-4394-9178-46bf91b978b2/result.json) · [文件清单](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/f34b5143-9877-4394-9178-46bf91b978b2/files.json) · [轨迹](tasks/e0208aafc9ae327c458fb1310a003ce4e2b23e6ec4c0556fa4b88588fbcc494b/attempts/f34b5143-9877-4394-9178-46bf91b978b2/agent/trajectory.jsonl) |
| test:7217 | completed | 1 | 9.62 | 0.00 | complete / not-produced | — | [result](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/7c3762f9-bf1f-41c8-9b46-e6c9c0794a0d/result.json) · [文件清单](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/7c3762f9-bf1f-41c8-9b46-e6c9c0794a0d/files.json) · [轨迹](tasks/e09e2c6ac5ff7a0c9b651723d21b1b20ace70a3a58bbac1e31e6ba513c25537d/attempts/7c3762f9-bf1f-41c8-9b46-e6c9c0794a0d/agent/trajectory.jsonl) |
| test:7290 | completed | 1 | 5.99 | 0.00 | complete / not-produced | — | [result](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/ac4f8b38-890d-4ad6-b7f8-bff84ccd9723/result.json) · [文件清单](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/ac4f8b38-890d-4ad6-b7f8-bff84ccd9723/files.json) · [轨迹](tasks/9cc6874828ec7c8f55b89f68e5b2463b03fe962b06284faf0f10691e59324a6f/attempts/ac4f8b38-890d-4ad6-b7f8-bff84ccd9723/agent/trajectory.jsonl) |
| test:7304 | completed | 1 | 6.14 | 0.00 | complete / not-produced | — | [result](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/529f34af-e66d-4ab7-8912-db8b0e58e0b0/result.json) · [文件清单](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/529f34af-e66d-4ab7-8912-db8b0e58e0b0/files.json) · [轨迹](tasks/5f259b2445e150a2e2860eff519edfc7e73798fa85bc06a7d57394ee5bcf5fe6/attempts/529f34af-e66d-4ab7-8912-db8b0e58e0b0/agent/trajectory.jsonl) |
| test:7312 | completed | 1 | 5.35 | 0.00 | complete / not-produced | — | [result](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/cc0b413b-60ec-4823-bab3-f755e651b1ec/result.json) · [文件清单](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/cc0b413b-60ec-4823-bab3-f755e651b1ec/files.json) · [轨迹](tasks/670ee191f89671d8e7712caecc6c9d5e29446ffe63dd9c738ea1ff27bad1ac83/attempts/cc0b413b-60ec-4823-bab3-f755e651b1ec/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

