<!-- snapshotDigest: d5b1f47652475df4a26470090dff618e9e51c8ef12429b9c1611a2987e045c96 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 100.00%（24/24）**

Run: 8dd70e88-156a-448d-93e0-9faa444a1b08 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:47:41.794Z / 2026-11-12T08:52:49.633Z |
| 总耗时 | 4 分 57 秒 |
| 答对 / 答错 / 解题超时 | 24 / 0 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 24 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 100.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 4 分 57 秒 |
| 环境准备耗时 | 3 分 14 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 42 秒 | 31 秒 | 1 分 52 秒 | 24 |
| 任务准备 | 0.6 毫秒 | 0.33 毫秒 | 1.73 毫秒 | 24 |
| 环境启动 | 20 秒 | 15 秒 | 30 秒 | 24 |
| 解题 | 11 秒 | 6 秒 | 1 分 16 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 8 秒 | 6 秒 | 11 秒 | 24 |
| 评分 | 0.73 毫秒 | 0.24 毫秒 | 2.21 毫秒 | 24 |
| 证据收集 | 10.5 毫秒 | 4.13 毫秒 | 30.82 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| b4c540a2-6763-49c1-ad37-d91b71bc23f7 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 36,550 | 16,659 | 53,209 | 24 / 24 | — |
| 运行累计 | 36,550 | 16,659 | 53,209 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:9405 | completed | 1 | 13.00 | 0.00 | complete / not-produced | — | [result](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/418d2109-8eec-432e-8ac9-39c95e0788b8/result.json) · [文件清单](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/418d2109-8eec-432e-8ac9-39c95e0788b8/files.json) · [轨迹](tasks/dd7e63fe68e1db93c4c3e2b82a704b3a10c4c175d6fd300b334d7d6f6cd9ca04/attempts/418d2109-8eec-432e-8ac9-39c95e0788b8/agent/trajectory.jsonl) |
| test:9769 | completed | 1 | 7.95 | 0.00 | complete / not-produced | — | [result](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/d5a86b5c-042f-475a-be8a-dc8b56ac5c27/result.json) · [文件清单](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/d5a86b5c-042f-475a-be8a-dc8b56ac5c27/files.json) · [轨迹](tasks/c486f5a76eec836d1d6237265417b1981bf341ecca2dc2645521a376a2987a28/attempts/d5a86b5c-042f-475a-be8a-dc8b56ac5c27/agent/trajectory.jsonl) |
| test:9843 | completed | 1 | 10.95 | 0.00 | complete / not-produced | — | [result](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/ddb23c24-b99a-4756-85bf-d16a110f48d7/result.json) · [文件清单](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/ddb23c24-b99a-4756-85bf-d16a110f48d7/files.json) · [轨迹](tasks/bf4fd4ea418aefc76f135992d53e63f469f92e1b92d34f78849e4b03e0c22e5b/attempts/ddb23c24-b99a-4756-85bf-d16a110f48d7/agent/trajectory.jsonl) |
| test:9864 | completed | 1 | 6.81 | 0.00 | complete / not-produced | — | [result](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/ac8ddb13-479a-414f-af82-2371e1a41ea7/result.json) · [文件清单](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/ac8ddb13-479a-414f-af82-2371e1a41ea7/files.json) · [轨迹](tasks/2e460b2d00df77681e215ff9219316cb22407103ad2414a76c3169d96333544c/attempts/ac8ddb13-479a-414f-af82-2371e1a41ea7/agent/trajectory.jsonl) |
| test:9901 | completed | 1 | 6.94 | 0.00 | complete / not-produced | — | [result](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/a53eaf07-6ab5-4ef3-89f6-b7e355d25178/result.json) · [文件清单](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/a53eaf07-6ab5-4ef3-89f6-b7e355d25178/files.json) · [轨迹](tasks/0838faabf0e42237bb411b42a72e52b0e7b739ddf2a5a46fc7fb3c28366388c6/attempts/a53eaf07-6ab5-4ef3-89f6-b7e355d25178/agent/trajectory.jsonl) |
| test:9931 | completed | 1 | 75.71 | 0.00 | complete / not-produced | — | [result](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/56ed4069-cfaa-45af-9ff1-a958f870cefb/result.json) · [文件清单](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/56ed4069-cfaa-45af-9ff1-a958f870cefb/files.json) · [轨迹](tasks/a4e9d39401b3ccf52e2238e9675449c2203ca7b9091e419b5f6c3178b626e825/attempts/56ed4069-cfaa-45af-9ff1-a958f870cefb/agent/trajectory.jsonl) |
| test:10127 | completed | 1 | 6.46 | 0.00 | complete / not-produced | — | [result](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/cd833730-a47a-4005-98f4-dc3cd5d8d28a/result.json) · [文件清单](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/cd833730-a47a-4005-98f4-dc3cd5d8d28a/files.json) · [轨迹](tasks/7b0e34598d33e3b04f3d99c5b9c4b51583b56c9738237e957afb9eff582481fa/attempts/cd833730-a47a-4005-98f4-dc3cd5d8d28a/agent/trajectory.jsonl) |
| test:10140 | completed | 1 | 8.10 | 0.00 | complete / not-produced | — | [result](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/47307869-2463-4f60-9a3a-2fdae1e1888b/result.json) · [文件清单](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/47307869-2463-4f60-9a3a-2fdae1e1888b/files.json) · [轨迹](tasks/507b9dcc3eece3062e860dcc001a3b84e0fc4d342e54412b1ac8eaacae21ecce/attempts/47307869-2463-4f60-9a3a-2fdae1e1888b/agent/trajectory.jsonl) |
| test:10174 | completed | 1 | 9.11 | 0.00 | complete / not-produced | — | [result](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/d91f7254-1491-461f-b4c1-9e7a860c5fe1/result.json) · [文件清单](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/d91f7254-1491-461f-b4c1-9e7a860c5fe1/files.json) · [轨迹](tasks/aaab5e7246c47c4435916bcbd503b0a033733cd8efa326e33cb68bd797a8a7fa/attempts/d91f7254-1491-461f-b4c1-9e7a860c5fe1/agent/trajectory.jsonl) |
| test:10184 | completed | 1 | 6.45 | 0.00 | complete / not-produced | — | [result](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/823c7e1e-fb9d-42b9-9a51-1681e3539631/result.json) · [文件清单](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/823c7e1e-fb9d-42b9-9a51-1681e3539631/files.json) · [轨迹](tasks/2edb060d9b6c5b988a6f0c8c6234901219f9f2e088b06e06329c7d11176b0a4e/attempts/823c7e1e-fb9d-42b9-9a51-1681e3539631/agent/trajectory.jsonl) |
| test:10189 | completed | 1 | 7.57 | 0.00 | complete / not-produced | — | [result](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/6f2b13e1-044e-470f-8d3a-b4f699c5097d/result.json) · [文件清单](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/6f2b13e1-044e-470f-8d3a-b4f699c5097d/files.json) · [轨迹](tasks/4ba5d06e780dbda75c2113abf3bd1cbe6026f8c2a9c542dafd1f5e88997c80cf/attempts/6f2b13e1-044e-470f-8d3a-b4f699c5097d/agent/trajectory.jsonl) |
| test:10294 | completed | 1 | 7.38 | 0.00 | complete / not-produced | — | [result](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/7ffd9d29-28fa-4d35-9bca-ec541b111c39/result.json) · [文件清单](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/7ffd9d29-28fa-4d35-9bca-ec541b111c39/files.json) · [轨迹](tasks/a0aaabd2254ef60e3c5d482ca5cdd5cf4b8cb34845dc8ee7a3d39f2a14e186c6/attempts/7ffd9d29-28fa-4d35-9bca-ec541b111c39/agent/trajectory.jsonl) |
| test:10318 | completed | 1 | 8.05 | 0.00 | complete / not-produced | — | [result](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/4f81ae99-6605-406a-9846-d91bce4faf02/result.json) · [文件清单](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/4f81ae99-6605-406a-9846-d91bce4faf02/files.json) · [轨迹](tasks/1745200b2cc504b32345d36ce668c8cfd3ad9ccc66a232707762928b27c810d6/attempts/4f81ae99-6605-406a-9846-d91bce4faf02/agent/trajectory.jsonl) |
| test:10362 | completed | 1 | 6.10 | 0.00 | complete / not-produced | — | [result](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/da2ff31c-0b2f-4631-b082-67829953615f/result.json) · [文件清单](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/da2ff31c-0b2f-4631-b082-67829953615f/files.json) · [轨迹](tasks/5e315a9ddfc18b95657460e48414ab69b895bf626724cf2e3b63d4e4bd9e2526/attempts/da2ff31c-0b2f-4631-b082-67829953615f/agent/trajectory.jsonl) |
| test:10396 | completed | 1 | 6.98 | 0.00 | complete / not-produced | — | [result](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/ec17bbf8-1e4d-42ed-a20b-0ca11c4a8904/result.json) · [文件清单](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/ec17bbf8-1e4d-42ed-a20b-0ca11c4a8904/files.json) · [轨迹](tasks/8bc733c30b09171a5d6f2f1618255e0a6247ebc4790b068f7f81b2e936ef8394/attempts/ec17bbf8-1e4d-42ed-a20b-0ca11c4a8904/agent/trajectory.jsonl) |
| test:10401 | completed | 1 | 10.37 | 0.00 | complete / not-produced | — | [result](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/77cfb7b0-dd33-41f6-8f78-9f64c44db199/result.json) · [文件清单](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/77cfb7b0-dd33-41f6-8f78-9f64c44db199/files.json) · [轨迹](tasks/47a1058774305775645f5c0213e5b852dd632d92b7a4619eb09fa40eed30dfa8/attempts/77cfb7b0-dd33-41f6-8f78-9f64c44db199/agent/trajectory.jsonl) |
| test:10403 | completed | 1 | 7.40 | 0.00 | complete / not-produced | — | [result](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/53a05765-fd05-428c-b5e4-f2dc8e4a475f/result.json) · [文件清单](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/53a05765-fd05-428c-b5e4-f2dc8e4a475f/files.json) · [轨迹](tasks/cc63a1201bd556f10f42bea7709c8929502ee19fbb81c8529e5b38c65d89e2ca/attempts/53a05765-fd05-428c-b5e4-f2dc8e4a475f/agent/trajectory.jsonl) |
| test:10412 | completed | 1 | 6.26 | 0.00 | complete / not-produced | — | [result](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/55e416d2-0121-4c4e-8dfc-c686f8a82830/result.json) · [文件清单](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/55e416d2-0121-4c4e-8dfc-c686f8a82830/files.json) · [轨迹](tasks/d9ca22602fbcff691ba154dbe6fb4955a3f81757176eec4154d12c431f54e4a9/attempts/55e416d2-0121-4c4e-8dfc-c686f8a82830/agent/trajectory.jsonl) |
| test:10421 | completed | 1 | 9.13 | 0.00 | complete / not-produced | — | [result](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/713e267e-dc42-4182-80ef-d550799d4d29/result.json) · [文件清单](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/713e267e-dc42-4182-80ef-d550799d4d29/files.json) · [轨迹](tasks/a862e88e8d571fe4aa2650946ab381b51e2f895f1916a0ef99a4869a8cd12ede/attempts/713e267e-dc42-4182-80ef-d550799d4d29/agent/trajectory.jsonl) |
| test:10424 | completed | 1 | 7.05 | 0.00 | complete / not-produced | — | [result](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/0d237660-cc0d-43e1-b1b6-6f114f3ab5c8/result.json) · [文件清单](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/0d237660-cc0d-43e1-b1b6-6f114f3ab5c8/files.json) · [轨迹](tasks/088ea43f3082585eaafe67e4d59afea1ad9d2d9bac522dbf55c83ac16d4c1cd6/attempts/0d237660-cc0d-43e1-b1b6-6f114f3ab5c8/agent/trajectory.jsonl) |
| test:10471 | completed | 1 | 6.69 | 0.00 | complete / not-produced | — | [result](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/43165b87-9e9e-4c05-9c74-354b5fa0e425/result.json) · [文件清单](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/43165b87-9e9e-4c05-9c74-354b5fa0e425/files.json) · [轨迹](tasks/93903b6cf56480725f06679917835f0806d9434b81ca16fb980575996c6941a2/attempts/43165b87-9e9e-4c05-9c74-354b5fa0e425/agent/trajectory.jsonl) |
| test:10479 | completed | 1 | 7.09 | 0.00 | complete / not-produced | — | [result](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/598d7267-5109-428b-9eb2-042e7a2f561c/result.json) · [文件清单](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/598d7267-5109-428b-9eb2-042e7a2f561c/files.json) · [轨迹](tasks/07c045498224e24dad8865bf9b7ebc3477908c3a733c73c5d6d4ac15bd178694/attempts/598d7267-5109-428b-9eb2-042e7a2f561c/agent/trajectory.jsonl) |
| test:10524 | completed | 1 | 10.97 | 0.00 | complete / not-produced | — | [result](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/35a3557b-f874-4253-8c89-cf6946747720/result.json) · [文件清单](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/35a3557b-f874-4253-8c89-cf6946747720/files.json) · [轨迹](tasks/a067aa8f65560fd92d34f71a8ab445316114c060473eb5445e6afa2868190806/attempts/35a3557b-f874-4253-8c89-cf6946747720/agent/trajectory.jsonl) |
| test:10607 | completed | 1 | 6.52 | 0.00 | complete / not-produced | — | [result](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/362822b2-8958-453f-b7f2-e2ed5c5872b6/result.json) · [文件清单](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/362822b2-8958-453f-b7f2-e2ed5c5872b6/files.json) · [轨迹](tasks/aa0b22e83ae9b58e5b8f462ae0d3becd7e1f2e37f4f0adfdc53ae5949582c14d/attempts/362822b2-8958-453f-b7f2-e2ed5c5872b6/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

