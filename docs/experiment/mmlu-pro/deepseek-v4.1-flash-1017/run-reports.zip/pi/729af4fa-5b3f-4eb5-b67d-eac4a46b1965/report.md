<!-- snapshotDigest: 5a20ff0d21acabb0cc307aad558336c769295b04f2b1dcf652bdf9bf9271321f -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 100.00%（5/5）**

Run: 729af4fa-5b3f-4eb5-b67d-eac4a46b1965 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T09:01:49.240Z / 2026-11-12T09:02:47.885Z |
| 总耗时 | 57 秒 |
| 答对 / 答错 / 解题超时 | 5 / 0 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 5 题；已保存 5 条记录；待运行 0 题。
有效评分覆盖率：5/5（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 5 |
| 计分题数 | 5 |
| 正常评分题数 | 5 |
| 答对题数 | 5 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 100.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 57 秒 |
| 环境准备耗时 | 28 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 24 秒 | 19 秒 | 31 秒 | 5 |
| 任务准备 | 0.43 毫秒 | 0.28 毫秒 | 0.55 毫秒 | 5 |
| 环境启动 | 12 秒 | 8 秒 | 13 秒 | 5 |
| 解题 | 7 秒 | 4 秒 | 12 秒 | 5 |
| 产物传输 | 2 秒 | 1 秒 | 2 秒 | 5 |
| 资源清理 | 4 秒 | 3 秒 | 5 秒 | 5 |
| 评分 | 1.53 毫秒 | 0.29 毫秒 | 6.15 毫秒 | 5 |
| 证据收集 | 8.22 毫秒 | 5.62 毫秒 | 13.09 毫秒 | 5 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 2bbf267a-8cb6-4d3d-953e-e64c6779ecc3 | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 6,685 | 2,925 | 9,610 | 5 / 5 | — |
| 运行累计 | 6,685 | 2,925 | 9,610 | 5 / 5 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:11802 | completed | 1 | 3.96 | 0.01 | complete / not-produced | — | [result](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/67bb1d9e-50c7-43f1-99bc-c5ca9b19de3c/result.json) · [文件清单](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/67bb1d9e-50c7-43f1-99bc-c5ca9b19de3c/files.json) · [轨迹](tasks/907d295680da612bc711aa7a0fa1788ab168925819966885a5d568a07c8b2fae/attempts/67bb1d9e-50c7-43f1-99bc-c5ca9b19de3c/agent/trajectory.jsonl) |
| test:11808 | completed | 1 | 7.21 | 0.00 | complete / not-produced | — | [result](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/bd5b216f-8ea9-4702-b7cb-0f2fd5f18e55/result.json) · [文件清单](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/bd5b216f-8ea9-4702-b7cb-0f2fd5f18e55/files.json) · [轨迹](tasks/0b27e862d829fe3b31768442f3f2933395854d01ee2e2d4789902a0f796458ec/attempts/bd5b216f-8ea9-4702-b7cb-0f2fd5f18e55/agent/trajectory.jsonl) |
| test:11824 | completed | 1 | 4.22 | 0.00 | complete / not-produced | — | [result](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/2d06a960-b2cf-4d42-8944-42a1f4f2b172/result.json) · [文件清单](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/2d06a960-b2cf-4d42-8944-42a1f4f2b172/files.json) · [轨迹](tasks/ce13f3a6b431fff5b76cebf8d459da5d7d8a08f373998ac5ab23b0f062a18c17/attempts/2d06a960-b2cf-4d42-8944-42a1f4f2b172/agent/trajectory.jsonl) |
| test:11925 | completed | 1 | 12.02 | 0.00 | complete / not-produced | — | [result](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/329f77ab-53e7-415c-850e-c9a9026749cd/result.json) · [文件清单](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/329f77ab-53e7-415c-850e-c9a9026749cd/files.json) · [轨迹](tasks/3d23c4ed576a01c937eb3c4119e4ad374507ada79bfd659db375159d5a4b9af0/attempts/329f77ab-53e7-415c-850e-c9a9026749cd/agent/trajectory.jsonl) |
| test:12002 | completed | 1 | 7.09 | 0.00 | complete / not-produced | — | [result](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/dd1b14f8-9003-4703-89c1-e6f0e338a3f5/result.json) · [文件清单](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/dd1b14f8-9003-4703-89c1-e6f0e338a3f5/files.json) · [轨迹](tasks/7ce123af7691672e439e6dd0258bd69eeea4a02defa09a5554b2510920db96e1/attempts/dd1b14f8-9003-4703-89c1-e6f0e338a3f5/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

