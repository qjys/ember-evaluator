<!-- snapshotDigest: 9e851931aad0c9547a6cf2937049ed0961eaf0e7dc8821d536279f08b5f426b2 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 75.00%（18/24）**

Run: c00eca45-7916-4ce3-9091-daaee5604a61 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:52:55.020Z / 2026-11-12T09:01:44.870Z |
| 总耗时 | 8 分 32 秒 |
| 答对 / 答错 / 解题超时 | 18 / 6 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 18 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 75.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 8 分 32 秒 |
| 环境准备耗时 | 3 分 6 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 53 秒 | 25 秒 | 4 分 20 秒 | 24 |
| 任务准备 | 0.49 毫秒 | 0.28 毫秒 | 1.58 毫秒 | 24 |
| 环境启动 | 14 秒 | 10 秒 | 19 秒 | 24 |
| 解题 | 30 秒 | 5 秒 | 3 分 57 秒 | 24 |
| 产物传输 | 2 秒 | 1 秒 | 4 秒 | 24 |
| 资源清理 | 6 秒 | 3 秒 | 8 秒 | 24 |
| 评分 | 1.47 毫秒 | 0.28 毫秒 | 7.17 毫秒 | 24 |
| 证据收集 | 14.23 毫秒 | 4.37 毫秒 | 35.47 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| d3eb8335-c226-4b6f-b0bf-1d418043b63c | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 29,294 | 81,945 | 111,239 | 24 / 24 | — |
| 运行累计 | 29,294 | 81,945 | 111,239 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:10656 | completed | 1 | 5.01 | 0.00 | complete / not-produced | — | [result](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/77f73985-1e62-414f-b6bb-7a366c215456/result.json) · [文件清单](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/77f73985-1e62-414f-b6bb-7a366c215456/files.json) · [轨迹](tasks/59439147678875fb39e1fe50111e48b3dc6e2897407cfab7dfb1a650a8aca1a6/attempts/77f73985-1e62-414f-b6bb-7a366c215456/agent/trajectory.jsonl) |
| test:10674 | completed | 1 | 10.93 | 0.00 | complete / not-produced | — | [result](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/8e6c7849-d7c2-4eaf-beef-b2b1677ef49e/result.json) · [文件清单](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/8e6c7849-d7c2-4eaf-beef-b2b1677ef49e/files.json) · [轨迹](tasks/ca6ac0ab804f1ce29e067818f918f3c89e42b9e749e39427ba97cf4ed4c50e75/attempts/8e6c7849-d7c2-4eaf-beef-b2b1677ef49e/agent/trajectory.jsonl) |
| test:10683 | completed | 1 | 5.04 | 0.00 | complete / not-produced | — | [result](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/a075c313-c963-44ce-96f3-036b169aa19d/result.json) · [文件清单](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/a075c313-c963-44ce-96f3-036b169aa19d/files.json) · [轨迹](tasks/e1de59a3fdfe0f6aeca31ccd0f72acdcb9ea686a517c0862f15ec21e64a8f356/attempts/a075c313-c963-44ce-96f3-036b169aa19d/agent/trajectory.jsonl) |
| test:10690 | completed | 1 | 7.86 | 0.00 | complete / not-produced | — | [result](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/2ba20ad4-0ff3-4020-9522-9dfb7d7c58e9/result.json) · [文件清单](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/2ba20ad4-0ff3-4020-9522-9dfb7d7c58e9/files.json) · [轨迹](tasks/ef9352259f3a53dbf4862c8681f6680806c78d844dadd00949b35f6c96056d1f/attempts/2ba20ad4-0ff3-4020-9522-9dfb7d7c58e9/agent/trajectory.jsonl) |
| test:10765 | completed | 1 | 5.85 | 0.00 | complete / not-produced | — | [result](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/63488c21-ef3c-40e5-aacb-1529fc00c781/result.json) · [文件清单](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/63488c21-ef3c-40e5-aacb-1529fc00c781/files.json) · [轨迹](tasks/d8867c01c3ba78bfd64c9c0f0b1d30f750f8edf8a1d9273dc15bb96cbf388904/attempts/63488c21-ef3c-40e5-aacb-1529fc00c781/agent/trajectory.jsonl) |
| test:10770 | completed | 1 | 13.92 | 0.00 | complete / not-produced | — | [result](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/0a44c575-4168-4f6c-a636-c305242bc00b/result.json) · [文件清单](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/0a44c575-4168-4f6c-a636-c305242bc00b/files.json) · [轨迹](tasks/ca88893fe0584132cae9138492211daf7495bb52abb6b9e9824afe9f4037c3d2/attempts/0a44c575-4168-4f6c-a636-c305242bc00b/agent/trajectory.jsonl) |
| test:10815 | completed | 1 | 4.87 | 0.01 | complete / not-produced | — | [result](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/b0c9ac58-d0f9-4937-aae5-48d4eee866fa/result.json) · [文件清单](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/b0c9ac58-d0f9-4937-aae5-48d4eee866fa/files.json) · [轨迹](tasks/e25e94247ef03e8d829d96937abe425712010f424228c630504912fba89df4ab/attempts/b0c9ac58-d0f9-4937-aae5-48d4eee866fa/agent/trajectory.jsonl) |
| test:10846 | completed | 1 | 78.02 | 0.01 | complete / not-produced | — | [result](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/eac2e63b-a969-4a07-a284-ef24f4909669/result.json) · [文件清单](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/eac2e63b-a969-4a07-a284-ef24f4909669/files.json) · [轨迹](tasks/70d3e5e3ce9f4c9df22734f8cb6ef92c5457489b4abb6c98328600b852e486c2/attempts/eac2e63b-a969-4a07-a284-ef24f4909669/agent/trajectory.jsonl) |
| test:10898 | completed | 1 | 8.46 | 0.00 | complete / not-produced | — | [result](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/b97797a4-a31d-4a92-88c4-251179c12b77/result.json) · [文件清单](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/b97797a4-a31d-4a92-88c4-251179c12b77/files.json) · [轨迹](tasks/afcf6ef0f9379163f125106dd7cbbc08b5a5f71714a44b966890bbf5a7592761/attempts/b97797a4-a31d-4a92-88c4-251179c12b77/agent/trajectory.jsonl) |
| test:10940 | completed | 1 | 7.47 | 0.00 | complete / not-produced | — | [result](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/e8b642a6-fb27-4d14-93e7-5ecf37d91482/result.json) · [文件清单](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/e8b642a6-fb27-4d14-93e7-5ecf37d91482/files.json) · [轨迹](tasks/2dca49b9c6ef2ff7e79b448f3886df6589a58888b7f0879c23883dc2b9f950b2/attempts/e8b642a6-fb27-4d14-93e7-5ecf37d91482/agent/trajectory.jsonl) |
| test:10966 | completed | 1 | 6.81 | 0.00 | complete / not-produced | — | [result](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/cbaa755a-d878-4b3e-8adf-2624d155c7ba/result.json) · [文件清单](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/cbaa755a-d878-4b3e-8adf-2624d155c7ba/files.json) · [轨迹](tasks/aa2b20e5772dbdac91ef1c8c81a7bf0d93a4bf4bff51a0d07febdd43f578a82a/attempts/cbaa755a-d878-4b3e-8adf-2624d155c7ba/agent/trajectory.jsonl) |
| test:11045 | completed | 0 | 6.47 | 0.00 | complete / not-produced | — | [result](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/b0d62e1e-f68a-4ff6-b534-96f638533a3d/result.json) · [文件清单](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/b0d62e1e-f68a-4ff6-b534-96f638533a3d/files.json) · [轨迹](tasks/3362781d58e9c4bdf17a235a6b641e5da9389f32328e7bd5c2549148240947e3/attempts/b0d62e1e-f68a-4ff6-b534-96f638533a3d/agent/trajectory.jsonl) |
| test:11050 | completed | 0 | 35.61 | 0.00 | complete / not-produced | — | [result](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/be2f43f9-c867-42a7-b370-b7ff7f841597/result.json) · [文件清单](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/be2f43f9-c867-42a7-b370-b7ff7f841597/files.json) · [轨迹](tasks/44cde2eb679a2a02721dabed1426c840464220bab42b08e79c5b4d53bf7814c9/attempts/be2f43f9-c867-42a7-b370-b7ff7f841597/agent/trajectory.jsonl) |
| test:11060 | completed | 1 | 5.12 | 0.00 | complete / not-produced | — | [result](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/7011ab03-8928-4654-ba68-bea954e7b8d3/result.json) · [文件清单](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/7011ab03-8928-4654-ba68-bea954e7b8d3/files.json) · [轨迹](tasks/bad82c3024386e3e2cb3e9ecd78a70c38f64c1adfe221ac09b3f5da6eb5d029e/attempts/7011ab03-8928-4654-ba68-bea954e7b8d3/agent/trajectory.jsonl) |
| test:11093 | completed | 0 | 56.00 | 0.01 | complete / not-produced | — | [result](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/73beb43e-f24d-471a-ad42-3a52144092ae/result.json) · [文件清单](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/73beb43e-f24d-471a-ad42-3a52144092ae/files.json) · [轨迹](tasks/22f6e2a0adb1c0b3382698c92bcd0fb337aa747449ba8354cb72a833eabf4822/attempts/73beb43e-f24d-471a-ad42-3a52144092ae/agent/trajectory.jsonl) |
| test:11210 | completed | 1 | 6.04 | 0.00 | complete / not-produced | — | [result](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/ed8e5e8e-4e24-40e1-a103-d932c8a5159a/result.json) · [文件清单](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/ed8e5e8e-4e24-40e1-a103-d932c8a5159a/files.json) · [轨迹](tasks/2db4039b3b1bec03b8a704aef470326853d3ffc57968ddca4d43c35639103a94/attempts/ed8e5e8e-4e24-40e1-a103-d932c8a5159a/agent/trajectory.jsonl) |
| test:11354 | completed | 0 | 5.78 | 0.00 | complete / not-produced | — | [result](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/2e480204-b2fc-4a4c-bd5d-fafe4c572e7a/result.json) · [文件清单](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/2e480204-b2fc-4a4c-bd5d-fafe4c572e7a/files.json) · [轨迹](tasks/867a806535fe41afdba7e6aa74db7ed7da810d7bbe369ad2e50cfe274bfe267b/attempts/2e480204-b2fc-4a4c-bd5d-fafe4c572e7a/agent/trajectory.jsonl) |
| test:11491 | completed | 0 | 39.10 | 0.00 | complete / not-produced | — | [result](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/a38cd8f3-595d-494f-858b-a4eee583459b/result.json) · [文件清单](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/a38cd8f3-595d-494f-858b-a4eee583459b/files.json) · [轨迹](tasks/90e9a71f29901fccea294ffeaa9a42399ab3139f07c67f47310d4525608c14d6/attempts/a38cd8f3-595d-494f-858b-a4eee583459b/agent/trajectory.jsonl) |
| test:11496 | completed | 1 | 236.59 | 0.00 | complete / not-produced | — | [result](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/1651d2de-65dd-456a-896a-bda6e4662b8f/result.json) · [文件清单](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/1651d2de-65dd-456a-896a-bda6e4662b8f/files.json) · [轨迹](tasks/38d4f4fcb88fac87c5d158c4c6ef1822997b6e2880124f2bf38e55db4e1ec9d3/attempts/1651d2de-65dd-456a-896a-bda6e4662b8f/agent/trajectory.jsonl) |
| test:11506 | completed | 1 | 44.89 | 0.00 | complete / not-produced | — | [result](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/1c6e9f96-d522-4cfe-8391-a36f394e4f25/result.json) · [文件清单](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/1c6e9f96-d522-4cfe-8391-a36f394e4f25/files.json) · [轨迹](tasks/4898157d07cff42ed8911acf8972593cf1853ef47784844aec6cf327f1a7ec31/attempts/1c6e9f96-d522-4cfe-8391-a36f394e4f25/agent/trajectory.jsonl) |
| test:11559 | completed | 1 | 6.71 | 0.00 | complete / not-produced | — | [result](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/640b8a34-b619-4b75-8515-d137623fd68c/result.json) · [文件清单](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/640b8a34-b619-4b75-8515-d137623fd68c/files.json) · [轨迹](tasks/03d4c0f2bb6e816c20b24e9bc30039d96d488c7f9660dc274fb0a09f95a49cf5/attempts/640b8a34-b619-4b75-8515-d137623fd68c/agent/trajectory.jsonl) |
| test:11576 | completed | 0 | 17.28 | 0.00 | complete / not-produced | — | [result](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/97b16647-d5ae-47a6-8888-18f30e05ce58/result.json) · [文件清单](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/97b16647-d5ae-47a6-8888-18f30e05ce58/files.json) · [轨迹](tasks/95f4b91c59380fbabe5f9491ca748596ec67fe6cc17582acb5161d48e79e3325/attempts/97b16647-d5ae-47a6-8888-18f30e05ce58/agent/trajectory.jsonl) |
| test:11629 | completed | 1 | 24.95 | 0.00 | complete / not-produced | — | [result](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/413fb484-5588-4a31-a3f8-16c75d97c6ee/result.json) · [文件清单](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/413fb484-5588-4a31-a3f8-16c75d97c6ee/files.json) · [轨迹](tasks/410e0f416408f716589a58c9add8ea521fdcbf916fcf589146b1f76fc68976f2/attempts/413fb484-5588-4a31-a3f8-16c75d97c6ee/agent/trajectory.jsonl) |
| test:11660 | completed | 1 | 85.70 | 0.00 | complete / not-produced | — | [result](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/c4305a04-e80d-452a-b40b-7f4789b14359/result.json) · [文件清单](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/c4305a04-e80d-452a-b40b-7f4789b14359/files.json) · [轨迹](tasks/2609ca3f00250466daeeb0f527c96aec91bef1c3a4a9be82fca7cc6cf70f32e5/attempts/c4305a04-e80d-452a-b40b-7f4789b14359/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

