<!-- snapshotDigest: 1b85d1f218bef5e4157167a4af16575def44423e1ac4e4b35eff9da870954f00 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 100.00%（24/24）**

Run: b5439388-80c7-46aa-a68e-2e2bf84d65ba · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:25:20.199Z / 2026-11-12T08:31:11.304Z |
| 总耗时 | 5 分 40 秒 |
| 答对 / 答错 / 解题超时 | 24 / 0 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 24 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 100.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 40 秒 |
| 环境准备耗时 | 3 分 46 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 49 秒 | 34 秒 | 2 分 44 秒 | 24 |
| 任务准备 | 0.52 毫秒 | 0.27 毫秒 | 1.42 毫秒 | 24 |
| 环境启动 | 23 秒 | 19 秒 | 28 秒 | 24 |
| 解题 | 15 秒 | 5 秒 | 2 分 5 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 5 秒 | 24 |
| 资源清理 | 8 秒 | 5 秒 | 10 秒 | 24 |
| 评分 | 1.1 毫秒 | 0.25 毫秒 | 4.56 毫秒 | 24 |
| 证据收集 | 15.45 毫秒 | 4.93 毫秒 | 39.81 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 46943922-76ce-48c8-b7d1-f4e34ed4fc5f | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 45,139 | 23,996 | 69,135 | 24 / 24 | — |
| 运行累计 | 45,139 | 23,996 | 69,135 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:3491 | completed | 1 | 125.49 | 0.00 | complete / not-produced | — | [result](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/f66cac1b-2b3c-4e3f-83db-9e1c81bcd7e1/result.json) · [文件清单](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/f66cac1b-2b3c-4e3f-83db-9e1c81bcd7e1/files.json) · [轨迹](tasks/77af3ed94783db8e022b7b5e5d834313b457d6cfe15593d03358338639d50e89/attempts/f66cac1b-2b3c-4e3f-83db-9e1c81bcd7e1/agent/trajectory.jsonl) |
| test:3552 | completed | 1 | 14.30 | 0.00 | complete / not-produced | — | [result](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/4a3f8659-9100-4003-a76e-4a229cc5cf65/result.json) · [文件清单](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/4a3f8659-9100-4003-a76e-4a229cc5cf65/files.json) · [轨迹](tasks/5dc639cb461534d1a8e0767ca3c0f675ecc207e73261cdf17f5a3afd0432e2ae/attempts/4a3f8659-9100-4003-a76e-4a229cc5cf65/agent/trajectory.jsonl) |
| test:3599 | completed | 1 | 11.25 | 0.00 | complete / not-produced | — | [result](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/4e70c48f-5f51-4d4f-8f46-9b8b762224ee/result.json) · [文件清单](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/4e70c48f-5f51-4d4f-8f46-9b8b762224ee/files.json) · [轨迹](tasks/a0aa7d9b9bfa2e9e1f9a5fb420cfd12ad9bf7b6b9b3c55df896c9ef21db8507c/attempts/4e70c48f-5f51-4d4f-8f46-9b8b762224ee/agent/trajectory.jsonl) |
| test:3626 | completed | 1 | 14.43 | 0.00 | complete / not-produced | — | [result](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/cc760cd4-9c9c-4461-8c78-c649622ab5b5/result.json) · [文件清单](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/cc760cd4-9c9c-4461-8c78-c649622ab5b5/files.json) · [轨迹](tasks/7ae66ef61c06adf5752faf068b4b48f830b133d5066bc6e3e495dd51d3773523/attempts/cc760cd4-9c9c-4461-8c78-c649622ab5b5/agent/trajectory.jsonl) |
| test:4021 | completed | 1 | 12.03 | 0.00 | complete / not-produced | — | [result](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/34bd3e88-8772-40d4-8ac4-aa27c76e24b3/result.json) · [文件清单](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/34bd3e88-8772-40d4-8ac4-aa27c76e24b3/files.json) · [轨迹](tasks/4508c412b2019c8fa46af463d743b33c1cdd5b0253273e6f03fe250089b970df/attempts/34bd3e88-8772-40d4-8ac4-aa27c76e24b3/agent/trajectory.jsonl) |
| test:4034 | completed | 1 | 7.43 | 0.00 | complete / not-produced | — | [result](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/98bd7809-9df8-4628-88f6-41e96c2d892d/result.json) · [文件清单](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/98bd7809-9df8-4628-88f6-41e96c2d892d/files.json) · [轨迹](tasks/e67c796140ad301aeda6453c33617a7a8b684855936dbe1cb07e2678780175ad/attempts/98bd7809-9df8-4628-88f6-41e96c2d892d/agent/trajectory.jsonl) |
| test:4058 | completed | 1 | 9.16 | 0.00 | complete / not-produced | — | [result](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/7cdc3bbc-da24-4959-8d4c-47f148998371/result.json) · [文件清单](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/7cdc3bbc-da24-4959-8d4c-47f148998371/files.json) · [轨迹](tasks/d20c3152fa65af2e375bb22c5d0fdb531822d5ec61314b6c28a8ab71225400f7/attempts/7cdc3bbc-da24-4959-8d4c-47f148998371/agent/trajectory.jsonl) |
| test:4075 | completed | 1 | 6.59 | 0.00 | complete / not-produced | — | [result](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/8890cdf8-ff0b-4e86-8cf3-2f18ded167d8/result.json) · [文件清单](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/8890cdf8-ff0b-4e86-8cf3-2f18ded167d8/files.json) · [轨迹](tasks/ce1062f2a619565d719227aee1ae196cc953434d50f0ab3fd6964a07f2aa840b/attempts/8890cdf8-ff0b-4e86-8cf3-2f18ded167d8/agent/trajectory.jsonl) |
| test:4142 | completed | 1 | 12.60 | 0.00 | complete / not-produced | — | [result](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/9bf6ff9d-e71d-4688-9a53-b3bc8d171561/result.json) · [文件清单](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/9bf6ff9d-e71d-4688-9a53-b3bc8d171561/files.json) · [轨迹](tasks/855fb652d75a5dcac2987b344f7c2b4ee559936a525ff7f0765722d1c2914804/attempts/9bf6ff9d-e71d-4688-9a53-b3bc8d171561/agent/trajectory.jsonl) |
| test:4208 | completed | 1 | 10.53 | 0.00 | complete / not-produced | — | [result](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/8a722481-8bdb-4c64-ae5b-181702f5b698/result.json) · [文件清单](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/8a722481-8bdb-4c64-ae5b-181702f5b698/files.json) · [轨迹](tasks/273e354d27da04cdb0ab240e4068b2c1ff2c46a0f22409b6a767d8635e504b66/attempts/8a722481-8bdb-4c64-ae5b-181702f5b698/agent/trajectory.jsonl) |
| test:4298 | completed | 1 | 6.90 | 0.00 | complete / not-produced | — | [result](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/ee7a3b69-4cd1-4e2b-8709-fb1bfb61554b/result.json) · [文件清单](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/ee7a3b69-4cd1-4e2b-8709-fb1bfb61554b/files.json) · [轨迹](tasks/2f5b3cc4f9c075e9812c5ef793c76a749e47eb9bbfb5e4ad1cd22dd076882b9b/attempts/ee7a3b69-4cd1-4e2b-8709-fb1bfb61554b/agent/trajectory.jsonl) |
| test:4337 | completed | 1 | 16.90 | 0.00 | complete / not-produced | — | [result](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/be7a2804-1b3a-4db2-8d45-924785fdc371/result.json) · [文件清单](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/be7a2804-1b3a-4db2-8d45-924785fdc371/files.json) · [轨迹](tasks/2b29d7f69157adde252b260bd80535e22ced2e71136763857b73724d67221c59/attempts/be7a2804-1b3a-4db2-8d45-924785fdc371/agent/trajectory.jsonl) |
| test:4376 | completed | 1 | 9.57 | 0.00 | complete / not-produced | — | [result](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/70ab8efc-eca8-4a90-b747-097cccc2a452/result.json) · [文件清单](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/70ab8efc-eca8-4a90-b747-097cccc2a452/files.json) · [轨迹](tasks/02e471239cebdbe67d3b291373eccc0c5703b063708c0e5b4cf0505b410b1695/attempts/70ab8efc-eca8-4a90-b747-097cccc2a452/agent/trajectory.jsonl) |
| test:4405 | completed | 1 | 11.65 | 0.00 | complete / not-produced | — | [result](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/7d59c5b3-bcd6-4191-9d2f-94b3c1aaee15/result.json) · [文件清单](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/7d59c5b3-bcd6-4191-9d2f-94b3c1aaee15/files.json) · [轨迹](tasks/0fed278720aefe35c7e95747a03e687425ff3ebe75714e22c8160b95d30169b9/attempts/7d59c5b3-bcd6-4191-9d2f-94b3c1aaee15/agent/trajectory.jsonl) |
| test:4552 | completed | 1 | 9.58 | 0.00 | complete / not-produced | — | [result](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/20cac101-4200-4484-bfd6-ff570632ab2e/result.json) · [文件清单](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/20cac101-4200-4484-bfd6-ff570632ab2e/files.json) · [轨迹](tasks/5b57899da21f6ef118584e8430c404be6ee52fe5652cb188d3b7112e50417266/attempts/20cac101-4200-4484-bfd6-ff570632ab2e/agent/trajectory.jsonl) |
| test:4560 | completed | 1 | 9.62 | 0.00 | complete / not-produced | — | [result](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/a67c9706-5797-4775-8d5f-2efbf38642b6/result.json) · [文件清单](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/a67c9706-5797-4775-8d5f-2efbf38642b6/files.json) · [轨迹](tasks/2a25f6d448958c48d8c34c7012cf8bea578c4374de7035558f860575d3b7f4f3/attempts/a67c9706-5797-4775-8d5f-2efbf38642b6/agent/trajectory.jsonl) |
| test:4568 | completed | 1 | 8.72 | 0.00 | complete / not-produced | — | [result](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/80753f48-eb2b-44dd-a85f-e90a63292fbc/result.json) · [文件清单](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/80753f48-eb2b-44dd-a85f-e90a63292fbc/files.json) · [轨迹](tasks/8377e5e2479898439d867413c01fffc1c75791a88c23b8dfa762657ba922b328/attempts/80753f48-eb2b-44dd-a85f-e90a63292fbc/agent/trajectory.jsonl) |
| test:4580 | completed | 1 | 11.18 | 0.00 | complete / not-produced | — | [result](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/524141e7-677d-4c0e-9bd5-2cde99c6d2d2/result.json) · [文件清单](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/524141e7-677d-4c0e-9bd5-2cde99c6d2d2/files.json) · [轨迹](tasks/b31a94b02eff2be43d89f585a0c617a3fe23f391b504b8c6447bb9be2767cbf3/attempts/524141e7-677d-4c0e-9bd5-2cde99c6d2d2/agent/trajectory.jsonl) |
| test:4603 | completed | 1 | 12.98 | 0.00 | complete / not-produced | — | [result](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/cf221a64-adc1-49ce-a9ed-7fd05f3ced87/result.json) · [文件清单](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/cf221a64-adc1-49ce-a9ed-7fd05f3ced87/files.json) · [轨迹](tasks/915589ccae416a1c2d279374a47568865232043e8c202d05f0bcf4a8ce1a1cf5/attempts/cf221a64-adc1-49ce-a9ed-7fd05f3ced87/agent/trajectory.jsonl) |
| test:4625 | completed | 1 | 11.68 | 0.00 | complete / not-produced | — | [result](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/af5e12fc-6d9d-4ca0-b44a-4cd00f78e6d9/result.json) · [文件清单](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/af5e12fc-6d9d-4ca0-b44a-4cd00f78e6d9/files.json) · [轨迹](tasks/f27a5ef9c6a3dfcfb81826af7e5a01d490a6a99f82a7cf96b3961beb347d678b/attempts/af5e12fc-6d9d-4ca0-b44a-4cd00f78e6d9/agent/trajectory.jsonl) |
| test:4627 | completed | 1 | 10.24 | 0.00 | complete / not-produced | — | [result](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/1886f7b3-7716-4ee6-b7ec-575a6c9ab3ed/result.json) · [文件清单](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/1886f7b3-7716-4ee6-b7ec-575a6c9ab3ed/files.json) · [轨迹](tasks/a7b463880f86741256739975e8061ae94bf69e508fff89d31e449cbc8dfc08c2/attempts/1886f7b3-7716-4ee6-b7ec-575a6c9ab3ed/agent/trajectory.jsonl) |
| test:4651 | completed | 1 | 8.32 | 0.00 | complete / not-produced | — | [result](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/37a98795-7553-4d20-9cc2-19eed67c5ab8/result.json) · [文件清单](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/37a98795-7553-4d20-9cc2-19eed67c5ab8/files.json) · [轨迹](tasks/1db6fd9062858dad147081a25f6869e932989e7e57ee985474131d3c78beff63/attempts/37a98795-7553-4d20-9cc2-19eed67c5ab8/agent/trajectory.jsonl) |
| test:4670 | completed | 1 | 9.38 | 0.00 | complete / not-produced | — | [result](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/ff0d131a-ae27-449f-b363-ec93f3f21b45/result.json) · [文件清单](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/ff0d131a-ae27-449f-b363-ec93f3f21b45/files.json) · [轨迹](tasks/9ec4753da32bf2edbfcd8986e5bf769d735f1ee1ea49612144836eb0a296c8a0/attempts/ff0d131a-ae27-449f-b363-ec93f3f21b45/agent/trajectory.jsonl) |
| test:4700 | completed | 1 | 5.33 | 0.00 | complete / not-produced | — | [result](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/38056206-3c1b-4f96-a292-9780ec938b3e/result.json) · [文件清单](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/38056206-3c1b-4f96-a292-9780ec938b3e/files.json) · [轨迹](tasks/7884baf871cc9bcf72e45d66848c5a2630327e500e8f03bbf511bcea619c2ba4/attempts/38056206-3c1b-4f96-a292-9780ec938b3e/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

