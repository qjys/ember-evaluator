<!-- snapshotDigest: 2a0572385fbbdb9f799fb03aa5fab082a27ff5ab248f16134e2abf6bac8d9925 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 0.63%（1/159）**

Run: 6eded8a1-afcf-4707-894d-6c8aca1a12c2 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:52:29.223Z / 2026-11-12T07:54:47.127Z |
| 总耗时 | 2 分 13 秒 |
| 答对 / 答错 / 解题超时 | 1 / 0 / 0 |
| 清理未确认 | 1 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 161 题；已保存 3 条记录；待运行 159 题。
有效评分覆盖率：1/161（0.62%）。
执行失败 1；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 2。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 161 |
| 计分题数 | 159 |
| 正常评分题数 | 1 |
| 答对题数 | 1 |
| 无效评测 | 2 |
| 待运行 | 159 |
| 正确率 | 0.63% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 分 13 秒 |
| 环境准备耗时 | 2 分 15 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 37 秒 | 6 秒 | 1 分 6 秒 | 3 |
| 任务准备 | 0.54 毫秒 | 0.31 毫秒 | 0.8 毫秒 | 3 |
| 环境启动 | 23 秒 | 6 秒 | 42 秒 | 3 |
| 解题 | 7 秒 | 5 秒 | 8 秒 | 2 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 2 |
| 资源清理 | 13 秒 | 11 秒 | 16 秒 | 2 |
| 证据收集 | 35.44 毫秒 | 11.89 毫秒 | 50.21 毫秒 | 3 |
| 评分 | 9.88 毫秒 | 9.88 毫秒 | 9.88 毫秒 | 1 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 5e0510a0-15b6-417e-a2e1-5e36fa9f5d94 | 未设置 | 600 | 2 | 2 | 1200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 2,848 | 284 | 3,132 | 2 / 161 | — |
| 运行累计 | 2,848 | 284 | 3,132 | 2 / 3 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:2951 | invalid | — | 5.29 | — | complete / not-produced | CLEANUP\_FAILED | [result](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/2c373007-717d-4905-9e45-6367ddad1480/result.json) · [文件清单](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/2c373007-717d-4905-9e45-6367ddad1480/files.json) · [轨迹](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/2c373007-717d-4905-9e45-6367ddad1480/agent/trajectory.jsonl) |
| test:3037 | completed | 1 | 7.87 | 0.01 | complete / not-produced | — | [result](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/3c1bca54-07ae-4c6c-bd9d-c5b014ee8ba3/result.json) · [文件清单](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/3c1bca54-07ae-4c6c-bd9d-c5b014ee8ba3/files.json) · [轨迹](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/3c1bca54-07ae-4c6c-bd9d-c5b014ee8ba3/agent/trajectory.jsonl) |
| test:3053 | cancelled | — | — | — | not-produced / not-produced | RUN\_CANCELLED | [result](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/10d8eb23-8541-43b2-989a-a0fa04b2e1be/result.json) · [文件清单](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/10d8eb23-8541-43b2-989a-a0fa04b2e1be/files.json) |
| test:3136 | pending | — | — | — | — | — | — |
| test:3165 | pending | — | — | — | — | — | — |
| test:3196 | pending | — | — | — | — | — | — |
| test:3231 | pending | — | — | — | — | — | — |
| test:3236 | pending | — | — | — | — | — | — |
| test:3270 | pending | — | — | — | — | — | — |
| test:3293 | pending | — | — | — | — | — | — |
| test:3331 | pending | — | — | — | — | — | — |
| test:3488 | pending | — | — | — | — | — | — |
| test:3491 | pending | — | — | — | — | — | — |
| test:3552 | pending | — | — | — | — | — | — |
| test:3599 | pending | — | — | — | — | — | — |
| test:3626 | pending | — | — | — | — | — | — |
| test:4021 | pending | — | — | — | — | — | — |
| test:4034 | pending | — | — | — | — | — | — |
| test:4058 | pending | — | — | — | — | — | — |
| test:4075 | pending | — | — | — | — | — | — |
| test:4142 | pending | — | — | — | — | — | — |
| test:4208 | pending | — | — | — | — | — | — |
| test:4298 | pending | — | — | — | — | — | — |
| test:4337 | pending | — | — | — | — | — | — |
| test:4376 | pending | — | — | — | — | — | — |
| test:4405 | pending | — | — | — | — | — | — |
| test:4552 | pending | — | — | — | — | — | — |
| test:4560 | pending | — | — | — | — | — | — |
| test:4568 | pending | — | — | — | — | — | — |
| test:4580 | pending | — | — | — | — | — | — |
| test:4603 | pending | — | — | — | — | — | — |
| test:4625 | pending | — | — | — | — | — | — |
| test:4627 | pending | — | — | — | — | — | — |
| test:4651 | pending | — | — | — | — | — | — |
| test:4670 | pending | — | — | — | — | — | — |
| test:4700 | pending | — | — | — | — | — | — |
| test:4709 | pending | — | — | — | — | — | — |
| test:4763 | pending | — | — | — | — | — | — |
| test:4770 | pending | — | — | — | — | — | — |
| test:4786 | pending | — | — | — | — | — | — |
| test:4879 | pending | — | — | — | — | — | — |
| test:5078 | pending | — | — | — | — | — | — |
| test:5123 | pending | — | — | — | — | — | — |
| test:5174 | pending | — | — | — | — | — | — |
| test:5198 | pending | — | — | — | — | — | — |
| test:5243 | pending | — | — | — | — | — | — |
| test:5309 | pending | — | — | — | — | — | — |
| test:5319 | pending | — | — | — | — | — | — |
| test:5328 | pending | — | — | — | — | — | — |
| test:5361 | pending | — | — | — | — | — | — |
| test:5457 | pending | — | — | — | — | — | — |
| test:5461 | pending | — | — | — | — | — | — |
| test:5530 | pending | — | — | — | — | — | — |
| test:5578 | pending | — | — | — | — | — | — |
| test:5580 | pending | — | — | — | — | — | — |
| test:5795 | pending | — | — | — | — | — | — |
| test:5919 | pending | — | — | — | — | — | — |
| test:5940 | pending | — | — | — | — | — | — |
| test:6055 | pending | — | — | — | — | — | — |
| test:6095 | pending | — | — | — | — | — | — |
| test:6120 | pending | — | — | — | — | — | — |
| test:6123 | pending | — | — | — | — | — | — |
| test:6147 | pending | — | — | — | — | — | — |
| test:6198 | pending | — | — | — | — | — | — |
| test:6223 | pending | — | — | — | — | — | — |
| test:6235 | pending | — | — | — | — | — | — |
| test:6403 | pending | — | — | — | — | — | — |
| test:6436 | pending | — | — | — | — | — | — |
| test:6508 | pending | — | — | — | — | — | — |
| test:6593 | pending | — | — | — | — | — | — |
| test:6655 | pending | — | — | — | — | — | — |
| test:6738 | pending | — | — | — | — | — | — |
| test:6751 | pending | — | — | — | — | — | — |
| test:6784 | pending | — | — | — | — | — | — |
| test:6792 | pending | — | — | — | — | — | — |
| test:6900 | pending | — | — | — | — | — | — |
| test:6928 | pending | — | — | — | — | — | — |
| test:6929 | pending | — | — | — | — | — | — |
| test:7161 | pending | — | — | — | — | — | — |
| test:7181 | pending | — | — | — | — | — | — |
| test:7217 | pending | — | — | — | — | — | — |
| test:7290 | pending | — | — | — | — | — | — |
| test:7304 | pending | — | — | — | — | — | — |
| test:7312 | pending | — | — | — | — | — | — |
| test:7448 | pending | — | — | — | — | — | — |
| test:7462 | pending | — | — | — | — | — | — |
| test:7526 | pending | — | — | — | — | — | — |
| test:7727 | pending | — | — | — | — | — | — |
| test:7752 | pending | — | — | — | — | — | — |
| test:7838 | pending | — | — | — | — | — | — |
| test:7954 | pending | — | — | — | — | — | — |
| test:7976 | pending | — | — | — | — | — | — |
| test:8199 | pending | — | — | — | — | — | — |
| test:8207 | pending | — | — | — | — | — | — |
| test:8304 | pending | — | — | — | — | — | — |
| test:8366 | pending | — | — | — | — | — | — |
| test:8511 | pending | — | — | — | — | — | — |
| test:8525 | pending | — | — | — | — | — | — |
| test:8604 | pending | — | — | — | — | — | — |
| test:8740 | pending | — | — | — | — | — | — |
| test:8839 | pending | — | — | — | — | — | — |
| test:8939 | pending | — | — | — | — | — | — |
| test:8967 | pending | — | — | — | — | — | — |
| test:8989 | pending | — | — | — | — | — | — |
| test:9136 | pending | — | — | — | — | — | — |
| test:9222 | pending | — | — | — | — | — | — |
| test:9391 | pending | — | — | — | — | — | — |
| test:9395 | pending | — | — | — | — | — | — |
| test:9405 | pending | — | — | — | — | — | — |
| test:9769 | pending | — | — | — | — | — | — |
| test:9843 | pending | — | — | — | — | — | — |
| test:9864 | pending | — | — | — | — | — | — |
| test:9901 | pending | — | — | — | — | — | — |
| test:9931 | pending | — | — | — | — | — | — |
| test:10127 | pending | — | — | — | — | — | — |
| test:10140 | pending | — | — | — | — | — | — |
| test:10174 | pending | — | — | — | — | — | — |
| test:10184 | pending | — | — | — | — | — | — |
| test:10189 | pending | — | — | — | — | — | — |
| test:10294 | pending | — | — | — | — | — | — |
| test:10318 | pending | — | — | — | — | — | — |
| test:10362 | pending | — | — | — | — | — | — |
| test:10396 | pending | — | — | — | — | — | — |
| test:10401 | pending | — | — | — | — | — | — |
| test:10403 | pending | — | — | — | — | — | — |
| test:10412 | pending | — | — | — | — | — | — |
| test:10421 | pending | — | — | — | — | — | — |
| test:10424 | pending | — | — | — | — | — | — |
| test:10471 | pending | — | — | — | — | — | — |
| test:10479 | pending | — | — | — | — | — | — |
| test:10524 | pending | — | — | — | — | — | — |
| test:10607 | pending | — | — | — | — | — | — |
| test:10656 | pending | — | — | — | — | — | — |
| test:10674 | pending | — | — | — | — | — | — |
| test:10683 | pending | — | — | — | — | — | — |
| test:10690 | pending | — | — | — | — | — | — |
| test:10765 | pending | — | — | — | — | — | — |
| test:10770 | pending | — | — | — | — | — | — |
| test:10815 | pending | — | — | — | — | — | — |
| test:10846 | pending | — | — | — | — | — | — |
| test:10898 | pending | — | — | — | — | — | — |
| test:10940 | pending | — | — | — | — | — | — |
| test:10966 | pending | — | — | — | — | — | — |
| test:11045 | pending | — | — | — | — | — | — |
| test:11050 | pending | — | — | — | — | — | — |
| test:11060 | pending | — | — | — | — | — | — |
| test:11093 | pending | — | — | — | — | — | — |
| test:11210 | pending | — | — | — | — | — | — |
| test:11354 | pending | — | — | — | — | — | — |
| test:11491 | pending | — | — | — | — | — | — |
| test:11496 | pending | — | — | — | — | — | — |
| test:11506 | pending | — | — | — | — | — | — |
| test:11559 | pending | — | — | — | — | — | — |
| test:11576 | pending | — | — | — | — | — | — |
| test:11629 | pending | — | — | — | — | — | — |
| test:11660 | pending | — | — | — | — | — | — |
| test:11802 | pending | — | — | — | — | — | — |
| test:11808 | pending | — | — | — | — | — | — |
| test:11824 | pending | — | — | — | — | — | — |
| test:11925 | pending | — | — | — | — | — | — |
| test:12002 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 2；错误记录 3（主流程 1；证据收集 0；资源清理 2）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| cleanup | CLEANUP_FAILED | 1 | 2 |
| environment | RUN_CANCELLED | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

