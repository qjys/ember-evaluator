<!-- snapshotDigest: a34f454d853e7f286e5f9c6beac52dfd0b634ec9f025c88e8f2b85009b2eeeb3 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 79.17%（19/24）**

Run: d1ce439f-6111-4420-b395-bccc91c9dc4a · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T08:31:17.763Z / 2026-11-12T08:36:44.958Z |
| 总耗时 | 5 分 16 秒 |
| 答对 / 答错 / 解题超时 | 19 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 24 题；已保存 24 条记录；待运行 0 题。
有效评分覆盖率：24/24（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 24 |
| 计分题数 | 24 |
| 正常评分题数 | 24 |
| 答对题数 | 19 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 79.17% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 分 16 秒 |
| 环境准备耗时 | 3 分 10 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 44 秒 | 32 秒 | 1 分 9 秒 | 24 |
| 任务准备 | 0.64 毫秒 | 0.27 毫秒 | 4.34 毫秒 | 24 |
| 环境启动 | 22 秒 | 17 秒 | 31 秒 | 24 |
| 解题 | 11 秒 | 5 秒 | 36 秒 | 24 |
| 产物传输 | 3 秒 | 2 秒 | 4 秒 | 24 |
| 资源清理 | 8 秒 | 5 秒 | 11 秒 | 24 |
| 评分 | 1.51 毫秒 | 0.26 毫秒 | 13.2 毫秒 | 24 |
| 证据收集 | 12.6 毫秒 | 3.87 毫秒 | 46.62 毫秒 | 24 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 2d17741e-5413-4bfa-ac20-bd786f91477b | 未设置 | 600 | 4 | 4 | 2400 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 31,902 | 13,201 | 45,103 | 24 / 24 | — |
| 运行累计 | 31,902 | 13,201 | 45,103 | 24 / 24 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:4709 | completed | 0 | 11.51 | 0.00 | complete / not-produced | — | [result](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/2d276ee2-7741-4821-8c02-23a44bc3a162/result.json) · [文件清单](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/2d276ee2-7741-4821-8c02-23a44bc3a162/files.json) · [轨迹](tasks/0b2a18aaae4e33ef1ffd087fef9dfcfb1c7c7c88b26b5b97a836ac1005217eea/attempts/2d276ee2-7741-4821-8c02-23a44bc3a162/agent/trajectory.jsonl) |
| test:4763 | completed | 1 | 18.78 | 0.00 | complete / not-produced | — | [result](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/2ca37626-0059-44b0-80ee-3e25abf4fc7c/result.json) · [文件清单](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/2ca37626-0059-44b0-80ee-3e25abf4fc7c/files.json) · [轨迹](tasks/fe5e4915d6823c55834cc88ee73cd4158c4f63b0a5a3e148f3464943459af97b/attempts/2ca37626-0059-44b0-80ee-3e25abf4fc7c/agent/trajectory.jsonl) |
| test:4770 | completed | 1 | 8.89 | 0.00 | complete / not-produced | — | [result](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/ec42451a-07ae-4bb6-ba69-162ee3688651/result.json) · [文件清单](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/ec42451a-07ae-4bb6-ba69-162ee3688651/files.json) · [轨迹](tasks/52daaece64cc9d0e9a6a59315b8662dc86d0d24dad9e96b78ef5b9eb449333ea/attempts/ec42451a-07ae-4bb6-ba69-162ee3688651/agent/trajectory.jsonl) |
| test:4786 | completed | 1 | 9.30 | 0.00 | complete / not-produced | — | [result](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/d8412d5a-7cf2-4fa8-9fcc-db29bbac96f4/result.json) · [文件清单](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/d8412d5a-7cf2-4fa8-9fcc-db29bbac96f4/files.json) · [轨迹](tasks/7af02d55b64f0f8b2fa34a1a75ea46c79a2f6b227a02ddede228cc9be2886215/attempts/d8412d5a-7cf2-4fa8-9fcc-db29bbac96f4/agent/trajectory.jsonl) |
| test:4879 | completed | 1 | 11.66 | 0.00 | complete / not-produced | — | [result](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/ff01e315-8437-4f6a-a7f8-21a63ed47abb/result.json) · [文件清单](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/ff01e315-8437-4f6a-a7f8-21a63ed47abb/files.json) · [轨迹](tasks/5efec7d7ac490d07a563735c9b841d45040b7503e0cf0a8792f1ca028cbbb637/attempts/ff01e315-8437-4f6a-a7f8-21a63ed47abb/agent/trajectory.jsonl) |
| test:5078 | completed | 1 | 11.06 | 0.00 | complete / not-produced | — | [result](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/65167352-0088-4b4d-a19b-3b14910e0627/result.json) · [文件清单](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/65167352-0088-4b4d-a19b-3b14910e0627/files.json) · [轨迹](tasks/4f5fd8d142d1ed6da401622787edee09fc0435bf4aa38d72171d803c3a2cbfb6/attempts/65167352-0088-4b4d-a19b-3b14910e0627/agent/trajectory.jsonl) |
| test:5123 | completed | 1 | 5.99 | 0.00 | complete / not-produced | — | [result](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/5d63b9ae-3f7c-45e5-9325-89e82e2f49a4/result.json) · [文件清单](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/5d63b9ae-3f7c-45e5-9325-89e82e2f49a4/files.json) · [轨迹](tasks/e89fbcb6c7cedc7c9decd018c5a1049c41e148f72c306be28c332f9f11fb7c41/attempts/5d63b9ae-3f7c-45e5-9325-89e82e2f49a4/agent/trajectory.jsonl) |
| test:5174 | completed | 1 | 6.35 | 0.00 | complete / not-produced | — | [result](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/26cf9120-61a8-470a-a8c7-fdfc23a4fbcf/result.json) · [文件清单](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/26cf9120-61a8-470a-a8c7-fdfc23a4fbcf/files.json) · [轨迹](tasks/207f12520f096c239b90e493145a9f14d478072c020a95ec5832c5b57bffb1a9/attempts/26cf9120-61a8-470a-a8c7-fdfc23a4fbcf/agent/trajectory.jsonl) |
| test:5198 | completed | 1 | 6.66 | 0.00 | complete / not-produced | — | [result](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/8d75b7b8-42d3-4a0a-a372-421b6e42fc6c/result.json) · [文件清单](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/8d75b7b8-42d3-4a0a-a372-421b6e42fc6c/files.json) · [轨迹](tasks/ae23cf3bc79d44831ef9a2ff46466b632068f8474c0efbd614487150938c4942/attempts/8d75b7b8-42d3-4a0a-a372-421b6e42fc6c/agent/trajectory.jsonl) |
| test:5243 | completed | 1 | 6.53 | 0.00 | complete / not-produced | — | [result](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/bdfbc267-836b-40c5-a211-11de91bc927d/result.json) · [文件清单](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/bdfbc267-836b-40c5-a211-11de91bc927d/files.json) · [轨迹](tasks/939220f53a11eef831ba33377aca282058b5e979ef9ad72d7277fe51a52c9e26/attempts/bdfbc267-836b-40c5-a211-11de91bc927d/agent/trajectory.jsonl) |
| test:5309 | completed | 1 | 7.38 | 0.00 | complete / not-produced | — | [result](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/1e1b5d04-89d7-439e-a83f-40d73778facc/result.json) · [文件清单](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/1e1b5d04-89d7-439e-a83f-40d73778facc/files.json) · [轨迹](tasks/47d1350ec6cf93743f6b701298ff019633b41e88e1d75ff4f4d24b3d5b0d6711/attempts/1e1b5d04-89d7-439e-a83f-40d73778facc/agent/trajectory.jsonl) |
| test:5319 | completed | 1 | 7.56 | 0.00 | complete / not-produced | — | [result](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/680e366e-1629-4083-905a-df7d16588bc0/result.json) · [文件清单](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/680e366e-1629-4083-905a-df7d16588bc0/files.json) · [轨迹](tasks/b22bd7673731341ed5dc49e956507026bf177a85b57e0070745e4ec0180be7cf/attempts/680e366e-1629-4083-905a-df7d16588bc0/agent/trajectory.jsonl) |
| test:5328 | completed | 0 | 12.35 | 0.00 | complete / not-produced | — | [result](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/2a70c7b2-c07f-4846-8b37-05730e621126/result.json) · [文件清单](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/2a70c7b2-c07f-4846-8b37-05730e621126/files.json) · [轨迹](tasks/4c57f5176aed4c1572aaf9b7de59745706366342cae99d9940029c5d16f5d5b6/attempts/2a70c7b2-c07f-4846-8b37-05730e621126/agent/trajectory.jsonl) |
| test:5361 | completed | 0 | 23.28 | 0.01 | complete / not-produced | — | [result](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/37a133ae-0d12-4bbd-987d-c3b7588fd5da/result.json) · [文件清单](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/37a133ae-0d12-4bbd-987d-c3b7588fd5da/files.json) · [轨迹](tasks/90bce75c0cc02a14f2c28ae4b95f0cdbac7b6a69bd17ce8a0e0761005bbdee02/attempts/37a133ae-0d12-4bbd-987d-c3b7588fd5da/agent/trajectory.jsonl) |
| test:5457 | completed | 1 | 7.50 | 0.00 | complete / not-produced | — | [result](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/cc7b0d20-5645-46df-ba28-e49634195eff/result.json) · [文件清单](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/cc7b0d20-5645-46df-ba28-e49634195eff/files.json) · [轨迹](tasks/d02d7437db28c29e4c13b0040ba0216af5885e78c95ea7279af1a47acc02fbcb/attempts/cc7b0d20-5645-46df-ba28-e49634195eff/agent/trajectory.jsonl) |
| test:5461 | completed | 1 | 8.51 | 0.00 | complete / not-produced | — | [result](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/d8502348-6462-4517-9330-d63cb29a1943/result.json) · [文件清单](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/d8502348-6462-4517-9330-d63cb29a1943/files.json) · [轨迹](tasks/dec3ed2287fa02cf6998d4a38956ffc73150eed5e5b9b05a8e75aff98da37f89/attempts/d8502348-6462-4517-9330-d63cb29a1943/agent/trajectory.jsonl) |
| test:5530 | completed | 0 | 12.62 | 0.00 | complete / not-produced | — | [result](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/ae55c8ec-5496-46f1-835d-7d30a481f02e/result.json) · [文件清单](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/ae55c8ec-5496-46f1-835d-7d30a481f02e/files.json) · [轨迹](tasks/5875e59c1946c0d9f7218e60886d753c8be008ff8163589899da8de2f94db454/attempts/ae55c8ec-5496-46f1-835d-7d30a481f02e/agent/trajectory.jsonl) |
| test:5578 | completed | 1 | 6.58 | 0.00 | complete / not-produced | — | [result](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/d70f8a0d-8a87-468d-9d67-29b0669149d7/result.json) · [文件清单](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/d70f8a0d-8a87-468d-9d67-29b0669149d7/files.json) · [轨迹](tasks/567556261d938c195f977cf5032e0af867323a7ef05973f00f679f6a29552632/attempts/d70f8a0d-8a87-468d-9d67-29b0669149d7/agent/trajectory.jsonl) |
| test:5580 | completed | 1 | 12.11 | 0.00 | complete / not-produced | — | [result](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/9897155f-858e-4cc8-8008-2e5323cbe5e0/result.json) · [文件清单](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/9897155f-858e-4cc8-8008-2e5323cbe5e0/files.json) · [轨迹](tasks/318cdd28aeb0633364fe77c0f0ee7d5eda363a3c47e9dc6bb0101f590a45fa2f/attempts/9897155f-858e-4cc8-8008-2e5323cbe5e0/agent/trajectory.jsonl) |
| test:5795 | completed | 1 | 6.80 | 0.00 | complete / not-produced | — | [result](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/b36b8e4f-4b81-4163-bc6f-b34393ad1634/result.json) · [文件清单](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/b36b8e4f-4b81-4163-bc6f-b34393ad1634/files.json) · [轨迹](tasks/7c52257045acc6ce9686efdb73002fb0f99a0cf242af40c2b44ffa273dcf9bf2/attempts/b36b8e4f-4b81-4163-bc6f-b34393ad1634/agent/trajectory.jsonl) |
| test:5919 | completed | 0 | 35.61 | 0.00 | complete / not-produced | — | [result](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/2aa347e6-f150-41aa-9542-4f3c0eddce81/result.json) · [文件清单](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/2aa347e6-f150-41aa-9542-4f3c0eddce81/files.json) · [轨迹](tasks/1f36b42516d972203def574c1bfb2cc91476127c82f950d6dd679242a2c90104/attempts/2aa347e6-f150-41aa-9542-4f3c0eddce81/agent/trajectory.jsonl) |
| test:5940 | completed | 1 | 6.66 | 0.00 | complete / not-produced | — | [result](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/9c54aac3-7b5e-4504-ae9a-96edb18b5591/result.json) · [文件清单](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/9c54aac3-7b5e-4504-ae9a-96edb18b5591/files.json) · [轨迹](tasks/7808c8073fbef7941a6791b3fcac4c5e82bcb3057bf91a559a06214a9a8e5d9c/attempts/9c54aac3-7b5e-4504-ae9a-96edb18b5591/agent/trajectory.jsonl) |
| test:6055 | completed | 1 | 5.43 | 0.00 | complete / not-produced | — | [result](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/0aa10dcc-40eb-4b44-bb3b-8d172be07751/result.json) · [文件清单](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/0aa10dcc-40eb-4b44-bb3b-8d172be07751/files.json) · [轨迹](tasks/1f19d8cce8631200ae67840b5714bdae7650ba92f6bb7f1920bfe5f3a3184625/attempts/0aa10dcc-40eb-4b44-bb3b-8d172be07751/agent/trajectory.jsonl) |
| test:6095 | completed | 1 | 8.90 | 0.00 | complete / not-produced | — | [result](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/e1a413b5-bb62-40f6-805d-3f9c36374fca/result.json) · [文件清单](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/e1a413b5-bb62-40f6-805d-3f9c36374fca/files.json) · [轨迹](tasks/3dc7798810285455061dff7b3d19eedf48795909d084abf61a8764a7957984f7/attempts/e1a413b5-bb62-40f6-805d-3f9c36374fca/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

