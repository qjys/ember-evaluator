<!-- snapshotDigest: ff56bd3f26ef6c1e1ddc45ed90fc254008c0ec9499491c656965e621a4fb5846 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 91.67%（11/12）**

Run: 32d56ebb-dc5f-48b0-b145-1f652ff3ab62 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | mmlu\_pro |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-12T07:54:06.164Z / 2026-11-12T07:56:12.897Z |
| 总耗时 | 2 分 3 秒 |
| 答对 / 答错 / 解题超时 | 11 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 12 题；已保存 12 条记录；待运行 0 题。
有效评分覆盖率：12/12（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 12 |
| 计分题数 | 12 |
| 正常评分题数 | 12 |
| 答对题数 | 11 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 91.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 分 3 秒 |
| 环境准备耗时 | 1 分 32 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 24 秒 | 18 秒 | 36 秒 | 12 |
| 任务准备 | 0.42 毫秒 | 0.31 毫秒 | 0.81 毫秒 | 12 |
| 环境启动 | 11 秒 | 9 秒 | 13 秒 | 12 |
| 解题 | 8 秒 | 4 秒 | 21 秒 | 12 |
| 产物传输 | 1 秒 | 977.55 毫秒 | 2 秒 | 12 |
| 资源清理 | 4 秒 | 3 秒 | 5 秒 | 12 |
| 评分 | 0.64 毫秒 | 0.28 毫秒 | 1.89 毫秒 | 12 |
| 证据收集 | 15.3 毫秒 | 5.99 毫秒 | 31.34 毫秒 | 12 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 54fa9a54-2839-4f28-ad0d-1145fb6818c7 | 未设置 | 600 | 3 | 3 | 1800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 17,509 | 6,209 | 23,718 | 12 / 12 | — |
| 运行累计 | 17,509 | 6,209 | 23,718 | 12 / 12 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| test:2951 | completed | 1 | 4.88 | 0.00 | complete / not-produced | — | [result](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/f6fde63b-b575-44dc-8b19-c1d321a8ce5b/result.json) · [文件清单](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/f6fde63b-b575-44dc-8b19-c1d321a8ce5b/files.json) · [轨迹](tasks/560d88a90a557ab08323703d3365d42270062d32e43c62dca09f3aabc10f5f03/attempts/f6fde63b-b575-44dc-8b19-c1d321a8ce5b/agent/trajectory.jsonl) |
| test:3037 | completed | 1 | 5.75 | 0.00 | complete / not-produced | — | [result](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/a663da8a-b2eb-4eea-8da4-dbaaea99801a/result.json) · [文件清单](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/a663da8a-b2eb-4eea-8da4-dbaaea99801a/files.json) · [轨迹](tasks/f9cabdad39c83893de0be24c286097e1ab463c2da6b75d473e02520f0dc36d40/attempts/a663da8a-b2eb-4eea-8da4-dbaaea99801a/agent/trajectory.jsonl) |
| test:3053 | completed | 0 | 20.50 | 0.00 | complete / not-produced | — | [result](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/cdd74aa9-57cf-46c0-9535-d3b6566a1c69/result.json) · [文件清单](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/cdd74aa9-57cf-46c0-9535-d3b6566a1c69/files.json) · [轨迹](tasks/f5357aad2d25abc8a53736e008dcbadeffedf66dd874250d161d9b9c7588ff98/attempts/cdd74aa9-57cf-46c0-9535-d3b6566a1c69/agent/trajectory.jsonl) |
| test:3136 | completed | 1 | 9.03 | 0.00 | complete / not-produced | — | [result](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/02fc582b-bd85-4e39-bf25-2d4f8505cd32/result.json) · [文件清单](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/02fc582b-bd85-4e39-bf25-2d4f8505cd32/files.json) · [轨迹](tasks/34860d6d8fbd7df08c0dea46b0470f5c1272ab0d1579436988fd72d7058c6c65/attempts/02fc582b-bd85-4e39-bf25-2d4f8505cd32/agent/trajectory.jsonl) |
| test:3165 | completed | 1 | 15.33 | 0.00 | complete / not-produced | — | [result](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/3e4a2566-9b64-44ac-8634-1eb2d48c1749/result.json) · [文件清单](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/3e4a2566-9b64-44ac-8634-1eb2d48c1749/files.json) · [轨迹](tasks/c64eea3c96bd521beb20efcdc94a4a824b7fd1fee8970838a4a68787bd07c880/attempts/3e4a2566-9b64-44ac-8634-1eb2d48c1749/agent/trajectory.jsonl) |
| test:3196 | completed | 1 | 4.14 | 0.00 | complete / not-produced | — | [result](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/d39fe206-fbf5-468e-9130-f8369ccccd8f/result.json) · [文件清单](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/d39fe206-fbf5-468e-9130-f8369ccccd8f/files.json) · [轨迹](tasks/e6293a83d2e716c0057d3579fd4558087b214f341a29da01292f718a1e8aab00/attempts/d39fe206-fbf5-468e-9130-f8369ccccd8f/agent/trajectory.jsonl) |
| test:3231 | completed | 1 | 4.61 | 0.00 | complete / not-produced | — | [result](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/4a073f3d-8db1-4e92-9469-71152e5a6927/result.json) · [文件清单](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/4a073f3d-8db1-4e92-9469-71152e5a6927/files.json) · [轨迹](tasks/d7b738acdbf6d8f264e5370050692a77659a9c17f413d9e5949ef6d2d6ec351e/attempts/4a073f3d-8db1-4e92-9469-71152e5a6927/agent/trajectory.jsonl) |
| test:3236 | completed | 1 | 5.35 | 0.00 | complete / not-produced | — | [result](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/a70e5d20-dc55-4f4f-9b2d-8c26bb2bc7d9/result.json) · [文件清单](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/a70e5d20-dc55-4f4f-9b2d-8c26bb2bc7d9/files.json) · [轨迹](tasks/624884e60706679a0cee113232f98d49e5c5c21519a88f9c7ce73a38e1ec8471/attempts/a70e5d20-dc55-4f4f-9b2d-8c26bb2bc7d9/agent/trajectory.jsonl) |
| test:3270 | completed | 1 | 6.22 | 0.00 | complete / not-produced | — | [result](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/89589cdf-38ad-483c-9af0-6e28861640ac/result.json) · [文件清单](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/89589cdf-38ad-483c-9af0-6e28861640ac/files.json) · [轨迹](tasks/e0845092e601cfc25b575136e9290af89c0d4216f7874fb5a460611e2388547f/attempts/89589cdf-38ad-483c-9af0-6e28861640ac/agent/trajectory.jsonl) |
| test:3293 | completed | 1 | 7.35 | 0.00 | complete / not-produced | — | [result](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/0cb56ca3-ef84-40ec-876c-8ff0c785327e/result.json) · [文件清单](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/0cb56ca3-ef84-40ec-876c-8ff0c785327e/files.json) · [轨迹](tasks/7af27e589cdeae1e6965b72992772f4b53bc5b5fa89e8728ab60d60dd81d06b4/attempts/0cb56ca3-ef84-40ec-876c-8ff0c785327e/agent/trajectory.jsonl) |
| test:3331 | completed | 1 | 4.43 | 0.00 | complete / not-produced | — | [result](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/1ea74557-296b-428a-8c69-7bb472229a4d/result.json) · [文件清单](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/1ea74557-296b-428a-8c69-7bb472229a4d/files.json) · [轨迹](tasks/2a68e7ac30f63491da08f7bf2c706014c7e74c8a891e0d4b7d794cb4f3aeff00/attempts/1ea74557-296b-428a-8c69-7bb472229a4d/agent/trajectory.jsonl) |
| test:3488 | completed | 1 | 7.64 | 0.00 | complete / not-produced | — | [result](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/f34b7be1-a360-4364-8fc4-44f2658768b0/result.json) · [文件清单](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/f34b7be1-a360-4364-8fc4-44f2658768b0/files.json) · [轨迹](tasks/d5f152067246201e510fb98a151db8d360ed07c3166a94853c59af5b013b9b78/attempts/f34b7be1-a360-4364-8fc4-44f2658768b0/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：local:TIGER-Lab/MMLU-Pro @ local:bfc6981b70620a814695e6b86d8baa0f23e5e2d78b94eb75b75b2cfd3f24b52b

