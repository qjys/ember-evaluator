<!-- snapshotDigest: cd71e84726557938bf893c7796eee80421177a9e2df4da7298ace3d0bec831f5 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 41.94%（13/31）**

Run: 26735a15-7f9e-4660-a30a-a26089e9714f · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-14T02:33:22.175Z / 2026-11-14T13:15:30.430Z |
| 总耗时 | 10 小时 20 分 23 秒 |
| 答对 / 答错 / 解题超时 | 13 / 18 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 31 题；已保存 31 条记录；待运行 0 题。
有效评分覆盖率：31/31（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 31 |
| 计分题数 | 31 |
| 正常评分题数 | 31 |
| 答对题数 | 13 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 41.94% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 10 小时 20 分 23 秒 |
| 环境准备耗时 | 6 小时 50 分 36 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 19 分 57 秒 | 6 分 50 秒 | 57 分 59 秒 | 31 |
| 任务准备 | 0.41 毫秒 | 0.25 毫秒 | 1.77 毫秒 | 31 |
| 环境启动 | 6 秒 | 5 秒 | 8 秒 | 31 |
| 解题 | 19 分 42 秒 | 6 分 37 秒 | 57 分 44 秒 | 31 |
| 产物传输 | 2 秒 | 1 秒 | 2 秒 | 31 |
| 证据收集 | 4 秒 | 1 秒 | 58 秒 | 31 |
| 资源清理 | 3 秒 | 3 秒 | 4 秒 | 31 |
| 评分 | 1 秒 | 1 秒 | 2 秒 | 31 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 5ef5d2c0-ffb5-4807-b454-9b40ab884698 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 603,079,130 | 959,210 | 604,038,340 | 31 / 31 | — |
| 运行累计 | 603,079,130 | 959,210 | 604,038,340 | 31 / 31 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 59 | completed | 0 | 701.68 | 1.51 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/d6133c95-8866-4d1a-8ddc-f5e3aee4aa42/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/d6133c95-8866-4d1a-8ddc-f5e3aee4aa42/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/d6133c95-8866-4d1a-8ddc-f5e3aee4aa42/agent/trajectory.jsonl) |
| 60 | completed | 1 | 705.87 | 1.73 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/8e08c261-a7a0-4ed6-8343-290d13a4caab/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/8e08c261-a7a0-4ed6-8343-290d13a4caab/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/8e08c261-a7a0-4ed6-8343-290d13a4caab/agent/trajectory.jsonl) |
| 61 | completed | 0 | 1291.37 | 1.37 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/555218dd-fa7d-4a57-af32-cade88b47846/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/555218dd-fa7d-4a57-af32-cade88b47846/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/555218dd-fa7d-4a57-af32-cade88b47846/agent/trajectory.jsonl) |
| 62 | completed | 0 | 3464.40 | 1.60 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/dece9fad-06a5-4d52-9108-e2c497b77fa4/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/dece9fad-06a5-4d52-9108-e2c497b77fa4/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/dece9fad-06a5-4d52-9108-e2c497b77fa4/agent/trajectory.jsonl) |
| 63 | completed | 1 | 825.84 | 1.37 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/94f52394-077a-4014-be2b-586d6824629e/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/94f52394-077a-4014-be2b-586d6824629e/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/94f52394-077a-4014-be2b-586d6824629e/agent/trajectory.jsonl) |
| 64 | completed | 0 | 1231.99 | 1.73 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/3d57c5ea-56ed-4495-83e7-fbeda4a7cd14/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/3d57c5ea-56ed-4495-83e7-fbeda4a7cd14/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/3d57c5ea-56ed-4495-83e7-fbeda4a7cd14/agent/trajectory.jsonl) |
| 65 | completed | 0 | 2148.90 | 1.21 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/27de05c0-0231-4141-8ded-e17a4207c7a0/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/27de05c0-0231-4141-8ded-e17a4207c7a0/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/27de05c0-0231-4141-8ded-e17a4207c7a0/agent/trajectory.jsonl) |
| 66 | completed | 1 | 397.00 | 1.35 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/26a42f74-e0c2-4d83-a1b4-d997003116bc/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/26a42f74-e0c2-4d83-a1b4-d997003116bc/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/26a42f74-e0c2-4d83-a1b4-d997003116bc/agent/trajectory.jsonl) |
| 67 | completed | 1 | 479.12 | 1.27 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/66bf4a49-47c5-4d3d-b4f2-8600d4b0cafe/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/66bf4a49-47c5-4d3d-b4f2-8600d4b0cafe/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/66bf4a49-47c5-4d3d-b4f2-8600d4b0cafe/agent/trajectory.jsonl) |
| 68 | completed | 1 | 417.72 | 1.38 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/a6f77056-ef89-4a02-8c77-faf4b73e2ddc/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/a6f77056-ef89-4a02-8c77-faf4b73e2ddc/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/a6f77056-ef89-4a02-8c77-faf4b73e2ddc/agent/trajectory.jsonl) |
| 69 | completed | 1 | 632.57 | 1.29 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/35ed3232-ca6e-41be-b248-26ff34ced0cc/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/35ed3232-ca6e-41be-b248-26ff34ced0cc/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/35ed3232-ca6e-41be-b248-26ff34ced0cc/agent/trajectory.jsonl) |
| 70 | completed | 1 | 851.28 | 1.24 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/4ef4d8c2-cccb-4a07-92fe-aeb683ae53a0/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/4ef4d8c2-cccb-4a07-92fe-aeb683ae53a0/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/4ef4d8c2-cccb-4a07-92fe-aeb683ae53a0/agent/trajectory.jsonl) |
| 71 | completed | 1 | 1908.33 | 1.16 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/eac52d47-d2ba-4f0c-a577-fc55b81ddca7/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/eac52d47-d2ba-4f0c-a577-fc55b81ddca7/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/eac52d47-d2ba-4f0c-a577-fc55b81ddca7/agent/trajectory.jsonl) |
| 72 | completed | 0 | 1835.51 | 1.19 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/677e8e1b-9fb5-481b-b305-b0b10b4367f1/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/677e8e1b-9fb5-481b-b305-b0b10b4367f1/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/677e8e1b-9fb5-481b-b305-b0b10b4367f1/agent/trajectory.jsonl) |
| 73 | completed | 0 | 927.43 | 1.34 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/419583f2-0fbb-4199-b4fd-fcd6a7bcc26e/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/419583f2-0fbb-4199-b4fd-fcd6a7bcc26e/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/419583f2-0fbb-4199-b4fd-fcd6a7bcc26e/agent/trajectory.jsonl) |
| 74 | completed | 0 | 1575.38 | 1.58 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/9e36b4ee-7121-45bb-bb70-00649b3d04c4/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/9e36b4ee-7121-45bb-bb70-00649b3d04c4/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/9e36b4ee-7121-45bb-bb70-00649b3d04c4/agent/trajectory.jsonl) |
| 75 | completed | 0 | 1160.17 | 1.22 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/4069d63a-580c-4390-a8db-f6dc9efcdeaf/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/4069d63a-580c-4390-a8db-f6dc9efcdeaf/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/4069d63a-580c-4390-a8db-f6dc9efcdeaf/agent/trajectory.jsonl) |
| 76 | completed | 0 | 577.66 | 1.20 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/d71b830f-a174-4926-83bf-a7536d3f78de/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/d71b830f-a174-4926-83bf-a7536d3f78de/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/d71b830f-a174-4926-83bf-a7536d3f78de/agent/trajectory.jsonl) |
| 77 | completed | 0 | 999.99 | 1.22 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/a2736ff2-9861-4fc5-aacf-406f8ee0bec5/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/a2736ff2-9861-4fc5-aacf-406f8ee0bec5/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/a2736ff2-9861-4fc5-aacf-406f8ee0bec5/agent/trajectory.jsonl) |
| 78 | completed | 1 | 619.57 | 1.23 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/4ab1719f-7efd-4de6-9535-6c60ffb02f2c/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/4ab1719f-7efd-4de6-9535-6c60ffb02f2c/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/4ab1719f-7efd-4de6-9535-6c60ffb02f2c/agent/trajectory.jsonl) |
| 79 | completed | 1 | 685.61 | 1.22 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/442e7d46-8a7b-4b7d-8ef3-b43b865450ab/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/442e7d46-8a7b-4b7d-8ef3-b43b865450ab/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/442e7d46-8a7b-4b7d-8ef3-b43b865450ab/agent/trajectory.jsonl) |
| 80 | completed | 0 | 520.68 | 1.21 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/390d9dec-9efd-4a2e-939f-113a1647c6a4/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/390d9dec-9efd-4a2e-939f-113a1647c6a4/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/390d9dec-9efd-4a2e-939f-113a1647c6a4/agent/trajectory.jsonl) |
| 81 | completed | 0 | 1508.41 | 1.18 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/f187225d-0815-4113-a1b8-c71d4fad73bf/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/f187225d-0815-4113-a1b8-c71d4fad73bf/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/f187225d-0815-4113-a1b8-c71d4fad73bf/agent/trajectory.jsonl) |
| 82 | completed | 0 | 1932.94 | 1.28 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/1501278a-3ab3-49dd-95fc-614e307e80d7/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/1501278a-3ab3-49dd-95fc-614e307e80d7/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/1501278a-3ab3-49dd-95fc-614e307e80d7/agent/trajectory.jsonl) |
| 83 | completed | 0 | 1235.22 | 1.21 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/6a1820e1-2eb2-4de0-9e3e-6ffb8a9efc62/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/6a1820e1-2eb2-4de0-9e3e-6ffb8a9efc62/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/6a1820e1-2eb2-4de0-9e3e-6ffb8a9efc62/agent/trajectory.jsonl) |
| 84 | completed | 0 | 2545.18 | 1.35 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/7b8cb2de-10cf-4aa2-99d2-91806a3670d3/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/7b8cb2de-10cf-4aa2-99d2-91806a3670d3/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/7b8cb2de-10cf-4aa2-99d2-91806a3670d3/agent/trajectory.jsonl) |
| 85 | completed | 0 | 2388.83 | 1.29 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/873a5b40-3061-4003-b551-7a7d56e0a69f/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/873a5b40-3061-4003-b551-7a7d56e0a69f/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/873a5b40-3061-4003-b551-7a7d56e0a69f/agent/trajectory.jsonl) |
| 86 | completed | 1 | 702.80 | 1.22 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/3b9c493c-aaea-4a58-b4fa-ec72d0dca854/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/3b9c493c-aaea-4a58-b4fa-ec72d0dca854/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/3b9c493c-aaea-4a58-b4fa-ec72d0dca854/agent/trajectory.jsonl) |
| 87 | completed | 1 | 522.82 | 1.39 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/a93221bf-573e-4c5b-9fae-09f3fbc76df5/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/a93221bf-573e-4c5b-9fae-09f3fbc76df5/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/a93221bf-573e-4c5b-9fae-09f3fbc76df5/agent/trajectory.jsonl) |
| 88 | completed | 1 | 760.20 | 1.26 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/6c2063a7-b0e1-49f6-890f-27d5bf466992/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/6c2063a7-b0e1-49f6-890f-27d5bf466992/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/6c2063a7-b0e1-49f6-890f-27d5bf466992/agent/trajectory.jsonl) |
| 89 | completed | 0 | 1072.24 | 1.41 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/446571f6-032d-4311-be41-b9893e055e13/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/446571f6-032d-4311-be41-b9893e055e13/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/446571f6-032d-4311-be41-b9893e055e13/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

