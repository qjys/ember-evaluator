<!-- snapshotDigest: dcea0824d41cc1040ae1a48d803884d6f8835545374978c9c23b59cba63f3af3 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 17.98%（16/89）**

Run: 52a5e0ad-391b-434d-b5a7-0c440d67460f · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T10:15:26.494Z / 2026-11-13T12:17:28.117Z |
| 总耗时 | 1 小时 57 分 59 秒 |
| 答对 / 答错 / 解题超时 | 16 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 18 条记录；待运行 72 题。
有效评分覆盖率：17/90（18.89%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 17 |
| 答对题数 | 16 |
| 无效评测 | 1 |
| 待运行 | 72 |
| 正确率 | 17.98% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 57 分 59 秒 |
| 环境准备耗时 | 2 小时 1 分 40 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 6 分 31 秒 | 56 秒 | 11 分 8 秒 | 18 |
| 任务准备 | 0.45 毫秒 | 0.27 毫秒 | 0.85 毫秒 | 18 |
| 环境启动 | 4 秒 | 3 秒 | 4 秒 | 18 |
| 解题 | 6 分 22 秒 | 47 秒 | 10 分 59 秒 | 18 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 17 |
| 证据收集 | 950.09 毫秒 | 671.36 毫秒 | 2 秒 | 18 |
| 资源清理 | 2 秒 | 2 秒 | 3 秒 | 18 |
| 评分 | 1 秒 | 936.84 毫秒 | 2 秒 | 17 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| db6cb18a-ebce-4475-987c-4a6d7c734588 | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 85,425,893 | 836,803 | 86,262,696 | 17 / 90 | — |
| 运行累计 | 85,425,893 | 836,803 | 86,262,696 | 17 / 18 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 353.00 | 1.52 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/7243fec9-438f-4553-8514-f7ee8a232008/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/7243fec9-438f-4553-8514-f7ee8a232008/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/7243fec9-438f-4553-8514-f7ee8a232008/agent/trajectory.jsonl) |
| 1 | completed | 1 | 352.53 | 0.94 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/8c5ecd38-89c4-4711-b359-f7a511b9d1ee/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/8c5ecd38-89c4-4711-b359-f7a511b9d1ee/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/8c5ecd38-89c4-4711-b359-f7a511b9d1ee/agent/trajectory.jsonl) |
| 2 | completed | 1 | 483.08 | 1.05 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/7064f400-fe74-48fa-8719-d0b56072e9ee/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/7064f400-fe74-48fa-8719-d0b56072e9ee/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/7064f400-fe74-48fa-8719-d0b56072e9ee/agent/trajectory.jsonl) |
| 3 | completed | 1 | 388.59 | 1.01 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/6e57ab2d-6efd-423e-9f19-41c6589fe1aa/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/6e57ab2d-6efd-423e-9f19-41c6589fe1aa/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/6e57ab2d-6efd-423e-9f19-41c6589fe1aa/agent/trajectory.jsonl) |
| 4 | completed | 1 | 109.34 | 1.10 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/6ec0f53b-01a4-4c11-9802-dc0fe8971ae5/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/6ec0f53b-01a4-4c11-9802-dc0fe8971ae5/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/6ec0f53b-01a4-4c11-9802-dc0fe8971ae5/agent/trajectory.jsonl) |
| 5 | completed | 1 | 329.65 | 0.95 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/66b2176b-eeba-4673-bb28-a097fec0fc43/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/66b2176b-eeba-4673-bb28-a097fec0fc43/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/66b2176b-eeba-4673-bb28-a097fec0fc43/agent/trajectory.jsonl) |
| 6 | completed | 1 | 445.62 | 1.00 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/86fff857-a474-438f-8777-c9fe9ed5561e/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/86fff857-a474-438f-8777-c9fe9ed5561e/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/86fff857-a474-438f-8777-c9fe9ed5561e/agent/trajectory.jsonl) |
| 7 | completed | 1 | 129.53 | 1.02 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/9a8e8669-a5ba-4a69-b04a-a370890ca699/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/9a8e8669-a5ba-4a69-b04a-a370890ca699/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/9a8e8669-a5ba-4a69-b04a-a370890ca699/agent/trajectory.jsonl) |
| 8 | completed | 0 | 398.39 | 0.99 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/ad25f4f0-609b-4b42-ab47-0e951ceb4f39/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/ad25f4f0-609b-4b42-ab47-0e951ceb4f39/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/ad25f4f0-609b-4b42-ab47-0e951ceb4f39/agent/trajectory.jsonl) |
| 9 | completed | 1 | 47.10 | 1.07 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/a4e62b91-780f-4b25-8e16-fa764f8bf61e/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/a4e62b91-780f-4b25-8e16-fa764f8bf61e/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/a4e62b91-780f-4b25-8e16-fa764f8bf61e/agent/trajectory.jsonl) |
| 10 | completed | 1 | 659.37 | 1.03 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/be2a7fd6-4e6f-4f88-8592-5d0d40ce91ff/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/be2a7fd6-4e6f-4f88-8592-5d0d40ce91ff/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/be2a7fd6-4e6f-4f88-8592-5d0d40ce91ff/agent/trajectory.jsonl) |
| 11 | completed | 1 | 482.73 | 1.14 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/d4b06756-b3f6-43d2-8035-127fe82e112d/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/d4b06756-b3f6-43d2-8035-127fe82e112d/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/d4b06756-b3f6-43d2-8035-127fe82e112d/agent/trajectory.jsonl) |
| 12 | completed | 1 | 366.32 | 1.01 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/4cc0e7ec-dc49-430e-a0fe-e32463759880/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/4cc0e7ec-dc49-430e-a0fe-e32463759880/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/4cc0e7ec-dc49-430e-a0fe-e32463759880/agent/trajectory.jsonl) |
| 13 | completed | 1 | 572.39 | 1.13 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/5106b15f-8819-4f69-8a0d-368ec31b6aca/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/5106b15f-8819-4f69-8a0d-368ec31b6aca/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/5106b15f-8819-4f69-8a0d-368ec31b6aca/agent/trajectory.jsonl) |
| 14 | completed | 1 | 656.12 | 1.04 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/cc563259-f4d0-462e-aa54-ed31166aca39/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/cc563259-f4d0-462e-aa54-ed31166aca39/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/cc563259-f4d0-462e-aa54-ed31166aca39/agent/trajectory.jsonl) |
| 15 | completed | 1 | 490.98 | 0.95 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/27bcbf8a-c2e6-4255-971c-bf7e1e30aae6/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/27bcbf8a-c2e6-4255-971c-bf7e1e30aae6/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/27bcbf8a-c2e6-4255-971c-bf7e1e30aae6/agent/trajectory.jsonl) |
| 16 | completed | 1 | 391.36 | 1.19 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/a8946c9b-3495-400d-9e10-8feaf624bb39/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/a8946c9b-3495-400d-9e10-8feaf624bb39/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/a8946c9b-3495-400d-9e10-8feaf624bb39/agent/trajectory.jsonl) |
| 17 | invalid | — | 214.61 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/db694e66-f91f-434c-ba62-86d9f093f132/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/db694e66-f91f-434c-ba62-86d9f093f132/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/db694e66-f91f-434c-ba62-86d9f093f132/agent/trajectory.jsonl) |
| 18 | pending | — | — | — | — | — | — |
| 19 | pending | — | — | — | — | — | — |
| 20 | pending | — | — | — | — | — | — |
| 21 | pending | — | — | — | — | — | — |
| 22 | pending | — | — | — | — | — | — |
| 23 | pending | — | — | — | — | — | — |
| 24 | pending | — | — | — | — | — | — |
| 25 | pending | — | — | — | — | — | — |
| 26 | pending | — | — | — | — | — | — |
| 27 | pending | — | — | — | — | — | — |
| 28 | pending | — | — | — | — | — | — |
| 29 | pending | — | — | — | — | — | — |
| 30 | pending | — | — | — | — | — | — |
| 31 | pending | — | — | — | — | — | — |
| 32 | pending | — | — | — | — | — | — |
| 33 | pending | — | — | — | — | — | — |
| 34 | pending | — | — | — | — | — | — |
| 35 | pending | — | — | — | — | — | — |
| 36 | pending | — | — | — | — | — | — |
| 37 | pending | — | — | — | — | — | — |
| 38 | pending | — | — | — | — | — | — |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

