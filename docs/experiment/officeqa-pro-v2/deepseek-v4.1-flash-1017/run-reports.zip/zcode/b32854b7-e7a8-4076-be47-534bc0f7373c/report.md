<!-- snapshotDigest: b7396c0d86de8e361b5cf77e42302ad09ac45a49644e648ae8479ee940fea915 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 33.33%（24/72）**

Run: b32854b7-e7a8-4076-be47-534bc0f7373c · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T13:21:36.033Z / 2026-11-13T23:02:53.901Z |
| 总耗时 | 9 小时 21 分 31 秒 |
| 答对 / 答错 / 解题超时 | 24 / 18 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 73 题；已保存 43 条记录；待运行 30 题。
有效评分覆盖率：42/73（57.53%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 73 |
| 计分题数 | 72 |
| 正常评分题数 | 42 |
| 答对题数 | 24 |
| 无效评测 | 1 |
| 待运行 | 30 |
| 正确率 | 33.33% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 21 分 31 秒 |
| 环境准备耗时 | 9 小时 40 分 58 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 13 分 2 秒 | 3 分 0 秒 | 40 分 11 秒 | 43 |
| 任务准备 | 0.78 毫秒 | 0.23 毫秒 | 8.44 毫秒 | 43 |
| 环境启动 | 4 秒 | 3 秒 | 13 秒 | 43 |
| 解题 | 12 分 52 秒 | 2 分 52 秒 | 40 分 0 秒 | 43 |
| 产物传输 | 1 秒 | 1 秒 | 3 秒 | 42 |
| 证据收集 | 1 秒 | 636.37 毫秒 | 2 秒 | 43 |
| 资源清理 | 3 秒 | 2 秒 | 6 秒 | 43 |
| 评分 | 1 秒 | 989.22 毫秒 | 2 秒 | 42 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| d20556c0-7e4e-4d70-85b3-5ad6ee0837e0 | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 450,375,127 | 3,004,434 | 453,379,561 | 42 / 73 | — |
| 运行累计 | 450,375,127 | 3,004,434 | 453,379,561 | 42 / 43 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 17 | completed | 1 | 212.24 | 1.27 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/897ac5dd-6afc-4a14-83b1-3d0d3b1baf80/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/897ac5dd-6afc-4a14-83b1-3d0d3b1baf80/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/897ac5dd-6afc-4a14-83b1-3d0d3b1baf80/agent/trajectory.jsonl) |
| 18 | completed | 0 | 1046.54 | 1.00 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/c882b200-9e0b-42c0-8c40-138a6d61d7e8/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/c882b200-9e0b-42c0-8c40-138a6d61d7e8/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/c882b200-9e0b-42c0-8c40-138a6d61d7e8/agent/trajectory.jsonl) |
| 19 | completed | 1 | 447.25 | 1.10 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/0ffe1f99-3b07-46fc-9834-3a9b37d1a4ab/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/0ffe1f99-3b07-46fc-9834-3a9b37d1a4ab/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/0ffe1f99-3b07-46fc-9834-3a9b37d1a4ab/agent/trajectory.jsonl) |
| 20 | completed | 1 | 597.54 | 1.15 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/6a047f51-56ea-4878-9f20-b36c33456e6c/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/6a047f51-56ea-4878-9f20-b36c33456e6c/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/6a047f51-56ea-4878-9f20-b36c33456e6c/agent/trajectory.jsonl) |
| 21 | completed | 1 | 718.78 | 1.11 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/c67e3e99-a765-4bda-9b77-55c7c4040407/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/c67e3e99-a765-4bda-9b77-55c7c4040407/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/c67e3e99-a765-4bda-9b77-55c7c4040407/agent/trajectory.jsonl) |
| 22 | completed | 1 | 171.58 | 1.14 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/64a3fd77-1d37-4363-ab7d-31a0c6d26804/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/64a3fd77-1d37-4363-ab7d-31a0c6d26804/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/64a3fd77-1d37-4363-ab7d-31a0c6d26804/agent/trajectory.jsonl) |
| 23 | completed | 1 | 301.36 | 1.04 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/bde6870c-04ef-40b2-b1f6-ac54a475bd95/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/bde6870c-04ef-40b2-b1f6-ac54a475bd95/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/bde6870c-04ef-40b2-b1f6-ac54a475bd95/agent/trajectory.jsonl) |
| 24 | completed | 0 | 836.28 | 1.17 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/94e38bbf-2c25-41e8-b821-4fe941f01d5d/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/94e38bbf-2c25-41e8-b821-4fe941f01d5d/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/94e38bbf-2c25-41e8-b821-4fe941f01d5d/agent/trajectory.jsonl) |
| 25 | completed | 1 | 652.96 | 1.08 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/5fc36cc2-cb8f-4abf-b00f-bffdac743c17/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/5fc36cc2-cb8f-4abf-b00f-bffdac743c17/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/5fc36cc2-cb8f-4abf-b00f-bffdac743c17/agent/trajectory.jsonl) |
| 26 | completed | 1 | 925.81 | 1.10 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/71446f89-aa5e-489d-9f7b-74dfaa107c4f/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/71446f89-aa5e-489d-9f7b-74dfaa107c4f/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/71446f89-aa5e-489d-9f7b-74dfaa107c4f/agent/trajectory.jsonl) |
| 27 | completed | 1 | 784.33 | 1.06 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/3ad642d1-7124-4f44-bab8-98fd90ddce57/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/3ad642d1-7124-4f44-bab8-98fd90ddce57/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/3ad642d1-7124-4f44-bab8-98fd90ddce57/agent/trajectory.jsonl) |
| 28 | completed | 1 | 2400.40 | 1.19 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/9d9a3b1f-3b1d-434f-9213-920953641249/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/9d9a3b1f-3b1d-434f-9213-920953641249/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/9d9a3b1f-3b1d-434f-9213-920953641249/agent/trajectory.jsonl) |
| 29 | completed | 0 | 1183.59 | 1.02 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/ff5a8666-0e26-470a-b6e5-98b8274191cf/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/ff5a8666-0e26-470a-b6e5-98b8274191cf/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/ff5a8666-0e26-470a-b6e5-98b8274191cf/agent/trajectory.jsonl) |
| 30 | completed | 0 | 655.51 | 1.10 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/d808d9c2-385e-4c75-b83d-7a50bd28675e/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/d808d9c2-385e-4c75-b83d-7a50bd28675e/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/d808d9c2-385e-4c75-b83d-7a50bd28675e/agent/trajectory.jsonl) |
| 31 | completed | 1 | 338.99 | 1.98 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/c64f396a-0fa7-426d-bc04-318730721fcd/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/c64f396a-0fa7-426d-bc04-318730721fcd/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/c64f396a-0fa7-426d-bc04-318730721fcd/agent/trajectory.jsonl) |
| 32 | completed | 0 | 481.76 | 1.64 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/c90c480e-e513-4db0-b3e8-d53ed1a71453/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/c90c480e-e513-4db0-b3e8-d53ed1a71453/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/c90c480e-e513-4db0-b3e8-d53ed1a71453/agent/trajectory.jsonl) |
| 33 | completed | 1 | 680.54 | 2.27 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/27f08e81-43c8-47a0-a5c2-324b11fc114d/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/27f08e81-43c8-47a0-a5c2-324b11fc114d/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/27f08e81-43c8-47a0-a5c2-324b11fc114d/agent/trajectory.jsonl) |
| 34 | completed | 0 | 624.07 | 1.03 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/6125a963-a53a-4c47-907f-74f294d93d15/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/6125a963-a53a-4c47-907f-74f294d93d15/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/6125a963-a53a-4c47-907f-74f294d93d15/agent/trajectory.jsonl) |
| 35 | completed | 1 | 614.96 | 1.18 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/7e92583a-f87d-4427-8f6f-450c30b5db26/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/7e92583a-f87d-4427-8f6f-450c30b5db26/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/7e92583a-f87d-4427-8f6f-450c30b5db26/agent/trajectory.jsonl) |
| 36 | completed | 0 | 1099.03 | 1.16 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/897ba6cc-6bcc-4c94-981f-5dc1e92dcf71/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/897ba6cc-6bcc-4c94-981f-5dc1e92dcf71/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/897ba6cc-6bcc-4c94-981f-5dc1e92dcf71/agent/trajectory.jsonl) |
| 37 | completed | 1 | 229.59 | 1.39 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/6b718374-8ed9-41c5-ac5c-393f4cea8b2f/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/6b718374-8ed9-41c5-ac5c-393f4cea8b2f/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/6b718374-8ed9-41c5-ac5c-393f4cea8b2f/agent/trajectory.jsonl) |
| 38 | completed | 0 | 1588.27 | 1.08 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/772d8694-3071-412e-bfe9-3924cc822769/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/772d8694-3071-412e-bfe9-3924cc822769/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/772d8694-3071-412e-bfe9-3924cc822769/agent/trajectory.jsonl) |
| 39 | completed | 1 | 413.05 | 1.21 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/8a0ef529-32e3-4852-949a-c8cba523d76c/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/8a0ef529-32e3-4852-949a-c8cba523d76c/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/8a0ef529-32e3-4852-949a-c8cba523d76c/agent/trajectory.jsonl) |
| 40 | completed | 0 | 369.97 | 1.25 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/fbcad7d4-c791-40ac-83ab-d4193b151a7d/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/fbcad7d4-c791-40ac-83ab-d4193b151a7d/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/fbcad7d4-c791-40ac-83ab-d4193b151a7d/agent/trajectory.jsonl) |
| 41 | completed | 1 | 553.74 | 1.08 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/5a3935d6-7d3a-4890-b43f-ec3957418ebd/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/5a3935d6-7d3a-4890-b43f-ec3957418ebd/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/5a3935d6-7d3a-4890-b43f-ec3957418ebd/agent/trajectory.jsonl) |
| 42 | completed | 0 | 745.58 | 1.32 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/21f135be-e80d-4fc6-96ed-175cb171b0de/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/21f135be-e80d-4fc6-96ed-175cb171b0de/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/21f135be-e80d-4fc6-96ed-175cb171b0de/agent/trajectory.jsonl) |
| 43 | completed | 0 | 844.17 | 1.11 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/9dc97c01-840d-4d3d-9fac-7d90102fb9ac/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/9dc97c01-840d-4d3d-9fac-7d90102fb9ac/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/9dc97c01-840d-4d3d-9fac-7d90102fb9ac/agent/trajectory.jsonl) |
| 44 | completed | 0 | 522.86 | 1.32 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/b2d80671-a8b5-4bbf-9e82-1ed45926f6a5/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/b2d80671-a8b5-4bbf-9e82-1ed45926f6a5/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/b2d80671-a8b5-4bbf-9e82-1ed45926f6a5/agent/trajectory.jsonl) |
| 45 | completed | 1 | 939.11 | 1.36 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/061568ae-41a6-4a6a-be2a-c49c0ba7f490/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/061568ae-41a6-4a6a-be2a-c49c0ba7f490/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/061568ae-41a6-4a6a-be2a-c49c0ba7f490/agent/trajectory.jsonl) |
| 46 | completed | 1 | 1595.52 | 1.29 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/a5250817-9a25-4b5d-aaff-df3bf59e2e83/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/a5250817-9a25-4b5d-aaff-df3bf59e2e83/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/a5250817-9a25-4b5d-aaff-df3bf59e2e83/agent/trajectory.jsonl) |
| 47 | completed | 0 | 848.62 | 1.28 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/02b94d02-54e9-4a37-99e4-6faefdf3f0bb/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/02b94d02-54e9-4a37-99e4-6faefdf3f0bb/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/02b94d02-54e9-4a37-99e4-6faefdf3f0bb/agent/trajectory.jsonl) |
| 48 | completed | 1 | 232.12 | 1.09 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/590e762d-863d-4983-90ea-e549d32b43c2/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/590e762d-863d-4983-90ea-e549d32b43c2/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/590e762d-863d-4983-90ea-e549d32b43c2/agent/trajectory.jsonl) |
| 49 | completed | 1 | 245.13 | 1.07 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/0378f468-a4d9-4e63-80e5-6b9224502228/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/0378f468-a4d9-4e63-80e5-6b9224502228/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/0378f468-a4d9-4e63-80e5-6b9224502228/agent/trajectory.jsonl) |
| 50 | completed | 0 | 1552.67 | 1.27 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/9b653ba2-2029-44b2-8de9-6eab41d9e622/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/9b653ba2-2029-44b2-8de9-6eab41d9e622/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/9b653ba2-2029-44b2-8de9-6eab41d9e622/agent/trajectory.jsonl) |
| 51 | completed | 0 | 1261.94 | 1.07 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/ca963a09-7688-47ab-92ee-7d02a8fbb997/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/ca963a09-7688-47ab-92ee-7d02a8fbb997/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/ca963a09-7688-47ab-92ee-7d02a8fbb997/agent/trajectory.jsonl) |
| 52 | completed | 0 | 839.02 | 1.74 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/da329dcc-5acf-4175-80ec-8c4b14de6cec/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/da329dcc-5acf-4175-80ec-8c4b14de6cec/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/da329dcc-5acf-4175-80ec-8c4b14de6cec/agent/trajectory.jsonl) |
| 53 | completed | 1 | 953.25 | 1.06 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/9e523f16-a08a-452a-8c43-c78d78f893cd/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/9e523f16-a08a-452a-8c43-c78d78f893cd/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/9e523f16-a08a-452a-8c43-c78d78f893cd/agent/trajectory.jsonl) |
| 54 | completed | 1 | 446.99 | 1.00 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/53496fd5-855a-43e1-a5c4-9de17f78d424/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/53496fd5-855a-43e1-a5c4-9de17f78d424/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/53496fd5-855a-43e1-a5c4-9de17f78d424/agent/trajectory.jsonl) |
| 55 | completed | 1 | 672.89 | 1.00 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/cf5f70d4-633c-4271-b83d-86cab141f12a/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/cf5f70d4-633c-4271-b83d-86cab141f12a/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/cf5f70d4-633c-4271-b83d-86cab141f12a/agent/trajectory.jsonl) |
| 56 | completed | 1 | 979.99 | 1.02 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/ce1b213f-0aa8-4717-bb36-f90e3ea057c3/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/ce1b213f-0aa8-4717-bb36-f90e3ea057c3/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/ce1b213f-0aa8-4717-bb36-f90e3ea057c3/agent/trajectory.jsonl) |
| 57 | completed | 0 | 1037.50 | 0.99 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/fec76fdf-524e-49aa-a37f-22643feed5b3/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/fec76fdf-524e-49aa-a37f-22643feed5b3/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/fec76fdf-524e-49aa-a37f-22643feed5b3/agent/trajectory.jsonl) |
| 58 | completed | 0 | 808.40 | 1.06 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/0d8dc677-7b35-4bfd-9d58-28b51a87bb3e/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/0d8dc677-7b35-4bfd-9d58-28b51a87bb3e/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/0d8dc677-7b35-4bfd-9d58-28b51a87bb3e/agent/trajectory.jsonl) |
| 59 | invalid | — | 731.52 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/cd538ac5-d8f9-4505-9221-993fbe7e74cd/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/cd538ac5-d8f9-4505-9221-993fbe7e74cd/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/cd538ac5-d8f9-4505-9221-993fbe7e74cd/agent/trajectory.jsonl) |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

