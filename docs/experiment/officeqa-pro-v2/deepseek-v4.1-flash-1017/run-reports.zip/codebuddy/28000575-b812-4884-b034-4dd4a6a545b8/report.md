<!-- snapshotDigest: f7b37a907a5d0f5b0a8648b2e4d65577d98ebca595ee19e5139c94c06d9f1f5e -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 26.67%（20/75）**

Run: 28000575-b812-4884-b034-4dd4a6a545b8 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T13:13:00.702Z / 2026-11-13T23:02:53.714Z |
| 总耗时 | 9 小时 29 分 49 秒 |
| 答对 / 答错 / 解题超时 | 20 / 16 / 1 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 2 / 0 |

已选择 76 题；已保存 38 条记录；待运行 38 题。
有效评分覆盖率：37/76（48.68%）。
执行失败 1；超时 1；取消 0；不支持 0。
Agent 解题超时 1（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 76 |
| 计分题数 | 75 |
| 正常评分题数 | 36 |
| 答对题数 | 20 |
| 无效评测 | 1 |
| 待运行 | 38 |
| 正确率 | 26.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 29 分 49 秒 |
| 环境准备耗时 | 9 小时 49 分 40 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 14 分 59 秒 | 46 秒 | 1 小时 0 分 5 秒 | 38 |
| 任务准备 | 0.46 毫秒 | 0.24 毫秒 | 1.46 毫秒 | 38 |
| 环境启动 | 4 秒 | 3 秒 | 12 秒 | 38 |
| 解题 | 14 分 48 秒 | 37 秒 | 59 分 57 秒 | 38 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 36 |
| 证据收集 | 867.81 毫秒 | 526.83 毫秒 | 3 秒 | 38 |
| 资源清理 | 3 秒 | 2 秒 | 8 秒 | 38 |
| 评分 | 1 秒 | 1 秒 | 4 秒 | 36 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 21f51862-c1cf-4767-8131-57facfc7939c | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 251,747,387 | 552,192 | 252,299,579 | 36 / 76 | — |
| 运行累计 | 251,747,387 | 552,192 | 252,299,579 | 36 / 38 | 2 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 14 | completed | 1 | 1297.14 | 1.07 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/37e45438-0fc5-4265-920b-979436207093/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/37e45438-0fc5-4265-920b-979436207093/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/37e45438-0fc5-4265-920b-979436207093/agent/trajectory.jsonl) |
| 15 | completed | 0 | 1095.09 | 1.21 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/dbe1ce7e-7756-498c-90f4-1b2604c795c4/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/dbe1ce7e-7756-498c-90f4-1b2604c795c4/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/dbe1ce7e-7756-498c-90f4-1b2604c795c4/agent/trajectory.jsonl) |
| 16 | completed | 1 | 1013.04 | 1.11 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/f0a7d570-0be2-4641-a3ae-790bbc566daf/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/f0a7d570-0be2-4641-a3ae-790bbc566daf/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/f0a7d570-0be2-4641-a3ae-790bbc566daf/agent/trajectory.jsonl) |
| 17 | completed | 1 | 907.39 | 1.36 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/c45f2a35-a2f7-4fcb-a232-7548fabbde23/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/c45f2a35-a2f7-4fcb-a232-7548fabbde23/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/c45f2a35-a2f7-4fcb-a232-7548fabbde23/agent/trajectory.jsonl) |
| 18 | completed | 1 | 1684.62 | 1.32 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/757d05a8-4bc4-4f35-94dd-66d70cefd8a5/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/757d05a8-4bc4-4f35-94dd-66d70cefd8a5/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/757d05a8-4bc4-4f35-94dd-66d70cefd8a5/agent/trajectory.jsonl) |
| 19 | completed | 1 | 496.87 | 1.24 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/fe34c36f-da3a-4962-bf8f-95c0d19aedf8/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/fe34c36f-da3a-4962-bf8f-95c0d19aedf8/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/fe34c36f-da3a-4962-bf8f-95c0d19aedf8/agent/trajectory.jsonl) |
| 20 | completed | 1 | 809.96 | 1.02 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/1c701707-da98-43b0-8ecc-ddc5d32a4aa2/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/1c701707-da98-43b0-8ecc-ddc5d32a4aa2/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/1c701707-da98-43b0-8ecc-ddc5d32a4aa2/agent/trajectory.jsonl) |
| 21 | completed | 1 | 291.82 | 1.08 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/ba181cff-229f-4a6a-882d-230a5ad86cd1/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/ba181cff-229f-4a6a-882d-230a5ad86cd1/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/ba181cff-229f-4a6a-882d-230a5ad86cd1/agent/trajectory.jsonl) |
| 22 | completed | 1 | 95.43 | 1.07 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/f7dbc219-b1dd-4d87-bc0c-8b67f3cf4067/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/f7dbc219-b1dd-4d87-bc0c-8b67f3cf4067/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/f7dbc219-b1dd-4d87-bc0c-8b67f3cf4067/agent/trajectory.jsonl) |
| 23 | completed | 1 | 312.23 | 4.16 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/6409718b-80b3-4ea7-a531-0a88b415949d/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/6409718b-80b3-4ea7-a531-0a88b415949d/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/6409718b-80b3-4ea7-a531-0a88b415949d/agent/trajectory.jsonl) |
| 24 | completed | 0 | 821.66 | 1.17 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/ec87b508-61d6-4161-88d7-313e0792ad22/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/ec87b508-61d6-4161-88d7-313e0792ad22/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/ec87b508-61d6-4161-88d7-313e0792ad22/agent/trajectory.jsonl) |
| 25 | completed | 0 | 440.23 | 1.73 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/ddb4be38-c491-4b28-b373-19a604827018/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/ddb4be38-c491-4b28-b373-19a604827018/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/ddb4be38-c491-4b28-b373-19a604827018/agent/trajectory.jsonl) |
| 26 | completed | 1 | 821.02 | 1.28 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/f17d388e-c264-4276-bf97-27894df195b0/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/f17d388e-c264-4276-bf97-27894df195b0/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/f17d388e-c264-4276-bf97-27894df195b0/agent/trajectory.jsonl) |
| 27 | completed | 1 | 915.33 | 1.04 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/059143f4-4dc8-4fbe-b4ea-31d97dbaf41b/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/059143f4-4dc8-4fbe-b4ea-31d97dbaf41b/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/059143f4-4dc8-4fbe-b4ea-31d97dbaf41b/agent/trajectory.jsonl) |
| 28 | completed | 1 | 733.18 | 1.55 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/844fdb99-2cf4-40cc-a50e-b9b2effc43c3/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/844fdb99-2cf4-40cc-a50e-b9b2effc43c3/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/844fdb99-2cf4-40cc-a50e-b9b2effc43c3/agent/trajectory.jsonl) |
| 29 | completed | 0 | 1592.37 | 1.21 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/2e43cdfb-e5ec-46f3-aa0a-bceb1dad711d/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/2e43cdfb-e5ec-46f3-aa0a-bceb1dad711d/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/2e43cdfb-e5ec-46f3-aa0a-bceb1dad711d/agent/trajectory.jsonl) |
| 30 | completed | 0 | 733.47 | 1.20 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/5d4dd148-98be-4a9f-9514-a30f207dd660/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/5d4dd148-98be-4a9f-9514-a30f207dd660/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/5d4dd148-98be-4a9f-9514-a30f207dd660/agent/trajectory.jsonl) |
| 31 | completed | 1 | 83.31 | 1.02 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/ecbe1a6d-4e0e-4948-8fb7-3a845f62e7b3/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/ecbe1a6d-4e0e-4948-8fb7-3a845f62e7b3/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/ecbe1a6d-4e0e-4948-8fb7-3a845f62e7b3/agent/trajectory.jsonl) |
| 32 | completed | 0 | 366.34 | 1.36 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/5c75c2d7-8720-42cc-80f4-50d3fcaf89b6/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/5c75c2d7-8720-42cc-80f4-50d3fcaf89b6/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/5c75c2d7-8720-42cc-80f4-50d3fcaf89b6/agent/trajectory.jsonl) |
| 33 | completed | 1 | 393.54 | 1.42 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/9ff4bd97-0cf0-42e6-ab5e-03e25cbfc751/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/9ff4bd97-0cf0-42e6-ab5e-03e25cbfc751/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/9ff4bd97-0cf0-42e6-ab5e-03e25cbfc751/agent/trajectory.jsonl) |
| 34 | completed | 0 | 854.83 | 1.43 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/0861626f-7ada-4291-b37f-4ee9e0b56fc4/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/0861626f-7ada-4291-b37f-4ee9e0b56fc4/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/0861626f-7ada-4291-b37f-4ee9e0b56fc4/agent/trajectory.jsonl) |
| 35 | completed | 0 | 199.85 | 1.26 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/9d3a40b0-ac78-471b-bbbf-9f2d51d360d2/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/9d3a40b0-ac78-471b-bbbf-9f2d51d360d2/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/9d3a40b0-ac78-471b-bbbf-9f2d51d360d2/agent/trajectory.jsonl) |
| 36 | completed | 0 | 3370.91 | 1.19 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/7e3f598c-96ab-4b88-896c-2c2a7ffb5e85/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/7e3f598c-96ab-4b88-896c-2c2a7ffb5e85/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/7e3f598c-96ab-4b88-896c-2c2a7ffb5e85/agent/trajectory.jsonl) |
| 37 | completed | 1 | 156.04 | 1.20 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/c759098d-ab6c-42d7-aea0-59fb6c148921/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/c759098d-ab6c-42d7-aea0-59fb6c148921/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/c759098d-ab6c-42d7-aea0-59fb6c148921/agent/trajectory.jsonl) |
| 38 | completed | 0 | 1732.97 | 1.12 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/c8be008e-8f9a-4225-aa44-1082cc18d7c4/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/c8be008e-8f9a-4225-aa44-1082cc18d7c4/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/c8be008e-8f9a-4225-aa44-1082cc18d7c4/agent/trajectory.jsonl) |
| 39 | completed | 1 | 3089.99 | 1.28 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/a29131b4-7276-4da2-b979-16b2c4825e25/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/a29131b4-7276-4da2-b979-16b2c4825e25/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/a29131b4-7276-4da2-b979-16b2c4825e25/agent/trajectory.jsonl) |
| 40 | completed | 0 | 164.19 | 1.14 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/c4a94738-4b01-407c-8dab-26ba4dd0dbf3/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/c4a94738-4b01-407c-8dab-26ba4dd0dbf3/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/c4a94738-4b01-407c-8dab-26ba4dd0dbf3/agent/trajectory.jsonl) |
| 41 | completed | 1 | 373.41 | 1.12 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/1e071eeb-7eb3-4e42-95f3-b7818a8d093b/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/1e071eeb-7eb3-4e42-95f3-b7818a8d093b/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/1e071eeb-7eb3-4e42-95f3-b7818a8d093b/agent/trajectory.jsonl) |
| 42 | completed | 0 | 235.02 | 1.24 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/6044851c-7a20-4f23-8c5a-a5b0739e8b60/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/6044851c-7a20-4f23-8c5a-a5b0739e8b60/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/6044851c-7a20-4f23-8c5a-a5b0739e8b60/agent/trajectory.jsonl) |
| 43 | completed | 0 | 359.96 | 1.25 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/7eedb685-45e9-4b66-92a8-e463208b945c/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/7eedb685-45e9-4b66-92a8-e463208b945c/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/7eedb685-45e9-4b66-92a8-e463208b945c/agent/trajectory.jsonl) |
| 44 | completed | 1 | 405.63 | 1.07 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/ec0965a2-f87f-4841-a749-83544c907da5/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/ec0965a2-f87f-4841-a749-83544c907da5/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/ec0965a2-f87f-4841-a749-83544c907da5/agent/trajectory.jsonl) |
| 45 | completed | 0 | 300.70 | 1.06 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/f3ae0a61-339f-4b3d-ab45-b0299e18a39d/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/f3ae0a61-339f-4b3d-ab45-b0299e18a39d/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/f3ae0a61-339f-4b3d-ab45-b0299e18a39d/agent/trajectory.jsonl) |
| 46 | timeout (agent) | 0 | 3597.36 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/533ae204-cc94-4211-a9ab-cce7a70c7f34/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/533ae204-cc94-4211-a9ab-cce7a70c7f34/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/533ae204-cc94-4211-a9ab-cce7a70c7f34/agent/trajectory.jsonl) |
| 47 | completed | 0 | 132.78 | 1.07 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/a9029027-2f74-4274-8ac2-a6944bc1f5b4/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/a9029027-2f74-4274-8ac2-a6944bc1f5b4/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/a9029027-2f74-4274-8ac2-a6944bc1f5b4/agent/trajectory.jsonl) |
| 48 | completed | 1 | 117.52 | 1.11 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/be24a8cb-0441-424f-885e-fdcaacd179c3/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/be24a8cb-0441-424f-885e-fdcaacd179c3/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/be24a8cb-0441-424f-885e-fdcaacd179c3/agent/trajectory.jsonl) |
| 49 | completed | 1 | 36.96 | 1.08 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/4865e851-bf0c-4f33-ab34-38da1260e464/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/4865e851-bf0c-4f33-ab34-38da1260e464/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/4865e851-bf0c-4f33-ab34-38da1260e464/agent/trajectory.jsonl) |
| 50 | completed | 0 | 756.21 | 1.03 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/2bdaebf6-70c1-4217-9dad-baa5281b3a13/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/2bdaebf6-70c1-4217-9dad-baa5281b3a13/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/2bdaebf6-70c1-4217-9dad-baa5281b3a13/agent/trajectory.jsonl) |
| 51 | invalid | — | 2961.38 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/8f55eb02-c3f6-4b1a-a2d1-e61f74e56bfb/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/8f55eb02-c3f6-4b1a-a2d1-e61f74e56bfb/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/8f55eb02-c3f6-4b1a-a2d1-e61f74e56bfb/agent/trajectory.jsonl) |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 2；错误记录 3（主流程 2；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 46 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

