<!-- snapshotDigest: 2144bc8d3dcde2894c76fac0d921705c2b4157075323fa16f969dc059a18ddfc -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 35.90%（14/39）**

Run: 39060452-afdb-4bce-bd94-c1b1b389ff5e · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-14T02:32:47.340Z / 2026-11-14T18:26:53.352Z |
| 总耗时 | 15 小时 21 分 30 秒 |
| 答对 / 答错 / 解题超时 | 14 / 20 / 5 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 5 / 0 |

已选择 39 题；已保存 39 条记录；待运行 0 题。
有效评分覆盖率：39/39（100.00%）。
执行失败 0；超时 5；取消 0；不支持 0。
Agent 解题超时 5（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 39 |
| 计分题数 | 39 |
| 正常评分题数 | 34 |
| 答对题数 | 14 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 35.90% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 15 小时 21 分 30 秒 |
| 环境准备耗时 | 12 小时 6 分 29 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 23 分 37 秒 | 2 分 15 秒 | 1 小时 0 分 7 秒 | 39 |
| 任务准备 | 0.4 毫秒 | 0.23 毫秒 | 0.97 毫秒 | 39 |
| 环境启动 | 6 秒 | 5 秒 | 8 秒 | 39 |
| 解题 | 23 分 23 秒 | 2 分 3 秒 | 59 分 55 秒 | 39 |
| 证据收集 | 1 秒 | 968.67 毫秒 | 4 秒 | 39 |
| 资源清理 | 3 秒 | 2 秒 | 4 秒 | 39 |
| 产物传输 | 2 秒 | 1 秒 | 2 秒 | 34 |
| 评分 | 1 秒 | 1 秒 | 2 秒 | 34 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 4e0d1538-96af-48e2-9d12-d6f105d33521 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 396,598,141 | 621,265 | 397,219,406 | 34 / 39 | — |
| 运行累计 | 396,598,141 | 621,265 | 397,219,406 | 34 / 39 | 5 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 51 | timeout (agent) | 0 | 3593.60 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/202fd616-92b5-4d19-985a-ef193a5b5de3/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/202fd616-92b5-4d19-985a-ef193a5b5de3/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/202fd616-92b5-4d19-985a-ef193a5b5de3/agent/trajectory.jsonl) |
| 52 | completed | 0 | 409.14 | 1.64 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/312f6045-64ad-4d67-956c-6949fa284323/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/312f6045-64ad-4d67-956c-6949fa284323/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/312f6045-64ad-4d67-956c-6949fa284323/agent/trajectory.jsonl) |
| 53 | completed | 1 | 2262.47 | 1.38 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/bef51f1a-b3a2-473b-9401-7fa58e9e98dc/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/bef51f1a-b3a2-473b-9401-7fa58e9e98dc/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/bef51f1a-b3a2-473b-9401-7fa58e9e98dc/agent/trajectory.jsonl) |
| 54 | completed | 1 | 1238.72 | 1.38 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/b5e21646-9a7b-4d33-be03-50af80165258/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/b5e21646-9a7b-4d33-be03-50af80165258/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/b5e21646-9a7b-4d33-be03-50af80165258/agent/trajectory.jsonl) |
| 55 | completed | 1 | 1283.88 | 1.40 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/a22f50c8-9ac3-4666-a1bd-a7d065f5272e/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/a22f50c8-9ac3-4666-a1bd-a7d065f5272e/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/a22f50c8-9ac3-4666-a1bd-a7d065f5272e/agent/trajectory.jsonl) |
| 56 | completed | 1 | 294.48 | 1.49 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/d7b7ef8e-4205-4f4e-8e23-3f446cf415a3/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/d7b7ef8e-4205-4f4e-8e23-3f446cf415a3/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/d7b7ef8e-4205-4f4e-8e23-3f446cf415a3/agent/trajectory.jsonl) |
| 57 | completed | 0 | 2346.31 | 1.25 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/b590ddb5-65ee-4877-8e39-bdf52c20cc1d/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/b590ddb5-65ee-4877-8e39-bdf52c20cc1d/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/b590ddb5-65ee-4877-8e39-bdf52c20cc1d/agent/trajectory.jsonl) |
| 58 | completed | 0 | 3454.98 | 1.22 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/85fedf45-9ce5-41d9-9f4c-57556eb429a7/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/85fedf45-9ce5-41d9-9f4c-57556eb429a7/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/85fedf45-9ce5-41d9-9f4c-57556eb429a7/agent/trajectory.jsonl) |
| 59 | completed | 0 | 340.18 | 1.23 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/14a904cb-1fca-4364-9a1c-c414d430f08e/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/14a904cb-1fca-4364-9a1c-c414d430f08e/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/14a904cb-1fca-4364-9a1c-c414d430f08e/agent/trajectory.jsonl) |
| 60 | completed | 1 | 697.92 | 1.32 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/bcf862b6-a985-4346-ac60-557362be5d07/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/bcf862b6-a985-4346-ac60-557362be5d07/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/bcf862b6-a985-4346-ac60-557362be5d07/agent/trajectory.jsonl) |
| 61 | completed | 0 | 1167.28 | 1.27 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/b7d11bb5-d77c-48c2-ae08-49adc41a63bb/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/b7d11bb5-d77c-48c2-ae08-49adc41a63bb/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/b7d11bb5-d77c-48c2-ae08-49adc41a63bb/agent/trajectory.jsonl) |
| 62 | completed | 0 | 2395.80 | 1.32 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/06947992-e830-4088-b390-6e87dd3e8ff1/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/06947992-e830-4088-b390-6e87dd3e8ff1/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/06947992-e830-4088-b390-6e87dd3e8ff1/agent/trajectory.jsonl) |
| 63 | completed | 1 | 306.78 | 1.28 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/a00fd6cb-23da-49c1-b9b9-5ff405497001/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/a00fd6cb-23da-49c1-b9b9-5ff405497001/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/a00fd6cb-23da-49c1-b9b9-5ff405497001/agent/trajectory.jsonl) |
| 64 | completed | 1 | 667.51 | 1.25 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/348bdd0c-9a9a-4d81-8047-0e7ed1adaf4a/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/348bdd0c-9a9a-4d81-8047-0e7ed1adaf4a/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/348bdd0c-9a9a-4d81-8047-0e7ed1adaf4a/agent/trajectory.jsonl) |
| 65 | completed | 0 | 705.90 | 1.35 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/9403049e-26c5-4182-b4f9-5dca720deb9d/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/9403049e-26c5-4182-b4f9-5dca720deb9d/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/9403049e-26c5-4182-b4f9-5dca720deb9d/agent/trajectory.jsonl) |
| 66 | completed | 0 | 221.96 | 1.17 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/0ef590c5-8f67-4610-b549-241537f90428/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/0ef590c5-8f67-4610-b549-241537f90428/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/0ef590c5-8f67-4610-b549-241537f90428/agent/trajectory.jsonl) |
| 67 | completed | 1 | 1417.19 | 1.30 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/d46d0002-1697-4418-9cbf-e14204f126c4/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/d46d0002-1697-4418-9cbf-e14204f126c4/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/d46d0002-1697-4418-9cbf-e14204f126c4/agent/trajectory.jsonl) |
| 68 | completed | 1 | 615.56 | 1.25 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/c20fbbcf-15eb-4bb7-8a1b-c9bdd8c9792f/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/c20fbbcf-15eb-4bb7-8a1b-c9bdd8c9792f/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/c20fbbcf-15eb-4bb7-8a1b-c9bdd8c9792f/agent/trajectory.jsonl) |
| 69 | completed | 1 | 319.84 | 1.22 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/e9675b97-fd02-429b-82ab-62fde9022243/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/e9675b97-fd02-429b-82ab-62fde9022243/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/e9675b97-fd02-429b-82ab-62fde9022243/agent/trajectory.jsonl) |
| 70 | timeout (agent) | 0 | 3594.61 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/eca47945-3d1b-4034-a304-35fb45ddcfd5/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/eca47945-3d1b-4034-a304-35fb45ddcfd5/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/eca47945-3d1b-4034-a304-35fb45ddcfd5/agent/trajectory.jsonl) |
| 71 | timeout (agent) | 0 | 3594.82 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/78fde9a0-d4e1-4934-8380-6d5c96811bab/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/78fde9a0-d4e1-4934-8380-6d5c96811bab/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/78fde9a0-d4e1-4934-8380-6d5c96811bab/agent/trajectory.jsonl) |
| 72 | completed | 0 | 1230.44 | 1.92 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/4985bd28-3a8c-4ab6-81f5-d94bb85503c7/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/4985bd28-3a8c-4ab6-81f5-d94bb85503c7/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/4985bd28-3a8c-4ab6-81f5-d94bb85503c7/agent/trajectory.jsonl) |
| 73 | completed | 1 | 1956.47 | 1.33 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/d5763844-d7cc-4835-b2ab-e0052a66b448/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/d5763844-d7cc-4835-b2ab-e0052a66b448/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/d5763844-d7cc-4835-b2ab-e0052a66b448/agent/trajectory.jsonl) |
| 74 | completed | 0 | 809.64 | 1.19 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/2f756092-dcb4-44b3-bace-61d1b9315268/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/2f756092-dcb4-44b3-bace-61d1b9315268/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/2f756092-dcb4-44b3-bace-61d1b9315268/agent/trajectory.jsonl) |
| 75 | timeout (agent) | 0 | 3594.67 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/584ce12b-388d-4a83-9427-59dce284e7b7/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/584ce12b-388d-4a83-9427-59dce284e7b7/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/584ce12b-388d-4a83-9427-59dce284e7b7/agent/trajectory.jsonl) |
| 76 | completed | 0 | 122.84 | 1.24 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/be09eba1-795f-465e-9355-986750379d1e/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/be09eba1-795f-465e-9355-986750379d1e/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/be09eba1-795f-465e-9355-986750379d1e/agent/trajectory.jsonl) |
| 77 | completed | 0 | 2087.68 | 1.35 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/99e63f75-ac99-4544-8bd0-aa971fe9c701/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/99e63f75-ac99-4544-8bd0-aa971fe9c701/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/99e63f75-ac99-4544-8bd0-aa971fe9c701/agent/trajectory.jsonl) |
| 78 | completed | 1 | 284.54 | 1.19 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/6529a5df-0fee-4303-91c2-e7ab8cc61aed/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/6529a5df-0fee-4303-91c2-e7ab8cc61aed/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/6529a5df-0fee-4303-91c2-e7ab8cc61aed/agent/trajectory.jsonl) |
| 79 | completed | 0 | 694.07 | 1.24 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/b6413bc3-dae8-41c1-8756-e210ad617fa5/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/b6413bc3-dae8-41c1-8756-e210ad617fa5/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/b6413bc3-dae8-41c1-8756-e210ad617fa5/agent/trajectory.jsonl) |
| 80 | completed | 0 | 1695.87 | 1.32 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/731ae7ad-e31b-4d16-afdb-12f327c4276c/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/731ae7ad-e31b-4d16-afdb-12f327c4276c/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/731ae7ad-e31b-4d16-afdb-12f327c4276c/agent/trajectory.jsonl) |
| 81 | completed | 0 | 1213.85 | 1.38 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/26de9f02-d319-4e58-b878-b4f88fba3628/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/26de9f02-d319-4e58-b878-b4f88fba3628/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/26de9f02-d319-4e58-b878-b4f88fba3628/agent/trajectory.jsonl) |
| 82 | completed | 0 | 3234.64 | 1.67 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/1683f7c9-7b2f-47ec-9beb-b0035b6e8a05/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/1683f7c9-7b2f-47ec-9beb-b0035b6e8a05/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/1683f7c9-7b2f-47ec-9beb-b0035b6e8a05/agent/trajectory.jsonl) |
| 83 | completed | 0 | 215.43 | 1.62 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/ad5197ea-0f7c-4b21-9d69-458e52daa3a1/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/ad5197ea-0f7c-4b21-9d69-458e52daa3a1/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/ad5197ea-0f7c-4b21-9d69-458e52daa3a1/agent/trajectory.jsonl) |
| 84 | completed | 1 | 1446.21 | 1.47 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/493f9eb6-66a7-4ad8-8033-52523539ce09/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/493f9eb6-66a7-4ad8-8033-52523539ce09/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/493f9eb6-66a7-4ad8-8033-52523539ce09/agent/trajectory.jsonl) |
| 85 | timeout (agent) | 0 | 3593.81 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/3382feba-7ab9-4ae2-b984-b7056a02ad66/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/3382feba-7ab9-4ae2-b984-b7056a02ad66/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/3382feba-7ab9-4ae2-b984-b7056a02ad66/agent/trajectory.jsonl) |
| 86 | completed | 0 | 612.16 | 1.29 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/0227b2d6-75cf-425e-bb59-fb7633caf06f/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/0227b2d6-75cf-425e-bb59-fb7633caf06f/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/0227b2d6-75cf-425e-bb59-fb7633caf06f/agent/trajectory.jsonl) |
| 87 | completed | 1 | 272.28 | 1.37 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/c91f66b0-bd2b-48a3-98fa-e7a32a570fc0/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/c91f66b0-bd2b-48a3-98fa-e7a32a570fc0/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/c91f66b0-bd2b-48a3-98fa-e7a32a570fc0/agent/trajectory.jsonl) |
| 88 | completed | 0 | 146.02 | 1.32 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/5b733879-65a9-41ca-89c2-ff2652349b16/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/5b733879-65a9-41ca-89c2-ff2652349b16/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/5b733879-65a9-41ca-89c2-ff2652349b16/agent/trajectory.jsonl) |
| 89 | completed | 0 | 594.12 | 1.33 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/a7300ec0-5e6d-4cce-8eef-2ea7d3de5fd5/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/a7300ec0-5e6d-4cce-8eef-2ea7d3de5fd5/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/a7300ec0-5e6d-4cce-8eef-2ea7d3de5fd5/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 5；错误记录 5（主流程 5；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 5 | 5 |

## 警告

警告涉及 5 个任务，共 5 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 51 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 70 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 71 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 75 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 85 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

