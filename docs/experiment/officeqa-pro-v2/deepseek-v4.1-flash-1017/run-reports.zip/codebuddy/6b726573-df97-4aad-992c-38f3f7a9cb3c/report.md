<!-- snapshotDigest: 27ee9c114b73972d169172c224589f71edf35e51840694580956b200f443fb71 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 13.48%（12/89）**

Run: 6b726573-df97-4aad-992c-38f3f7a9cb3c · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T10:15:41.952Z / 2026-11-13T12:18:05.999Z |
| 总耗时 | 1 小时 58 分 21 秒 |
| 答对 / 答错 / 解题超时 | 12 / 1 / 1 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 2 / 0 |

已选择 90 题；已保存 15 条记录；待运行 75 题。
有效评分覆盖率：14/90（15.56%）。
执行失败 1；超时 1；取消 0；不支持 0。
Agent 解题超时 1（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 13 |
| 答对题数 | 12 |
| 无效评测 | 1 |
| 待运行 | 75 |
| 正确率 | 13.48% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 58 分 21 秒 |
| 环境准备耗时 | 2 小时 2 分 6 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 7 分 51 秒 | 38 秒 | 1 小时 0 分 5 秒 | 15 |
| 任务准备 | 0.51 毫秒 | 0.33 毫秒 | 0.74 毫秒 | 15 |
| 环境启动 | 3 秒 | 3 秒 | 4 秒 | 15 |
| 解题 | 7 分 42 秒 | 30 秒 | 59 分 57 秒 | 15 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 13 |
| 证据收集 | 963.35 毫秒 | 557.43 毫秒 | 3 秒 | 15 |
| 资源清理 | 3 秒 | 2 秒 | 3 秒 | 15 |
| 评分 | 1 秒 | 910.22 毫秒 | 1 秒 | 13 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| a631320e-b65d-4c8f-aec6-c90cee7c83fb | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 16,509,374 | 383,355 | 16,892,729 | 13 / 90 | — |
| 运行累计 | 16,509,374 | 383,355 | 16,892,729 | 13 / 15 | 2 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 404.98 | 1.36 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/a71fa128-a8e7-43f5-a97a-8dd661453ac0/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/a71fa128-a8e7-43f5-a97a-8dd661453ac0/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/a71fa128-a8e7-43f5-a97a-8dd661453ac0/agent/trajectory.jsonl) |
| 1 | completed | 1 | 79.29 | 1.24 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/1dcacf68-fb3b-40b1-ab00-f0176152c90f/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/1dcacf68-fb3b-40b1-ab00-f0176152c90f/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/1dcacf68-fb3b-40b1-ab00-f0176152c90f/agent/trajectory.jsonl) |
| 2 | completed | 1 | 279.44 | 0.96 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/b6be8816-f8fa-446a-acca-4e081fc77a91/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/b6be8816-f8fa-446a-acca-4e081fc77a91/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/b6be8816-f8fa-446a-acca-4e081fc77a91/agent/trajectory.jsonl) |
| 3 | completed | 1 | 196.91 | 0.91 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/f573f067-9f3a-4b82-b1bb-45bb1d4b05f2/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/f573f067-9f3a-4b82-b1bb-45bb1d4b05f2/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/f573f067-9f3a-4b82-b1bb-45bb1d4b05f2/agent/trajectory.jsonl) |
| 4 | completed | 1 | 30.00 | 0.99 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/e1a28fd1-a364-4970-8879-190df7a03b1e/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/e1a28fd1-a364-4970-8879-190df7a03b1e/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/e1a28fd1-a364-4970-8879-190df7a03b1e/agent/trajectory.jsonl) |
| 5 | completed | 1 | 61.06 | 1.42 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/45273385-362b-49f7-b8b2-cb3058db26df/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/45273385-362b-49f7-b8b2-cb3058db26df/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/45273385-362b-49f7-b8b2-cb3058db26df/agent/trajectory.jsonl) |
| 6 | completed | 1 | 182.12 | 1.00 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/b97cd3fa-a5b7-4a5f-a59d-869e094b28ce/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/b97cd3fa-a5b7-4a5f-a59d-869e094b28ce/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/b97cd3fa-a5b7-4a5f-a59d-869e094b28ce/agent/trajectory.jsonl) |
| 7 | completed | 1 | 80.81 | 1.12 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/6f70988e-af17-4b19-9398-ab6b5caa9a19/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/6f70988e-af17-4b19-9398-ab6b5caa9a19/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/6f70988e-af17-4b19-9398-ab6b5caa9a19/agent/trajectory.jsonl) |
| 8 | completed | 0 | 303.28 | 1.05 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/43246cb7-8efb-4fff-a3c9-41c0d953ea9d/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/43246cb7-8efb-4fff-a3c9-41c0d953ea9d/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/43246cb7-8efb-4fff-a3c9-41c0d953ea9d/agent/trajectory.jsonl) |
| 9 | completed | 1 | 42.35 | 1.04 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/eff80eb9-9b47-4afc-814f-0c7ffa507142/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/eff80eb9-9b47-4afc-814f-0c7ffa507142/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/eff80eb9-9b47-4afc-814f-0c7ffa507142/agent/trajectory.jsonl) |
| 10 | timeout (agent) | 0 | 3596.64 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/fa9c1771-e027-4787-b657-d69757a24c9b/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/fa9c1771-e027-4787-b657-d69757a24c9b/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/fa9c1771-e027-4787-b657-d69757a24c9b/agent/trajectory.jsonl) |
| 11 | completed | 1 | 280.57 | 1.22 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/cd802fa5-516b-4c1a-bd13-d1216c977b66/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/cd802fa5-516b-4c1a-bd13-d1216c977b66/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/cd802fa5-516b-4c1a-bd13-d1216c977b66/agent/trajectory.jsonl) |
| 12 | completed | 1 | 111.50 | 1.15 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/d147b794-459a-4df8-9ea7-0f22f33b95b0/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/d147b794-459a-4df8-9ea7-0f22f33b95b0/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/d147b794-459a-4df8-9ea7-0f22f33b95b0/agent/trajectory.jsonl) |
| 13 | completed | 1 | 825.54 | 1.00 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/b4214103-fcdc-4543-afd9-1f7a85372973/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/b4214103-fcdc-4543-afd9-1f7a85372973/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/b4214103-fcdc-4543-afd9-1f7a85372973/agent/trajectory.jsonl) |
| 14 | invalid | — | 456.74 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/794a4db5-4809-4c24-b8c1-66a666438543/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/794a4db5-4809-4c24-b8c1-66a666438543/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/794a4db5-4809-4c24-b8c1-66a666438543/agent/trajectory.jsonl) |
| 15 | pending | — | — | — | — | — | — |
| 16 | pending | — | — | — | — | — | — |
| 17 | pending | — | — | — | — | — | — |
| 18 | pending | — | — | — | — | — | — |
| 19 | pending | — | — | — | — | — | — |
| 20 | pending | — | — | — | — | — | — |
| 21 | pending | — | — | — | — | — | — |
| 22 | pending | — | — | — | — | — | — |
| 23 | pending | — | — | — | — | — | — |
| 24 | pending | — | — | — | — | — | — |
| 25 | pending | — | — | — | — | — | — |
| 26 | pending | — | — | — | — | — | — |
| 27 | pending | — | — | — | — | — | — |
| 28 | pending | — | — | — | — | — | — |
| 29 | pending | — | — | — | — | — | — |
| 30 | pending | — | — | — | — | — | — |
| 31 | pending | — | — | — | — | — | — |
| 32 | pending | — | — | — | — | — | — |
| 33 | pending | — | — | — | — | — | — |
| 34 | pending | — | — | — | — | — | — |
| 35 | pending | — | — | — | — | — | — |
| 36 | pending | — | — | — | — | — | — |
| 37 | pending | — | — | — | — | — | — |
| 38 | pending | — | — | — | — | — | — |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 2；错误记录 3（主流程 2；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 10 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

