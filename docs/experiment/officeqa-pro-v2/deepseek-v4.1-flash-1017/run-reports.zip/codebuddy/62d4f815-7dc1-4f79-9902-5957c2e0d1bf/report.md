<!-- snapshotDigest: b978328259eba7037111fb3e6bec5a9775f7c0d625f2870756b7a6f7aca30863 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 33.33%（2/6）**

Run: 62d4f815-7dc1-4f79-9902-5957c2e0d1bf · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-14T16:21:42.791Z / 2026-11-14T22:40:28.027Z |
| 总耗时 | 6 小时 5 分 18 秒 |
| 答对 / 答错 / 解题超时 | 2 / 4 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 6 题；已保存 6 条记录；待运行 0 题。
有效评分覆盖率：6/6（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 6 |
| 计分题数 | 6 |
| 正常评分题数 | 6 |
| 答对题数 | 2 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 33.33% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 6 小时 5 分 18 秒 |
| 环境准备耗时 | 1 分 25 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 小时 0 分 47 秒 | 19 分 13 秒 | 2 小时 0 分 16 秒 | 6 |
| 任务准备 | 0.41 毫秒 | 0.24 毫秒 | 0.8 毫秒 | 6 |
| 环境启动 | 5 秒 | 5 秒 | 7 秒 | 6 |
| 解题 | 1 小时 0 分 34 秒 | 19 分 1 秒 | 2 小时 0 分 0 秒 | 6 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 6 |
| 证据收集 | 1 秒 | 1 秒 | 1 秒 | 6 |
| 资源清理 | 3 秒 | 3 秒 | 4 秒 | 6 |
| 评分 | 1 秒 | 1 秒 | 1 秒 | 6 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 895a5be2-de4b-4fce-b54d-c3dc7054ebb3 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 226,786,385 | 181,046 | 226,967,431 | 5 / 6 | — |
| 运行累计 | 226,786,385 | 181,046 | 226,967,431 | 5 / 6 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | completed | 1 | 2452.27 | 1.24 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/dfe1cfc1-6ac0-4dfa-86a9-6070c214b02f/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/dfe1cfc1-6ac0-4dfa-86a9-6070c214b02f/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/dfe1cfc1-6ac0-4dfa-86a9-6070c214b02f/agent/trajectory.jsonl) |
| 46 | completed | 0 | 7200.05 | 1.43 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/d7d30edf-583d-42c2-ad0b-f766f43a1b72/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/d7d30edf-583d-42c2-ad0b-f766f43a1b72/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/d7d30edf-583d-42c2-ad0b-f766f43a1b72/agent/trajectory.jsonl) |
| 51 | completed | 0 | 1685.33 | 1.25 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/162380a7-b567-4752-8bf3-65751efcb127/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/162380a7-b567-4752-8bf3-65751efcb127/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/162380a7-b567-4752-8bf3-65751efcb127/agent/trajectory.jsonl) |
| 70 | completed | 0 | 5890.99 | 1.26 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/bf0ff0c0-eeeb-49a3-b621-5e0c46ee8412/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/bf0ff0c0-eeeb-49a3-b621-5e0c46ee8412/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/bf0ff0c0-eeeb-49a3-b621-5e0c46ee8412/agent/trajectory.jsonl) |
| 71 | completed | 1 | 3434.95 | 1.19 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/a3f3e810-c8c1-4d6e-8874-8255a12c0e89/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/a3f3e810-c8c1-4d6e-8874-8255a12c0e89/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/a3f3e810-c8c1-4d6e-8874-8255a12c0e89/agent/trajectory.jsonl) |
| 75 | completed | 0 | 1140.92 | 1.19 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/a9aebd77-c46a-424f-be59-bbcff19c8ca1/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/a9aebd77-c46a-424f-be59-bbcff19c8ca1/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/a9aebd77-c46a-424f-be59-bbcff19c8ca1/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 1（主流程 1；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 46 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

