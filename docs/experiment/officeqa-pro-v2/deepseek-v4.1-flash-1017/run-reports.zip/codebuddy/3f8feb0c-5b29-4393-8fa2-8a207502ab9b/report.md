<!-- snapshotDigest: 65774c9e744c9c208ebe67dd56c9f3c9fb197b3f8acf5bde70e5112d47f74ffe -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 0.00%（0/2）**

Run: 3f8feb0c-5b29-4393-8fa2-8a207502ab9b · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-15T04:19:38.539Z / 2026-11-15T09:31:35.293Z |
| 总耗时 | 5 小时 1 分 11 秒 |
| 答对 / 答错 / 解题超时 | 0 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 2 题；已保存 2 条记录；待运行 0 题。
有效评分覆盖率：2/2（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 2 |
| 计分题数 | 2 |
| 正常评分题数 | 2 |
| 答对题数 | 0 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 0.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 小时 1 分 11 秒 |
| 环境准备耗时 | 20 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 2 小时 30 分 22 秒 | 1 小时 0 分 25 秒 | 4 小时 0 分 18 秒 | 2 |
| 任务准备 | 0.65 毫秒 | 0.58 毫秒 | 0.72 毫秒 | 2 |
| 环境启动 | 5 秒 | 5 秒 | 5 秒 | 2 |
| 解题 | 2 小时 30 分 6 秒 | 1 小时 0 分 12 秒 | 4 小时 0 分 0 秒 | 2 |
| 产物传输 | 3 秒 | 2 秒 | 4 秒 | 2 |
| 证据收集 | 2 秒 | 1 秒 | 2 秒 | 2 |
| 资源清理 | 4 秒 | 3 秒 | 4 秒 | 2 |
| 评分 | 1 秒 | 1 秒 | 2 秒 | 2 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| e2501ec9-784a-4ec3-8658-ef96d30df188 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 60,129,908 | 37,774 | 60,167,682 | 1 / 2 | — |
| 运行累计 | 60,129,908 | 37,774 | 60,167,682 | 1 / 2 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 46 | completed | 0 | 14400.06 | 1.51 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/3444a04d-d90d-4965-99c2-00c590158b96/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/3444a04d-d90d-4965-99c2-00c590158b96/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/3444a04d-d90d-4965-99c2-00c590158b96/agent/trajectory.jsonl) |
| 85 | completed | 0 | 3612.12 | 1.46 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/f6baef8f-ae63-4afa-9c64-4924e8e962e9/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/f6baef8f-ae63-4afa-9c64-4924e8e962e9/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/f6baef8f-ae63-4afa-9c64-4924e8e962e9/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 1（主流程 1；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 46 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

