<!-- snapshotDigest: 327dcdbd0721e620f278edd12dc52e0cb96c770865d1be9bf2a384fee2917e07 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 40.38%（21/52）**

Run: 8395b950-c227-4667-be10-1dea89ccf303 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T13:13:15.143Z / 2026-11-13T17:59:15.962Z |
| 总耗时 | 4 小时 36 分 33 秒 |
| 答对 / 答错 / 解题超时 | 21 / 31 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 4 / 0 |

已选择 52 题；已保存 52 条记录；待运行 0 题。
有效评分覆盖率：52/52（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 52 |
| 计分题数 | 52 |
| 正常评分题数 | 52 |
| 答对题数 | 21 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 40.38% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 4 小时 36 分 33 秒 |
| 环境准备耗时 | 3 小时 42 分 14 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 5 分 18 秒 | 53 秒 | 10 分 35 秒 | 52 |
| 任务准备 | 0.42 毫秒 | 0.19 毫秒 | 1.12 毫秒 | 52 |
| 环境启动 | 18 秒 | 13 秒 | 26 秒 | 52 |
| 解题 | 4 分 53 秒 | 33 秒 | 10 分 8 秒 | 52 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 52 |
| 证据收集 | 885.91 毫秒 | 606.53 毫秒 | 2 秒 | 52 |
| 资源清理 | 3 秒 | 2 秒 | 4 秒 | 52 |
| 评分 | 1 秒 | 1 秒 | 2 秒 | 52 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| bb320df3-1691-44a6-836c-875eb17ca05a | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 88,047,678 | 407,500 | 88,455,178 | 48 / 52 | — |
| 运行累计 | 88,047,678 | 407,500 | 88,455,178 | 48 / 52 | 4 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 38 | completed | 0 | 552.54 | 1.08 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/74bc0550-2954-4b82-b57b-355209f80caf/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/74bc0550-2954-4b82-b57b-355209f80caf/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/74bc0550-2954-4b82-b57b-355209f80caf/agent/trajectory.jsonl) |
| 39 | completed | 0 | 149.20 | 1.09 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/46f01b7a-f8c8-4edb-ad35-8c5fdeefff87/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/46f01b7a-f8c8-4edb-ad35-8c5fdeefff87/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/46f01b7a-f8c8-4edb-ad35-8c5fdeefff87/agent/trajectory.jsonl) |
| 40 | completed | 1 | 85.18 | 1.12 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/d25c18c4-f32f-4054-aed9-93b5e444af58/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/d25c18c4-f32f-4054-aed9-93b5e444af58/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/d25c18c4-f32f-4054-aed9-93b5e444af58/agent/trajectory.jsonl) |
| 41 | completed | 1 | 200.02 | 1.04 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/f32b85fa-b74a-4e5e-9973-48c8b53ce463/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/f32b85fa-b74a-4e5e-9973-48c8b53ce463/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/f32b85fa-b74a-4e5e-9973-48c8b53ce463/agent/trajectory.jsonl) |
| 42 | completed | 0 | 239.72 | 1.17 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/9148a648-da57-4155-b2bf-b9430bd96f6a/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/9148a648-da57-4155-b2bf-b9430bd96f6a/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/9148a648-da57-4155-b2bf-b9430bd96f6a/agent/trajectory.jsonl) |
| 43 | completed | 0 | 127.71 | 1.16 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/7d309a5a-74b6-4dce-a2ae-e29b41319ab8/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/7d309a5a-74b6-4dce-a2ae-e29b41319ab8/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/7d309a5a-74b6-4dce-a2ae-e29b41319ab8/agent/trajectory.jsonl) |
| 44 | completed | 1 | 191.02 | 1.56 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/278d69cc-6f47-426e-bcd3-82a0c85bf778/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/278d69cc-6f47-426e-bcd3-82a0c85bf778/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/278d69cc-6f47-426e-bcd3-82a0c85bf778/agent/trajectory.jsonl) |
| 45 | completed | 0 | 520.83 | 1.09 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/1ef2e79b-4bc9-4401-b980-4119f4e60e9a/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/1ef2e79b-4bc9-4401-b980-4119f4e60e9a/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/1ef2e79b-4bc9-4401-b980-4119f4e60e9a/agent/trajectory.jsonl) |
| 46 | completed | 0 | 607.22 | 1.08 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/7c6b743d-b43a-43fe-b2bf-38bd9c64ab70/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/7c6b743d-b43a-43fe-b2bf-38bd9c64ab70/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/7c6b743d-b43a-43fe-b2bf-38bd9c64ab70/agent/trajectory.jsonl) |
| 47 | completed | 0 | 77.42 | 1.05 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/3a3e29d3-d252-409e-8f35-233dbd6985ed/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/3a3e29d3-d252-409e-8f35-233dbd6985ed/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/3a3e29d3-d252-409e-8f35-233dbd6985ed/agent/trajectory.jsonl) |
| 48 | completed | 1 | 88.46 | 1.06 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/73926857-81a5-4d52-868a-72f1f21b326b/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/73926857-81a5-4d52-868a-72f1f21b326b/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/73926857-81a5-4d52-868a-72f1f21b326b/agent/trajectory.jsonl) |
| 49 | completed | 1 | 60.34 | 1.63 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/98eada6b-e58a-4606-8e61-36e9a14baea5/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/98eada6b-e58a-4606-8e61-36e9a14baea5/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/98eada6b-e58a-4606-8e61-36e9a14baea5/agent/trajectory.jsonl) |
| 50 | completed | 0 | 608.06 | 1.11 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/5389a695-0a84-486f-a9e4-19035b573fc3/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/5389a695-0a84-486f-a9e4-19035b573fc3/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/5389a695-0a84-486f-a9e4-19035b573fc3/agent/trajectory.jsonl) |
| 51 | completed | 0 | 309.52 | 1.39 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/5190747c-c6b8-4467-8c5d-c167eb6c5be1/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/5190747c-c6b8-4467-8c5d-c167eb6c5be1/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/5190747c-c6b8-4467-8c5d-c167eb6c5be1/agent/trajectory.jsonl) |
| 52 | completed | 0 | 105.50 | 1.01 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/9430e726-aa33-462f-b35b-437d6466224a/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/9430e726-aa33-462f-b35b-437d6466224a/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/9430e726-aa33-462f-b35b-437d6466224a/agent/trajectory.jsonl) |
| 53 | completed | 0 | 607.39 | 1.04 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/9862f83c-7da8-4675-b1f9-2317cc73531f/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/9862f83c-7da8-4675-b1f9-2317cc73531f/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/9862f83c-7da8-4675-b1f9-2317cc73531f/agent/trajectory.jsonl) |
| 54 | completed | 1 | 577.59 | 1.07 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/43638075-00b4-4802-a3c0-338e0d1978d9/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/43638075-00b4-4802-a3c0-338e0d1978d9/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/43638075-00b4-4802-a3c0-338e0d1978d9/agent/trajectory.jsonl) |
| 55 | completed | 1 | 201.52 | 1.19 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/16c62bed-9e8b-4525-be20-a4f431cb49cf/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/16c62bed-9e8b-4525-be20-a4f431cb49cf/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/16c62bed-9e8b-4525-be20-a4f431cb49cf/agent/trajectory.jsonl) |
| 56 | completed | 1 | 142.49 | 1.58 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/042ce4cd-aa72-49ef-ae64-5047b8b8ae72/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/042ce4cd-aa72-49ef-ae64-5047b8b8ae72/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/042ce4cd-aa72-49ef-ae64-5047b8b8ae72/agent/trajectory.jsonl) |
| 57 | completed | 0 | 607.98 | 1.28 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/08c4424b-6ef9-488a-968f-97a6a6baea3a/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/08c4424b-6ef9-488a-968f-97a6a6baea3a/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/08c4424b-6ef9-488a-968f-97a6a6baea3a/agent/trajectory.jsonl) |
| 58 | completed | 0 | 424.18 | 1.08 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/c7798524-94fc-404d-924b-07a4644bb918/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/c7798524-94fc-404d-924b-07a4644bb918/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/c7798524-94fc-404d-924b-07a4644bb918/agent/trajectory.jsonl) |
| 59 | completed | 0 | 141.55 | 1.40 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/0079c69a-d3b1-4a9f-906a-0a9e1a293020/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/0079c69a-d3b1-4a9f-906a-0a9e1a293020/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/0079c69a-d3b1-4a9f-906a-0a9e1a293020/agent/trajectory.jsonl) |
| 60 | completed | 1 | 228.31 | 1.12 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/68dc5b1b-9f1a-4490-a91c-b322453986e7/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/68dc5b1b-9f1a-4490-a91c-b322453986e7/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/68dc5b1b-9f1a-4490-a91c-b322453986e7/agent/trajectory.jsonl) |
| 61 | completed | 0 | 277.91 | 1.29 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/740e47eb-b433-4df1-b0c2-9f2996454e6d/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/740e47eb-b433-4df1-b0c2-9f2996454e6d/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/740e47eb-b433-4df1-b0c2-9f2996454e6d/agent/trajectory.jsonl) |
| 62 | completed | 0 | 586.47 | 1.45 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/8e55fd6a-2a23-4214-84d6-c4c1824943ca/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/8e55fd6a-2a23-4214-84d6-c4c1824943ca/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/8e55fd6a-2a23-4214-84d6-c4c1824943ca/agent/trajectory.jsonl) |
| 63 | completed | 1 | 142.96 | 1.11 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/10bc8dd8-00e1-42d9-b607-b8d3051983a5/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/10bc8dd8-00e1-42d9-b607-b8d3051983a5/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/10bc8dd8-00e1-42d9-b607-b8d3051983a5/agent/trajectory.jsonl) |
| 64 | completed | 1 | 176.73 | 1.06 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/5411fc38-f2bf-4020-afea-3f8db7bcdf84/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/5411fc38-f2bf-4020-afea-3f8db7bcdf84/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/5411fc38-f2bf-4020-afea-3f8db7bcdf84/agent/trajectory.jsonl) |
| 65 | completed | 0 | 209.37 | 1.07 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/c2dea985-e3bd-4d42-932c-4cdd2a11f533/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/c2dea985-e3bd-4d42-932c-4cdd2a11f533/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/c2dea985-e3bd-4d42-932c-4cdd2a11f533/agent/trajectory.jsonl) |
| 66 | completed | 1 | 128.98 | 1.06 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/1618d1f1-cb92-4157-9968-f6ecdd64b780/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/1618d1f1-cb92-4157-9968-f6ecdd64b780/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/1618d1f1-cb92-4157-9968-f6ecdd64b780/agent/trajectory.jsonl) |
| 67 | completed | 1 | 284.00 | 1.46 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/995a87a3-d511-42b1-a4b2-d24ffff7853c/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/995a87a3-d511-42b1-a4b2-d24ffff7853c/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/995a87a3-d511-42b1-a4b2-d24ffff7853c/agent/trajectory.jsonl) |
| 68 | completed | 1 | 139.71 | 1.15 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/94b1a0a1-c2ff-4503-8c55-d8719990934c/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/94b1a0a1-c2ff-4503-8c55-d8719990934c/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/94b1a0a1-c2ff-4503-8c55-d8719990934c/agent/trajectory.jsonl) |
| 69 | completed | 1 | 216.73 | 1.45 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/46933824-af56-4b2f-8a0c-27ba7cac03d5/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/46933824-af56-4b2f-8a0c-27ba7cac03d5/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/46933824-af56-4b2f-8a0c-27ba7cac03d5/agent/trajectory.jsonl) |
| 70 | completed | 1 | 559.44 | 1.93 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/71aade1d-3ee4-4eef-a6bf-3a0d80be7b01/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/71aade1d-3ee4-4eef-a6bf-3a0d80be7b01/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/71aade1d-3ee4-4eef-a6bf-3a0d80be7b01/agent/trajectory.jsonl) |
| 71 | completed | 1 | 523.64 | 1.23 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/ad160c66-93b3-4a1f-afad-e521955786b1/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/ad160c66-93b3-4a1f-afad-e521955786b1/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/ad160c66-93b3-4a1f-afad-e521955786b1/agent/trajectory.jsonl) |
| 72 | completed | 0 | 379.29 | 1.38 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/7a018ced-1d50-4a7e-b90b-d63963bd023e/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/7a018ced-1d50-4a7e-b90b-d63963bd023e/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/7a018ced-1d50-4a7e-b90b-d63963bd023e/agent/trajectory.jsonl) |
| 73 | completed | 1 | 447.48 | 1.35 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/5646cfb4-6870-46d4-b620-9c1599779fd8/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/5646cfb4-6870-46d4-b620-9c1599779fd8/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/5646cfb4-6870-46d4-b620-9c1599779fd8/agent/trajectory.jsonl) |
| 74 | completed | 0 | 261.51 | 1.11 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/98e1003a-1686-4166-b5df-3babcb4c15e6/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/98e1003a-1686-4166-b5df-3babcb4c15e6/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/98e1003a-1686-4166-b5df-3babcb4c15e6/agent/trajectory.jsonl) |
| 75 | completed | 0 | 210.03 | 1.06 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/ba4dad76-1831-4bc8-b4fa-5b2e876a7014/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/ba4dad76-1831-4bc8-b4fa-5b2e876a7014/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/ba4dad76-1831-4bc8-b4fa-5b2e876a7014/agent/trajectory.jsonl) |
| 76 | completed | 0 | 33.34 | 1.15 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/88bd6e5d-ec9b-40c2-9a75-2db852b01adb/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/88bd6e5d-ec9b-40c2-9a75-2db852b01adb/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/88bd6e5d-ec9b-40c2-9a75-2db852b01adb/agent/trajectory.jsonl) |
| 77 | completed | 0 | 295.24 | 1.29 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/bf04bed3-50fe-4042-a57b-c7b7ad14c8ca/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/bf04bed3-50fe-4042-a57b-c7b7ad14c8ca/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/bf04bed3-50fe-4042-a57b-c7b7ad14c8ca/agent/trajectory.jsonl) |
| 78 | completed | 1 | 104.04 | 1.31 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/277470c3-7b1e-41bf-b596-83fe5a96ea4c/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/277470c3-7b1e-41bf-b596-83fe5a96ea4c/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/277470c3-7b1e-41bf-b596-83fe5a96ea4c/agent/trajectory.jsonl) |
| 79 | completed | 1 | 331.48 | 1.31 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/0d417a43-3d6a-407b-b369-f6d369381d68/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/0d417a43-3d6a-407b-b369-f6d369381d68/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/0d417a43-3d6a-407b-b369-f6d369381d68/agent/trajectory.jsonl) |
| 80 | completed | 0 | 440.06 | 1.15 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/ca80b06d-5561-4db0-a152-aaf57546b8b3/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/ca80b06d-5561-4db0-a152-aaf57546b8b3/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/ca80b06d-5561-4db0-a152-aaf57546b8b3/agent/trajectory.jsonl) |
| 81 | completed | 0 | 256.42 | 1.00 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/8cb54254-95fa-4f98-af47-dc61ae267f9a/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/8cb54254-95fa-4f98-af47-dc61ae267f9a/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/8cb54254-95fa-4f98-af47-dc61ae267f9a/agent/trajectory.jsonl) |
| 82 | completed | 0 | 423.26 | 1.38 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/20b418d3-510b-4ae4-a37a-3e93f28a1125/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/20b418d3-510b-4ae4-a37a-3e93f28a1125/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/20b418d3-510b-4ae4-a37a-3e93f28a1125/agent/trajectory.jsonl) |
| 83 | completed | 0 | 297.45 | 1.53 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/92b8805c-d605-437e-bace-8c25195619de/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/92b8805c-d605-437e-bace-8c25195619de/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/92b8805c-d605-437e-bace-8c25195619de/agent/trajectory.jsonl) |
| 84 | completed | 0 | 314.31 | 1.87 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/b5665927-9d90-44cd-9e6b-41fdbcba0fe5/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/b5665927-9d90-44cd-9e6b-41fdbcba0fe5/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/b5665927-9d90-44cd-9e6b-41fdbcba0fe5/agent/trajectory.jsonl) |
| 85 | completed | 0 | 466.47 | 1.26 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/fe1c3d56-9c4c-4938-a2bd-6f3cf1beb006/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/fe1c3d56-9c4c-4938-a2bd-6f3cf1beb006/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/fe1c3d56-9c4c-4938-a2bd-6f3cf1beb006/agent/trajectory.jsonl) |
| 86 | completed | 1 | 231.61 | 1.08 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a4adf319-992c-435a-9929-42346588bae2/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a4adf319-992c-435a-9929-42346588bae2/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a4adf319-992c-435a-9929-42346588bae2/agent/trajectory.jsonl) |
| 87 | completed | 0 | 111.99 | 1.29 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/d6d0ace2-85e7-4fea-8015-5e2b99ed5800/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/d6d0ace2-85e7-4fea-8015-5e2b99ed5800/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/d6d0ace2-85e7-4fea-8015-5e2b99ed5800/agent/trajectory.jsonl) |
| 88 | completed | 0 | 234.85 | 1.44 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/3ea3902b-a5b2-4290-bed4-76a3cc1483d2/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/3ea3902b-a5b2-4290-bed4-76a3cc1483d2/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/3ea3902b-a5b2-4290-bed4-76a3cc1483d2/agent/trajectory.jsonl) |
| 89 | completed | 0 | 307.77 | 1.26 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/2cfa6cc7-d43d-4f08-a679-92993fec2986/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/2cfa6cc7-d43d-4f08-a679-92993fec2986/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/2cfa6cc7-d43d-4f08-a679-92993fec2986/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 4；错误记录 4（主流程 4；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 4 | 4 |

## 警告

警告涉及 4 个任务，共 4 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 46 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 50 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 53 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 57 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

