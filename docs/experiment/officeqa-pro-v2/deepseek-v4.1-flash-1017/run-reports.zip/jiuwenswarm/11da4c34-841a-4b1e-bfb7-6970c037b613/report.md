<!-- snapshotDigest: 75e889ef9ecd20bcce3985828ffa99bd09d8aa3bce43cd08479a853e780af7cc -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 25.00%（1/4）**

Run: 11da4c34-841a-4b1e-bfb7-6970c037b613 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-14T16:20:44.638Z / 2026-11-14T16:55:17.415Z |
| 总耗时 | 33 分 21 秒 |
| 答对 / 答错 / 解题超时 | 1 / 3 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 4 题；已保存 4 条记录；待运行 0 题。
有效评分覆盖率：4/4（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 4 |
| 计分题数 | 4 |
| 正常评分题数 | 4 |
| 答对题数 | 1 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 25.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 33 分 21 秒 |
| 环境准备耗时 | 1 分 25 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 8 分 6 秒 | 3 分 19 秒 | 11 分 45 秒 | 4 |
| 任务准备 | 0.39 毫秒 | 0.24 毫秒 | 0.71 毫秒 | 4 |
| 环境启动 | 21 秒 | 17 秒 | 31 秒 | 4 |
| 解题 | 7 分 36 秒 | 2 分 52 秒 | 11 分 5 秒 | 4 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 4 |
| 证据收集 | 1 秒 | 1 秒 | 2 秒 | 4 |
| 资源清理 | 4 秒 | 4 秒 | 4 秒 | 4 |
| 评分 | 2 秒 | 1 秒 | 2 秒 | 4 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 9195cbb0-8111-4a3c-a897-1bdbdd5d0529 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 6,856,727 | 37,047 | 6,893,774 | 4 / 4 | — |
| 运行累计 | 6,856,727 | 37,047 | 6,893,774 | 4 / 4 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 46 | completed | 0 | 665.19 | 1.51 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/13475344-90b1-4b7e-908f-5effb70c28ff/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/13475344-90b1-4b7e-908f-5effb70c28ff/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/13475344-90b1-4b7e-908f-5effb70c28ff/agent/trajectory.jsonl) |
| 50 | completed | 0 | 171.52 | 1.43 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/28b0650e-c287-438d-a7a0-570295ac5587/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/28b0650e-c287-438d-a7a0-570295ac5587/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/28b0650e-c287-438d-a7a0-570295ac5587/agent/trajectory.jsonl) |
| 53 | completed | 1 | 644.63 | 1.50 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/225acee4-775b-4af1-87a7-0c3b03b90b45/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/225acee4-775b-4af1-87a7-0c3b03b90b45/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/225acee4-775b-4af1-87a7-0c3b03b90b45/agent/trajectory.jsonl) |
| 57 | completed | 0 | 341.74 | 1.61 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/64f7b622-79d8-412a-bf2a-12c54f1ee96f/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/64f7b622-79d8-412a-bf2a-12c54f1ee96f/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/64f7b622-79d8-412a-bf2a-12c54f1ee96f/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

