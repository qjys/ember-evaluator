<!-- snapshotDigest: 955ef0769a64e1f164b9c095587722ecb7314ea05e9fab43effdc01613167b14 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 31.46%（28/89）**

Run: cd3ce568-92cb-40e4-ac0c-1b26c4ba9169 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T10:10:02.778Z / 2026-11-13T12:17:24.267Z |
| 总耗时 | 2 小时 3 分 14 秒 |
| 答对 / 答错 / 解题超时 | 28 / 10 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 39 条记录；待运行 51 题。
有效评分覆盖率：38/90（42.22%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 38 |
| 答对题数 | 28 |
| 无效评测 | 1 |
| 待运行 | 51 |
| 正确率 | 31.46% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 小时 3 分 14 秒 |
| 环境准备耗时 | 2 小时 7 分 4 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 3 分 8 秒 | 48 秒 | 8 分 14 秒 | 39 |
| 任务准备 | 0.42 毫秒 | 0.22 毫秒 | 1.64 毫秒 | 39 |
| 环境启动 | 16 秒 | 13 秒 | 23 秒 | 39 |
| 解题 | 2 分 46 秒 | 29 秒 | 7 分 53 秒 | 39 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 38 |
| 证据收集 | 879.69 毫秒 | 656.73 毫秒 | 2 秒 | 39 |
| 资源清理 | 3 秒 | 2 秒 | 5 秒 | 39 |
| 评分 | 1 秒 | 888.4 毫秒 | 2 秒 | 38 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 3032bac3-2fce-47e0-a77f-f88d7816e8d0 | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 77,885,782 | 727,742 | 78,613,524 | 38 / 90 | — |
| 运行累计 | 77,885,782 | 727,742 | 78,613,524 | 38 / 39 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 102.37 | 1.49 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/1fc57467-7240-4331-ab9d-05b8f562faf1/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/1fc57467-7240-4331-ab9d-05b8f562faf1/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/1fc57467-7240-4331-ab9d-05b8f562faf1/agent/trajectory.jsonl) |
| 1 | completed | 1 | 102.73 | 1.45 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/e1918714-c0ff-465d-9936-999eae4f68d1/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/e1918714-c0ff-465d-9936-999eae4f68d1/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/e1918714-c0ff-465d-9936-999eae4f68d1/agent/trajectory.jsonl) |
| 2 | completed | 1 | 155.80 | 1.03 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/34dbf29b-635e-4b8b-b967-87fe975cc142/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/34dbf29b-635e-4b8b-b967-87fe975cc142/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/34dbf29b-635e-4b8b-b967-87fe975cc142/agent/trajectory.jsonl) |
| 3 | completed | 0 | 132.37 | 0.98 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/41e733f5-3d8d-4aea-9247-df910f8ab490/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/41e733f5-3d8d-4aea-9247-df910f8ab490/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/41e733f5-3d8d-4aea-9247-df910f8ab490/agent/trajectory.jsonl) |
| 4 | completed | 1 | 29.28 | 1.05 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/36896138-0bbc-4b36-8543-8abac7b54fb7/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/36896138-0bbc-4b36-8543-8abac7b54fb7/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/36896138-0bbc-4b36-8543-8abac7b54fb7/agent/trajectory.jsonl) |
| 5 | completed | 1 | 149.43 | 1.07 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/82934dd7-56b2-4750-afb9-2259c2838cfc/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/82934dd7-56b2-4750-afb9-2259c2838cfc/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/82934dd7-56b2-4750-afb9-2259c2838cfc/agent/trajectory.jsonl) |
| 6 | completed | 1 | 164.94 | 1.30 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/33aa6bca-91bc-423e-96c3-8a7e4767bba6/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/33aa6bca-91bc-423e-96c3-8a7e4767bba6/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/33aa6bca-91bc-423e-96c3-8a7e4767bba6/agent/trajectory.jsonl) |
| 7 | completed | 1 | 44.23 | 0.99 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/3601a269-5417-487e-88b6-09abe3af4c1b/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/3601a269-5417-487e-88b6-09abe3af4c1b/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/3601a269-5417-487e-88b6-09abe3af4c1b/agent/trajectory.jsonl) |
| 8 | completed | 0 | 48.03 | 1.47 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/506f29f8-4508-4685-96a4-c7aadb41bd3d/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/506f29f8-4508-4685-96a4-c7aadb41bd3d/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/506f29f8-4508-4685-96a4-c7aadb41bd3d/agent/trajectory.jsonl) |
| 9 | completed | 0 | 52.93 | 0.96 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/35d68bae-6559-4179-bcea-eddf9b129fca/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/35d68bae-6559-4179-bcea-eddf9b129fca/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/35d68bae-6559-4179-bcea-eddf9b129fca/agent/trajectory.jsonl) |
| 10 | completed | 1 | 170.79 | 1.01 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/bae6afd2-20b3-435f-8436-fc61a8c8171e/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/bae6afd2-20b3-435f-8436-fc61a8c8171e/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/bae6afd2-20b3-435f-8436-fc61a8c8171e/agent/trajectory.jsonl) |
| 11 | completed | 1 | 124.77 | 0.93 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/cf5695e3-9138-4b64-be97-a370242dd325/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/cf5695e3-9138-4b64-be97-a370242dd325/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/cf5695e3-9138-4b64-be97-a370242dd325/agent/trajectory.jsonl) |
| 12 | completed | 1 | 90.60 | 1.50 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/afb04c8b-0914-46b8-8320-2c1f283e7efc/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/afb04c8b-0914-46b8-8320-2c1f283e7efc/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/afb04c8b-0914-46b8-8320-2c1f283e7efc/agent/trajectory.jsonl) |
| 13 | completed | 1 | 253.81 | 0.92 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/293cefe9-9c99-494f-ae72-bb8ac25fe7a6/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/293cefe9-9c99-494f-ae72-bb8ac25fe7a6/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/293cefe9-9c99-494f-ae72-bb8ac25fe7a6/agent/trajectory.jsonl) |
| 14 | completed | 1 | 70.69 | 1.03 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/5b2e2458-c77e-439d-99f9-feee7becca05/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/5b2e2458-c77e-439d-99f9-feee7becca05/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/5b2e2458-c77e-439d-99f9-feee7becca05/agent/trajectory.jsonl) |
| 15 | completed | 1 | 149.70 | 1.01 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/bcaf8475-5f5b-4056-8d26-119ecb1b9101/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/bcaf8475-5f5b-4056-8d26-119ecb1b9101/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/bcaf8475-5f5b-4056-8d26-119ecb1b9101/agent/trajectory.jsonl) |
| 16 | completed | 1 | 228.23 | 1.07 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/d7461a77-f9b9-404e-a247-129b73cf0c5b/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/d7461a77-f9b9-404e-a247-129b73cf0c5b/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/d7461a77-f9b9-404e-a247-129b73cf0c5b/agent/trajectory.jsonl) |
| 17 | completed | 1 | 177.12 | 0.92 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/69f9dd68-8fac-4ce2-b8fb-115d9e3287cb/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/69f9dd68-8fac-4ce2-b8fb-115d9e3287cb/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/69f9dd68-8fac-4ce2-b8fb-115d9e3287cb/agent/trajectory.jsonl) |
| 18 | completed | 1 | 167.35 | 1.03 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/f1db22e1-6813-4877-a491-504ffbafb679/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/f1db22e1-6813-4877-a491-504ffbafb679/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/f1db22e1-6813-4877-a491-504ffbafb679/agent/trajectory.jsonl) |
| 19 | completed | 1 | 232.48 | 1.10 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/5736030e-5581-4793-8bfe-05078faa878e/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/5736030e-5581-4793-8bfe-05078faa878e/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/5736030e-5581-4793-8bfe-05078faa878e/agent/trajectory.jsonl) |
| 20 | completed | 1 | 227.83 | 1.00 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/cb7bf1a5-e1f5-4591-a1cc-0f8fdaa9f855/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/cb7bf1a5-e1f5-4591-a1cc-0f8fdaa9f855/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/cb7bf1a5-e1f5-4591-a1cc-0f8fdaa9f855/agent/trajectory.jsonl) |
| 21 | completed | 1 | 148.70 | 1.16 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/1153ad77-2947-42cc-a602-168911fa8826/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/1153ad77-2947-42cc-a602-168911fa8826/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/1153ad77-2947-42cc-a602-168911fa8826/agent/trajectory.jsonl) |
| 22 | completed | 1 | 80.44 | 1.05 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/b8f1dbdd-1f9c-4dc3-a144-530c961c6b5f/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/b8f1dbdd-1f9c-4dc3-a144-530c961c6b5f/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/b8f1dbdd-1f9c-4dc3-a144-530c961c6b5f/agent/trajectory.jsonl) |
| 23 | completed | 1 | 152.83 | 1.02 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/40b6ee88-03de-4c44-b521-a30b198467e9/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/40b6ee88-03de-4c44-b521-a30b198467e9/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/40b6ee88-03de-4c44-b521-a30b198467e9/agent/trajectory.jsonl) |
| 24 | completed | 0 | 144.64 | 1.55 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/fb98ca66-65db-4d86-973c-267424d3ba97/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/fb98ca66-65db-4d86-973c-267424d3ba97/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/fb98ca66-65db-4d86-973c-267424d3ba97/agent/trajectory.jsonl) |
| 25 | completed | 0 | 170.16 | 1.27 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/bb1fbfc3-aec4-48c7-b53f-0b4577c7782e/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/bb1fbfc3-aec4-48c7-b53f-0b4577c7782e/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/bb1fbfc3-aec4-48c7-b53f-0b4577c7782e/agent/trajectory.jsonl) |
| 26 | completed | 1 | 200.52 | 1.25 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/777f95bd-799e-4533-a59c-69849127a93c/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/777f95bd-799e-4533-a59c-69849127a93c/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/777f95bd-799e-4533-a59c-69849127a93c/agent/trajectory.jsonl) |
| 27 | completed | 1 | 157.84 | 0.97 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/3e54ca4b-640a-4c3f-a399-55bfa62f5235/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/3e54ca4b-640a-4c3f-a399-55bfa62f5235/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/3e54ca4b-640a-4c3f-a399-55bfa62f5235/agent/trajectory.jsonl) |
| 28 | completed | 0 | 413.28 | 1.04 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/7d7e3921-cb88-4be7-a03b-98bb6659a1ad/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/7d7e3921-cb88-4be7-a03b-98bb6659a1ad/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/7d7e3921-cb88-4be7-a03b-98bb6659a1ad/agent/trajectory.jsonl) |
| 29 | completed | 0 | 448.31 | 0.99 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/2b606b4c-8e7e-4d75-aa0d-211edc23c9bc/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/2b606b4c-8e7e-4d75-aa0d-211edc23c9bc/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/2b606b4c-8e7e-4d75-aa0d-211edc23c9bc/agent/trajectory.jsonl) |
| 30 | completed | 0 | 125.08 | 0.89 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/08bf622c-9141-4795-b67b-cc15e509e0f5/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/08bf622c-9141-4795-b67b-cc15e509e0f5/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/08bf622c-9141-4795-b67b-cc15e509e0f5/agent/trajectory.jsonl) |
| 31 | completed | 1 | 39.97 | 1.07 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/c2aac3c2-983f-4ae2-bfaf-2097e703ecf7/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/c2aac3c2-983f-4ae2-bfaf-2097e703ecf7/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/c2aac3c2-983f-4ae2-bfaf-2097e703ecf7/agent/trajectory.jsonl) |
| 32 | completed | 1 | 90.25 | 1.00 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/bcdf8a3f-2b61-4e5f-92a0-53def70af097/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/bcdf8a3f-2b61-4e5f-92a0-53def70af097/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/bcdf8a3f-2b61-4e5f-92a0-53def70af097/agent/trajectory.jsonl) |
| 33 | completed | 1 | 156.04 | 1.01 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/d96fe030-abde-4e63-af5b-cb56b22574fc/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/d96fe030-abde-4e63-af5b-cb56b22574fc/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/d96fe030-abde-4e63-af5b-cb56b22574fc/agent/trajectory.jsonl) |
| 34 | completed | 0 | 257.12 | 1.18 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/f5da813c-455f-4155-91c2-c630e550b277/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/f5da813c-455f-4155-91c2-c630e550b277/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/f5da813c-455f-4155-91c2-c630e550b277/agent/trajectory.jsonl) |
| 35 | completed | 1 | 56.05 | 1.01 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/2f299245-f90e-4ee5-beba-753c6a5433e8/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/2f299245-f90e-4ee5-beba-753c6a5433e8/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/2f299245-f90e-4ee5-beba-753c6a5433e8/agent/trajectory.jsonl) |
| 36 | completed | 0 | 335.71 | 0.99 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/c9a796d5-1089-461f-9148-7e2cc88b2f98/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/c9a796d5-1089-461f-9148-7e2cc88b2f98/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/c9a796d5-1089-461f-9148-7e2cc88b2f98/agent/trajectory.jsonl) |
| 37 | completed | 1 | 151.96 | 1.15 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/9c4141c4-db00-4636-a2e4-c4bcaf3a5b0e/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/9c4141c4-db00-4636-a2e4-c4bcaf3a5b0e/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/9c4141c4-db00-4636-a2e4-c4bcaf3a5b0e/agent/trajectory.jsonl) |
| 38 | invalid | — | 473.30 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/7d5bea63-2eec-4e67-867e-7d35a10d45dd/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/7d5bea63-2eec-4e67-867e-7d35a10d45dd/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/7d5bea63-2eec-4e67-867e-7d35a10d45dd/agent/trajectory.jsonl) |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

