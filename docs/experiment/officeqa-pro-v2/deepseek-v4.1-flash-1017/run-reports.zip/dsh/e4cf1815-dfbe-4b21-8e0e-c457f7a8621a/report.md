<!-- snapshotDigest: cd2baad0bb6446d30afbbf5ce47889ce17e83f811fd1c7117abd8da5274fb8f5 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 46.77%（29/62）**

Run: e4cf1815-dfbe-4b21-8e0e-c457f7a8621a · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T13:14:08.073Z / 2026-11-13T23:02:51.041Z |
| 总耗时 | 9 小时 28 分 43 秒 |
| 答对 / 答错 / 解题超时 | 29 / 25 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 63 题；已保存 55 条记录；待运行 8 题。
有效评分覆盖率：54/63（85.71%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 63 |
| 计分题数 | 62 |
| 正常评分题数 | 54 |
| 答对题数 | 29 |
| 无效评测 | 1 |
| 待运行 | 8 |
| 正确率 | 46.77% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 28 分 43 秒 |
| 环境准备耗时 | 9 小时 35 分 0 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 10 分 19 秒 | 41 秒 | 55 分 8 秒 | 55 |
| 任务准备 | 0.5 毫秒 | 0.2 毫秒 | 4.47 毫秒 | 55 |
| 环境启动 | 17 秒 | 11 秒 | 26 秒 | 55 |
| 解题 | 9 分 56 秒 | 25 秒 | 54 分 23 秒 | 55 |
| 产物传输 | 1 秒 | 1 秒 | 3 秒 | 54 |
| 证据收集 | 1 秒 | 518.34 毫秒 | 26 秒 | 55 |
| 资源清理 | 3 秒 | 2 秒 | 5 秒 | 55 |
| 评分 | 1 秒 | 957.11 毫秒 | 2 秒 | 54 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| f1f509ed-8f92-4607-95f8-d6c0597c4486 | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 773,740 | 414,228,585 | 54 / 63 | — |
| 运行累计 | — | 773,740 | 414,228,585 | 54 / 55 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 27 | completed | 1 | 622.40 | 1.22 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/170065ca-55be-4969-a28d-b8a43b16496e/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/170065ca-55be-4969-a28d-b8a43b16496e/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/170065ca-55be-4969-a28d-b8a43b16496e/agent/trajectory.jsonl) |
| 28 | completed | 1 | 799.41 | 1.16 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/5976281d-d5cf-4cb8-b461-0e5900bdfc83/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/5976281d-d5cf-4cb8-b461-0e5900bdfc83/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/5976281d-d5cf-4cb8-b461-0e5900bdfc83/agent/trajectory.jsonl) |
| 29 | completed | 0 | 887.50 | 1.36 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/8c1e08df-2548-4266-ac41-e8980e33b833/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/8c1e08df-2548-4266-ac41-e8980e33b833/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/8c1e08df-2548-4266-ac41-e8980e33b833/agent/trajectory.jsonl) |
| 30 | completed | 0 | 495.34 | 0.96 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/db4f3747-1512-48cf-a5a7-bd8e73291cde/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/db4f3747-1512-48cf-a5a7-bd8e73291cde/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/db4f3747-1512-48cf-a5a7-bd8e73291cde/agent/trajectory.jsonl) |
| 31 | completed | 1 | 213.09 | 1.23 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/7cf86027-5c5c-4550-acff-4683db0e3a3d/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/7cf86027-5c5c-4550-acff-4683db0e3a3d/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/7cf86027-5c5c-4550-acff-4683db0e3a3d/agent/trajectory.jsonl) |
| 32 | completed | 0 | 139.90 | 1.06 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/aa5b2b6d-bd5b-44c7-80c4-1b7cf43cd3f3/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/aa5b2b6d-bd5b-44c7-80c4-1b7cf43cd3f3/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/aa5b2b6d-bd5b-44c7-80c4-1b7cf43cd3f3/agent/trajectory.jsonl) |
| 33 | completed | 1 | 475.99 | 1.16 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/9f30a21a-2fd0-4485-a307-6e4e094b783c/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/9f30a21a-2fd0-4485-a307-6e4e094b783c/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/9f30a21a-2fd0-4485-a307-6e4e094b783c/agent/trajectory.jsonl) |
| 34 | completed | 0 | 447.55 | 1.38 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/29acc97e-f222-4017-8eb9-6dfa60650cf3/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/29acc97e-f222-4017-8eb9-6dfa60650cf3/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/29acc97e-f222-4017-8eb9-6dfa60650cf3/agent/trajectory.jsonl) |
| 35 | completed | 1 | 330.40 | 0.98 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/30e1ae04-9979-419b-aa6f-118176b78081/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/30e1ae04-9979-419b-aa6f-118176b78081/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/30e1ae04-9979-419b-aa6f-118176b78081/agent/trajectory.jsonl) |
| 36 | completed | 0 | 1192.93 | 1.23 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/5ef0e58d-0e8e-43ec-bb05-4acb7ecdc8a3/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/5ef0e58d-0e8e-43ec-bb05-4acb7ecdc8a3/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/5ef0e58d-0e8e-43ec-bb05-4acb7ecdc8a3/agent/trajectory.jsonl) |
| 37 | completed | 1 | 199.36 | 1.10 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/888dd775-8e3b-4027-9a13-ae6447412d1e/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/888dd775-8e3b-4027-9a13-ae6447412d1e/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/888dd775-8e3b-4027-9a13-ae6447412d1e/agent/trajectory.jsonl) |
| 38 | completed | 0 | 502.65 | 1.13 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/bde70d4f-036e-4bc8-afce-ef42214c9d82/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/bde70d4f-036e-4bc8-afce-ef42214c9d82/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/bde70d4f-036e-4bc8-afce-ef42214c9d82/agent/trajectory.jsonl) |
| 39 | completed | 1 | 283.36 | 1.13 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/3f99e194-785f-4f15-bb09-fd0ffd361139/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/3f99e194-785f-4f15-bb09-fd0ffd361139/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/3f99e194-785f-4f15-bb09-fd0ffd361139/agent/trajectory.jsonl) |
| 40 | completed | 1 | 219.55 | 1.80 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/d0a3fc15-6b6a-4479-a424-23697cc30e91/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/d0a3fc15-6b6a-4479-a424-23697cc30e91/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/d0a3fc15-6b6a-4479-a424-23697cc30e91/agent/trajectory.jsonl) |
| 41 | completed | 1 | 346.30 | 1.02 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/9382d566-feb1-4938-a311-13c63513a016/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/9382d566-feb1-4938-a311-13c63513a016/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/9382d566-feb1-4938-a311-13c63513a016/agent/trajectory.jsonl) |
| 42 | completed | 0 | 345.07 | 1.15 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/859e000e-c51f-450c-bdef-3a9adec2ed6f/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/859e000e-c51f-450c-bdef-3a9adec2ed6f/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/859e000e-c51f-450c-bdef-3a9adec2ed6f/agent/trajectory.jsonl) |
| 43 | completed | 0 | 623.02 | 1.20 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/a3a6a0cf-f11a-4418-bf1a-5f159d69abaa/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/a3a6a0cf-f11a-4418-bf1a-5f159d69abaa/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/a3a6a0cf-f11a-4418-bf1a-5f159d69abaa/agent/trajectory.jsonl) |
| 44 | completed | 0 | 339.57 | 1.04 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/2b3b1c52-f994-48dd-8b0a-ed15e3478422/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/2b3b1c52-f994-48dd-8b0a-ed15e3478422/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/2b3b1c52-f994-48dd-8b0a-ed15e3478422/agent/trajectory.jsonl) |
| 45 | completed | 0 | 420.85 | 1.07 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/bf96ac7f-fca4-43a1-9786-71542a6db881/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/bf96ac7f-fca4-43a1-9786-71542a6db881/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/bf96ac7f-fca4-43a1-9786-71542a6db881/agent/trajectory.jsonl) |
| 46 | completed | 1 | 1053.46 | 1.55 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/480542d5-f393-4c34-a20a-22f77b307741/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/480542d5-f393-4c34-a20a-22f77b307741/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/480542d5-f393-4c34-a20a-22f77b307741/agent/trajectory.jsonl) |
| 47 | completed | 1 | 706.94 | 1.39 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/160eec5d-ff52-44c6-9432-918e94b28093/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/160eec5d-ff52-44c6-9432-918e94b28093/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/160eec5d-ff52-44c6-9432-918e94b28093/agent/trajectory.jsonl) |
| 48 | completed | 1 | 1799.62 | 1.32 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/580c036e-7237-49b3-b350-3a01ca4ab7f1/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/580c036e-7237-49b3-b350-3a01ca4ab7f1/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/580c036e-7237-49b3-b350-3a01ca4ab7f1/agent/trajectory.jsonl) |
| 49 | completed | 1 | 309.76 | 1.33 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/04c4aaa4-e562-476d-965f-1572984a3707/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/04c4aaa4-e562-476d-965f-1572984a3707/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/04c4aaa4-e562-476d-965f-1572984a3707/agent/trajectory.jsonl) |
| 50 | completed | 0 | 777.50 | 1.01 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/f7fc4941-b895-4f9e-8cf4-6457ab9e5d49/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/f7fc4941-b895-4f9e-8cf4-6457ab9e5d49/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/f7fc4941-b895-4f9e-8cf4-6457ab9e5d49/agent/trajectory.jsonl) |
| 51 | completed | 0 | 1669.25 | 1.23 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/5348e5e3-2424-4536-b88b-3e36b1c26ce0/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/5348e5e3-2424-4536-b88b-3e36b1c26ce0/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/5348e5e3-2424-4536-b88b-3e36b1c26ce0/agent/trajectory.jsonl) |
| 52 | completed | 0 | 560.07 | 1.33 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/f5ecded5-c592-4bee-a9dd-fe07e5ca6256/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/f5ecded5-c592-4bee-a9dd-fe07e5ca6256/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/f5ecded5-c592-4bee-a9dd-fe07e5ca6256/agent/trajectory.jsonl) |
| 53 | completed | 1 | 514.78 | 1.16 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/263921f9-257e-4f9d-9d2c-d681a1925d72/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/263921f9-257e-4f9d-9d2c-d681a1925d72/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/263921f9-257e-4f9d-9d2c-d681a1925d72/agent/trajectory.jsonl) |
| 54 | completed | 1 | 1351.39 | 1.22 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/28f151c3-2e05-4e54-870d-ff56bd68c458/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/28f151c3-2e05-4e54-870d-ff56bd68c458/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/28f151c3-2e05-4e54-870d-ff56bd68c458/agent/trajectory.jsonl) |
| 55 | completed | 1 | 413.02 | 1.18 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/bc634877-5b37-402b-bfff-0e4ba9a7c92a/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/bc634877-5b37-402b-bfff-0e4ba9a7c92a/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/bc634877-5b37-402b-bfff-0e4ba9a7c92a/agent/trajectory.jsonl) |
| 56 | completed | 1 | 711.27 | 2.08 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/772b2d68-6edb-4a05-a4a3-edc916659768/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/772b2d68-6edb-4a05-a4a3-edc916659768/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/772b2d68-6edb-4a05-a4a3-edc916659768/agent/trajectory.jsonl) |
| 57 | completed | 0 | 1065.66 | 1.26 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/f334234f-af7a-4b89-adc5-824203f15647/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/f334234f-af7a-4b89-adc5-824203f15647/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/f334234f-af7a-4b89-adc5-824203f15647/agent/trajectory.jsonl) |
| 58 | completed | 1 | 373.79 | 1.25 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/5baf7d2f-f04f-4195-b238-026ad5b2a575/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/5baf7d2f-f04f-4195-b238-026ad5b2a575/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/5baf7d2f-f04f-4195-b238-026ad5b2a575/agent/trajectory.jsonl) |
| 59 | completed | 0 | 520.67 | 1.33 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/7a31d92f-7a16-4799-b99a-27427b43b73a/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/7a31d92f-7a16-4799-b99a-27427b43b73a/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/7a31d92f-7a16-4799-b99a-27427b43b73a/agent/trajectory.jsonl) |
| 60 | completed | 1 | 356.90 | 1.38 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/b0abc413-f22c-464e-88e8-f2b3851785ed/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/b0abc413-f22c-464e-88e8-f2b3851785ed/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/b0abc413-f22c-464e-88e8-f2b3851785ed/agent/trajectory.jsonl) |
| 61 | completed | 0 | 261.00 | 1.41 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/b47c8f73-3a5b-4f3c-844a-8b5ab7ac12b0/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/b47c8f73-3a5b-4f3c-844a-8b5ab7ac12b0/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/b47c8f73-3a5b-4f3c-844a-8b5ab7ac12b0/agent/trajectory.jsonl) |
| 62 | completed | 0 | 370.77 | 1.16 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/a536203f-4d9b-432c-85a7-49a7490ef264/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/a536203f-4d9b-432c-85a7-49a7490ef264/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/a536203f-4d9b-432c-85a7-49a7490ef264/agent/trajectory.jsonl) |
| 63 | completed | 0 | 452.78 | 1.29 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/de2bd703-45d4-4cf7-ab2c-be0e28968c15/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/de2bd703-45d4-4cf7-ab2c-be0e28968c15/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/de2bd703-45d4-4cf7-ab2c-be0e28968c15/agent/trajectory.jsonl) |
| 64 | completed | 1 | 447.54 | 1.49 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/d384aa8d-18bb-4464-acb0-47d8353f95ed/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/d384aa8d-18bb-4464-acb0-47d8353f95ed/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/d384aa8d-18bb-4464-acb0-47d8353f95ed/agent/trajectory.jsonl) |
| 65 | completed | 0 | 664.89 | 1.17 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/00f5f856-3c62-4303-bb4f-e53e3eb58e6f/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/00f5f856-3c62-4303-bb4f-e53e3eb58e6f/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/00f5f856-3c62-4303-bb4f-e53e3eb58e6f/agent/trajectory.jsonl) |
| 66 | completed | 1 | 245.66 | 1.08 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/b9673caa-9d37-4ff2-9a3c-ef315b6033d1/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/b9673caa-9d37-4ff2-9a3c-ef315b6033d1/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/b9673caa-9d37-4ff2-9a3c-ef315b6033d1/agent/trajectory.jsonl) |
| 67 | completed | 1 | 241.07 | 1.15 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/b2c05c05-a98e-47eb-941b-363f3dab94ee/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/b2c05c05-a98e-47eb-941b-363f3dab94ee/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/b2c05c05-a98e-47eb-941b-363f3dab94ee/agent/trajectory.jsonl) |
| 68 | completed | 1 | 540.77 | 1.55 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/02efa417-5183-4666-8e52-52e4fe3edf18/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/02efa417-5183-4666-8e52-52e4fe3edf18/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/02efa417-5183-4666-8e52-52e4fe3edf18/agent/trajectory.jsonl) |
| 69 | completed | 1 | 263.38 | 1.10 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/ce8766ae-e6b3-4157-9548-3519456f23d0/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/ce8766ae-e6b3-4157-9548-3519456f23d0/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/ce8766ae-e6b3-4157-9548-3519456f23d0/agent/trajectory.jsonl) |
| 70 | completed | 1 | 1040.97 | 1.14 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/60cfe74f-7724-407b-9eeb-8ec1c9cc80a9/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/60cfe74f-7724-407b-9eeb-8ec1c9cc80a9/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/60cfe74f-7724-407b-9eeb-8ec1c9cc80a9/agent/trajectory.jsonl) |
| 71 | completed | 0 | 690.92 | 0.99 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/151d538f-d52e-402a-9861-3490887aa52f/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/151d538f-d52e-402a-9861-3490887aa52f/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/151d538f-d52e-402a-9861-3490887aa52f/agent/trajectory.jsonl) |
| 72 | completed | 0 | 3263.24 | 1.46 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/756dec3d-fa4a-4610-9b41-9d415ad7f382/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/756dec3d-fa4a-4610-9b41-9d415ad7f382/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/756dec3d-fa4a-4610-9b41-9d415ad7f382/agent/trajectory.jsonl) |
| 73 | completed | 1 | 470.72 | 0.99 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/090c541d-35cf-4adb-9401-0d70149a33df/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/090c541d-35cf-4adb-9401-0d70149a33df/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/090c541d-35cf-4adb-9401-0d70149a33df/agent/trajectory.jsonl) |
| 74 | completed | 0 | 193.88 | 1.06 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/f44093e5-7e17-4d5a-b8ad-1c39c5b37d66/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/f44093e5-7e17-4d5a-b8ad-1c39c5b37d66/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/f44093e5-7e17-4d5a-b8ad-1c39c5b37d66/agent/trajectory.jsonl) |
| 75 | completed | 0 | 537.44 | 0.97 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/4b877b7c-7f38-43df-9dbf-dbdc6da4d6df/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/4b877b7c-7f38-43df-9dbf-dbdc6da4d6df/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/4b877b7c-7f38-43df-9dbf-dbdc6da4d6df/agent/trajectory.jsonl) |
| 76 | completed | 1 | 194.31 | 1.05 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/0db1493b-2175-497d-9371-443c058a038f/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/0db1493b-2175-497d-9371-443c058a038f/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/0db1493b-2175-497d-9371-443c058a038f/agent/trajectory.jsonl) |
| 77 | completed | 0 | 597.72 | 0.98 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/5e187556-23c7-4d22-b06b-b253d3d1721b/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/5e187556-23c7-4d22-b06b-b253d3d1721b/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/5e187556-23c7-4d22-b06b-b253d3d1721b/agent/trajectory.jsonl) |
| 78 | completed | 1 | 493.55 | 1.12 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/40a4a471-cd8e-4e3c-abdf-8c6c19a46cf1/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/40a4a471-cd8e-4e3c-abdf-8c6c19a46cf1/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/40a4a471-cd8e-4e3c-abdf-8c6c19a46cf1/agent/trajectory.jsonl) |
| 79 | completed | 1 | 250.08 | 1.08 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d6a69502-df0d-4036-b10a-53d760391c8b/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d6a69502-df0d-4036-b10a-53d760391c8b/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d6a69502-df0d-4036-b10a-53d760391c8b/agent/trajectory.jsonl) |
| 80 | completed | 0 | 451.53 | 1.01 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/7902ee4d-dfe5-4b3c-a928-4c47d23d3e25/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/7902ee4d-dfe5-4b3c-a928-4c47d23d3e25/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/7902ee4d-dfe5-4b3c-a928-4c47d23d3e25/agent/trajectory.jsonl) |
| 81 | invalid | — | 25.26 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/a7a0ba4f-1375-444f-91ae-7e3a49416fbd/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/a7a0ba4f-1375-444f-91ae-7e3a49416fbd/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/a7a0ba4f-1375-444f-91ae-7e3a49416fbd/agent/trajectory.jsonl) |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

