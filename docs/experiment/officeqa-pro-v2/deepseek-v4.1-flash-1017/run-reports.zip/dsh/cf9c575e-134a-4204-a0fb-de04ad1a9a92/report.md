<!-- snapshotDigest: 329cc7fbbff74dd56f19b2eb39bf572b54ea302b6fdc0b2246f38f8ded2c899a -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 28.09%（25/89）**

Run: cf9c575e-134a-4204-a0fb-de04ad1a9a92 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T09:59:14.309Z / 2026-11-13T12:17:31.948Z |
| 总耗时 | 2 小时 13 分 45 秒 |
| 答对 / 答错 / 解题超时 | 25 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 28 条记录；待运行 62 题。
有效评分覆盖率：27/90（30.00%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 27 |
| 答对题数 | 25 |
| 无效评测 | 1 |
| 待运行 | 62 |
| 正确率 | 28.09% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 小时 13 分 45 秒 |
| 环境准备耗时 | 2 小时 18 分 0 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 4 分 46 秒 | 1 分 4 秒 | 9 分 9 秒 | 28 |
| 任务准备 | 0.4 毫秒 | 0.24 毫秒 | 0.74 毫秒 | 28 |
| 环境启动 | 15 秒 | 11 秒 | 20 秒 | 28 |
| 解题 | 4 分 24 秒 | 41 秒 | 8 分 50 秒 | 28 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 27 |
| 证据收集 | 2 秒 | 522.41 毫秒 | 39 秒 | 28 |
| 资源清理 | 3 秒 | 2 秒 | 4 秒 | 28 |
| 评分 | 1 秒 | 881.55 毫秒 | 2 秒 | 27 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| a6788449-23db-4b31-83be-76bd22a2441e | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 816,556 | 101,719,129 | 27 / 90 | — |
| 运行累计 | — | 816,556 | 101,719,129 | 27 / 28 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 391.46 | 1.20 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/7dce6ad1-b7ba-436e-af91-48184c3849bc/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/7dce6ad1-b7ba-436e-af91-48184c3849bc/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/7dce6ad1-b7ba-436e-af91-48184c3849bc/agent/trajectory.jsonl) |
| 1 | completed | 1 | 138.85 | 1.46 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/bffb7a66-a5a0-4ab5-ad76-3b5a4db7cdaa/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/bffb7a66-a5a0-4ab5-ad76-3b5a4db7cdaa/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/bffb7a66-a5a0-4ab5-ad76-3b5a4db7cdaa/agent/trajectory.jsonl) |
| 2 | completed | 1 | 159.84 | 1.40 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/8962431a-cc52-4775-8fd8-3d5e743249a6/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/8962431a-cc52-4775-8fd8-3d5e743249a6/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/8962431a-cc52-4775-8fd8-3d5e743249a6/agent/trajectory.jsonl) |
| 3 | completed | 1 | 385.72 | 0.99 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/b38b748d-17d3-4315-a8f5-5d1a0fa9a171/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/b38b748d-17d3-4315-a8f5-5d1a0fa9a171/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/b38b748d-17d3-4315-a8f5-5d1a0fa9a171/agent/trajectory.jsonl) |
| 4 | completed | 1 | 91.44 | 1.31 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/79087961-eaed-442b-a74f-11ebced4adac/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/79087961-eaed-442b-a74f-11ebced4adac/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/79087961-eaed-442b-a74f-11ebced4adac/agent/trajectory.jsonl) |
| 5 | completed | 1 | 236.33 | 1.17 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/1989d4b6-f36f-49f3-bb28-982089e7ffaa/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/1989d4b6-f36f-49f3-bb28-982089e7ffaa/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/1989d4b6-f36f-49f3-bb28-982089e7ffaa/agent/trajectory.jsonl) |
| 6 | completed | 1 | 193.50 | 1.24 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/41874a69-b0c6-46d2-835e-246af33a6796/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/41874a69-b0c6-46d2-835e-246af33a6796/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/41874a69-b0c6-46d2-835e-246af33a6796/agent/trajectory.jsonl) |
| 7 | completed | 1 | 71.12 | 1.11 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/196710ba-1372-4f29-b107-2b408b212e72/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/196710ba-1372-4f29-b107-2b408b212e72/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/196710ba-1372-4f29-b107-2b408b212e72/agent/trajectory.jsonl) |
| 8 | completed | 0 | 137.34 | 0.88 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/61480ec5-89cf-4610-8b1d-cde7430235d6/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/61480ec5-89cf-4610-8b1d-cde7430235d6/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/61480ec5-89cf-4610-8b1d-cde7430235d6/agent/trajectory.jsonl) |
| 9 | completed | 1 | 41.32 | 1.06 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/4a14fc2c-1595-4de3-a38a-c629edd4104b/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/4a14fc2c-1595-4de3-a38a-c629edd4104b/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/4a14fc2c-1595-4de3-a38a-c629edd4104b/agent/trajectory.jsonl) |
| 10 | completed | 1 | 446.87 | 0.98 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/adfea3ad-e2ac-48bf-adbd-42de313068d4/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/adfea3ad-e2ac-48bf-adbd-42de313068d4/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/adfea3ad-e2ac-48bf-adbd-42de313068d4/agent/trajectory.jsonl) |
| 11 | completed | 1 | 230.31 | 1.52 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/d481ba2f-d887-4d7e-9530-e4a1076f1263/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/d481ba2f-d887-4d7e-9530-e4a1076f1263/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/d481ba2f-d887-4d7e-9530-e4a1076f1263/agent/trajectory.jsonl) |
| 12 | completed | 1 | 245.68 | 0.95 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/ee00a933-1a89-4c1c-aed0-edbebf6db486/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/ee00a933-1a89-4c1c-aed0-edbebf6db486/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/ee00a933-1a89-4c1c-aed0-edbebf6db486/agent/trajectory.jsonl) |
| 13 | completed | 1 | 327.04 | 1.06 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/231fad65-7d07-4a70-be98-42feca68bac0/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/231fad65-7d07-4a70-be98-42feca68bac0/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/231fad65-7d07-4a70-be98-42feca68bac0/agent/trajectory.jsonl) |
| 14 | completed | 1 | 181.07 | 1.11 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/4038a7b7-b470-47f6-9fef-3f45fb28ba87/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/4038a7b7-b470-47f6-9fef-3f45fb28ba87/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/4038a7b7-b470-47f6-9fef-3f45fb28ba87/agent/trajectory.jsonl) |
| 15 | completed | 0 | 398.31 | 1.01 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/43c1d531-0853-4d9f-ad81-7c7651f52271/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/43c1d531-0853-4d9f-ad81-7c7651f52271/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/43c1d531-0853-4d9f-ad81-7c7651f52271/agent/trajectory.jsonl) |
| 16 | completed | 1 | 279.62 | 0.98 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/b172fe3a-8b15-459c-a518-909dd0016a15/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/b172fe3a-8b15-459c-a518-909dd0016a15/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/b172fe3a-8b15-459c-a518-909dd0016a15/agent/trajectory.jsonl) |
| 17 | completed | 1 | 177.32 | 0.99 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/fa7c0af6-8fd1-49a8-a880-4f640254932e/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/fa7c0af6-8fd1-49a8-a880-4f640254932e/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/fa7c0af6-8fd1-49a8-a880-4f640254932e/agent/trajectory.jsonl) |
| 18 | completed | 1 | 450.73 | 1.50 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/dfe29c7c-30fc-456e-8006-cd6c10576806/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/dfe29c7c-30fc-456e-8006-cd6c10576806/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/dfe29c7c-30fc-456e-8006-cd6c10576806/agent/trajectory.jsonl) |
| 19 | completed | 1 | 199.48 | 1.10 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/6a583817-93f3-4df7-98ba-192d04409fbd/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/6a583817-93f3-4df7-98ba-192d04409fbd/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/6a583817-93f3-4df7-98ba-192d04409fbd/agent/trajectory.jsonl) |
| 20 | completed | 1 | 306.06 | 0.92 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/e3311bc2-b8e5-40a7-a400-3968dfbcac18/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/e3311bc2-b8e5-40a7-a400-3968dfbcac18/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/e3311bc2-b8e5-40a7-a400-3968dfbcac18/agent/trajectory.jsonl) |
| 21 | completed | 1 | 353.02 | 1.07 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/8df2ec6c-1b7a-4fc8-93cb-92e6fd3380b6/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/8df2ec6c-1b7a-4fc8-93cb-92e6fd3380b6/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/8df2ec6c-1b7a-4fc8-93cb-92e6fd3380b6/agent/trajectory.jsonl) |
| 22 | completed | 1 | 138.77 | 0.94 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/626bd58e-15d3-451e-9856-3f70893d16fb/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/626bd58e-15d3-451e-9856-3f70893d16fb/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/626bd58e-15d3-451e-9856-3f70893d16fb/agent/trajectory.jsonl) |
| 23 | completed | 1 | 149.43 | 1.14 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/e33dc687-1399-4f45-a9ac-790990e2b55b/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/e33dc687-1399-4f45-a9ac-790990e2b55b/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/e33dc687-1399-4f45-a9ac-790990e2b55b/agent/trajectory.jsonl) |
| 24 | completed | 1 | 344.00 | 1.20 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/15243d8d-5dce-412c-b29e-eafe34858189/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/15243d8d-5dce-412c-b29e-eafe34858189/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/15243d8d-5dce-412c-b29e-eafe34858189/agent/trajectory.jsonl) |
| 25 | completed | 1 | 342.30 | 1.07 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/b90483b1-d7a4-4c27-b580-b4187fb612d0/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/b90483b1-d7a4-4c27-b580-b4187fb612d0/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/b90483b1-d7a4-4c27-b580-b4187fb612d0/agent/trajectory.jsonl) |
| 26 | completed | 1 | 434.00 | 1.09 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/3f473f2e-98bf-4f64-9278-18025c2cbb63/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/3f473f2e-98bf-4f64-9278-18025c2cbb63/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/3f473f2e-98bf-4f64-9278-18025c2cbb63/agent/trajectory.jsonl) |
| 27 | invalid | — | 530.14 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/34f68f38-7003-4af8-b1b9-7ad763a43c5e/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/34f68f38-7003-4af8-b1b9-7ad763a43c5e/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/34f68f38-7003-4af8-b1b9-7ad763a43c5e/agent/trajectory.jsonl) |
| 28 | pending | — | — | — | — | — | — |
| 29 | pending | — | — | — | — | — | — |
| 30 | pending | — | — | — | — | — | — |
| 31 | pending | — | — | — | — | — | — |
| 32 | pending | — | — | — | — | — | — |
| 33 | pending | — | — | — | — | — | — |
| 34 | pending | — | — | — | — | — | — |
| 35 | pending | — | — | — | — | — | — |
| 36 | pending | — | — | — | — | — | — |
| 37 | pending | — | — | — | — | — | — |
| 38 | pending | — | — | — | — | — | — |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

