<!-- snapshotDigest: e673b735bc4ffab183803aa088598bf5cb67498946efdc6adb254f9ac2e9879e -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 44.44%（4/9）**

Run: 752700de-291b-4413-a719-5ad674e77a46 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-14T02:32:49.196Z / 2026-11-14T04:05:47.186Z |
| 总耗时 | 1 小时 29 分 46 秒 |
| 答对 / 答错 / 解题超时 | 4 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 9 题；已保存 9 条记录；待运行 0 题。
有效评分覆盖率：9/9（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 9 |
| 计分题数 | 9 |
| 正常评分题数 | 9 |
| 答对题数 | 4 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 44.44% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 29 分 46 秒 |
| 环境准备耗时 | 4 分 41 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 9 分 53 秒 | 4 分 7 秒 | 15 分 28 秒 | 9 |
| 任务准备 | 0.38 毫秒 | 0.19 毫秒 | 0.85 毫秒 | 9 |
| 环境启动 | 18 秒 | 15 秒 | 25 秒 | 9 |
| 解题 | 9 分 26 秒 | 3 分 42 秒 | 15 分 0 秒 | 9 |
| 产物传输 | 2 秒 | 2 秒 | 3 秒 | 9 |
| 证据收集 | 2 秒 | 1 秒 | 3 秒 | 9 |
| 资源清理 | 4 秒 | 4 秒 | 5 秒 | 9 |
| 评分 | 2 秒 | 1 秒 | 2 秒 | 9 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 76cf40a8-d9e9-4c2e-9b47-5af4d8d0a834 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 137,286 | 76,053,637 | 9 / 9 | — |
| 运行累计 | — | 137,286 | 76,053,637 | 9 / 9 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 81 | completed | 1 | 774.16 | 1.48 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/2038d7a2-ed18-45b6-b93d-a4fd33b7373d/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/2038d7a2-ed18-45b6-b93d-a4fd33b7373d/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/2038d7a2-ed18-45b6-b93d-a4fd33b7373d/agent/trajectory.jsonl) |
| 82 | completed | 0 | 550.06 | 1.73 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/3a7a1ab0-b756-4e20-8a23-fb3173aa0cd9/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/3a7a1ab0-b756-4e20-8a23-fb3173aa0cd9/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/3a7a1ab0-b756-4e20-8a23-fb3173aa0cd9/agent/trajectory.jsonl) |
| 83 | completed | 0 | 650.98 | 1.51 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/9487900f-73f2-4718-9e5f-557c07a151b5/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/9487900f-73f2-4718-9e5f-557c07a151b5/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/9487900f-73f2-4718-9e5f-557c07a151b5/agent/trajectory.jsonl) |
| 84 | completed | 1 | 899.54 | 2.10 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/9125db00-e976-4937-bb4d-2744fb3a316e/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/9125db00-e976-4937-bb4d-2744fb3a316e/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/9125db00-e976-4937-bb4d-2744fb3a316e/agent/trajectory.jsonl) |
| 85 | completed | 0 | 779.27 | 1.44 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/0d86a0bc-56d1-463e-b2f3-b1260a84bdc4/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/0d86a0bc-56d1-463e-b2f3-b1260a84bdc4/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/0d86a0bc-56d1-463e-b2f3-b1260a84bdc4/agent/trajectory.jsonl) |
| 86 | completed | 1 | 404.13 | 1.26 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a166c7db-1ec0-4946-aad6-c9a311aad6ac/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a166c7db-1ec0-4946-aad6-c9a311aad6ac/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a166c7db-1ec0-4946-aad6-c9a311aad6ac/agent/trajectory.jsonl) |
| 87 | completed | 1 | 221.80 | 1.49 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/60594dd5-9b5e-4533-8513-07f0683b183f/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/60594dd5-9b5e-4533-8513-07f0683b183f/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/60594dd5-9b5e-4533-8513-07f0683b183f/agent/trajectory.jsonl) |
| 88 | completed | 0 | 329.98 | 1.58 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/005d119b-fe24-4c18-b0bf-1e99b03d0f60/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/005d119b-fe24-4c18-b0bf-1e99b03d0f60/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/005d119b-fe24-4c18-b0bf-1e99b03d0f60/agent/trajectory.jsonl) |
| 89 | completed | 0 | 483.95 | 1.69 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/79d0ef8a-6d8b-4510-8bd5-8798392dfc2c/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/79d0ef8a-6d8b-4510-8bd5-8798392dfc2c/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/79d0ef8a-6d8b-4510-8bd5-8798392dfc2c/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

