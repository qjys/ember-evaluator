<!-- snapshotDigest: fa0bf6199c1d58f64f3e1576be5c5682eb85645691965080223e87bf11e50145 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 40.91%（18/44）**

Run: 91745923-01a3-4c37-8f0f-e91210229b34 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-14T02:34:16.983Z / 2026-11-14T21:15:52.183Z |
| 总耗时 | 18 小时 3 分 3 秒 |
| 答对 / 答错 / 解题超时 | 18 / 19 / 7 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 7 / 0 |

已选择 44 题；已保存 44 条记录；待运行 0 题。
有效评分覆盖率：44/44（100.00%）。
执行失败 0；超时 7；取消 0；不支持 0。
Agent 解题超时 7（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 44 |
| 计分题数 | 44 |
| 正常评分题数 | 37 |
| 答对题数 | 18 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 40.91% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 18 小时 3 分 3 秒 |
| 环境准备耗时 | 13 小时 30 分 1 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 24 分 35 秒 | 54 秒 | 1 小时 0 分 13 秒 | 44 |
| 任务准备 | 0.39 毫秒 | 0.19 毫秒 | 1.31 毫秒 | 44 |
| 环境启动 | 6 秒 | 5 秒 | 9 秒 | 44 |
| 解题 | 24 分 22 秒 | 33 秒 | 59 分 55 秒 | 44 |
| 证据收集 | 2 秒 | 982.92 毫秒 | 9 秒 | 44 |
| 资源清理 | 3 秒 | 3 秒 | 6 秒 | 44 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 37 |
| 评分 | 1 秒 | 1 秒 | 2 秒 | 37 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 1769bfdc-dd28-4e3b-8c92-6bd36e6c103e | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 172,638,503 | 5,328,841 | 177,967,344 | 37 / 44 | — |
| 运行累计 | 172,638,503 | 5,328,841 | 177,967,344 | 37 / 44 | 7 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 46 | timeout (agent) | 0 | 3592.55 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/86491a9f-196c-48dc-b514-c5b0bcf51d7e/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/86491a9f-196c-48dc-b514-c5b0bcf51d7e/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/86491a9f-196c-48dc-b514-c5b0bcf51d7e/agent/trajectory.jsonl) |
| 47 | completed | 0 | 32.50 | 2.27 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/caa8155c-d007-42ab-97f6-0bd870f30ad7/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/caa8155c-d007-42ab-97f6-0bd870f30ad7/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/caa8155c-d007-42ab-97f6-0bd870f30ad7/agent/trajectory.jsonl) |
| 48 | completed | 1 | 493.75 | 1.56 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/2c5c9810-99b6-4355-9708-94bcda919525/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/2c5c9810-99b6-4355-9708-94bcda919525/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/2c5c9810-99b6-4355-9708-94bcda919525/agent/trajectory.jsonl) |
| 49 | completed | 1 | 63.72 | 1.66 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/9ee5ea9a-2405-4e42-a5be-ccd197cc70be/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/9ee5ea9a-2405-4e42-a5be-ccd197cc70be/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/9ee5ea9a-2405-4e42-a5be-ccd197cc70be/agent/trajectory.jsonl) |
| 50 | completed | 0 | 1011.41 | 1.41 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/04bea38e-b1f2-496f-941c-c352bbc10dd7/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/04bea38e-b1f2-496f-941c-c352bbc10dd7/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/04bea38e-b1f2-496f-941c-c352bbc10dd7/agent/trajectory.jsonl) |
| 51 | timeout (agent) | 0 | 3594.50 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/98ef2051-1d7c-435a-b89f-fe14b7388804/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/98ef2051-1d7c-435a-b89f-fe14b7388804/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/98ef2051-1d7c-435a-b89f-fe14b7388804/agent/trajectory.jsonl) |
| 52 | completed | 0 | 934.07 | 2.07 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/20fc3510-ccb5-4845-9852-c40440e9d24e/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/20fc3510-ccb5-4845-9852-c40440e9d24e/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/20fc3510-ccb5-4845-9852-c40440e9d24e/agent/trajectory.jsonl) |
| 53 | completed | 1 | 1056.10 | 1.31 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/009d90cf-a46f-4622-b9fd-308a96e0655e/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/009d90cf-a46f-4622-b9fd-308a96e0655e/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/009d90cf-a46f-4622-b9fd-308a96e0655e/agent/trajectory.jsonl) |
| 54 | completed | 1 | 1773.08 | 1.30 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/7e5586c4-f502-408b-9e7c-9849947a6808/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/7e5586c4-f502-408b-9e7c-9849947a6808/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/7e5586c4-f502-408b-9e7c-9849947a6808/agent/trajectory.jsonl) |
| 55 | completed | 1 | 626.66 | 1.35 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/f05eb492-7fb2-421d-9a8b-f5e46134aa6a/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/f05eb492-7fb2-421d-9a8b-f5e46134aa6a/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/f05eb492-7fb2-421d-9a8b-f5e46134aa6a/agent/trajectory.jsonl) |
| 56 | completed | 1 | 120.37 | 1.29 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/51904456-dc37-40fb-abc4-6450f7b6e5ca/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/51904456-dc37-40fb-abc4-6450f7b6e5ca/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/51904456-dc37-40fb-abc4-6450f7b6e5ca/agent/trajectory.jsonl) |
| 57 | completed | 0 | 2482.36 | 1.42 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/b7fa5a8b-2075-4da7-bc5a-6ef6b2959d65/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/b7fa5a8b-2075-4da7-bc5a-6ef6b2959d65/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/b7fa5a8b-2075-4da7-bc5a-6ef6b2959d65/agent/trajectory.jsonl) |
| 58 | completed | 0 | 2056.37 | 1.34 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/322a95b8-5327-478b-9c8e-8e0123d3c675/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/322a95b8-5327-478b-9c8e-8e0123d3c675/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/322a95b8-5327-478b-9c8e-8e0123d3c675/agent/trajectory.jsonl) |
| 59 | completed | 0 | 810.86 | 1.40 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/4cb8b604-96a9-4030-9ce0-86e782da8e15/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/4cb8b604-96a9-4030-9ce0-86e782da8e15/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/4cb8b604-96a9-4030-9ce0-86e782da8e15/agent/trajectory.jsonl) |
| 60 | completed | 1 | 719.32 | 1.91 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/9e3a6d07-b933-4516-b04c-6b5b0edc5dc2/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/9e3a6d07-b933-4516-b04c-6b5b0edc5dc2/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/9e3a6d07-b933-4516-b04c-6b5b0edc5dc2/agent/trajectory.jsonl) |
| 61 | completed | 0 | 807.55 | 1.30 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/7d0b150a-4d09-44d0-b506-648114ca54bd/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/7d0b150a-4d09-44d0-b506-648114ca54bd/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/7d0b150a-4d09-44d0-b506-648114ca54bd/agent/trajectory.jsonl) |
| 62 | completed | 0 | 1151.37 | 1.37 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/159ef61a-41a8-497a-8e7a-6d5d421ed5aa/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/159ef61a-41a8-497a-8e7a-6d5d421ed5aa/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/159ef61a-41a8-497a-8e7a-6d5d421ed5aa/agent/trajectory.jsonl) |
| 63 | completed | 1 | 447.15 | 1.21 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/7bfaa2d9-3da0-4dd8-9984-160e85e92613/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/7bfaa2d9-3da0-4dd8-9984-160e85e92613/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/7bfaa2d9-3da0-4dd8-9984-160e85e92613/agent/trajectory.jsonl) |
| 64 | completed | 1 | 412.13 | 1.28 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/eb74465f-e27c-455c-9040-679493d65ea6/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/eb74465f-e27c-455c-9040-679493d65ea6/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/eb74465f-e27c-455c-9040-679493d65ea6/agent/trajectory.jsonl) |
| 65 | completed | 0 | 1551.65 | 1.24 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/4a90a88f-66a9-4f7d-adae-42bbe8d7294c/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/4a90a88f-66a9-4f7d-adae-42bbe8d7294c/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/4a90a88f-66a9-4f7d-adae-42bbe8d7294c/agent/trajectory.jsonl) |
| 66 | completed | 1 | 701.71 | 1.27 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/bb109f6a-0c94-4df9-acf7-85232b9e4954/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/bb109f6a-0c94-4df9-acf7-85232b9e4954/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/bb109f6a-0c94-4df9-acf7-85232b9e4954/agent/trajectory.jsonl) |
| 67 | completed | 1 | 827.67 | 1.31 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/afa91ceb-0fb6-4e1e-b866-473da81e8798/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/afa91ceb-0fb6-4e1e-b866-473da81e8798/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/afa91ceb-0fb6-4e1e-b866-473da81e8798/agent/trajectory.jsonl) |
| 68 | completed | 1 | 933.75 | 1.43 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/6f55297c-234c-4ad8-a3a7-0e6786b0f774/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/6f55297c-234c-4ad8-a3a7-0e6786b0f774/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/6f55297c-234c-4ad8-a3a7-0e6786b0f774/agent/trajectory.jsonl) |
| 69 | completed | 1 | 473.32 | 1.26 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/3e9de3fd-d748-4bfb-84fb-546dc8953ee1/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/3e9de3fd-d748-4bfb-84fb-546dc8953ee1/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/3e9de3fd-d748-4bfb-84fb-546dc8953ee1/agent/trajectory.jsonl) |
| 70 | timeout (agent) | 0 | 3594.38 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/e4845996-a069-4cd7-9687-43f0ca77976f/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/e4845996-a069-4cd7-9687-43f0ca77976f/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/e4845996-a069-4cd7-9687-43f0ca77976f/agent/trajectory.jsonl) |
| 71 | completed | 1 | 1697.61 | 1.44 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/ee98802b-d27d-48d5-b0ab-0b68a3108855/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/ee98802b-d27d-48d5-b0ab-0b68a3108855/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/ee98802b-d27d-48d5-b0ab-0b68a3108855/agent/trajectory.jsonl) |
| 72 | timeout (agent) | 0 | 3594.33 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/37ccc371-3805-4100-a842-9dc9a37f7010/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/37ccc371-3805-4100-a842-9dc9a37f7010/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/37ccc371-3805-4100-a842-9dc9a37f7010/agent/trajectory.jsonl) |
| 73 | completed | 1 | 2223.81 | 1.26 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/9d374df2-2b32-47eb-82ca-9d0d7a3706a9/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/9d374df2-2b32-47eb-82ca-9d0d7a3706a9/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/9d374df2-2b32-47eb-82ca-9d0d7a3706a9/agent/trajectory.jsonl) |
| 74 | completed | 0 | 743.01 | 1.26 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/12382b04-8076-4359-9837-9f47acb25015/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/12382b04-8076-4359-9837-9f47acb25015/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/12382b04-8076-4359-9837-9f47acb25015/agent/trajectory.jsonl) |
| 75 | timeout (agent) | 0 | 3595.04 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/d2785ed9-28c1-472d-af3d-1c330bd94fb5/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/d2785ed9-28c1-472d-af3d-1c330bd94fb5/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/d2785ed9-28c1-472d-af3d-1c330bd94fb5/agent/trajectory.jsonl) |
| 76 | completed | 0 | 241.11 | 1.19 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/14e6f438-efc0-4d42-a0b7-71bda0bf163a/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/14e6f438-efc0-4d42-a0b7-71bda0bf163a/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/14e6f438-efc0-4d42-a0b7-71bda0bf163a/agent/trajectory.jsonl) |
| 77 | completed | 0 | 2713.07 | 1.38 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/f7146ad3-b625-4732-93f9-8eb2d69a3002/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/f7146ad3-b625-4732-93f9-8eb2d69a3002/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/f7146ad3-b625-4732-93f9-8eb2d69a3002/agent/trajectory.jsonl) |
| 78 | completed | 1 | 275.78 | 1.37 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/ec48ad0f-908e-4a17-9ca2-8e6cde166a01/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/ec48ad0f-908e-4a17-9ca2-8e6cde166a01/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/ec48ad0f-908e-4a17-9ca2-8e6cde166a01/agent/trajectory.jsonl) |
| 79 | completed | 0 | 1084.37 | 1.36 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d240dfbd-de7d-41aa-93aa-1591ffd2b552/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d240dfbd-de7d-41aa-93aa-1591ffd2b552/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d240dfbd-de7d-41aa-93aa-1591ffd2b552/agent/trajectory.jsonl) |
| 80 | completed | 0 | 1933.62 | 1.43 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/cf91fb35-baa7-411d-b056-0ee1c6c46122/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/cf91fb35-baa7-411d-b056-0ee1c6c46122/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/cf91fb35-baa7-411d-b056-0ee1c6c46122/agent/trajectory.jsonl) |
| 81 | completed | 0 | 2821.18 | 1.28 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/ab9d711a-6379-4502-83df-a7f01bfd0707/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/ab9d711a-6379-4502-83df-a7f01bfd0707/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/ab9d711a-6379-4502-83df-a7f01bfd0707/agent/trajectory.jsonl) |
| 82 | timeout (agent) | 0 | 3594.81 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/a9d0ef75-8523-42d1-9920-1245883331a9/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/a9d0ef75-8523-42d1-9920-1245883331a9/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/a9d0ef75-8523-42d1-9920-1245883331a9/agent/trajectory.jsonl) |
| 83 | completed | 0 | 418.73 | 1.31 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/f07e4c55-4bd7-4fd6-9b2a-fa9f7d9f1f1f/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/f07e4c55-4bd7-4fd6-9b2a-fa9f7d9f1f1f/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/f07e4c55-4bd7-4fd6-9b2a-fa9f7d9f1f1f/agent/trajectory.jsonl) |
| 84 | completed | 1 | 1741.22 | 1.35 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/4ba765fb-abf1-4408-bc00-b596506e4cdd/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/4ba765fb-abf1-4408-bc00-b596506e4cdd/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/4ba765fb-abf1-4408-bc00-b596506e4cdd/agent/trajectory.jsonl) |
| 85 | timeout (agent) | 0 | 3594.94 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/a1ba0210-8ef8-4d27-ac35-d377f1879ba1/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/a1ba0210-8ef8-4d27-ac35-d377f1879ba1/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/a1ba0210-8ef8-4d27-ac35-d377f1879ba1/agent/trajectory.jsonl) |
| 86 | completed | 0 | 1700.73 | 1.28 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/8d402280-249a-4587-abca-dded96e3ba7c/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/8d402280-249a-4587-abca-dded96e3ba7c/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/8d402280-249a-4587-abca-dded96e3ba7c/agent/trajectory.jsonl) |
| 87 | completed | 1 | 434.00 | 1.29 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/9290a4ec-c2df-40d1-be60-2317e70b11f5/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/9290a4ec-c2df-40d1-be60-2317e70b11f5/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/9290a4ec-c2df-40d1-be60-2317e70b11f5/agent/trajectory.jsonl) |
| 88 | completed | 0 | 524.88 | 1.41 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/4f2455ac-d2b0-49e3-924d-0f2e8da60720/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/4f2455ac-d2b0-49e3-924d-0f2e8da60720/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/4f2455ac-d2b0-49e3-924d-0f2e8da60720/agent/trajectory.jsonl) |
| 89 | completed | 0 | 1116.80 | 1.34 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/fc50b25d-53bb-4bcf-9c16-c0e2148cd898/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/fc50b25d-53bb-4bcf-9c16-c0e2148cd898/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/fc50b25d-53bb-4bcf-9c16-c0e2148cd898/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 7；错误记录 7（主流程 7；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 7 | 7 |

## 警告

警告涉及 7 个任务，共 7 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 46 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 51 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 70 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 72 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 75 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 82 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 85 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

