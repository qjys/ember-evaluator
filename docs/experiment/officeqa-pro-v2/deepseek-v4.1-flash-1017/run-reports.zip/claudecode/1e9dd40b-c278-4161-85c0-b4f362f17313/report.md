<!-- snapshotDigest: c23212e5bf50a499c02b0d3f62ca61973ff9d97979561775d1f8d761714dc045 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 18.92%（14/74）**

Run: 1e9dd40b-c278-4161-85c0-b4f362f17313 · Status: cancelled

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T10:04:29.160Z / 2026-11-13T13:06:22.316Z |
| 总耗时 | 2 小时 55 分 52 秒 |
| 答对 / 答错 / 解题超时 | 14 / 2 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 16 / 0 |

已选择 90 题；已保存 32 条记录；待运行 59 题。
有效评分覆盖率：16/90（17.78%）。
执行失败 15；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 16。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 74 |
| 正常评分题数 | 16 |
| 答对题数 | 14 |
| 无效评测 | 16 |
| 待运行 | 59 |
| 正确率 | 18.92% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 小时 55 分 52 秒 |
| 环境准备耗时 | 3 小时 1 分 37 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 5 分 29 秒 | 33 秒 | 15 分 39 秒 | 32 |
| 任务准备 | 0.36 毫秒 | 0.23 毫秒 | 0.53 毫秒 | 32 |
| 环境启动 | 3 秒 | 3 秒 | 5 秒 | 32 |
| 解题 | 5 分 21 秒 | 27 秒 | 15 分 28 秒 | 32 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 16 |
| 证据收集 | 1 秒 | 551.02 毫秒 | 2 秒 | 32 |
| 资源清理 | 2 秒 | 2 秒 | 3 秒 | 32 |
| 评分 | 1 秒 | 909.42 毫秒 | 2 秒 | 16 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| d0682e01-1190-4177-95c3-c0896c64bc73 | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 32,183,468 | 967,674 | 33,151,142 | 16 / 90 | — |
| 运行累计 | 32,183,468 | 967,674 | 33,151,142 | 16 / 32 | 16 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 295.27 | 1.28 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/169cf1ba-8095-47c1-ad5e-c1f6419a2c62/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/169cf1ba-8095-47c1-ad5e-c1f6419a2c62/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/169cf1ba-8095-47c1-ad5e-c1f6419a2c62/agent/trajectory.jsonl) |
| 1 | completed | 1 | 144.23 | 1.42 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/b3e18df8-0e89-4bf9-a148-6731e7769b9e/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/b3e18df8-0e89-4bf9-a148-6731e7769b9e/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/b3e18df8-0e89-4bf9-a148-6731e7769b9e/agent/trajectory.jsonl) |
| 2 | completed | 1 | 530.50 | 1.07 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/f5ba8f5b-decb-49d0-b58d-be80cddffe86/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/f5ba8f5b-decb-49d0-b58d-be80cddffe86/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/f5ba8f5b-decb-49d0-b58d-be80cddffe86/agent/trajectory.jsonl) |
| 3 | completed | 1 | 335.44 | 1.14 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/9cccc771-b1bd-4bd3-a4d2-bfb6cdda7661/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/9cccc771-b1bd-4bd3-a4d2-bfb6cdda7661/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/9cccc771-b1bd-4bd3-a4d2-bfb6cdda7661/agent/trajectory.jsonl) |
| 4 | completed | 1 | 116.58 | 1.23 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/d60f2a1e-b559-443c-99d9-54491ccf3e17/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/d60f2a1e-b559-443c-99d9-54491ccf3e17/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/d60f2a1e-b559-443c-99d9-54491ccf3e17/agent/trajectory.jsonl) |
| 5 | completed | 1 | 111.69 | 0.98 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/088952e5-2831-42fd-abfe-8cab91b2c00f/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/088952e5-2831-42fd-abfe-8cab91b2c00f/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/088952e5-2831-42fd-abfe-8cab91b2c00f/agent/trajectory.jsonl) |
| 6 | completed | 1 | 268.63 | 1.07 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/cc5b6753-b57d-4307-b29f-c5df61ce9adc/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/cc5b6753-b57d-4307-b29f-c5df61ce9adc/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/cc5b6753-b57d-4307-b29f-c5df61ce9adc/agent/trajectory.jsonl) |
| 7 | completed | 1 | 137.99 | 1.28 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/40f5de61-583c-48c7-8457-495d42c2e662/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/40f5de61-583c-48c7-8457-495d42c2e662/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/40f5de61-583c-48c7-8457-495d42c2e662/agent/trajectory.jsonl) |
| 8 | completed | 0 | 482.03 | 1.57 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/0fa91a8d-368c-4245-8d3e-2998fea5f5da/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/0fa91a8d-368c-4245-8d3e-2998fea5f5da/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/0fa91a8d-368c-4245-8d3e-2998fea5f5da/agent/trajectory.jsonl) |
| 9 | completed | 1 | 71.95 | 0.93 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/60c3e5a4-45c3-4ba7-9808-e436b0048e3b/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/60c3e5a4-45c3-4ba7-9808-e436b0048e3b/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/60c3e5a4-45c3-4ba7-9808-e436b0048e3b/agent/trajectory.jsonl) |
| 10 | completed | 1 | 878.06 | 1.11 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/279c559e-db5c-4838-a8c3-89c3c86f2408/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/279c559e-db5c-4838-a8c3-89c3c86f2408/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/279c559e-db5c-4838-a8c3-89c3c86f2408/agent/trajectory.jsonl) |
| 11 | completed | 1 | 695.00 | 0.98 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/174bc192-eeb0-45d6-879f-24a98d5adfb7/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/174bc192-eeb0-45d6-879f-24a98d5adfb7/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/174bc192-eeb0-45d6-879f-24a98d5adfb7/agent/trajectory.jsonl) |
| 12 | completed | 1 | 613.27 | 1.04 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/33ddaaf3-11ac-4b64-8f3b-f0ee1026e30f/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/33ddaaf3-11ac-4b64-8f3b-f0ee1026e30f/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/33ddaaf3-11ac-4b64-8f3b-f0ee1026e30f/agent/trajectory.jsonl) |
| 13 | completed | 1 | 835.11 | 1.02 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/6e3a69b4-0c0c-4694-830b-6e0431755681/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/6e3a69b4-0c0c-4694-830b-6e0431755681/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/6e3a69b4-0c0c-4694-830b-6e0431755681/agent/trajectory.jsonl) |
| 14 | completed | 1 | 928.33 | 1.44 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/1318ff95-e9a2-4913-b0e8-5dfa15c94105/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/1318ff95-e9a2-4913-b0e8-5dfa15c94105/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/1318ff95-e9a2-4913-b0e8-5dfa15c94105/agent/trajectory.jsonl) |
| 15 | completed | 0 | 710.86 | 0.91 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/b2cf9f24-feeb-45be-95f2-382e7a9402d5/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/b2cf9f24-feeb-45be-95f2-382e7a9402d5/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/b2cf9f24-feeb-45be-95f2-382e7a9402d5/agent/trajectory.jsonl) |
| 16 | invalid | — | 557.84 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/c9e1d798-46d2-4a55-a8a3-00807f4ed2ae/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/c9e1d798-46d2-4a55-a8a3-00807f4ed2ae/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/c9e1d798-46d2-4a55-a8a3-00807f4ed2ae/agent/trajectory.jsonl) |
| 17 | invalid | — | 178.29 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/48f09f61-38c9-42aa-9152-11b8c98eaad5/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/48f09f61-38c9-42aa-9152-11b8c98eaad5/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/48f09f61-38c9-42aa-9152-11b8c98eaad5/agent/trajectory.jsonl) |
| 18 | invalid | — | 174.39 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/ac26f58d-36ca-41af-ada4-c6795e6b34fb/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/ac26f58d-36ca-41af-ada4-c6795e6b34fb/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/ac26f58d-36ca-41af-ada4-c6795e6b34fb/agent/trajectory.jsonl) |
| 19 | invalid | — | 180.51 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/547678f9-7db8-4ec1-a617-36aa1c07a8ce/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/547678f9-7db8-4ec1-a617-36aa1c07a8ce/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/547678f9-7db8-4ec1-a617-36aa1c07a8ce/agent/trajectory.jsonl) |
| 20 | invalid | — | 180.29 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/e0fabb33-0dfa-4676-a5c4-db74de6c3ea7/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/e0fabb33-0dfa-4676-a5c4-db74de6c3ea7/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/e0fabb33-0dfa-4676-a5c4-db74de6c3ea7/agent/trajectory.jsonl) |
| 21 | invalid | — | 170.29 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/f710e3f6-b059-4b53-bf71-30c2d6c1cbbe/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/f710e3f6-b059-4b53-bf71-30c2d6c1cbbe/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/f710e3f6-b059-4b53-bf71-30c2d6c1cbbe/agent/trajectory.jsonl) |
| 22 | invalid | — | 186.27 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/e037a0b4-7646-4d14-9908-926c6e973e2f/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/e037a0b4-7646-4d14-9908-926c6e973e2f/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/e037a0b4-7646-4d14-9908-926c6e973e2f/agent/trajectory.jsonl) |
| 23 | invalid | — | 181.16 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/a2484e0e-6c36-4940-81d0-ee5167205edf/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/a2484e0e-6c36-4940-81d0-ee5167205edf/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/a2484e0e-6c36-4940-81d0-ee5167205edf/agent/trajectory.jsonl) |
| 24 | invalid | — | 192.36 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/47c1bca7-cfd3-4509-93a3-94debc7be1bf/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/47c1bca7-cfd3-4509-93a3-94debc7be1bf/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/47c1bca7-cfd3-4509-93a3-94debc7be1bf/agent/trajectory.jsonl) |
| 25 | invalid | — | 184.26 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/89a3479e-4b21-42c3-ba4d-a2f30746f37d/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/89a3479e-4b21-42c3-ba4d-a2f30746f37d/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/89a3479e-4b21-42c3-ba4d-a2f30746f37d/agent/trajectory.jsonl) |
| 26 | invalid | — | 184.96 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/d603d0f6-2ad5-45ca-9e5c-6123ad77d7f0/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/d603d0f6-2ad5-45ca-9e5c-6123ad77d7f0/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/d603d0f6-2ad5-45ca-9e5c-6123ad77d7f0/agent/trajectory.jsonl) |
| 27 | invalid | — | 179.85 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/49ed1c87-38a6-4f4b-86c4-3b011aaa4f1a/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/49ed1c87-38a6-4f4b-86c4-3b011aaa4f1a/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/49ed1c87-38a6-4f4b-86c4-3b011aaa4f1a/agent/trajectory.jsonl) |
| 28 | invalid | — | 181.82 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/261b30d3-19a7-4349-96cd-6ee0acc419f1/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/261b30d3-19a7-4349-96cd-6ee0acc419f1/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/261b30d3-19a7-4349-96cd-6ee0acc419f1/agent/trajectory.jsonl) |
| 29 | invalid | — | 181.60 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/6023b575-455f-42c6-8cb7-ff1abf40074c/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/6023b575-455f-42c6-8cb7-ff1abf40074c/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/6023b575-455f-42c6-8cb7-ff1abf40074c/agent/trajectory.jsonl) |
| 30 | invalid | — | 173.38 | — | partial / complete | NETWORK\_FAILURE | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/dc6c8334-9bb6-4ed7-a6e8-e74d26acad83/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/dc6c8334-9bb6-4ed7-a6e8-e74d26acad83/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/dc6c8334-9bb6-4ed7-a6e8-e74d26acad83/agent/trajectory.jsonl) |
| 31 | cancelled | — | 26.81 | — | partial / complete | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/6f731b8a-a2fa-450f-9623-baabdb363909/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/6f731b8a-a2fa-450f-9623-baabdb363909/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/6f731b8a-a2fa-450f-9623-baabdb363909/agent/trajectory.jsonl) |
| 32 | pending | — | — | — | — | — | — |
| 33 | pending | — | — | — | — | — | — |
| 34 | pending | — | — | — | — | — | — |
| 35 | pending | — | — | — | — | — | — |
| 36 | pending | — | — | — | — | — | — |
| 37 | pending | — | — | — | — | — | — |
| 38 | pending | — | — | — | — | — | — |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 16；错误记录 17（主流程 16；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | NETWORK_FAILURE | 15 | 15 |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 警告

警告涉及 15 个任务，共 15 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 16 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 17 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 18 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 19 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 20 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 21 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 22 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 23 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 24 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 25 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 26 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 27 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 28 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 29 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |
| 30 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Network failure ended the solver trajectory before completion |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

