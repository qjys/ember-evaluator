<!-- snapshotDigest: 0cd0f403b69db1d5fdb405bf79de3259812ba38daf518108e9650d42f2679e34 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 0.00%（0/4）**

Run: ba9aa180-a773-4ea3-ac2e-5efe2e6ce378 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-15T04:19:56.442Z / 2026-11-15T10:31:35.827Z |
| 总耗时 | 5 小时 58 分 48 秒 |
| 答对 / 答错 / 解题超时 | 0 / 4 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 4 题；已保存 4 条记录；待运行 0 题。
有效评分覆盖率：4/4（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 4 |
| 计分题数 | 4 |
| 正常评分题数 | 4 |
| 答对题数 | 0 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 0.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 小时 58 分 48 秒 |
| 环境准备耗时 | 44 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 小时 29 分 34 秒 | 41 分 49 秒 | 2 小时 30 分 12 秒 | 4 |
| 任务准备 | 0.48 毫秒 | 0.35 毫秒 | 0.77 毫秒 | 4 |
| 环境启动 | 6 秒 | 5 秒 | 7 秒 | 4 |
| 解题 | 1 小时 29 分 20 秒 | 41 分 36 秒 | 2 小时 29 分 57 秒 | 4 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 4 |
| 证据收集 | 1 秒 | 1 秒 | 2 秒 | 4 |
| 资源清理 | 3 秒 | 3 秒 | 4 秒 | 4 |
| 评分 | 1 秒 | 1 秒 | 1 秒 | 4 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 2d313696-a9c2-4ff1-a813-4a48777d2cf4 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 66,132,583 | 3,193,476 | 69,326,059 | 4 / 4 | — |
| 运行累计 | 66,132,583 | 3,193,476 | 69,326,059 | 4 / 4 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 72 | completed | 0 | 2495.82 | 1.37 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/a33e341b-71ef-4f84-ab46-68e858aca4ba/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/a33e341b-71ef-4f84-ab46-68e858aca4ba/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/a33e341b-71ef-4f84-ab46-68e858aca4ba/agent/trajectory.jsonl) |
| 75 | completed | 0 | 8997.11 | 1.23 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/60e28dbe-494c-42ab-9b78-b80317e585f5/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/60e28dbe-494c-42ab-9b78-b80317e585f5/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/60e28dbe-494c-42ab-9b78-b80317e585f5/agent/trajectory.jsonl) |
| 82 | completed | 0 | 6508.47 | 1.26 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/6b3267b5-f0fb-4a91-ab46-86ebbe0a2796/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/6b3267b5-f0fb-4a91-ab46-86ebbe0a2796/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/6b3267b5-f0fb-4a91-ab46-86ebbe0a2796/agent/trajectory.jsonl) |
| 85 | completed | 0 | 3437.66 | 1.33 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/a7119526-5a9d-42b5-bd15-4a39dffd4e0c/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/a7119526-5a9d-42b5-bd15-4a39dffd4e0c/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/a7119526-5a9d-42b5-bd15-4a39dffd4e0c/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

