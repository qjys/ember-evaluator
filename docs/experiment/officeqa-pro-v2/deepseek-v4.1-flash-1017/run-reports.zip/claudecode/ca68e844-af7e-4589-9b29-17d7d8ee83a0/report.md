<!-- snapshotDigest: f6db74074ab1cef5a521b22d253c0ae4f9a0a819ae558c5cc91520394490b9ff -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 0.00%（0/1）**

Run: ca68e844-af7e-4589-9b29-17d7d8ee83a0 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-15T06:09:56.820Z / 2026-11-15T10:19:15.471Z |
| 总耗时 | 4 小时 0 分 43 秒 |
| 答对 / 答错 / 解题超时 | 0 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 1 题；已保存 1 条记录；待运行 0 题。
有效评分覆盖率：1/1（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 1 |
| 计分题数 | 1 |
| 正常评分题数 | 1 |
| 答对题数 | 0 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 0.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 4 小时 0 分 43 秒 |
| 环境准备耗时 | 12 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 4 小时 0 分 20 秒 | 4 小时 0 分 20 秒 | 4 小时 0 分 20 秒 | 1 |
| 任务准备 | 0.45 毫秒 | 0.45 毫秒 | 0.45 毫秒 | 1 |
| 环境启动 | 5 秒 | 5 秒 | 5 秒 | 1 |
| 解题 | 4 小时 0 分 0 秒 | 4 小时 0 分 0 秒 | 4 小时 0 分 0 秒 | 1 |
| 产物传输 | 3 秒 | 3 秒 | 3 秒 | 1 |
| 证据收集 | 7 秒 | 7 秒 | 7 秒 | 1 |
| 资源清理 | 4 秒 | 4 秒 | 4 秒 | 1 |
| 评分 | 1 秒 | 1 秒 | 1 秒 | 1 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 62041758-3b18-45b7-92d1-0294d70c8f1c | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | — | — | 0 / 1 | — |
| 运行累计 | — | — | — | 0 / 1 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 46 | completed | 0 | 14400.02 | 1.40 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/bd845148-8915-4ef4-a6b4-d17fcd4d94b2/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/bd845148-8915-4ef4-a6b4-d17fcd4d94b2/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/bd845148-8915-4ef4-a6b4-d17fcd4d94b2/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 1（主流程 1；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 46 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

