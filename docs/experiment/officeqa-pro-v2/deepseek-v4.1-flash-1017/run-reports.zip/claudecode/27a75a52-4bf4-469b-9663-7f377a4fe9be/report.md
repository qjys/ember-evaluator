<!-- snapshotDigest: b41cfa60e2dd642fd11904c77d48bd5fa621c31fe273810f4642d9797a0adc5d -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 28.77%（21/73）**

Run: 27a75a52-4bf4-469b-9663-7f377a4fe9be · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T13:17:02.713Z / 2026-11-13T23:02:43.486Z |
| 总耗时 | 9 小时 25 分 45 秒 |
| 答对 / 答错 / 解题超时 | 21 / 7 / 2 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 3 / 0 |

已选择 74 题；已保存 31 条记录；待运行 43 题。
有效评分覆盖率：30/74（40.54%）。
执行失败 1；超时 2；取消 0；不支持 0。
Agent 解题超时 2（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 74 |
| 计分题数 | 73 |
| 正常评分题数 | 28 |
| 答对题数 | 21 |
| 无效评测 | 1 |
| 待运行 | 43 |
| 正确率 | 28.77% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 25 分 45 秒 |
| 环境准备耗时 | 9 小时 45 分 27 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 18 分 14 秒 | 57 秒 | 1 小时 0 分 5 秒 | 31 |
| 任务准备 | 0.44 毫秒 | 0.25 毫秒 | 1.17 毫秒 | 31 |
| 环境启动 | 4 秒 | 3 秒 | 7 秒 | 31 |
| 解题 | 18 分 4 秒 | 45 秒 | 59 分 57 秒 | 31 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 28 |
| 证据收集 | 985.58 毫秒 | 533.65 毫秒 | 3 秒 | 31 |
| 资源清理 | 3 秒 | 2 秒 | 6 秒 | 31 |
| 评分 | 1 秒 | 952.96 毫秒 | 2 秒 | 28 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 75d15631-e220-4804-a870-a716104d1142 | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 112,672,829 | 3,350,276 | 116,023,105 | 28 / 74 | — |
| 运行累计 | 112,672,829 | 3,350,276 | 116,023,105 | 28 / 31 | 3 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 16 | completed | 1 | 1714.54 | 1.08 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/4b5b7bca-93f1-4984-af30-ad92a8538e38/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/4b5b7bca-93f1-4984-af30-ad92a8538e38/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/4b5b7bca-93f1-4984-af30-ad92a8538e38/agent/trajectory.jsonl) |
| 17 | completed | 1 | 286.16 | 1.14 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/3b6ff865-8fa4-41be-badf-3ce3c11ea6f0/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/3b6ff865-8fa4-41be-badf-3ce3c11ea6f0/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/3b6ff865-8fa4-41be-badf-3ce3c11ea6f0/agent/trajectory.jsonl) |
| 18 | completed | 1 | 2137.60 | 1.22 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/7ed1b8e0-4aa4-4d77-8ced-1b03aa99cd2b/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/7ed1b8e0-4aa4-4d77-8ced-1b03aa99cd2b/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/7ed1b8e0-4aa4-4d77-8ced-1b03aa99cd2b/agent/trajectory.jsonl) |
| 19 | completed | 1 | 1414.97 | 1.45 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/cbc7260e-5223-47db-8770-a5554a181668/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/cbc7260e-5223-47db-8770-a5554a181668/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/cbc7260e-5223-47db-8770-a5554a181668/agent/trajectory.jsonl) |
| 20 | completed | 1 | 616.83 | 1.08 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/0249db23-a119-46e0-9a2c-e30cb343eb09/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/0249db23-a119-46e0-9a2c-e30cb343eb09/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/0249db23-a119-46e0-9a2c-e30cb343eb09/agent/trajectory.jsonl) |
| 21 | completed | 1 | 981.32 | 1.19 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/83d853f9-64f2-4dfe-8f3e-aaedd670b8a7/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/83d853f9-64f2-4dfe-8f3e-aaedd670b8a7/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/83d853f9-64f2-4dfe-8f3e-aaedd670b8a7/agent/trajectory.jsonl) |
| 22 | completed | 1 | 269.66 | 1.15 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/a6467394-a05e-4701-82b8-ba3a21610029/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/a6467394-a05e-4701-82b8-ba3a21610029/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/a6467394-a05e-4701-82b8-ba3a21610029/agent/trajectory.jsonl) |
| 23 | completed | 1 | 463.47 | 2.30 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/03ceaf74-76b3-4c97-95f3-3618bcca57a2/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/03ceaf74-76b3-4c97-95f3-3618bcca57a2/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/03ceaf74-76b3-4c97-95f3-3618bcca57a2/agent/trajectory.jsonl) |
| 24 | completed | 0 | 1564.54 | 1.19 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/a9a1d9ea-cae3-40cf-b705-2853af375349/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/a9a1d9ea-cae3-40cf-b705-2853af375349/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/a9a1d9ea-cae3-40cf-b705-2853af375349/agent/trajectory.jsonl) |
| 25 | completed | 1 | 458.80 | 1.38 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/80edc3fd-c39d-43c9-8912-30cb61c288ca/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/80edc3fd-c39d-43c9-8912-30cb61c288ca/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/80edc3fd-c39d-43c9-8912-30cb61c288ca/agent/trajectory.jsonl) |
| 26 | completed | 1 | 857.91 | 1.04 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/ca56a0e9-ebe0-4d68-a2fe-56b5e18e070e/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/ca56a0e9-ebe0-4d68-a2fe-56b5e18e070e/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/ca56a0e9-ebe0-4d68-a2fe-56b5e18e070e/agent/trajectory.jsonl) |
| 27 | completed | 1 | 1098.49 | 1.14 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/93f08c30-2e7c-4d53-a791-9527cffd6f6e/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/93f08c30-2e7c-4d53-a791-9527cffd6f6e/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/93f08c30-2e7c-4d53-a791-9527cffd6f6e/agent/trajectory.jsonl) |
| 28 | completed | 1 | 2848.10 | 2.13 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/95353e69-6d60-409f-9eee-cd2e5edd10d2/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/95353e69-6d60-409f-9eee-cd2e5edd10d2/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/95353e69-6d60-409f-9eee-cd2e5edd10d2/agent/trajectory.jsonl) |
| 29 | completed | 1 | 2307.07 | 1.52 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/804cb0e3-4282-40ae-a2ac-2d2f0dd0b025/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/804cb0e3-4282-40ae-a2ac-2d2f0dd0b025/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/804cb0e3-4282-40ae-a2ac-2d2f0dd0b025/agent/trajectory.jsonl) |
| 30 | completed | 0 | 1423.53 | 1.16 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/5f8c2fc5-9a95-401a-ad76-96ffdd63035a/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/5f8c2fc5-9a95-401a-ad76-96ffdd63035a/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/5f8c2fc5-9a95-401a-ad76-96ffdd63035a/agent/trajectory.jsonl) |
| 31 | completed | 1 | 44.68 | 1.43 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/a4dda2ba-10ad-4b1a-bb92-5f857ba45646/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/a4dda2ba-10ad-4b1a-bb92-5f857ba45646/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/a4dda2ba-10ad-4b1a-bb92-5f857ba45646/agent/trajectory.jsonl) |
| 32 | completed | 0 | 419.38 | 1.21 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/4a9916a3-f886-4b9c-8791-3e32ce09c051/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/4a9916a3-f886-4b9c-8791-3e32ce09c051/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/4a9916a3-f886-4b9c-8791-3e32ce09c051/agent/trajectory.jsonl) |
| 33 | completed | 1 | 556.91 | 1.48 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/b9278884-2f91-49ee-83ac-33a4edcaf044/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/b9278884-2f91-49ee-83ac-33a4edcaf044/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/b9278884-2f91-49ee-83ac-33a4edcaf044/agent/trajectory.jsonl) |
| 34 | completed | 0 | 718.17 | 1.28 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/dc34349e-1c6e-4d08-ac00-17f404c236ff/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/dc34349e-1c6e-4d08-ac00-17f404c236ff/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/dc34349e-1c6e-4d08-ac00-17f404c236ff/agent/trajectory.jsonl) |
| 35 | completed | 1 | 148.44 | 1.41 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/462e5e58-8afb-467b-aad2-332aae9ad5b1/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/462e5e58-8afb-467b-aad2-332aae9ad5b1/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/462e5e58-8afb-467b-aad2-332aae9ad5b1/agent/trajectory.jsonl) |
| 36 | timeout (agent) | 0 | 3595.32 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/fd149f83-b8ef-4e9c-8a07-4dbb171c9258/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/fd149f83-b8ef-4e9c-8a07-4dbb171c9258/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/fd149f83-b8ef-4e9c-8a07-4dbb171c9258/agent/trajectory.jsonl) |
| 37 | completed | 1 | 248.19 | 1.07 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/d810cc01-9c6b-432f-b2cc-a4dced768eba/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/d810cc01-9c6b-432f-b2cc-a4dced768eba/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/d810cc01-9c6b-432f-b2cc-a4dced768eba/agent/trajectory.jsonl) |
| 38 | timeout (agent) | 0 | 3596.99 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/9742525b-bb9f-48ec-bdd3-ae8a883b4b41/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/9742525b-bb9f-48ec-bdd3-ae8a883b4b41/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/9742525b-bb9f-48ec-bdd3-ae8a883b4b41/agent/trajectory.jsonl) |
| 39 | completed | 1 | 2502.12 | 1.30 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/8c8d9808-7170-4f48-be2c-0d9234abed6c/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/8c8d9808-7170-4f48-be2c-0d9234abed6c/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/8c8d9808-7170-4f48-be2c-0d9234abed6c/agent/trajectory.jsonl) |
| 40 | completed | 0 | 103.26 | 1.18 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/b71be80b-434a-404f-8a1f-1031d81c2754/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/b71be80b-434a-404f-8a1f-1031d81c2754/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/b71be80b-434a-404f-8a1f-1031d81c2754/agent/trajectory.jsonl) |
| 41 | completed | 1 | 256.88 | 1.08 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/b2d069e7-9acb-4c4b-ada8-0116e95bf43e/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/b2d069e7-9acb-4c4b-ada8-0116e95bf43e/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/b2d069e7-9acb-4c4b-ada8-0116e95bf43e/agent/trajectory.jsonl) |
| 42 | completed | 1 | 800.23 | 1.11 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/93fd1177-82c5-47fe-9b0d-94392b5e2676/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/93fd1177-82c5-47fe-9b0d-94392b5e2676/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/93fd1177-82c5-47fe-9b0d-94392b5e2676/agent/trajectory.jsonl) |
| 43 | completed | 0 | 267.45 | 1.02 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/4d8af3ba-4f99-4b72-8a7e-2a41233321ba/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/4d8af3ba-4f99-4b72-8a7e-2a41233321ba/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/4d8af3ba-4f99-4b72-8a7e-2a41233321ba/agent/trajectory.jsonl) |
| 44 | completed | 1 | 498.14 | 0.95 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/d7293732-5b46-40a5-b032-bff1dac3191e/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/d7293732-5b46-40a5-b032-bff1dac3191e/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/d7293732-5b46-40a5-b032-bff1dac3191e/agent/trajectory.jsonl) |
| 45 | completed | 0 | 345.11 | 1.10 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/70398ec9-aad5-4ce5-b968-434016643a06/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/70398ec9-aad5-4ce5-b968-434016643a06/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/70398ec9-aad5-4ce5-b968-434016643a06/agent/trajectory.jsonl) |
| 46 | invalid | — | 1048.07 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/47e860e4-ff44-405e-aff7-e553364a6b86/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/47e860e4-ff44-405e-aff7-e553364a6b86/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/47e860e4-ff44-405e-aff7-e553364a6b86/agent/trajectory.jsonl) |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 3；错误记录 4（主流程 3；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 2 | 2 |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 警告

警告涉及 2 个任务，共 2 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 36 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 38 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

