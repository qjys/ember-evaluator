<!-- snapshotDigest: e694b2e9eb75e358a878086024ac26bed42f56b721bed17958d70a69959a0231 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 0.00%（0/6）**

Run: 7037802c-7110-4f23-8e85-18597f1ad0b6 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-14T16:22:13.307Z / 2026-11-15T02:54:44.043Z |
| 总耗时 | 10 小时 10 分 1 秒 |
| 答对 / 答错 / 解题超时 | 0 / 6 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 3 / 0 |

已选择 7 题；已保存 7 条记录；待运行 0 题。
有效评分覆盖率：6/7（85.71%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 7 |
| 计分题数 | 6 |
| 正常评分题数 | 6 |
| 答对题数 | 0 |
| 无效评测 | 1 |
| 待运行 | 0 |
| 正确率 | 0.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 10 小时 10 分 1 秒 |
| 环境准备耗时 | 1 分 25 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 1 小时 27 分 2 秒 | 47 分 18 秒 | 2 小时 0 分 13 秒 | 7 |
| 任务准备 | 0.51 毫秒 | 0.21 毫秒 | 1.28 毫秒 | 7 |
| 环境启动 | 6 秒 | 5 秒 | 11 秒 | 7 |
| 解题 | 1 小时 26 分 45 秒 | 47 分 6 秒 | 2 小时 0 分 0 秒 | 7 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 6 |
| 证据收集 | 6 秒 | 961.89 毫秒 | 33 秒 | 7 |
| 资源清理 | 3 秒 | 3 秒 | 3 秒 | 7 |
| 评分 | 1 秒 | 1 秒 | 1 秒 | 6 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 11160e67-8af3-48d7-a1f4-09838288e345 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 51,658,584 | 2,200,600 | 53,859,184 | 4 / 7 | — |
| 运行累计 | 51,658,584 | 2,200,600 | 53,859,184 | 4 / 7 | 3 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 36 | completed | 0 | 3391.67 | 1.28 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/f3c960f3-99ae-4d11-bcfe-fe24920d1ede/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/f3c960f3-99ae-4d11-bcfe-fe24920d1ede/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/f3c960f3-99ae-4d11-bcfe-fe24920d1ede/agent/trajectory.jsonl) |
| 38 | completed | 0 | 3940.19 | 1.33 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/db87c1ed-ec82-4a5a-aad2-cbabed7546ea/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/db87c1ed-ec82-4a5a-aad2-cbabed7546ea/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/db87c1ed-ec82-4a5a-aad2-cbabed7546ea/agent/trajectory.jsonl) |
| 46 | invalid | — | 5369.58 | — | partial / complete | SOLVER\_OUTPUT\_LIMIT; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/6bafb7bb-d4f1-4a17-9768-310181c9a21c/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/6bafb7bb-d4f1-4a17-9768-310181c9a21c/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/6bafb7bb-d4f1-4a17-9768-310181c9a21c/agent/trajectory.jsonl) |
| 51 | completed | 0 | 6506.61 | 1.34 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/dc7b99db-2ee5-436a-8f2b-6a60a50c8aea/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/dc7b99db-2ee5-436a-8f2b-6a60a50c8aea/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/dc7b99db-2ee5-436a-8f2b-6a60a50c8aea/agent/trajectory.jsonl) |
| 70 | completed | 0 | 2825.75 | 1.23 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/cb04474f-6f27-4fca-91ed-82410861aeab/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/cb04474f-6f27-4fca-91ed-82410861aeab/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/cb04474f-6f27-4fca-91ed-82410861aeab/agent/trajectory.jsonl) |
| 72 | completed | 0 | 7200.01 | 1.15 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/a74482a4-fdae-4bdd-a0cf-3a19678272e4/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/a74482a4-fdae-4bdd-a0cf-3a19678272e4/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/a74482a4-fdae-4bdd-a0cf-3a19678272e4/agent/trajectory.jsonl) |
| 75 | completed | 0 | 7200.01 | 1.18 | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/e0271788-5b49-4e52-82c5-7c3dde903c19/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/e0271788-5b49-4e52-82c5-7c3dde903c19/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/e0271788-5b49-4e52-82c5-7c3dde903c19/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 3；错误记录 4（主流程 3；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_OUTPUT_LIMIT | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |
| solve | SOLVER_AGENT_TIMEOUT | 2 | 2 |

## 警告

警告涉及 2 个任务，共 2 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 72 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |
| 75 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

