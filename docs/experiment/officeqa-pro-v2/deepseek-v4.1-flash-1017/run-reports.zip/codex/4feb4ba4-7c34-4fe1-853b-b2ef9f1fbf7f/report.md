<!-- snapshotDigest: 732619a10f20f201cb7b839e9aa32cf5413ade66541bb89a9b1d5bcdb50157d7 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 25.84%（23/89）**

Run: 4feb4ba4-7c34-4fe1-853b-b2ef9f1fbf7f · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T10:09:59.794Z / 2026-11-13T12:17:37.985Z |
| 总耗时 | 2 小时 3 分 26 秒 |
| 答对 / 答错 / 解题超时 | 23 / 4 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 28 条记录；待运行 62 题。
有效评分覆盖率：27/90（30.00%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 27 |
| 答对题数 | 23 |
| 无效评测 | 1 |
| 待运行 | 62 |
| 正确率 | 25.84% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 2 小时 3 分 26 秒 |
| 环境准备耗时 | 2 小时 7 分 22 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 4 分 16 秒 | 45 秒 | 19 分 46 秒 | 28 |
| 任务准备 | 0.53 毫秒 | 0.26 毫秒 | 1.23 毫秒 | 28 |
| 环境启动 | 3 秒 | 3 秒 | 5 秒 | 28 |
| 解题 | 4 分 7 秒 | 37 秒 | 19 分 39 秒 | 28 |
| 产物传输 | 1 秒 | 996.82 毫秒 | 2 秒 | 27 |
| 证据收集 | 744.55 毫秒 | 525.33 毫秒 | 2 秒 | 28 |
| 资源清理 | 2 秒 | 2 秒 | 4 秒 | 28 |
| 评分 | 1 秒 | 875.48 毫秒 | 2 秒 | 27 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 8ac31745-bf2a-41eb-bde7-45217e8a760e | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 66,720,404 | 717,639 | 67,438,043 | 27 / 90 | — |
| 运行累计 | 66,720,404 | 717,639 | 67,438,043 | 27 / 28 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 88.79 | 1.80 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/b430f083-c9cf-455a-9d79-055c95240efe/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/b430f083-c9cf-455a-9d79-055c95240efe/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/b430f083-c9cf-455a-9d79-055c95240efe/agent/trajectory.jsonl) |
| 1 | completed | 1 | 65.30 | 1.45 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/4d6d5447-0407-49b6-a84e-75c2e0c7f154/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/4d6d5447-0407-49b6-a84e-75c2e0c7f154/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/4d6d5447-0407-49b6-a84e-75c2e0c7f154/agent/trajectory.jsonl) |
| 2 | completed | 1 | 179.82 | 1.09 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/e220ad8c-5e8d-4bfe-a49a-f335b12fae19/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/e220ad8c-5e8d-4bfe-a49a-f335b12fae19/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/e220ad8c-5e8d-4bfe-a49a-f335b12fae19/agent/trajectory.jsonl) |
| 3 | completed | 0 | 340.62 | 0.94 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/16acc484-274b-4786-be5f-91e8438753b7/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/16acc484-274b-4786-be5f-91e8438753b7/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/16acc484-274b-4786-be5f-91e8438753b7/agent/trajectory.jsonl) |
| 4 | completed | 1 | 67.65 | 1.08 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/e79aea3a-82af-42a8-b246-ea68660e71f5/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/e79aea3a-82af-42a8-b246-ea68660e71f5/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/e79aea3a-82af-42a8-b246-ea68660e71f5/agent/trajectory.jsonl) |
| 5 | completed | 1 | 398.84 | 1.67 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/1f6246f0-36f5-4905-aa35-71c7499b10ae/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/1f6246f0-36f5-4905-aa35-71c7499b10ae/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/1f6246f0-36f5-4905-aa35-71c7499b10ae/agent/trajectory.jsonl) |
| 6 | completed | 1 | 144.60 | 0.97 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/54753686-cac5-4963-b1ab-ddc0e3a18b77/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/54753686-cac5-4963-b1ab-ddc0e3a18b77/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/54753686-cac5-4963-b1ab-ddc0e3a18b77/agent/trajectory.jsonl) |
| 7 | completed | 1 | 98.08 | 0.97 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/abe3406a-f1ec-4b6b-a770-7cd5fa01c9a3/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/abe3406a-f1ec-4b6b-a770-7cd5fa01c9a3/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/abe3406a-f1ec-4b6b-a770-7cd5fa01c9a3/agent/trajectory.jsonl) |
| 8 | completed | 0 | 187.31 | 0.88 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/6b2d24a0-a7d6-4f6f-818c-3bde5eedbce1/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/6b2d24a0-a7d6-4f6f-818c-3bde5eedbce1/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/6b2d24a0-a7d6-4f6f-818c-3bde5eedbce1/agent/trajectory.jsonl) |
| 9 | completed | 1 | 37.60 | 0.92 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/271fc2f4-3a2d-458b-9212-809dcfee77db/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/271fc2f4-3a2d-458b-9212-809dcfee77db/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/271fc2f4-3a2d-458b-9212-809dcfee77db/agent/trajectory.jsonl) |
| 10 | completed | 1 | 177.48 | 1.16 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/3cb57681-404c-429e-9ba1-d32f184b01d5/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/3cb57681-404c-429e-9ba1-d32f184b01d5/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/3cb57681-404c-429e-9ba1-d32f184b01d5/agent/trajectory.jsonl) |
| 11 | completed | 1 | 108.23 | 0.97 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/51f4de9e-9804-42a6-962a-526e0203e2b0/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/51f4de9e-9804-42a6-962a-526e0203e2b0/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/51f4de9e-9804-42a6-962a-526e0203e2b0/agent/trajectory.jsonl) |
| 12 | completed | 1 | 95.93 | 0.96 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/2db1a264-b291-4068-8bc2-a698a84db13b/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/2db1a264-b291-4068-8bc2-a698a84db13b/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/2db1a264-b291-4068-8bc2-a698a84db13b/agent/trajectory.jsonl) |
| 13 | completed | 1 | 235.66 | 0.90 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/5d6aa622-2bbe-460c-8a9f-44efc07c2d99/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/5d6aa622-2bbe-460c-8a9f-44efc07c2d99/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/5d6aa622-2bbe-460c-8a9f-44efc07c2d99/agent/trajectory.jsonl) |
| 14 | completed | 1 | 36.97 | 0.97 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/0f961441-8285-4fe1-8e3c-6bb04ec4f132/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/0f961441-8285-4fe1-8e3c-6bb04ec4f132/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/0f961441-8285-4fe1-8e3c-6bb04ec4f132/agent/trajectory.jsonl) |
| 15 | completed | 0 | 214.20 | 1.03 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/00250e3b-200c-4a5d-8f6e-a6bee61f9fa7/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/00250e3b-200c-4a5d-8f6e-a6bee61f9fa7/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/00250e3b-200c-4a5d-8f6e-a6bee61f9fa7/agent/trajectory.jsonl) |
| 16 | completed | 1 | 215.80 | 1.08 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/31e3ba5d-a876-4d23-ae53-2f1d2d946e6c/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/31e3ba5d-a876-4d23-ae53-2f1d2d946e6c/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/31e3ba5d-a876-4d23-ae53-2f1d2d946e6c/agent/trajectory.jsonl) |
| 17 | completed | 1 | 225.07 | 1.00 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/1fedae1a-b906-46eb-9854-b61bc9013271/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/1fedae1a-b906-46eb-9854-b61bc9013271/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/1fedae1a-b906-46eb-9854-b61bc9013271/agent/trajectory.jsonl) |
| 18 | completed | 1 | 534.47 | 1.07 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/16f96073-874a-4057-957a-babf10718e01/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/16f96073-874a-4057-957a-babf10718e01/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/16f96073-874a-4057-957a-babf10718e01/agent/trajectory.jsonl) |
| 19 | completed | 1 | 314.97 | 0.99 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/d82ce848-f713-4a1e-9413-73244200455a/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/d82ce848-f713-4a1e-9413-73244200455a/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/d82ce848-f713-4a1e-9413-73244200455a/agent/trajectory.jsonl) |
| 20 | completed | 1 | 196.59 | 1.09 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/230b85e4-f159-49ca-b55d-1391f4750c4c/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/230b85e4-f159-49ca-b55d-1391f4750c4c/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/230b85e4-f159-49ca-b55d-1391f4750c4c/agent/trajectory.jsonl) |
| 21 | completed | 1 | 135.02 | 1.07 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/6b2d8618-3498-4c2c-b79d-f90e711e4382/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/6b2d8618-3498-4c2c-b79d-f90e711e4382/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/6b2d8618-3498-4c2c-b79d-f90e711e4382/agent/trajectory.jsonl) |
| 22 | completed | 1 | 78.71 | 1.05 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/f0298270-a9da-4b62-b0e3-ff3ef1d22859/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/f0298270-a9da-4b62-b0e3-ff3ef1d22859/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/f0298270-a9da-4b62-b0e3-ff3ef1d22859/agent/trajectory.jsonl) |
| 23 | completed | 1 | 181.31 | 0.98 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/dc29ee5e-5f43-497b-906a-6a2583a9a12b/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/dc29ee5e-5f43-497b-906a-6a2583a9a12b/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/dc29ee5e-5f43-497b-906a-6a2583a9a12b/agent/trajectory.jsonl) |
| 24 | completed | 0 | 619.93 | 1.27 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/59eaa721-92e8-4246-8531-19b1350d7c80/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/59eaa721-92e8-4246-8531-19b1350d7c80/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/59eaa721-92e8-4246-8531-19b1350d7c80/agent/trajectory.jsonl) |
| 25 | completed | 1 | 174.05 | 0.98 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/6fae1ac7-1c8f-403f-8e4c-8abf7882cdd9/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/6fae1ac7-1c8f-403f-8e4c-8abf7882cdd9/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/6fae1ac7-1c8f-403f-8e4c-8abf7882cdd9/agent/trajectory.jsonl) |
| 26 | completed | 1 | 1178.57 | 0.93 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/4b337e57-ad5a-4951-8cfd-835e31403842/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/4b337e57-ad5a-4951-8cfd-835e31403842/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/4b337e57-ad5a-4951-8cfd-835e31403842/agent/trajectory.jsonl) |
| 27 | invalid | — | 585.99 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/1a88b4eb-7982-4af1-950f-7fb32d0e3756/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/1a88b4eb-7982-4af1-950f-7fb32d0e3756/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/1a88b4eb-7982-4af1-950f-7fb32d0e3756/agent/trajectory.jsonl) |
| 28 | pending | — | — | — | — | — | — |
| 29 | pending | — | — | — | — | — | — |
| 30 | pending | — | — | — | — | — | — |
| 31 | pending | — | — | — | — | — | — |
| 32 | pending | — | — | — | — | — | — |
| 33 | pending | — | — | — | — | — | — |
| 34 | pending | — | — | — | — | — | — |
| 35 | pending | — | — | — | — | — | — |
| 36 | pending | — | — | — | — | — | — |
| 37 | pending | — | — | — | — | — | — |
| 38 | pending | — | — | — | — | — | — |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

