<!-- snapshotDigest: 1193461c89c69f41b4c10c8a9049dbfc45516a96266dd36e1256b77248079305 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 50.00%（1/2）**

Run: 41f1fd0e-84e6-4759-9414-46f864d80b13 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-14T02:32:45.872Z / 2026-11-14T02:57:33.648Z |
| 总耗时 | 23 分 57 秒 |
| 答对 / 答错 / 解题超时 | 1 / 1 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 2 题；已保存 2 条记录；待运行 0 题。
有效评分覆盖率：2/2（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 2 |
| 计分题数 | 2 |
| 正常评分题数 | 2 |
| 答对题数 | 1 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 50.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 23 分 57 秒 |
| 环境准备耗时 | 39 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 11 分 40 秒 | 5 分 36 秒 | 17 分 44 秒 | 2 |
| 任务准备 | 0.66 毫秒 | 0.65 毫秒 | 0.67 毫秒 | 2 |
| 环境启动 | 9 秒 | 7 秒 | 11 秒 | 2 |
| 解题 | 11 分 22 秒 | 5 分 16 秒 | 17 分 28 秒 | 2 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 2 |
| 证据收集 | 1 秒 | 1 秒 | 1 秒 | 2 |
| 资源清理 | 4 秒 | 4 秒 | 5 秒 | 2 |
| 评分 | 2 秒 | 2 秒 | 2 秒 | 2 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| ea46553d-2860-40c0-8e17-052e1d0cfe13 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 20,813,818 | 129,294 | 20,943,112 | 2 / 2 | — |
| 运行累计 | 20,813,818 | 129,294 | 20,943,112 | 2 / 2 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 61 | completed | 0 | 1047.57 | 2.03 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/2cb7b315-0fa5-4a50-97d5-fe00d9cf6cad/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/2cb7b315-0fa5-4a50-97d5-fe00d9cf6cad/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/2cb7b315-0fa5-4a50-97d5-fe00d9cf6cad/agent/trajectory.jsonl) |
| 87 | completed | 1 | 315.94 | 1.82 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/06fbfa00-4520-414c-b698-b22f2c057538/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/06fbfa00-4520-414c-b698-b22f2c057538/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/06fbfa00-4520-414c-b698-b22f2c057538/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

