<!-- snapshotDigest: e245c6761c72c010d3d1375da78bc4a2665a8d87e1b56a443c601e259e54f259 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 36.67%（22/60）**

Run: eb3c4e21-263c-450c-bcc9-eac4e31d0b7d · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T13:13:26.244Z / 2026-11-13T23:03:12.815Z |
| 总耗时 | 9 小时 29 分 43 秒 |
| 答对 / 答错 / 解题超时 | 22 / 19 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 2 / 0 |

已选择 62 题；已保存 43 条记录；待运行 19 题。
有效评分覆盖率：41/62（66.13%）。
执行失败 2；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 2。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 62 |
| 计分题数 | 60 |
| 正常评分题数 | 41 |
| 答对题数 | 22 |
| 无效评测 | 2 |
| 待运行 | 19 |
| 正确率 | 36.67% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 29 分 43 秒 |
| 环境准备耗时 | 9 小时 49 分 8 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 13 分 13 秒 | 1 分 12 秒 | 54 分 35 秒 | 43 |
| 任务准备 | 0.77 毫秒 | 0.28 毫秒 | 5.9 毫秒 | 43 |
| 环境启动 | 4 秒 | 3 秒 | 13 秒 | 43 |
| 解题 | 13 分 1 秒 | 1 分 2 秒 | 54 分 24 秒 | 43 |
| 产物传输 | 2 秒 | 1 秒 | 4 秒 | 41 |
| 证据收集 | 2 秒 | 569.25 毫秒 | 1 分 5 秒 | 43 |
| 资源清理 | 3 秒 | 2 秒 | 8 秒 | 43 |
| 评分 | 1 秒 | 977.61 毫秒 | 4 秒 | 41 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| b9259b39-cdc1-4667-83e3-81cebc847a1a | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 177,257,331 | 734,547 | 177,991,878 | 41 / 62 | — |
| 运行累计 | 208,824,058 | 850,180 | 209,674,238 | 43 / 43 | 2 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 28 | completed | 1 | 663.75 | 1.30 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/aabd1590-b0f4-4be3-a8d5-544a2272949f/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/aabd1590-b0f4-4be3-a8d5-544a2272949f/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/aabd1590-b0f4-4be3-a8d5-544a2272949f/agent/trajectory.jsonl) |
| 29 | invalid | — | 2192.82 | — | partial / complete | INTERNAL\_ERROR; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/e7f20393-7b61-431d-aa01-6a5f82ee84d6/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/e7f20393-7b61-431d-aa01-6a5f82ee84d6/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/e7f20393-7b61-431d-aa01-6a5f82ee84d6/agent/trajectory.jsonl) |
| 30 | completed | 0 | 247.13 | 1.17 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/2cc60864-1ff7-4ba1-8fa9-3737f75f5c8c/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/2cc60864-1ff7-4ba1-8fa9-3737f75f5c8c/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/2cc60864-1ff7-4ba1-8fa9-3737f75f5c8c/agent/trajectory.jsonl) |
| 31 | completed | 1 | 61.92 | 1.14 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/704c5565-c4c5-476a-9a0d-51e5402f4d90/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/704c5565-c4c5-476a-9a0d-51e5402f4d90/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/704c5565-c4c5-476a-9a0d-51e5402f4d90/agent/trajectory.jsonl) |
| 32 | completed | 0 | 172.69 | 1.03 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/2eab96db-782b-442a-a13a-dff3a05b8653/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/2eab96db-782b-442a-a13a-dff3a05b8653/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/2eab96db-782b-442a-a13a-dff3a05b8653/agent/trajectory.jsonl) |
| 33 | completed | 1 | 223.06 | 0.98 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/525ed3d7-4eba-431d-b373-8e7121d81ba2/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/525ed3d7-4eba-431d-b373-8e7121d81ba2/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/525ed3d7-4eba-431d-b373-8e7121d81ba2/agent/trajectory.jsonl) |
| 34 | completed | 0 | 429.63 | 1.52 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/fd073c9f-29ca-4c72-9391-bb2eb1b8fb6a/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/fd073c9f-29ca-4c72-9391-bb2eb1b8fb6a/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/fd073c9f-29ca-4c72-9391-bb2eb1b8fb6a/agent/trajectory.jsonl) |
| 35 | completed | 1 | 74.40 | 1.52 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/a05e7780-5627-40b2-9e1f-84862f9d4559/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/a05e7780-5627-40b2-9e1f-84862f9d4559/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/a05e7780-5627-40b2-9e1f-84862f9d4559/agent/trajectory.jsonl) |
| 36 | completed | 0 | 1784.29 | 1.24 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/cf2e3a06-5561-4892-9384-7a95624def70/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/cf2e3a06-5561-4892-9384-7a95624def70/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/cf2e3a06-5561-4892-9384-7a95624def70/agent/trajectory.jsonl) |
| 37 | completed | 1 | 94.24 | 1.03 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/bb623c42-7539-44ae-9eb0-07c329371918/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/bb623c42-7539-44ae-9eb0-07c329371918/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/bb623c42-7539-44ae-9eb0-07c329371918/agent/trajectory.jsonl) |
| 38 | completed | 0 | 739.75 | 1.06 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/4fc75d21-23b4-49a5-9971-342154656ba5/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/4fc75d21-23b4-49a5-9971-342154656ba5/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/4fc75d21-23b4-49a5-9971-342154656ba5/agent/trajectory.jsonl) |
| 39 | completed | 1 | 305.27 | 1.08 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/78bea41c-e393-4223-8d32-c9b4f0b12e7b/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/78bea41c-e393-4223-8d32-c9b4f0b12e7b/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/78bea41c-e393-4223-8d32-c9b4f0b12e7b/agent/trajectory.jsonl) |
| 40 | completed | 0 | 81.15 | 1.25 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/5908e91a-a849-4856-89e0-010477c10d33/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/5908e91a-a849-4856-89e0-010477c10d33/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/5908e91a-a849-4856-89e0-010477c10d33/agent/trajectory.jsonl) |
| 41 | completed | 1 | 281.87 | 1.10 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/282a9e58-d43c-49a7-9906-9ed7ed3ab15d/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/282a9e58-d43c-49a7-9906-9ed7ed3ab15d/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/282a9e58-d43c-49a7-9906-9ed7ed3ab15d/agent/trajectory.jsonl) |
| 42 | completed | 0 | 175.35 | 0.99 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/f36d8ba2-3667-4f98-bda9-f7ec5710bdc5/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/f36d8ba2-3667-4f98-bda9-f7ec5710bdc5/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/f36d8ba2-3667-4f98-bda9-f7ec5710bdc5/agent/trajectory.jsonl) |
| 43 | completed | 0 | 386.30 | 4.26 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/c652a3b3-766d-4696-a130-e8e16df7b647/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/c652a3b3-766d-4696-a130-e8e16df7b647/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/c652a3b3-766d-4696-a130-e8e16df7b647/agent/trajectory.jsonl) |
| 44 | completed | 0 | 714.22 | 0.99 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/003302e0-1194-4a36-8f1d-1dca11578a15/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/003302e0-1194-4a36-8f1d-1dca11578a15/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/003302e0-1194-4a36-8f1d-1dca11578a15/agent/trajectory.jsonl) |
| 45 | completed | 1 | 182.54 | 1.05 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/a1f3e7f1-2557-481d-bdc7-85f8d0b4bafb/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/a1f3e7f1-2557-481d-bdc7-85f8d0b4bafb/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/a1f3e7f1-2557-481d-bdc7-85f8d0b4bafb/agent/trajectory.jsonl) |
| 46 | completed | 0 | 936.01 | 1.48 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/4f6a4ddf-2dec-4f68-b083-1aba3c7e37ef/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/4f6a4ddf-2dec-4f68-b083-1aba3c7e37ef/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/4f6a4ddf-2dec-4f68-b083-1aba3c7e37ef/agent/trajectory.jsonl) |
| 47 | completed | 0 | 174.33 | 1.79 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/5b4a3112-7ee7-4fd0-bf0f-b9209ee04db8/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/5b4a3112-7ee7-4fd0-bf0f-b9209ee04db8/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/5b4a3112-7ee7-4fd0-bf0f-b9209ee04db8/agent/trajectory.jsonl) |
| 48 | completed | 1 | 135.49 | 1.53 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/26db39dc-6bae-410a-a238-8bc083c77c2d/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/26db39dc-6bae-410a-a238-8bc083c77c2d/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/26db39dc-6bae-410a-a238-8bc083c77c2d/agent/trajectory.jsonl) |
| 49 | completed | 1 | 233.44 | 1.32 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/fc61d80e-6a2e-4258-a222-4df8b6f0b644/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/fc61d80e-6a2e-4258-a222-4df8b6f0b644/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/fc61d80e-6a2e-4258-a222-4df8b6f0b644/agent/trajectory.jsonl) |
| 50 | completed | 0 | 706.20 | 1.67 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/4e6187e6-60ad-46f5-8777-0ad9cde7d37d/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/4e6187e6-60ad-46f5-8777-0ad9cde7d37d/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/4e6187e6-60ad-46f5-8777-0ad9cde7d37d/agent/trajectory.jsonl) |
| 51 | completed | 0 | 2395.57 | 1.21 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/1aa5f5bb-1b7b-4076-bf91-90299fdf7de8/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/1aa5f5bb-1b7b-4076-bf91-90299fdf7de8/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/1aa5f5bb-1b7b-4076-bf91-90299fdf7de8/agent/trajectory.jsonl) |
| 52 | completed | 0 | 963.26 | 1.95 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/23d4f5d0-2af8-4072-9698-e63c4876ab87/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/23d4f5d0-2af8-4072-9698-e63c4876ab87/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/23d4f5d0-2af8-4072-9698-e63c4876ab87/agent/trajectory.jsonl) |
| 53 | completed | 1 | 996.62 | 1.15 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/705464bc-ed73-41b2-841c-b89a07305bcd/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/705464bc-ed73-41b2-841c-b89a07305bcd/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/705464bc-ed73-41b2-841c-b89a07305bcd/agent/trajectory.jsonl) |
| 54 | completed | 1 | 755.53 | 1.11 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/6840f2b1-bbae-4330-b73c-d96f8291586e/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/6840f2b1-bbae-4330-b73c-d96f8291586e/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/6840f2b1-bbae-4330-b73c-d96f8291586e/agent/trajectory.jsonl) |
| 55 | completed | 1 | 3264.23 | 1.35 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/61b11c29-d247-4290-8dbe-080fc8ea35ee/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/61b11c29-d247-4290-8dbe-080fc8ea35ee/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/61b11c29-d247-4290-8dbe-080fc8ea35ee/agent/trajectory.jsonl) |
| 56 | completed | 1 | 425.59 | 1.45 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/37ea10a6-00c8-4a1f-b28f-0cf2fca06540/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/37ea10a6-00c8-4a1f-b28f-0cf2fca06540/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/37ea10a6-00c8-4a1f-b28f-0cf2fca06540/agent/trajectory.jsonl) |
| 57 | completed | 0 | 1088.20 | 1.20 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/8bd5b8ba-9b42-4e0e-9692-6435bd416bfb/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/8bd5b8ba-9b42-4e0e-9692-6435bd416bfb/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/8bd5b8ba-9b42-4e0e-9692-6435bd416bfb/agent/trajectory.jsonl) |
| 58 | completed | 1 | 2883.14 | 1.46 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/a06ab8f2-9a64-46ac-8f14-86e57bb2693b/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/a06ab8f2-9a64-46ac-8f14-86e57bb2693b/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/a06ab8f2-9a64-46ac-8f14-86e57bb2693b/agent/trajectory.jsonl) |
| 59 | completed | 0 | 358.88 | 1.73 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/86cd069a-9f42-4c9a-84a6-ac947424a9bb/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/86cd069a-9f42-4c9a-84a6-ac947424a9bb/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/86cd069a-9f42-4c9a-84a6-ac947424a9bb/agent/trajectory.jsonl) |
| 60 | completed | 1 | 416.39 | 1.23 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/8e761d52-2359-4774-88fa-a95d09da9a50/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/8e761d52-2359-4774-88fa-a95d09da9a50/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/8e761d52-2359-4774-88fa-a95d09da9a50/agent/trajectory.jsonl) |
| 61 | completed | 0 | 610.30 | 1.26 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/3063fe6d-27d6-4b49-a4bf-52f8d35c0e23/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/3063fe6d-27d6-4b49-a4bf-52f8d35c0e23/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/3063fe6d-27d6-4b49-a4bf-52f8d35c0e23/agent/trajectory.jsonl) |
| 62 | completed | 0 | 2114.21 | 1.07 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/d5ba392e-1e7c-4eec-83fa-e7c92619fdd2/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/d5ba392e-1e7c-4eec-83fa-e7c92619fdd2/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/d5ba392e-1e7c-4eec-83fa-e7c92619fdd2/agent/trajectory.jsonl) |
| 63 | completed | 1 | 581.62 | 1.09 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/893e92be-acd4-43b0-a339-1124cf3387ac/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/893e92be-acd4-43b0-a339-1124cf3387ac/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/893e92be-acd4-43b0-a339-1124cf3387ac/agent/trajectory.jsonl) |
| 64 | completed | 1 | 239.13 | 1.06 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/5fccc06d-1b8c-4fdb-bd8a-8e8ecd79ae92/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/5fccc06d-1b8c-4fdb-bd8a-8e8ecd79ae92/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/5fccc06d-1b8c-4fdb-bd8a-8e8ecd79ae92/agent/trajectory.jsonl) |
| 65 | completed | 0 | 1045.00 | 1.07 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/d2ab3af6-b740-4e83-84f5-6fe2463e9a5b/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/d2ab3af6-b740-4e83-84f5-6fe2463e9a5b/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/d2ab3af6-b740-4e83-84f5-6fe2463e9a5b/agent/trajectory.jsonl) |
| 66 | completed | 1 | 260.60 | 1.03 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/6d2c9da6-9ba4-4b64-8cbc-8258f0a199de/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/6d2c9da6-9ba4-4b64-8cbc-8258f0a199de/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/6d2c9da6-9ba4-4b64-8cbc-8258f0a199de/agent/trajectory.jsonl) |
| 67 | completed | 1 | 256.55 | 1.11 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/f23884e2-2533-4f5d-a6a9-4f1fac4b538a/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/f23884e2-2533-4f5d-a6a9-4f1fac4b538a/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/f23884e2-2533-4f5d-a6a9-4f1fac4b538a/agent/trajectory.jsonl) |
| 68 | completed | 1 | 825.43 | 1.01 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/2ac6c969-d182-423d-8579-13b0eec61338/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/2ac6c969-d182-423d-8579-13b0eec61338/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/2ac6c969-d182-423d-8579-13b0eec61338/agent/trajectory.jsonl) |
| 69 | completed | 1 | 213.17 | 1.24 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/f6fe0a84-d026-4a83-81e0-c9f76bc39c30/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/f6fe0a84-d026-4a83-81e0-c9f76bc39c30/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/f6fe0a84-d026-4a83-81e0-c9f76bc39c30/agent/trajectory.jsonl) |
| 70 | invalid | — | 2873.95 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/cdc4f586-326d-4e8a-a381-3763c88f82d8/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/cdc4f586-326d-4e8a-a381-3763c88f82d8/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/cdc4f586-326d-4e8a-a381-3763c88f82d8/agent/trajectory.jsonl) |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 2；错误记录 4（主流程 2；证据收集 2；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | INTERNAL_ERROR | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 2 | 2 |
| solve | MODEL_AUTH_FAILED | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

