<!-- snapshotDigest: cc0b280437c848182fc29d00d477d88fd78c20a909178ca41b236435d3ac43b4 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成；部分证据不完整。

**正确率 19.05%（4/21）**

Run: 86496f6e-c027-47b1-a5c3-b4f133b01b2e · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-14T02:33:18.488Z / 2026-11-14T09:14:45.744Z |
| 总耗时 | 6 小时 27 分 51 秒 |
| 答对 / 答错 / 解题超时 | 4 / 16 / 1 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 21 题；已保存 21 条记录；待运行 0 题。
有效评分覆盖率：21/21（100.00%）。
执行失败 0；超时 1；取消 0；不支持 0。
Agent 解题超时 1（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 21 |
| 计分题数 | 21 |
| 正常评分题数 | 20 |
| 答对题数 | 4 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 19.05% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 6 小时 27 分 51 秒 |
| 环境准备耗时 | 3 小时 38 分 49 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 18 分 25 秒 | 2 分 7 秒 | 1 小时 0 分 6 秒 | 21 |
| 任务准备 | 0.37 毫秒 | 0.22 毫秒 | 0.77 毫秒 | 21 |
| 环境启动 | 6 秒 | 5 秒 | 9 秒 | 21 |
| 解题 | 18 分 12 秒 | 1 分 55 秒 | 59 分 55 秒 | 21 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 20 |
| 证据收集 | 1 秒 | 995.28 毫秒 | 3 秒 | 21 |
| 资源清理 | 3 秒 | 3 秒 | 5 秒 | 21 |
| 评分 | 1 秒 | 1 秒 | 2 秒 | 20 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 2e40c743-3d07-40a4-95c8-399d0dbc21c5 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 159,856,642 | 813,901 | 160,670,543 | 20 / 21 | — |
| 运行累计 | 182,181,783 | 953,735 | 183,135,518 | 21 / 21 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 29 | completed | 0 | 2406.62 | 1.57 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/ef82437f-fa3c-4554-81b6-9d557cf7364e/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/ef82437f-fa3c-4554-81b6-9d557cf7364e/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/ef82437f-fa3c-4554-81b6-9d557cf7364e/agent/trajectory.jsonl) |
| 70 | completed | 1 | 1905.90 | 1.75 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/3dc0683c-48d4-42d5-a759-85a5ddd2331b/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/3dc0683c-48d4-42d5-a759-85a5ddd2331b/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/3dc0683c-48d4-42d5-a759-85a5ddd2331b/agent/trajectory.jsonl) |
| 71 | completed | 0 | 379.51 | 1.82 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/8a7de034-e1a2-4388-b3e3-0132c10301cb/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/8a7de034-e1a2-4388-b3e3-0132c10301cb/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/8a7de034-e1a2-4388-b3e3-0132c10301cb/agent/trajectory.jsonl) |
| 72 | completed | 0 | 3197.53 | 1.33 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/1743a697-99b1-4184-8dbf-4a4599383b1a/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/1743a697-99b1-4184-8dbf-4a4599383b1a/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/1743a697-99b1-4184-8dbf-4a4599383b1a/agent/trajectory.jsonl) |
| 73 | completed | 0 | 1640.72 | 1.43 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/bd6c6b01-b84d-4351-94f9-b5aef3dbb25d/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/bd6c6b01-b84d-4351-94f9-b5aef3dbb25d/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/bd6c6b01-b84d-4351-94f9-b5aef3dbb25d/agent/trajectory.jsonl) |
| 74 | completed | 0 | 323.22 | 1.35 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/f654938c-ff9d-4187-ab8d-864bdab7ac60/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/f654938c-ff9d-4187-ab8d-864bdab7ac60/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/f654938c-ff9d-4187-ab8d-864bdab7ac60/agent/trajectory.jsonl) |
| 75 | completed | 0 | 783.85 | 1.33 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/affda8e5-fe03-4b57-a07a-719a410c44b7/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/affda8e5-fe03-4b57-a07a-719a410c44b7/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/affda8e5-fe03-4b57-a07a-719a410c44b7/agent/trajectory.jsonl) |
| 76 | completed | 1 | 420.77 | 1.30 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/130d6068-5bc4-4271-97f6-bef102d51a15/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/130d6068-5bc4-4271-97f6-bef102d51a15/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/130d6068-5bc4-4271-97f6-bef102d51a15/agent/trajectory.jsonl) |
| 77 | completed | 0 | 730.20 | 1.47 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/ae4ea9c4-66b6-438d-ba2d-36198580e5f6/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/ae4ea9c4-66b6-438d-ba2d-36198580e5f6/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/ae4ea9c4-66b6-438d-ba2d-36198580e5f6/agent/trajectory.jsonl) |
| 78 | completed | 0 | 429.07 | 1.42 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/34ac485f-d692-4aff-a665-283fec84c04d/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/34ac485f-d692-4aff-a665-283fec84c04d/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/34ac485f-d692-4aff-a665-283fec84c04d/agent/trajectory.jsonl) |
| 79 | completed | 0 | 258.26 | 1.25 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/65a27cdc-b254-4785-926d-e04cdd51b83e/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/65a27cdc-b254-4785-926d-e04cdd51b83e/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/65a27cdc-b254-4785-926d-e04cdd51b83e/agent/trajectory.jsonl) |
| 80 | completed | 0 | 356.23 | 1.22 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/39045548-becb-4135-8990-70bf8ad77f08/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/39045548-becb-4135-8990-70bf8ad77f08/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/39045548-becb-4135-8990-70bf8ad77f08/agent/trajectory.jsonl) |
| 81 | completed | 0 | 903.72 | 1.24 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/a45c5e9a-9c24-4ca0-a822-28e2ca786314/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/a45c5e9a-9c24-4ca0-a822-28e2ca786314/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/a45c5e9a-9c24-4ca0-a822-28e2ca786314/agent/trajectory.jsonl) |
| 82 | completed | 0 | 528.54 | 1.34 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/a37590f3-7cee-4328-95da-2a66de5fb788/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/a37590f3-7cee-4328-95da-2a66de5fb788/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/a37590f3-7cee-4328-95da-2a66de5fb788/agent/trajectory.jsonl) |
| 83 | completed | 0 | 298.54 | 1.38 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/8e27e764-ca6b-4ca6-b9d4-9938264f45d4/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/8e27e764-ca6b-4ca6-b9d4-9938264f45d4/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/8e27e764-ca6b-4ca6-b9d4-9938264f45d4/agent/trajectory.jsonl) |
| 84 | completed | 0 | 2043.39 | 1.30 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/df71347b-9386-4325-98b1-e6cc15549115/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/df71347b-9386-4325-98b1-e6cc15549115/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/df71347b-9386-4325-98b1-e6cc15549115/agent/trajectory.jsonl) |
| 85 | timeout (agent) | 0 | 3595.14 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/380a51dd-a183-4dda-9bb1-edc5ebaa2606/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/380a51dd-a183-4dda-9bb1-edc5ebaa2606/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/380a51dd-a183-4dda-9bb1-edc5ebaa2606/agent/trajectory.jsonl) |
| 86 | completed | 1 | 629.51 | 1.19 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/da925577-3922-4ca8-bf90-96b8c87609f0/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/da925577-3922-4ca8-bf90-96b8c87609f0/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/da925577-3922-4ca8-bf90-96b8c87609f0/agent/trajectory.jsonl) |
| 87 | completed | 1 | 114.75 | 1.21 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/88ab4879-14a3-4046-9b43-5c905ff66c75/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/88ab4879-14a3-4046-9b43-5c905ff66c75/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/88ab4879-14a3-4046-9b43-5c905ff66c75/agent/trajectory.jsonl) |
| 88 | completed | 0 | 1686.54 | 1.25 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/fb83a769-8cc8-48cc-ac4e-bcde4fb19715/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/fb83a769-8cc8-48cc-ac4e-bcde4fb19715/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/fb83a769-8cc8-48cc-ac4e-bcde4fb19715/agent/trajectory.jsonl) |
| 89 | completed | 0 | 294.21 | 1.20 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/74bbd776-64e1-42b5-920c-9416bac2b132/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/74bbd776-64e1-42b5-920c-9416bac2b132/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/74bbd776-64e1-42b5-920c-9416bac2b132/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 1（主流程 1；证据收集 0；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 85 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

