<!-- snapshotDigest: 6d95224eee582bf3235b2347481fabceb1aea9a69dbbe89f865dea8fbc434c77 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 26.97%（24/89）**

Run: 4ad4352a-1f55-4445-8188-445db16d3577 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T10:13:55.029Z / 2026-11-13T12:17:27.166Z |
| 总耗时 | 1 小时 59 分 27 秒 |
| 答对 / 答错 / 解题超时 | 24 / 4 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 29 条记录；待运行 61 题。
有效评分覆盖率：28/90（31.11%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 28 |
| 答对题数 | 24 |
| 无效评测 | 1 |
| 待运行 | 61 |
| 正确率 | 26.97% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 59 分 27 秒 |
| 环境准备耗时 | 2 小时 3 分 17 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 4 分 6 秒 | 37 秒 | 10 分 7 秒 | 29 |
| 任务准备 | 0.45 毫秒 | 0.25 毫秒 | 1.56 毫秒 | 29 |
| 环境启动 | 3 秒 | 3 秒 | 6 秒 | 29 |
| 解题 | 3 分 57 秒 | 27 秒 | 9 分 59 秒 | 29 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 28 |
| 证据收集 | 737.56 毫秒 | 531.37 毫秒 | 2 秒 | 29 |
| 资源清理 | 2 秒 | 2 秒 | 3 秒 | 29 |
| 评分 | 1 秒 | 916.49 毫秒 | 2 秒 | 28 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| eee33d30-17ac-4c9d-a67b-b65ceacf5819 | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 75,593,921 | 810,160 | 76,404,081 | 28 / 90 | — |
| 运行累计 | 76,149,410 | 815,851 | 76,965,261 | 29 / 29 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 146.32 | 1.55 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/e7f4d36d-7930-48d7-b9de-52d349c0d61c/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/e7f4d36d-7930-48d7-b9de-52d349c0d61c/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/e7f4d36d-7930-48d7-b9de-52d349c0d61c/agent/trajectory.jsonl) |
| 1 | completed | 1 | 65.72 | 1.12 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/f7ceaa5d-2e44-4c19-b213-b401de6b9395/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/f7ceaa5d-2e44-4c19-b213-b401de6b9395/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/f7ceaa5d-2e44-4c19-b213-b401de6b9395/agent/trajectory.jsonl) |
| 2 | completed | 1 | 123.51 | 1.08 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/945edf94-727c-4d3f-9619-f0273c07bb57/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/945edf94-727c-4d3f-9619-f0273c07bb57/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/945edf94-727c-4d3f-9619-f0273c07bb57/agent/trajectory.jsonl) |
| 3 | completed | 1 | 307.42 | 0.98 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/328f342e-0f9e-4ae2-98bb-4c65977ad1f5/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/328f342e-0f9e-4ae2-98bb-4c65977ad1f5/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/328f342e-0f9e-4ae2-98bb-4c65977ad1f5/agent/trajectory.jsonl) |
| 4 | completed | 1 | 27.22 | 1.32 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/9eadac75-211a-47db-8532-ca37fb300fc9/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/9eadac75-211a-47db-8532-ca37fb300fc9/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/9eadac75-211a-47db-8532-ca37fb300fc9/agent/trajectory.jsonl) |
| 5 | completed | 1 | 184.40 | 1.17 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/0d203488-d5da-4cc2-aba2-ab49e6a78e36/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/0d203488-d5da-4cc2-aba2-ab49e6a78e36/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/0d203488-d5da-4cc2-aba2-ab49e6a78e36/agent/trajectory.jsonl) |
| 6 | completed | 1 | 261.27 | 1.17 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/7656eed6-d926-43be-811e-e1a195d856be/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/7656eed6-d926-43be-811e-e1a195d856be/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/7656eed6-d926-43be-811e-e1a195d856be/agent/trajectory.jsonl) |
| 7 | completed | 1 | 65.87 | 1.45 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/039e4ccc-8136-41b1-9580-50960dc44496/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/039e4ccc-8136-41b1-9580-50960dc44496/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/039e4ccc-8136-41b1-9580-50960dc44496/agent/trajectory.jsonl) |
| 8 | completed | 0 | 346.44 | 1.13 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/4ff7b583-5ded-44d5-941d-6231ba76fd6c/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/4ff7b583-5ded-44d5-941d-6231ba76fd6c/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/4ff7b583-5ded-44d5-941d-6231ba76fd6c/agent/trajectory.jsonl) |
| 9 | completed | 1 | 35.01 | 0.92 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/9d8d19ee-9cf6-4e4d-9003-533f1849e4aa/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/9d8d19ee-9cf6-4e4d-9003-533f1849e4aa/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/9d8d19ee-9cf6-4e4d-9003-533f1849e4aa/agent/trajectory.jsonl) |
| 10 | completed | 1 | 288.01 | 1.18 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/6501c5a3-c88a-4066-ad95-c518bfc64492/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/6501c5a3-c88a-4066-ad95-c518bfc64492/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/6501c5a3-c88a-4066-ad95-c518bfc64492/agent/trajectory.jsonl) |
| 11 | completed | 1 | 327.54 | 1.04 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/2627bedf-c632-47cb-990f-f522cd128c64/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/2627bedf-c632-47cb-990f-f522cd128c64/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/2627bedf-c632-47cb-990f-f522cd128c64/agent/trajectory.jsonl) |
| 12 | completed | 1 | 120.30 | 1.04 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/e8e2d0ba-a4d0-471b-95ab-1d4cae5d808d/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/e8e2d0ba-a4d0-471b-95ab-1d4cae5d808d/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/e8e2d0ba-a4d0-471b-95ab-1d4cae5d808d/agent/trajectory.jsonl) |
| 13 | completed | 1 | 137.06 | 0.92 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/4fc994c0-777a-436d-9df0-d8a96c2b7f4f/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/4fc994c0-777a-436d-9df0-d8a96c2b7f4f/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/4fc994c0-777a-436d-9df0-d8a96c2b7f4f/agent/trajectory.jsonl) |
| 14 | completed | 1 | 171.38 | 0.96 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/ebb91534-6b45-4a99-ba1a-0a06e987c0a6/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/ebb91534-6b45-4a99-ba1a-0a06e987c0a6/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/ebb91534-6b45-4a99-ba1a-0a06e987c0a6/agent/trajectory.jsonl) |
| 15 | completed | 1 | 460.33 | 0.98 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/d0a51479-d9dd-4a2d-b0ec-a04ed2e75c4a/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/d0a51479-d9dd-4a2d-b0ec-a04ed2e75c4a/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/d0a51479-d9dd-4a2d-b0ec-a04ed2e75c4a/agent/trajectory.jsonl) |
| 16 | completed | 1 | 236.56 | 0.93 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/eedf9cf3-3360-4809-889d-b1c3c11315f4/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/eedf9cf3-3360-4809-889d-b1c3c11315f4/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/eedf9cf3-3360-4809-889d-b1c3c11315f4/agent/trajectory.jsonl) |
| 17 | completed | 1 | 223.75 | 1.04 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/1676138f-dd53-4db3-a98e-8112632f4306/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/1676138f-dd53-4db3-a98e-8112632f4306/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/1676138f-dd53-4db3-a98e-8112632f4306/agent/trajectory.jsonl) |
| 18 | completed | 1 | 417.17 | 0.92 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/8c74f624-7ab3-4832-9510-14da97794240/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/8c74f624-7ab3-4832-9510-14da97794240/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/8c74f624-7ab3-4832-9510-14da97794240/agent/trajectory.jsonl) |
| 19 | completed | 1 | 289.97 | 1.08 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/bd58fe20-8832-49cc-b40a-15351fefa494/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/bd58fe20-8832-49cc-b40a-15351fefa494/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/bd58fe20-8832-49cc-b40a-15351fefa494/agent/trajectory.jsonl) |
| 20 | completed | 0 | 598.82 | 0.95 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/9044989a-aa95-4595-bf2e-2a50e7eeffaa/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/9044989a-aa95-4595-bf2e-2a50e7eeffaa/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/9044989a-aa95-4595-bf2e-2a50e7eeffaa/agent/trajectory.jsonl) |
| 21 | completed | 1 | 263.18 | 0.93 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/43af031a-965e-473f-b098-ba75340f6c34/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/43af031a-965e-473f-b098-ba75340f6c34/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/43af031a-965e-473f-b098-ba75340f6c34/agent/trajectory.jsonl) |
| 22 | completed | 1 | 75.36 | 1.00 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/05056d9a-66a8-4df1-9410-f1455a097c1f/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/05056d9a-66a8-4df1-9410-f1455a097c1f/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/05056d9a-66a8-4df1-9410-f1455a097c1f/agent/trajectory.jsonl) |
| 23 | completed | 1 | 147.71 | 1.01 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/f2cd71bc-ed6d-461e-ad6e-abc25a62ea44/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/f2cd71bc-ed6d-461e-ad6e-abc25a62ea44/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/f2cd71bc-ed6d-461e-ad6e-abc25a62ea44/agent/trajectory.jsonl) |
| 24 | completed | 0 | 386.55 | 1.18 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/da68eebd-90f3-4f4a-9e5d-db1239595e9a/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/da68eebd-90f3-4f4a-9e5d-db1239595e9a/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/da68eebd-90f3-4f4a-9e5d-db1239595e9a/agent/trajectory.jsonl) |
| 25 | completed | 0 | 240.63 | 1.02 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/520d8429-d6d7-407d-b347-2304d094b478/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/520d8429-d6d7-407d-b347-2304d094b478/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/520d8429-d6d7-407d-b347-2304d094b478/agent/trajectory.jsonl) |
| 26 | completed | 1 | 286.83 | 1.14 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/b94312d3-adb0-465c-9171-0ab9648f0878/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/b94312d3-adb0-465c-9171-0ab9648f0878/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/b94312d3-adb0-465c-9171-0ab9648f0878/agent/trajectory.jsonl) |
| 27 | completed | 1 | 589.46 | 1.13 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/096bc20a-1844-4742-941c-b40b52922a3d/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/096bc20a-1844-4742-941c-b40b52922a3d/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/096bc20a-1844-4742-941c-b40b52922a3d/agent/trajectory.jsonl) |
| 28 | invalid | — | 54.16 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/bb973871-5622-4a4c-953e-c86ec8f9f256/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/bb973871-5622-4a4c-953e-c86ec8f9f256/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/bb973871-5622-4a4c-953e-c86ec8f9f256/agent/trajectory.jsonl) |
| 29 | pending | — | — | — | — | — | — |
| 30 | pending | — | — | — | — | — | — |
| 31 | pending | — | — | — | — | — | — |
| 32 | pending | — | — | — | — | — | — |
| 33 | pending | — | — | — | — | — | — |
| 34 | pending | — | — | — | — | — | — |
| 35 | pending | — | — | — | — | — | — |
| 36 | pending | — | — | — | — | — | — |
| 37 | pending | — | — | — | — | — | — |
| 38 | pending | — | — | — | — | — | — |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

