<!-- snapshotDigest: 92e48f956922d56baf6b3e9e046c3181b19fe84e515107e7379585ea4df40fdf -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 25.84%（23/89）**

Run: c8b84151-3573-4395-a6ab-e29e6263d75a · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T10:13:53.811Z / 2026-11-13T12:17:31.988Z |
| 总耗时 | 1 小时 59 分 33 秒 |
| 答对 / 答错 / 解题超时 | 23 / 3 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 27 条记录；待运行 63 题。
有效评分覆盖率：26/90（28.89%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 26 |
| 答对题数 | 23 |
| 无效评测 | 1 |
| 待运行 | 63 |
| 正确率 | 25.84% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 59 分 33 秒 |
| 环境准备耗时 | 2 小时 3 分 23 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 3 分 58 秒 | 39 秒 | 15 分 39 秒 | 27 |
| 任务准备 | 0.42 毫秒 | 0.27 毫秒 | 0.77 毫秒 | 27 |
| 环境启动 | 4 秒 | 3 秒 | 5 秒 | 27 |
| 解题 | 3 分 49 秒 | 30 秒 | 15 分 30 秒 | 27 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 26 |
| 证据收集 | 757.66 毫秒 | 538.54 毫秒 | 2 秒 | 27 |
| 资源清理 | 3 秒 | 2 秒 | 4 秒 | 27 |
| 评分 | 1 秒 | 897.99 毫秒 | 2 秒 | 26 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 3c38ea41-71de-4a47-9e7f-b53c24307d79 | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 70,982,768 | 661,793 | 71,644,561 | 26 / 90 | — |
| 运行累计 | 70,982,768 | 661,793 | 71,644,561 | 26 / 29 | 3 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 66.42 | 1.68 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/4348c285-ab11-4490-8358-e46cb9b2aa67/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/4348c285-ab11-4490-8358-e46cb9b2aa67/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/4348c285-ab11-4490-8358-e46cb9b2aa67/agent/trajectory.jsonl) |
| 1 | completed | 1 | 82.09 | 1.35 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/44e3cb0b-d649-4ea4-954f-4dc5ccc329ed/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/44e3cb0b-d649-4ea4-954f-4dc5ccc329ed/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/44e3cb0b-d649-4ea4-954f-4dc5ccc329ed/agent/trajectory.jsonl) |
| 2 | completed | 1 | 101.91 | 1.27 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/d1d5bfc4-bbfa-4a3b-92d2-ec612a0b8fbd/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/d1d5bfc4-bbfa-4a3b-92d2-ec612a0b8fbd/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/d1d5bfc4-bbfa-4a3b-92d2-ec612a0b8fbd/agent/trajectory.jsonl) |
| 3 | completed | 1 | 280.34 | 1.06 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/7500c89f-8ab7-4d4d-bd1a-d0f6b6bc5606/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/7500c89f-8ab7-4d4d-bd1a-d0f6b6bc5606/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/7500c89f-8ab7-4d4d-bd1a-d0f6b6bc5606/agent/trajectory.jsonl) |
| 4 | completed | 1 | 51.54 | 1.16 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/dc269c81-7071-416d-b684-aa79d24ad491/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/dc269c81-7071-416d-b684-aa79d24ad491/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/dc269c81-7071-416d-b684-aa79d24ad491/agent/trajectory.jsonl) |
| 5 | completed | 1 | 103.91 | 0.94 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/49dc7df3-2445-4fdd-98c3-27051e8a74eb/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/49dc7df3-2445-4fdd-98c3-27051e8a74eb/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/49dc7df3-2445-4fdd-98c3-27051e8a74eb/agent/trajectory.jsonl) |
| 6 | completed | 1 | 448.83 | 1.18 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/cdc3a4ae-fd51-4541-91e4-ab296fdf1ae4/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/cdc3a4ae-fd51-4541-91e4-ab296fdf1ae4/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/cdc3a4ae-fd51-4541-91e4-ab296fdf1ae4/agent/trajectory.jsonl) |
| 7 | completed | 1 | 30.07 | 1.00 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/1dec9284-1ed5-4033-9cad-eb2eb836057a/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/1dec9284-1ed5-4033-9cad-eb2eb836057a/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/1dec9284-1ed5-4033-9cad-eb2eb836057a/agent/trajectory.jsonl) |
| 8 | completed | 0 | 154.30 | 0.98 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/a483219f-2ea9-4446-b70a-b06b45d371f8/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/a483219f-2ea9-4446-b70a-b06b45d371f8/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/a483219f-2ea9-4446-b70a-b06b45d371f8/agent/trajectory.jsonl) |
| 9 | completed | 1 | 31.56 | 1.20 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/35e69ede-2017-4c20-91a8-336ebe9536b9/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/35e69ede-2017-4c20-91a8-336ebe9536b9/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/35e69ede-2017-4c20-91a8-336ebe9536b9/agent/trajectory.jsonl) |
| 10 | completed | 1 | 354.40 | 1.08 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/feaa10e0-38d3-4f56-83a6-aadbd0b99f43/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/feaa10e0-38d3-4f56-83a6-aadbd0b99f43/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/feaa10e0-38d3-4f56-83a6-aadbd0b99f43/agent/trajectory.jsonl) |
| 11 | completed | 1 | 125.99 | 1.01 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/892ba362-e545-4db8-b519-18f5236bdb60/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/892ba362-e545-4db8-b519-18f5236bdb60/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/892ba362-e545-4db8-b519-18f5236bdb60/agent/trajectory.jsonl) |
| 12 | completed | 1 | 286.26 | 1.28 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/09880c4b-c707-40ce-ae00-e0d41b65d68f/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/09880c4b-c707-40ce-ae00-e0d41b65d68f/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/09880c4b-c707-40ce-ae00-e0d41b65d68f/agent/trajectory.jsonl) |
| 13 | completed | 1 | 369.40 | 0.90 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/28eeb9af-cc06-42b2-bb53-014af1bb193a/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/28eeb9af-cc06-42b2-bb53-014af1bb193a/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/28eeb9af-cc06-42b2-bb53-014af1bb193a/agent/trajectory.jsonl) |
| 14 | completed | 1 | 251.90 | 1.08 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/621c18e5-c029-4a32-bb95-3f072c6bcf12/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/621c18e5-c029-4a32-bb95-3f072c6bcf12/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/621c18e5-c029-4a32-bb95-3f072c6bcf12/agent/trajectory.jsonl) |
| 15 | completed | 0 | 337.17 | 1.41 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/7646d176-e895-4a0d-92e4-3b4156a973f5/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/7646d176-e895-4a0d-92e4-3b4156a973f5/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/7646d176-e895-4a0d-92e4-3b4156a973f5/agent/trajectory.jsonl) |
| 16 | completed | 1 | 173.07 | 1.07 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/94a80732-080d-47b9-8af8-ad0415977be6/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/94a80732-080d-47b9-8af8-ad0415977be6/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/94a80732-080d-47b9-8af8-ad0415977be6/agent/trajectory.jsonl) |
| 17 | completed | 1 | 110.05 | 0.95 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/4a81ab32-d20c-4fd0-914e-8029adca8341/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/4a81ab32-d20c-4fd0-914e-8029adca8341/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/4a81ab32-d20c-4fd0-914e-8029adca8341/agent/trajectory.jsonl) |
| 18 | completed | 1 | 929.97 | 1.17 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/a7a99607-877e-4a74-af18-1ec265cb4db0/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/a7a99607-877e-4a74-af18-1ec265cb4db0/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/a7a99607-877e-4a74-af18-1ec265cb4db0/agent/trajectory.jsonl) |
| 19 | completed | 1 | 154.33 | 1.09 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/b4869b74-7bdc-4a28-93bb-0f9c732d39cb/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/b4869b74-7bdc-4a28-93bb-0f9c732d39cb/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/b4869b74-7bdc-4a28-93bb-0f9c732d39cb/agent/trajectory.jsonl) |
| 20 | completed | 1 | 341.24 | 0.99 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/80540aab-f48f-4dd0-b1e4-9f5df61f805d/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/80540aab-f48f-4dd0-b1e4-9f5df61f805d/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/80540aab-f48f-4dd0-b1e4-9f5df61f805d/agent/trajectory.jsonl) |
| 21 | completed | 1 | 226.75 | 1.50 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/ae5ee7bd-bc8a-458d-8014-d9d233054d6d/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/ae5ee7bd-bc8a-458d-8014-d9d233054d6d/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/ae5ee7bd-bc8a-458d-8014-d9d233054d6d/agent/trajectory.jsonl) |
| 22 | completed | 1 | 115.91 | 1.01 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/17f91be3-5d5a-4ea8-bf87-dfa552c520f3/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/17f91be3-5d5a-4ea8-bf87-dfa552c520f3/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/17f91be3-5d5a-4ea8-bf87-dfa552c520f3/agent/trajectory.jsonl) |
| 23 | completed | 1 | 213.96 | 1.02 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/eac52190-364b-409b-b2a7-ec21da70952d/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/eac52190-364b-409b-b2a7-ec21da70952d/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/eac52190-364b-409b-b2a7-ec21da70952d/agent/trajectory.jsonl) |
| 24 | completed | 0 | 334.64 | 1.31 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/392c4eab-1f3e-451b-9feb-3373fafe61db/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/392c4eab-1f3e-451b-9feb-3373fafe61db/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/392c4eab-1f3e-451b-9feb-3373fafe61db/agent/trajectory.jsonl) |
| 25 | completed | 1 | 256.31 | 0.98 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/3227f984-6fae-457f-8021-6a9419cdb6f4/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/3227f984-6fae-457f-8021-6a9419cdb6f4/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/3227f984-6fae-457f-8021-6a9419cdb6f4/agent/trajectory.jsonl) |
| 26 | invalid | — | 240.05 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/84eda71f-4584-4a3a-ad82-32e5bbea8370/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/84eda71f-4584-4a3a-ad82-32e5bbea8370/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/84eda71f-4584-4a3a-ad82-32e5bbea8370/agent/trajectory.jsonl) |
| 27 | pending | — | — | — | — | — | — |
| 28 | pending | — | — | — | — | — | — |
| 29 | pending | — | — | — | — | — | — |
| 30 | pending | — | — | — | — | — | — |
| 31 | pending | — | — | — | — | — | — |
| 32 | pending | — | — | — | — | — | — |
| 33 | pending | — | — | — | — | — | — |
| 34 | pending | — | — | — | — | — | — |
| 35 | pending | — | — | — | — | — | — |
| 36 | pending | — | — | — | — | — | — |
| 37 | pending | — | — | — | — | — | — |
| 38 | pending | — | — | — | — | — | — |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

