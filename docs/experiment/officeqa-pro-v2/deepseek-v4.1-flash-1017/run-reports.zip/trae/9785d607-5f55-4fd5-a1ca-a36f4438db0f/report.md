<!-- snapshotDigest: 8f8445fff465966cecdb7b23008f8f7a87b1f2098dec67a77890a91a4400c001 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 22.22%（2/9）**

Run: 9785d607-5f55-4fd5-a1ca-a36f4438db0f · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-14T02:34:07.779Z / 2026-11-14T04:28:26.722Z |
| 总耗时 | 1 小时 50 分 22 秒 |
| 答对 / 答错 / 解题超时 | 2 / 7 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 9 题；已保存 9 条记录；待运行 0 题。
有效评分覆盖率：9/9（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 9 |
| 计分题数 | 9 |
| 正常评分题数 | 9 |
| 答对题数 | 2 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 22.22% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 50 分 22 秒 |
| 环境准备耗时 | 4 分 18 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 12 分 9 秒 | 3 分 48 秒 | 27 分 31 秒 | 9 |
| 任务准备 | 0.47 毫秒 | 0.31 毫秒 | 1.02 毫秒 | 9 |
| 环境启动 | 6 秒 | 5 秒 | 8 秒 | 9 |
| 解题 | 11 分 54 秒 | 3 分 33 秒 | 27 分 15 秒 | 9 |
| 产物传输 | 2 秒 | 2 秒 | 2 秒 | 9 |
| 证据收集 | 1 秒 | 1 秒 | 2 秒 | 9 |
| 资源清理 | 4 秒 | 3 秒 | 4 秒 | 9 |
| 评分 | 2 秒 | 1 秒 | 2 秒 | 9 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| b15f4e30-4bc4-4ea8-9323-be7c25911be5 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 70,030,471 | 176,159 | 70,206,630 | 9 / 9 | — |
| 运行累计 | 70,030,471 | 176,159 | 70,206,630 | 9 / 9 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 81 | completed | 0 | 303.95 | 1.81 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/f8f4f7c2-e650-40e6-9fb6-edbd13022d63/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/f8f4f7c2-e650-40e6-9fb6-edbd13022d63/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/f8f4f7c2-e650-40e6-9fb6-edbd13022d63/agent/trajectory.jsonl) |
| 82 | completed | 0 | 625.48 | 1.54 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/764c5fdc-8abc-48e0-bf58-e0b72593ae2e/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/764c5fdc-8abc-48e0-bf58-e0b72593ae2e/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/764c5fdc-8abc-48e0-bf58-e0b72593ae2e/agent/trajectory.jsonl) |
| 83 | completed | 0 | 367.44 | 1.50 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/7aa71112-c643-455c-a22f-63938726ff34/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/7aa71112-c643-455c-a22f-63938726ff34/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/7aa71112-c643-455c-a22f-63938726ff34/agent/trajectory.jsonl) |
| 84 | completed | 1 | 1635.09 | 1.78 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/ac6192fd-c11a-48be-a907-b959f5b7d515/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/ac6192fd-c11a-48be-a907-b959f5b7d515/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/ac6192fd-c11a-48be-a907-b959f5b7d515/agent/trajectory.jsonl) |
| 85 | completed | 0 | 1476.33 | 1.55 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/afd946ca-cb62-4494-99a0-9c2b0dfef136/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/afd946ca-cb62-4494-99a0-9c2b0dfef136/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/afd946ca-cb62-4494-99a0-9c2b0dfef136/agent/trajectory.jsonl) |
| 86 | completed | 0 | 652.97 | 1.47 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/c6d327ba-63db-4c47-8e55-f53e59d1f34c/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/c6d327ba-63db-4c47-8e55-f53e59d1f34c/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/c6d327ba-63db-4c47-8e55-f53e59d1f34c/agent/trajectory.jsonl) |
| 87 | completed | 1 | 213.34 | 1.77 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/7ea5f23a-c9f4-42ad-94fc-b42ac3c1813a/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/7ea5f23a-c9f4-42ad-94fc-b42ac3c1813a/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/7ea5f23a-c9f4-42ad-94fc-b42ac3c1813a/agent/trajectory.jsonl) |
| 88 | completed | 0 | 520.34 | 1.74 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/46ec6b02-2721-4725-bf33-a8c6147c51b3/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/46ec6b02-2721-4725-bf33-a8c6147c51b3/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/46ec6b02-2721-4725-bf33-a8c6147c51b3/agent/trajectory.jsonl) |
| 89 | completed | 0 | 632.01 | 1.48 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/0a6e5b56-3a6a-4d43-b568-868959fd8add/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/0a6e5b56-3a6a-4d43-b568-868959fd8add/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/0a6e5b56-3a6a-4d43-b568-868959fd8add/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

