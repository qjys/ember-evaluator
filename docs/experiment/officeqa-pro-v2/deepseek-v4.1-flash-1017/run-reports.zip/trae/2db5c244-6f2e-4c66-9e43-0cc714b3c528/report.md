<!-- snapshotDigest: 19657f921d198294a594e3c13051c6963ebcec31e04bba94ecad73c8dda6a359 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 34.21%（13/38）**

Run: 2db5c244-6f2e-4c66-9e43-0cc714b3c528 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T17:34:57.268Z / 2026-11-13T23:03:01.809Z |
| 总耗时 | 5 小时 16 分 42 秒 |
| 答对 / 答错 / 解题超时 | 13 / 17 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 39 题；已保存 31 条记录；待运行 8 题。
有效评分覆盖率：30/39（76.92%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 39 |
| 计分题数 | 38 |
| 正常评分题数 | 30 |
| 答对题数 | 13 |
| 无效评测 | 1 |
| 待运行 | 8 |
| 正确率 | 34.21% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 5 小时 16 分 42 秒 |
| 环境准备耗时 | 5 小时 1 分 51 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 10 分 11 秒 | 1 分 56 秒 | 37 分 21 秒 | 31 |
| 任务准备 | 0.37 毫秒 | 0.24 毫秒 | 0.81 毫秒 | 31 |
| 环境启动 | 7 秒 | 5 秒 | 10 秒 | 31 |
| 解题 | 9 分 56 秒 | 1 分 43 秒 | 37 分 6 秒 | 31 |
| 产物传输 | 2 秒 | 2 秒 | 3 秒 | 30 |
| 证据收集 | 1 秒 | 996.74 毫秒 | 5 秒 | 31 |
| 资源清理 | 4 秒 | 3 秒 | 5 秒 | 31 |
| 评分 | 2 秒 | 1 秒 | 2 秒 | 30 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 31c7c798-54e1-4c10-b324-02e872f804ae | 14,400 | 3600 | 3 | 3 | 10800 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 182,969,895 | 505,131 | 183,475,026 | 30 / 39 | — |
| 运行累计 | 182,969,895 | 505,131 | 183,475,026 | 30 / 31 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 38 | completed | 0 | 1067.77 | 1.59 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/c3135976-fb2c-44c6-bd94-3f906890c018/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/c3135976-fb2c-44c6-bd94-3f906890c018/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/c3135976-fb2c-44c6-bd94-3f906890c018/agent/trajectory.jsonl) |
| 43 | completed | 0 | 589.88 | 1.62 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/a6f73e21-6fd0-4238-9a6f-49772f538d87/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/a6f73e21-6fd0-4238-9a6f-49772f538d87/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/a6f73e21-6fd0-4238-9a6f-49772f538d87/agent/trajectory.jsonl) |
| 45 | completed | 0 | 289.06 | 1.85 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/376a85bf-2c27-4fe0-863e-0e91ca8370c7/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/376a85bf-2c27-4fe0-863e-0e91ca8370c7/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/376a85bf-2c27-4fe0-863e-0e91ca8370c7/agent/trajectory.jsonl) |
| 46 | completed | 1 | 1238.62 | 1.72 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/6d628879-9013-4d65-8945-ac0f019ccbe3/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/6d628879-9013-4d65-8945-ac0f019ccbe3/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/6d628879-9013-4d65-8945-ac0f019ccbe3/agent/trajectory.jsonl) |
| 47 | completed | 0 | 363.13 | 1.60 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/220508e5-a323-453d-b300-3954c5b785c4/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/220508e5-a323-453d-b300-3954c5b785c4/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/220508e5-a323-453d-b300-3954c5b785c4/agent/trajectory.jsonl) |
| 48 | completed | 1 | 127.69 | 1.39 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/cad87704-1341-4142-8399-ded6828ca8fd/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/cad87704-1341-4142-8399-ded6828ca8fd/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/cad87704-1341-4142-8399-ded6828ca8fd/agent/trajectory.jsonl) |
| 50 | completed | 0 | 656.96 | 1.64 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/840d5243-8299-4613-8123-7b8ea7d8ae49/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/840d5243-8299-4613-8123-7b8ea7d8ae49/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/840d5243-8299-4613-8123-7b8ea7d8ae49/agent/trajectory.jsonl) |
| 52 | completed | 0 | 421.88 | 1.72 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/d254843b-985d-41b7-8400-d6ccfe881bcc/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/d254843b-985d-41b7-8400-d6ccfe881bcc/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/d254843b-985d-41b7-8400-d6ccfe881bcc/agent/trajectory.jsonl) |
| 54 | completed | 1 | 608.43 | 1.69 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/79ef3823-9478-49bf-814c-030b764f628d/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/79ef3823-9478-49bf-814c-030b764f628d/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/79ef3823-9478-49bf-814c-030b764f628d/agent/trajectory.jsonl) |
| 55 | completed | 1 | 2225.53 | 1.52 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/453735be-d491-40b3-8ed3-1ec28483e653/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/453735be-d491-40b3-8ed3-1ec28483e653/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/453735be-d491-40b3-8ed3-1ec28483e653/agent/trajectory.jsonl) |
| 57 | completed | 0 | 531.75 | 1.40 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/32d8ce84-436a-43a3-8e20-72c5572a2721/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/32d8ce84-436a-43a3-8e20-72c5572a2721/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/32d8ce84-436a-43a3-8e20-72c5572a2721/agent/trajectory.jsonl) |
| 61 | completed | 0 | 357.29 | 1.82 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/1214ef2f-7e5a-4986-9d65-3345a3b576fc/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/1214ef2f-7e5a-4986-9d65-3345a3b576fc/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/1214ef2f-7e5a-4986-9d65-3345a3b576fc/agent/trajectory.jsonl) |
| 62 | completed | 0 | 818.44 | 1.33 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/7f0a1625-b98f-4b97-a8fd-4bb5423f53eb/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/7f0a1625-b98f-4b97-a8fd-4bb5423f53eb/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/7f0a1625-b98f-4b97-a8fd-4bb5423f53eb/agent/trajectory.jsonl) |
| 64 | completed | 1 | 296.63 | 1.37 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/1be023c7-8d4c-40b4-bbe1-bcfb1b3ec511/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/1be023c7-8d4c-40b4-bbe1-bcfb1b3ec511/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/1be023c7-8d4c-40b4-bbe1-bcfb1b3ec511/agent/trajectory.jsonl) |
| 65 | completed | 0 | 427.10 | 1.38 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/971b0615-b2a6-4f19-a325-89b43a8c6a4c/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/971b0615-b2a6-4f19-a325-89b43a8c6a4c/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/971b0615-b2a6-4f19-a325-89b43a8c6a4c/agent/trajectory.jsonl) |
| 66 | completed | 1 | 193.18 | 1.38 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/952664f4-320f-4303-adba-3759d356ecea/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/952664f4-320f-4303-adba-3759d356ecea/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/952664f4-320f-4303-adba-3759d356ecea/agent/trajectory.jsonl) |
| 67 | completed | 1 | 132.27 | 1.26 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/5a1de07d-9d88-492f-b707-2f9b5179112c/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/5a1de07d-9d88-492f-b707-2f9b5179112c/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/5a1de07d-9d88-492f-b707-2f9b5179112c/agent/trajectory.jsonl) |
| 68 | completed | 1 | 368.50 | 1.33 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/329b9f02-768e-4265-bc1e-e36302641d4f/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/329b9f02-768e-4265-bc1e-e36302641d4f/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/329b9f02-768e-4265-bc1e-e36302641d4f/agent/trajectory.jsonl) |
| 69 | completed | 1 | 255.91 | 1.30 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/af86e2e6-fd43-44f7-b947-48c7712ed0b8/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/af86e2e6-fd43-44f7-b947-48c7712ed0b8/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/af86e2e6-fd43-44f7-b947-48c7712ed0b8/agent/trajectory.jsonl) |
| 70 | completed | 1 | 593.87 | 1.68 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/74240220-e96a-4c32-b310-2b51afe22cd2/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/74240220-e96a-4c32-b310-2b51afe22cd2/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/74240220-e96a-4c32-b310-2b51afe22cd2/agent/trajectory.jsonl) |
| 71 | completed | 0 | 979.34 | 1.28 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/d8120416-bc24-4824-83dd-ff2026692a78/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/d8120416-bc24-4824-83dd-ff2026692a78/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/d8120416-bc24-4824-83dd-ff2026692a78/agent/trajectory.jsonl) |
| 72 | completed | 1 | 553.93 | 1.31 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/103092ff-7f2d-49cd-8329-88197fbf3142/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/103092ff-7f2d-49cd-8329-88197fbf3142/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/103092ff-7f2d-49cd-8329-88197fbf3142/agent/trajectory.jsonl) |
| 73 | completed | 1 | 453.49 | 1.39 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/d0a3f321-9ceb-4c61-ae53-7d2a739d8c82/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/d0a3f321-9ceb-4c61-ae53-7d2a739d8c82/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/d0a3f321-9ceb-4c61-ae53-7d2a739d8c82/agent/trajectory.jsonl) |
| 74 | completed | 0 | 406.83 | 1.25 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/f3ccf44c-b1b7-4371-9d67-5113c8c6dc3e/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/f3ccf44c-b1b7-4371-9d67-5113c8c6dc3e/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/f3ccf44c-b1b7-4371-9d67-5113c8c6dc3e/agent/trajectory.jsonl) |
| 75 | completed | 0 | 1810.90 | 1.46 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/37969300-7d47-4cf2-ba3d-78dc764475e4/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/37969300-7d47-4cf2-ba3d-78dc764475e4/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/37969300-7d47-4cf2-ba3d-78dc764475e4/agent/trajectory.jsonl) |
| 76 | completed | 0 | 308.24 | 1.44 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/a854c78e-a212-43a2-a634-d49effcd3534/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/a854c78e-a212-43a2-a634-d49effcd3534/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/a854c78e-a212-43a2-a634-d49effcd3534/agent/trajectory.jsonl) |
| 77 | completed | 0 | 578.21 | 2.19 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/9594f703-ec18-4d53-91a4-0737c8ce7a51/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/9594f703-ec18-4d53-91a4-0737c8ce7a51/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/9594f703-ec18-4d53-91a4-0737c8ce7a51/agent/trajectory.jsonl) |
| 78 | completed | 1 | 102.81 | 1.35 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/feeb547c-3126-44cd-bde1-465ac364a5c0/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/feeb547c-3126-44cd-bde1-465ac364a5c0/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/feeb547c-3126-44cd-bde1-465ac364a5c0/agent/trajectory.jsonl) |
| 79 | completed | 0 | 246.80 | 1.56 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/5cd76a37-ce4d-444a-ad73-837201e56f72/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/5cd76a37-ce4d-444a-ad73-837201e56f72/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/5cd76a37-ce4d-444a-ad73-837201e56f72/agent/trajectory.jsonl) |
| 80 | completed | 0 | 1057.26 | 1.53 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/a2ef22e5-9b72-41b4-aded-846cfca56f93/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/a2ef22e5-9b72-41b4-aded-846cfca56f93/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/a2ef22e5-9b72-41b4-aded-846cfca56f93/agent/trajectory.jsonl) |
| 81 | invalid | — | 425.60 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/c5b3b383-f10e-444b-b29f-b6264cc572b5/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/c5b3b383-f10e-444b-b29f-b6264cc572b5/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/c5b3b383-f10e-444b-b29f-b6264cc572b5/agent/trajectory.jsonl) |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

