<!-- snapshotDigest: 7d382525b1660e0c1bbbb107483afeba9a54156f68fb966ae7bfd40b89eecab1 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 40.00%（8/20）**

Run: 43abfa52-2ed1-4d4f-be6a-88fde93e8690 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-14T02:33:33.377Z / 2026-11-14T06:51:24.903Z |
| 总耗时 | 4 小时 9 分 3 秒 |
| 答对 / 答错 / 解题超时 | 8 / 12 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 20 题；已保存 20 条记录；待运行 0 题。
有效评分覆盖率：20/20（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 20 |
| 计分题数 | 20 |
| 正常评分题数 | 20 |
| 答对题数 | 8 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 40.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 4 小时 9 分 3 秒 |
| 环境准备耗时 | 2 小时 27 分 31 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 12 分 24 秒 | 3 分 10 秒 | 26 分 7 秒 | 20 |
| 任务准备 | 0.41 毫秒 | 0.23 毫秒 | 1.14 毫秒 | 20 |
| 环境启动 | 7 秒 | 6 秒 | 10 秒 | 20 |
| 解题 | 12 分 9 秒 | 2 分 56 秒 | 25 分 49 秒 | 20 |
| 产物传输 | 2 秒 | 2 秒 | 3 秒 | 20 |
| 证据收集 | 1 秒 | 1 秒 | 2 秒 | 20 |
| 资源清理 | 4 秒 | 3 秒 | 4 秒 | 20 |
| 评分 | 1 秒 | 1 秒 | 2 秒 | 20 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 8f4f1b2b-ff67-4231-85f1-abac9aa48788 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 120,535,331 | 500,610 | 121,035,941 | 20 / 20 | — |
| 运行累计 | 120,535,331 | 500,610 | 121,035,941 | 20 / 20 | 0 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 70 | completed | 1 | 1086.37 | 1.48 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/34c0ba5f-cceb-4044-91b6-67229b3c00cb/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/34c0ba5f-cceb-4044-91b6-67229b3c00cb/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/34c0ba5f-cceb-4044-91b6-67229b3c00cb/agent/trajectory.jsonl) |
| 71 | completed | 0 | 1549.33 | 1.57 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/20b6cad0-eb0a-47cd-8f14-cf223330861d/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/20b6cad0-eb0a-47cd-8f14-cf223330861d/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/20b6cad0-eb0a-47cd-8f14-cf223330861d/agent/trajectory.jsonl) |
| 72 | completed | 0 | 1237.40 | 1.53 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/0ea61d55-0f9b-441c-9ba6-c16f1c1de07c/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/0ea61d55-0f9b-441c-9ba6-c16f1c1de07c/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/0ea61d55-0f9b-441c-9ba6-c16f1c1de07c/agent/trajectory.jsonl) |
| 73 | completed | 1 | 602.25 | 1.52 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/501aa636-fcbd-4d27-b40b-0ecf3b60959c/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/501aa636-fcbd-4d27-b40b-0ecf3b60959c/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/501aa636-fcbd-4d27-b40b-0ecf3b60959c/agent/trajectory.jsonl) |
| 74 | completed | 0 | 448.12 | 1.58 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/640629b0-7e36-44fa-8dc1-6b8213a7a26a/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/640629b0-7e36-44fa-8dc1-6b8213a7a26a/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/640629b0-7e36-44fa-8dc1-6b8213a7a26a/agent/trajectory.jsonl) |
| 75 | completed | 0 | 1243.74 | 1.46 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/e0feb085-b028-404d-acdf-7db087a5535e/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/e0feb085-b028-404d-acdf-7db087a5535e/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/e0feb085-b028-404d-acdf-7db087a5535e/agent/trajectory.jsonl) |
| 76 | completed | 1 | 181.57 | 1.36 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/b1b18553-6fef-470f-876a-744a6f4f8a42/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/b1b18553-6fef-470f-876a-744a6f4f8a42/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/b1b18553-6fef-470f-876a-744a6f4f8a42/agent/trajectory.jsonl) |
| 77 | completed | 0 | 1408.65 | 1.32 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/29752050-7f9b-498b-bbad-e691f1d5fff6/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/29752050-7f9b-498b-bbad-e691f1d5fff6/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/29752050-7f9b-498b-bbad-e691f1d5fff6/agent/trajectory.jsonl) |
| 78 | completed | 0 | 410.82 | 1.62 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/c02d8346-be74-4fd6-8d66-6dfbd355c19b/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/c02d8346-be74-4fd6-8d66-6dfbd355c19b/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/c02d8346-be74-4fd6-8d66-6dfbd355c19b/agent/trajectory.jsonl) |
| 79 | completed | 1 | 175.63 | 1.29 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/9bc8be3f-edfe-45c8-b30f-46ce4207aad1/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/9bc8be3f-edfe-45c8-b30f-46ce4207aad1/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/9bc8be3f-edfe-45c8-b30f-46ce4207aad1/agent/trajectory.jsonl) |
| 80 | completed | 0 | 473.54 | 1.39 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/a6f01e1c-c265-4ae9-88dc-ba171dd8b8ae/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/a6f01e1c-c265-4ae9-88dc-ba171dd8b8ae/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/a6f01e1c-c265-4ae9-88dc-ba171dd8b8ae/agent/trajectory.jsonl) |
| 81 | completed | 1 | 659.45 | 1.30 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/372862fd-9260-4d7e-8c50-395cf489dce0/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/372862fd-9260-4d7e-8c50-395cf489dce0/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/372862fd-9260-4d7e-8c50-395cf489dce0/agent/trajectory.jsonl) |
| 82 | completed | 0 | 408.90 | 1.26 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/d8eda8d0-58ba-4095-9732-f32c381500c7/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/d8eda8d0-58ba-4095-9732-f32c381500c7/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/d8eda8d0-58ba-4095-9732-f32c381500c7/agent/trajectory.jsonl) |
| 83 | completed | 0 | 336.66 | 1.38 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/f63f73ba-6ced-4d72-b026-1b785f5808b9/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/f63f73ba-6ced-4d72-b026-1b785f5808b9/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/f63f73ba-6ced-4d72-b026-1b785f5808b9/agent/trajectory.jsonl) |
| 84 | completed | 1 | 1048.79 | 1.27 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/dbc4fae1-15e2-4278-b32a-4f05cabaf0df/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/dbc4fae1-15e2-4278-b32a-4f05cabaf0df/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/dbc4fae1-15e2-4278-b32a-4f05cabaf0df/agent/trajectory.jsonl) |
| 85 | completed | 0 | 1237.48 | 1.36 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/1ace4cbd-de62-4640-89bf-2ac89d27e19e/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/1ace4cbd-de62-4640-89bf-2ac89d27e19e/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/1ace4cbd-de62-4640-89bf-2ac89d27e19e/agent/trajectory.jsonl) |
| 86 | completed | 1 | 416.73 | 1.31 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/e53562cd-1e5e-4b87-a271-84ba5e1b0ce6/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/e53562cd-1e5e-4b87-a271-84ba5e1b0ce6/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/e53562cd-1e5e-4b87-a271-84ba5e1b0ce6/agent/trajectory.jsonl) |
| 87 | completed | 1 | 384.09 | 1.30 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/312c54c0-7772-499d-a753-5fd479546e7e/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/312c54c0-7772-499d-a753-5fd479546e7e/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/312c54c0-7772-499d-a753-5fd479546e7e/agent/trajectory.jsonl) |
| 88 | completed | 0 | 389.99 | 1.32 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/a71cf398-53c6-4883-9a5c-dacf44d65baa/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/a71cf398-53c6-4883-9a5c-dacf44d65baa/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/a71cf398-53c6-4883-9a5c-dacf44d65baa/agent/trajectory.jsonl) |
| 89 | completed | 0 | 884.52 | 1.18 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/f5b2f465-ba85-46f5-bb52-b3ac850fb68c/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/f5b2f465-ba85-46f5-bb52-b3ac850fb68c/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/f5b2f465-ba85-46f5-bb52-b3ac850fb68c/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

