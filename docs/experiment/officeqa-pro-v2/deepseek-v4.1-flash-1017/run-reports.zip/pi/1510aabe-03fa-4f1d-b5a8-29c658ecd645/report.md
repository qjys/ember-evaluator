<!-- snapshotDigest: 8bc936926cd7f3da0abf9b2ddf9138711bf573a4749cd769a93f47b271c942da -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 38.10%（24/63）**

Run: 1510aabe-03fa-4f1d-b5a8-29c658ecd645 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T13:13:27.937Z / 2026-11-13T23:06:35.733Z |
| 总耗时 | 9 小时 32 分 58 秒 |
| 答对 / 答错 / 解题超时 | 24 / 19 / 1 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 2 / 0 |

已选择 64 题；已保存 45 条记录；待运行 19 题。
有效评分覆盖率：44/64（68.75%）。
执行失败 1；超时 1；取消 0；不支持 0。
Agent 解题超时 1（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 64 |
| 计分题数 | 63 |
| 正常评分题数 | 43 |
| 答对题数 | 24 |
| 无效评测 | 1 |
| 待运行 | 19 |
| 正确率 | 38.10% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 32 分 58 秒 |
| 环境准备耗时 | 9 小时 52 分 51 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 12 分 43 秒 | 1 分 28 秒 | 1 小时 0 分 4 秒 | 45 |
| 任务准备 | 0.48 毫秒 | 0.24 毫秒 | 1.55 毫秒 | 45 |
| 环境启动 | 5 秒 | 3 秒 | 10 秒 | 45 |
| 解题 | 12 分 32 秒 | 1 分 17 秒 | 59 分 56 秒 | 45 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 43 |
| 证据收集 | 902.52 毫秒 | 554.14 毫秒 | 3 秒 | 45 |
| 资源清理 | 3 秒 | 2 秒 | 4 秒 | 45 |
| 评分 | 1 秒 | 1 秒 | 2 秒 | 43 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| e374296a-244a-480c-a7ca-8fcf34aa5e1c | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 194,662,156 | 837,638 | 195,499,794 | 43 / 64 | — |
| 运行累计 | 212,723,565 | 907,336 | 213,630,901 | 45 / 45 | 2 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 26 | completed | 1 | 811.53 | 1.06 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/5d237bf4-c324-4055-bd02-24ada7928d5f/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/5d237bf4-c324-4055-bd02-24ada7928d5f/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/5d237bf4-c324-4055-bd02-24ada7928d5f/agent/trajectory.jsonl) |
| 27 | completed | 1 | 1612.09 | 1.13 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/13dbbce4-54c1-4eeb-b7c5-e3fce66a308d/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/13dbbce4-54c1-4eeb-b7c5-e3fce66a308d/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/13dbbce4-54c1-4eeb-b7c5-e3fce66a308d/agent/trajectory.jsonl) |
| 28 | completed | 1 | 1321.32 | 1.16 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/a42f8255-3f2f-4609-bf75-dea707834f7c/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/a42f8255-3f2f-4609-bf75-dea707834f7c/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/a42f8255-3f2f-4609-bf75-dea707834f7c/agent/trajectory.jsonl) |
| 29 | completed | 0 | 697.31 | 1.08 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/97a28010-e247-492a-bb6a-c9f9e56ce90b/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/97a28010-e247-492a-bb6a-c9f9e56ce90b/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/97a28010-e247-492a-bb6a-c9f9e56ce90b/agent/trajectory.jsonl) |
| 30 | completed | 0 | 645.52 | 1.03 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/8ccf9792-ab7c-4241-b3b8-d4a32b3ce03d/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/8ccf9792-ab7c-4241-b3b8-d4a32b3ce03d/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/8ccf9792-ab7c-4241-b3b8-d4a32b3ce03d/agent/trajectory.jsonl) |
| 31 | completed | 1 | 109.66 | 1.05 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/1ca90817-0b7f-457d-a2b6-863d34de7c93/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/1ca90817-0b7f-457d-a2b6-863d34de7c93/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/1ca90817-0b7f-457d-a2b6-863d34de7c93/agent/trajectory.jsonl) |
| 32 | completed | 0 | 91.30 | 1.10 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/e37c69be-6022-416f-9015-915b0086faa4/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/e37c69be-6022-416f-9015-915b0086faa4/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/e37c69be-6022-416f-9015-915b0086faa4/agent/trajectory.jsonl) |
| 33 | completed | 1 | 482.66 | 1.07 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/5455e4b0-e4fc-466c-94ae-f833818857e6/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/5455e4b0-e4fc-466c-94ae-f833818857e6/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/5455e4b0-e4fc-466c-94ae-f833818857e6/agent/trajectory.jsonl) |
| 34 | completed | 0 | 470.34 | 1.05 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/dff86972-3fe2-4f17-95ba-b3c84c91d553/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/dff86972-3fe2-4f17-95ba-b3c84c91d553/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/dff86972-3fe2-4f17-95ba-b3c84c91d553/agent/trajectory.jsonl) |
| 35 | completed | 1 | 283.05 | 1.02 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/bec7f8d8-2c89-4d97-969c-948bbcabad9c/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/bec7f8d8-2c89-4d97-969c-948bbcabad9c/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/bec7f8d8-2c89-4d97-969c-948bbcabad9c/agent/trajectory.jsonl) |
| 36 | completed | 0 | 1507.56 | 1.71 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/189d253a-88f1-4d20-9dca-9792df32fb1c/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/189d253a-88f1-4d20-9dca-9792df32fb1c/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/189d253a-88f1-4d20-9dca-9792df32fb1c/agent/trajectory.jsonl) |
| 37 | completed | 1 | 176.41 | 1.46 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/0e2ea701-780a-4734-9f2f-467a36023e6d/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/0e2ea701-780a-4734-9f2f-467a36023e6d/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/0e2ea701-780a-4734-9f2f-467a36023e6d/agent/trajectory.jsonl) |
| 38 | completed | 0 | 2068.11 | 1.87 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/a991f773-70bb-41ff-8097-860831e88ee5/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/a991f773-70bb-41ff-8097-860831e88ee5/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/a991f773-70bb-41ff-8097-860831e88ee5/agent/trajectory.jsonl) |
| 39 | completed | 1 | 312.91 | 1.24 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/73b989d5-a898-47e5-9b9b-58f209c6858a/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/73b989d5-a898-47e5-9b9b-58f209c6858a/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/73b989d5-a898-47e5-9b9b-58f209c6858a/agent/trajectory.jsonl) |
| 40 | completed | 0 | 77.29 | 1.13 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/f7a4620c-7cd6-4bab-b1fe-d736108c5e03/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/f7a4620c-7cd6-4bab-b1fe-d736108c5e03/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/f7a4620c-7cd6-4bab-b1fe-d736108c5e03/agent/trajectory.jsonl) |
| 41 | completed | 1 | 170.59 | 1.00 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/1215527a-7c6a-42dd-86e3-0da5cd5dbc63/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/1215527a-7c6a-42dd-86e3-0da5cd5dbc63/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/1215527a-7c6a-42dd-86e3-0da5cd5dbc63/agent/trajectory.jsonl) |
| 42 | completed | 0 | 232.37 | 1.61 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/bd420b8d-fbaa-4ab1-a5b5-316a5b637b2f/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/bd420b8d-fbaa-4ab1-a5b5-316a5b637b2f/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/bd420b8d-fbaa-4ab1-a5b5-316a5b637b2f/agent/trajectory.jsonl) |
| 43 | completed | 1 | 448.43 | 1.30 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/04a1a5c1-7a2f-4245-adaa-72e6e4426b4f/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/04a1a5c1-7a2f-4245-adaa-72e6e4426b4f/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/04a1a5c1-7a2f-4245-adaa-72e6e4426b4f/agent/trajectory.jsonl) |
| 44 | completed | 0 | 675.23 | 1.05 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/4e29d00f-f088-48f9-9c91-8652e44485d8/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/4e29d00f-f088-48f9-9c91-8652e44485d8/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/4e29d00f-f088-48f9-9c91-8652e44485d8/agent/trajectory.jsonl) |
| 45 | completed | 0 | 263.53 | 1.13 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/4a7c13d7-c8fe-4bc6-9902-0cf9e8f55f1c/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/4a7c13d7-c8fe-4bc6-9902-0cf9e8f55f1c/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/4a7c13d7-c8fe-4bc6-9902-0cf9e8f55f1c/agent/trajectory.jsonl) |
| 46 | completed | 1 | 1121.67 | 1.08 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/7d37f6f8-6cbd-4fc9-9fbd-30088160467a/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/7d37f6f8-6cbd-4fc9-9fbd-30088160467a/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/7d37f6f8-6cbd-4fc9-9fbd-30088160467a/agent/trajectory.jsonl) |
| 47 | completed | 0 | 575.72 | 1.45 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/d9802aee-37d3-4c4a-afa8-475ae4eb595b/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/d9802aee-37d3-4c4a-afa8-475ae4eb595b/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/d9802aee-37d3-4c4a-afa8-475ae4eb595b/agent/trajectory.jsonl) |
| 48 | completed | 1 | 310.83 | 1.45 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/134d1b5a-8c30-4ee2-92e5-564786f271dd/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/134d1b5a-8c30-4ee2-92e5-564786f271dd/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/134d1b5a-8c30-4ee2-92e5-564786f271dd/agent/trajectory.jsonl) |
| 49 | completed | 1 | 182.47 | 1.39 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/e9159126-a82d-4071-ac48-3f5f91973950/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/e9159126-a82d-4071-ac48-3f5f91973950/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/e9159126-a82d-4071-ac48-3f5f91973950/agent/trajectory.jsonl) |
| 50 | completed | 0 | 726.59 | 1.31 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/eeb6dc23-92a5-4fd0-98a4-b12209b0a288/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/eeb6dc23-92a5-4fd0-98a4-b12209b0a288/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/eeb6dc23-92a5-4fd0-98a4-b12209b0a288/agent/trajectory.jsonl) |
| 51 | completed | 0 | 2224.79 | 1.25 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/9c21e2eb-1298-4c07-a74b-140b350dba3a/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/9c21e2eb-1298-4c07-a74b-140b350dba3a/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/9c21e2eb-1298-4c07-a74b-140b350dba3a/agent/trajectory.jsonl) |
| 52 | completed | 0 | 436.24 | 1.10 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/00728016-35a5-4a53-81b4-6c668d617ae0/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/00728016-35a5-4a53-81b4-6c668d617ae0/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/00728016-35a5-4a53-81b4-6c668d617ae0/agent/trajectory.jsonl) |
| 53 | completed | 1 | 461.75 | 1.27 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/1ecc4f62-f7f2-4bd5-a2db-a2749c150b26/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/1ecc4f62-f7f2-4bd5-a2db-a2749c150b26/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/1ecc4f62-f7f2-4bd5-a2db-a2749c150b26/agent/trajectory.jsonl) |
| 54 | completed | 1 | 383.79 | 1.16 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/95b0b856-691f-4383-ae9b-4c5f6bf85dcd/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/95b0b856-691f-4383-ae9b-4c5f6bf85dcd/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/95b0b856-691f-4383-ae9b-4c5f6bf85dcd/agent/trajectory.jsonl) |
| 55 | completed | 1 | 1509.35 | 1.51 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/7db7335a-a92e-461d-a4df-4b4685ce5e60/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/7db7335a-a92e-461d-a4df-4b4685ce5e60/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/7db7335a-a92e-461d-a4df-4b4685ce5e60/agent/trajectory.jsonl) |
| 56 | completed | 1 | 337.82 | 1.18 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/af9e520d-0046-40db-a242-8bbf32b3f1d6/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/af9e520d-0046-40db-a242-8bbf32b3f1d6/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/af9e520d-0046-40db-a242-8bbf32b3f1d6/agent/trajectory.jsonl) |
| 57 | completed | 0 | 2684.81 | 1.20 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/18dbab6f-d165-4a0e-b944-830585f89f45/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/18dbab6f-d165-4a0e-b944-830585f89f45/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/18dbab6f-d165-4a0e-b944-830585f89f45/agent/trajectory.jsonl) |
| 58 | completed | 0 | 379.30 | 1.26 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/2cbfaa86-d86b-4951-bf6d-2994a94a4f14/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/2cbfaa86-d86b-4951-bf6d-2994a94a4f14/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/2cbfaa86-d86b-4951-bf6d-2994a94a4f14/agent/trajectory.jsonl) |
| 59 | completed | 0 | 129.61 | 1.21 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/6492db34-e253-4742-a046-1a5ec2cffee2/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/6492db34-e253-4742-a046-1a5ec2cffee2/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/6492db34-e253-4742-a046-1a5ec2cffee2/agent/trajectory.jsonl) |
| 60 | completed | 1 | 465.04 | 1.08 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/0e811aef-071a-42d3-bf1e-85fc45f5d50e/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/0e811aef-071a-42d3-bf1e-85fc45f5d50e/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/0e811aef-071a-42d3-bf1e-85fc45f5d50e/agent/trajectory.jsonl) |
| 61 | completed | 0 | 333.18 | 1.16 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/c40addfc-0e02-42cc-b345-c317b6fec955/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/c40addfc-0e02-42cc-b345-c317b6fec955/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/c40addfc-0e02-42cc-b345-c317b6fec955/agent/trajectory.jsonl) |
| 62 | timeout (agent) | 0 | 3596.17 | — | partial / complete | SOLVER\_AGENT\_TIMEOUT | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/fe8888c3-0296-46a6-8be0-c8e55ceb0a34/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/fe8888c3-0296-46a6-8be0-c8e55ceb0a34/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/fe8888c3-0296-46a6-8be0-c8e55ceb0a34/agent/trajectory.jsonl) |
| 63 | completed | 1 | 435.70 | 1.13 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/348d3640-afbf-45ea-9fc4-c23fbad32105/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/348d3640-afbf-45ea-9fc4-c23fbad32105/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/348d3640-afbf-45ea-9fc4-c23fbad32105/agent/trajectory.jsonl) |
| 64 | completed | 1 | 452.13 | 1.03 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/9f93c440-5d41-43db-99fa-2f169e78cf4e/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/9f93c440-5d41-43db-99fa-2f169e78cf4e/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/9f93c440-5d41-43db-99fa-2f169e78cf4e/agent/trajectory.jsonl) |
| 65 | completed | 0 | 1512.41 | 1.13 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/de2e4e11-eb5a-48f3-897d-8e66fff877a1/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/de2e4e11-eb5a-48f3-897d-8e66fff877a1/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/de2e4e11-eb5a-48f3-897d-8e66fff877a1/agent/trajectory.jsonl) |
| 66 | completed | 1 | 216.06 | 1.06 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/801a59fa-b7f7-4938-9ccd-867d03c1b8ab/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/801a59fa-b7f7-4938-9ccd-867d03c1b8ab/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/801a59fa-b7f7-4938-9ccd-867d03c1b8ab/agent/trajectory.jsonl) |
| 67 | completed | 1 | 248.19 | 1.16 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/d44ca29e-408e-4434-8241-1d19032671b8/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/d44ca29e-408e-4434-8241-1d19032671b8/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/d44ca29e-408e-4434-8241-1d19032671b8/agent/trajectory.jsonl) |
| 68 | completed | 1 | 222.56 | 1.09 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/f433a277-ca03-4b3e-b877-b1eace32c407/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/f433a277-ca03-4b3e-b877-b1eace32c407/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/f433a277-ca03-4b3e-b877-b1eace32c407/agent/trajectory.jsonl) |
| 69 | completed | 1 | 233.85 | 1.01 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/c9c9c0eb-bc59-4f6f-acd7-4577a53f13ef/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/c9c9c0eb-bc59-4f6f-acd7-4577a53f13ef/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/c9c9c0eb-bc59-4f6f-acd7-4577a53f13ef/agent/trajectory.jsonl) |
| 70 | invalid | — | 2183.99 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/7164ed4c-4982-4f71-ad7b-61ee5955df7f/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/7164ed4c-4982-4f71-ad7b-61ee5955df7f/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/7164ed4c-4982-4f71-ad7b-61ee5955df7f/agent/trajectory.jsonl) |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 2；错误记录 3（主流程 2；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_AGENT_TIMEOUT | 1 | 1 |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 警告

警告涉及 1 个任务，共 1 条记录。

| 任务 | 阶段 / 代码 | 说明 |
| --- | --- | --- |
| 62 | collect / ARTIFACT\_COLLECTION\_INCOMPLETE | Agent solve deadline ended the trajectory before completion; all required files were collected |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

