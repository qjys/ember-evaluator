<!-- snapshotDigest: f605d9e75e4d28f52049881067194f94e73c51130ae2354927012e02cf172e16 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 24.72%（22/89）**

Run: 12955fc0-9d2e-4278-b549-dd39f4dcf299 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | volcengine/deepseek-v4.1-flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-13T10:17:35.990Z / 2026-11-13T12:17:19.970Z |
| 总耗时 | 1 小时 55 分 46 秒 |
| 答对 / 答错 / 解题超时 | 22 / 4 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 27 条记录；待运行 63 题。
有效评分覆盖率：26/90（28.89%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 26 |
| 答对题数 | 22 |
| 无效评测 | 1 |
| 待运行 | 63 |
| 正确率 | 24.72% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 1 小时 55 分 46 秒 |
| 环境准备耗时 | 1 小时 59 分 33 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 4 分 16 秒 | 1 分 2 秒 | 10 分 16 秒 | 27 |
| 任务准备 | 0.47 毫秒 | 0.27 毫秒 | 1.74 毫秒 | 27 |
| 环境启动 | 5 秒 | 4 秒 | 6 秒 | 27 |
| 解题 | 4 分 6 秒 | 52 秒 | 10 分 7 秒 | 27 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 26 |
| 证据收集 | 723.68 毫秒 | 532.1 毫秒 | 2 秒 | 27 |
| 资源清理 | 2 秒 | 2 秒 | 3 秒 | 27 |
| 评分 | 1 秒 | 911.32 毫秒 | 1 秒 | 26 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 37cfe5eb-d9aa-4d60-b9d0-5c320a3ca21d | 14,400 | 3600 | 1 | 1 | 3600 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 62,043,959 | 704,853 | 62,748,812 | 26 / 90 | — |
| 运行累计 | 65,389,128 | 746,009 | 66,135,137 | 27 / 27 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 303.41 | 1.03 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/80aab4d4-5def-4537-86c7-e2d7f989fb6c/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/80aab4d4-5def-4537-86c7-e2d7f989fb6c/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/80aab4d4-5def-4537-86c7-e2d7f989fb6c/agent/trajectory.jsonl) |
| 1 | completed | 1 | 253.35 | 1.25 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/61e0f111-c573-4fbc-943c-2f7aa2228021/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/61e0f111-c573-4fbc-943c-2f7aa2228021/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/61e0f111-c573-4fbc-943c-2f7aa2228021/agent/trajectory.jsonl) |
| 2 | completed | 1 | 151.78 | 1.22 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/87bfdb23-90b1-4823-b3d4-767e0f4f49d0/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/87bfdb23-90b1-4823-b3d4-767e0f4f49d0/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/87bfdb23-90b1-4823-b3d4-767e0f4f49d0/agent/trajectory.jsonl) |
| 3 | completed | 1 | 251.74 | 1.48 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/5414ea55-4db5-47dc-9833-62f5c7dc71be/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/5414ea55-4db5-47dc-9833-62f5c7dc71be/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/5414ea55-4db5-47dc-9833-62f5c7dc71be/agent/trajectory.jsonl) |
| 4 | completed | 1 | 176.39 | 0.96 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/06b7ed09-78e3-47e7-b04a-be746acd60b5/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/06b7ed09-78e3-47e7-b04a-be746acd60b5/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/06b7ed09-78e3-47e7-b04a-be746acd60b5/agent/trajectory.jsonl) |
| 5 | completed | 1 | 140.18 | 1.00 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/d024434d-ce8f-43d5-8383-ca7c6e2a8e71/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/d024434d-ce8f-43d5-8383-ca7c6e2a8e71/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/d024434d-ce8f-43d5-8383-ca7c6e2a8e71/agent/trajectory.jsonl) |
| 6 | completed | 1 | 257.41 | 1.24 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/317f24e6-70e1-4297-9cea-5a6e2ea8f978/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/317f24e6-70e1-4297-9cea-5a6e2ea8f978/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/317f24e6-70e1-4297-9cea-5a6e2ea8f978/agent/trajectory.jsonl) |
| 7 | completed | 1 | 93.63 | 1.02 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/2fd855ef-a7cc-4eb2-9aae-7994bfe679e0/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/2fd855ef-a7cc-4eb2-9aae-7994bfe679e0/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/2fd855ef-a7cc-4eb2-9aae-7994bfe679e0/agent/trajectory.jsonl) |
| 8 | completed | 0 | 261.38 | 0.91 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/37e50d12-c991-4d11-ad98-831717771052/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/37e50d12-c991-4d11-ad98-831717771052/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/37e50d12-c991-4d11-ad98-831717771052/agent/trajectory.jsonl) |
| 9 | completed | 1 | 59.99 | 1.15 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/113fe059-b5e2-4603-b62f-228af2a1c0ba/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/113fe059-b5e2-4603-b62f-228af2a1c0ba/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/113fe059-b5e2-4603-b62f-228af2a1c0ba/agent/trajectory.jsonl) |
| 10 | completed | 1 | 197.73 | 1.04 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/95b090a1-4707-428a-9624-c3bea2b81700/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/95b090a1-4707-428a-9624-c3bea2b81700/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/95b090a1-4707-428a-9624-c3bea2b81700/agent/trajectory.jsonl) |
| 11 | completed | 1 | 190.18 | 1.03 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/eb71db6c-2f3e-4b17-b807-f6cdc29c9089/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/eb71db6c-2f3e-4b17-b807-f6cdc29c9089/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/eb71db6c-2f3e-4b17-b807-f6cdc29c9089/agent/trajectory.jsonl) |
| 12 | completed | 1 | 175.88 | 1.10 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/427c634c-a0d7-493f-b8bf-9f9399045104/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/427c634c-a0d7-493f-b8bf-9f9399045104/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/427c634c-a0d7-493f-b8bf-9f9399045104/agent/trajectory.jsonl) |
| 13 | completed | 1 | 372.87 | 1.36 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/d1157237-b590-4574-9175-2d10d846f844/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/d1157237-b590-4574-9175-2d10d846f844/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/d1157237-b590-4574-9175-2d10d846f844/agent/trajectory.jsonl) |
| 14 | completed | 1 | 51.59 | 1.05 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/0558c07d-cc30-442d-b077-eee39a128dde/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/0558c07d-cc30-442d-b077-eee39a128dde/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/0558c07d-cc30-442d-b077-eee39a128dde/agent/trajectory.jsonl) |
| 15 | completed | 0 | 606.90 | 1.07 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/43292845-2f9f-4a0b-800a-21869b3bbae9/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/43292845-2f9f-4a0b-800a-21869b3bbae9/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/43292845-2f9f-4a0b-800a-21869b3bbae9/agent/trajectory.jsonl) |
| 16 | completed | 1 | 235.24 | 1.11 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/ad76d76e-d9fe-4051-bc18-f8d33819428f/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/ad76d76e-d9fe-4051-bc18-f8d33819428f/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/ad76d76e-d9fe-4051-bc18-f8d33819428f/agent/trajectory.jsonl) |
| 17 | completed | 1 | 211.31 | 1.11 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/3c6b3a82-d698-487f-834d-8cc04b226123/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/3c6b3a82-d698-487f-834d-8cc04b226123/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/3c6b3a82-d698-487f-834d-8cc04b226123/agent/trajectory.jsonl) |
| 18 | completed | 0 | 568.73 | 0.91 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/05c67b5b-82dd-435d-9373-a0500e97c693/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/05c67b5b-82dd-435d-9373-a0500e97c693/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/05c67b5b-82dd-435d-9373-a0500e97c693/agent/trajectory.jsonl) |
| 19 | completed | 1 | 150.26 | 0.93 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/e7a19d2a-6145-463d-a1a7-35e2e9834b8a/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/e7a19d2a-6145-463d-a1a7-35e2e9834b8a/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/e7a19d2a-6145-463d-a1a7-35e2e9834b8a/agent/trajectory.jsonl) |
| 20 | completed | 1 | 394.00 | 1.01 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/1ca3feb6-c8b9-41e5-b481-b4d9cd9f438e/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/1ca3feb6-c8b9-41e5-b481-b4d9cd9f438e/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/1ca3feb6-c8b9-41e5-b481-b4d9cd9f438e/agent/trajectory.jsonl) |
| 21 | completed | 1 | 214.66 | 1.36 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/55fa8c44-9d18-422d-b6da-f979e81c0d45/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/55fa8c44-9d18-422d-b6da-f979e81c0d45/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/55fa8c44-9d18-422d-b6da-f979e81c0d45/agent/trajectory.jsonl) |
| 22 | completed | 1 | 112.93 | 1.06 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/6b494755-4faf-4259-8266-9da7fb7a44d0/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/6b494755-4faf-4259-8266-9da7fb7a44d0/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/6b494755-4faf-4259-8266-9da7fb7a44d0/agent/trajectory.jsonl) |
| 23 | completed | 1 | 135.04 | 1.44 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/55c6a78f-75fd-44be-9f9b-97da62c81825/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/55c6a78f-75fd-44be-9f9b-97da62c81825/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/55c6a78f-75fd-44be-9f9b-97da62c81825/agent/trajectory.jsonl) |
| 24 | completed | 0 | 266.83 | 1.07 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/3ef0c285-7ea4-4521-961d-4c0452bd4edc/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/3ef0c285-7ea4-4521-961d-4c0452bd4edc/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/3ef0c285-7ea4-4521-961d-4c0452bd4edc/agent/trajectory.jsonl) |
| 25 | completed | 1 | 494.70 | 1.04 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/362c2db2-76e2-4ac9-b654-e79d226e6460/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/362c2db2-76e2-4ac9-b654-e79d226e6460/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/362c2db2-76e2-4ac9-b654-e79d226e6460/agent/trajectory.jsonl) |
| 26 | invalid | — | 322.37 | — | partial / complete | MODEL\_AUTH\_FAILED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/7e76d693-9e9a-4d35-8914-cfcb8c3bb512/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/7e76d693-9e9a-4d35-8914-cfcb8c3bb512/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/7e76d693-9e9a-4d35-8914-cfcb8c3bb512/agent/trajectory.jsonl) |
| 27 | pending | — | — | — | — | — | — |
| 28 | pending | — | — | — | — | — | — |
| 29 | pending | — | — | — | — | — | — |
| 30 | pending | — | — | — | — | — | — |
| 31 | pending | — | — | — | — | — | — |
| 32 | pending | — | — | — | — | — | — |
| 33 | pending | — | — | — | — | — | — |
| 34 | pending | — | — | — | — | — | — |
| 35 | pending | — | — | — | — | — | — |
| 36 | pending | — | — | — | — | — | — |
| 37 | pending | — | — | — | — | — | — |
| 38 | pending | — | — | — | — | — | — |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | MODEL_AUTH_FAILED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

