<!-- snapshotDigest: cc49c5ac4ee2fdc0e9f3d7e6e47b2d061e56f33f4f80f7990aaaec6bf54f21ec -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 24.72%（22/89）**

Run: 43552c02-bfe7-4425-8d1e-d7c0cf493b25 · Status: cancelled

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | trae |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-19T15:53:31.607Z / 2026-11-20T01:47:49.255Z |
| 总耗时 | 9 小时 54 分 18 秒 |
| 答对 / 答错 / 解题超时 | 22 / 5 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 28 条记录；待运行 63 题。
有效评分覆盖率：27/90（30.00%）。
执行失败 0；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 27 |
| 答对题数 | 22 |
| 无效评测 | 1 |
| 待运行 | 63 |
| 正确率 | 24.72% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 54 分 18 秒 |
| 环境准备耗时 | 9 小时 53 分 55 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 7 分 43 秒 | 35 秒 | 26 分 43 秒 | 28 |
| 任务准备 | 0.38 毫秒 | 0.22 毫秒 | 0.91 毫秒 | 28 |
| 环境启动 | 5 秒 | 3 秒 | 13 秒 | 28 |
| 解题 | 7 分 32 秒 | 25 秒 | 26 分 31 秒 | 28 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 27 |
| 证据收集 | 1 秒 | 848.47 毫秒 | 4 秒 | 28 |
| 资源清理 | 3 秒 | 2 秒 | 5 秒 | 28 |
| 评分 | 827.88 毫秒 | 686.17 毫秒 | 1 秒 | 27 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 5cdad28a-60f5-44ed-a439-68a997aca767 | 14,400 | 3600 | 2 | 2 | 7200 |
| 1e9e9f38-0f9f-4e1f-916a-6c2866c89ba1 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 76,029,411 | 1,449,595 | 77,479,006 | 27 / 90 | — |
| 运行累计 | 76,029,411 | 1,449,595 | 77,479,006 | 27 / 29 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 1590.68 | 0.92 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/838663cf-ffaf-4e3d-bc93-bfb99031ccdb/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/838663cf-ffaf-4e3d-bc93-bfb99031ccdb/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/838663cf-ffaf-4e3d-bc93-bfb99031ccdb/agent/trajectory.jsonl) |
| 1 | completed | 1 | 204.09 | 0.69 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/ccb7a07e-424a-4953-8c13-01507546f050/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/ccb7a07e-424a-4953-8c13-01507546f050/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/ccb7a07e-424a-4953-8c13-01507546f050/agent/trajectory.jsonl) |
| 2 | completed | 1 | 245.57 | 0.94 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/ae87607f-1a2f-4b48-adbf-ab566131d434/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/ae87607f-1a2f-4b48-adbf-ab566131d434/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/ae87607f-1a2f-4b48-adbf-ab566131d434/agent/trajectory.jsonl) |
| 3 | completed | 0 | 100.77 | 0.75 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/f0b95889-40b9-4401-bd49-5849f65fadb6/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/f0b95889-40b9-4401-bd49-5849f65fadb6/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/f0b95889-40b9-4401-bd49-5849f65fadb6/agent/trajectory.jsonl) |
| 4 | completed | 1 | 53.25 | 0.89 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/0c28ac0b-aee6-45ee-823a-925bb23b59b6/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/0c28ac0b-aee6-45ee-823a-925bb23b59b6/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/0c28ac0b-aee6-45ee-823a-925bb23b59b6/agent/trajectory.jsonl) |
| 5 | completed | 1 | 140.28 | 0.82 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/ce2dd3d9-6bac-4e63-ad8d-c6b1d424ff4f/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/ce2dd3d9-6bac-4e63-ad8d-c6b1d424ff4f/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/ce2dd3d9-6bac-4e63-ad8d-c6b1d424ff4f/agent/trajectory.jsonl) |
| 6 | completed | 1 | 355.71 | 0.79 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/b9850d3f-63e4-4964-9017-86ca945425d2/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/b9850d3f-63e4-4964-9017-86ca945425d2/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/b9850d3f-63e4-4964-9017-86ca945425d2/agent/trajectory.jsonl) |
| 7 | completed | 1 | 43.33 | 0.78 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/18d75ba1-8dcc-4065-a6ce-196fac16d99d/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/18d75ba1-8dcc-4065-a6ce-196fac16d99d/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/18d75ba1-8dcc-4065-a6ce-196fac16d99d/agent/trajectory.jsonl) |
| 8 | completed | 0 | 28.82 | 0.88 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/2b99347a-572a-479a-bf8f-c5cd0886d62f/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/2b99347a-572a-479a-bf8f-c5cd0886d62f/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/2b99347a-572a-479a-bf8f-c5cd0886d62f/agent/trajectory.jsonl) |
| 9 | completed | 1 | 25.18 | 0.74 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/4de59dd5-73dc-482f-89b7-92c3063a5560/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/4de59dd5-73dc-482f-89b7-92c3063a5560/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/4de59dd5-73dc-482f-89b7-92c3063a5560/agent/trajectory.jsonl) |
| 10 | completed | 1 | 570.28 | 0.84 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/3587a811-80e2-489f-abab-6a97d74cebe6/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/3587a811-80e2-489f-abab-6a97d74cebe6/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/3587a811-80e2-489f-abab-6a97d74cebe6/agent/trajectory.jsonl) |
| 11 | completed | 1 | 244.30 | 0.75 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/eee75821-9b42-423d-a29f-4a3a52055bbb/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/eee75821-9b42-423d-a29f-4a3a52055bbb/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/eee75821-9b42-423d-a29f-4a3a52055bbb/agent/trajectory.jsonl) |
| 12 | completed | 1 | 227.62 | 0.82 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/b4f3d764-a71d-4745-8763-b4c192ccb645/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/b4f3d764-a71d-4745-8763-b4c192ccb645/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/b4f3d764-a71d-4745-8763-b4c192ccb645/agent/trajectory.jsonl) |
| 13 | completed | 1 | 1236.17 | 0.82 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/0f26a72c-6b09-4bec-9756-d50d781b7a5d/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/0f26a72c-6b09-4bec-9756-d50d781b7a5d/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/0f26a72c-6b09-4bec-9756-d50d781b7a5d/agent/trajectory.jsonl) |
| 14 | completed | 0 | 409.06 | 0.80 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/6326e3a7-3cd9-4aa5-8ee5-99ecd5e424a9/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/6326e3a7-3cd9-4aa5-8ee5-99ecd5e424a9/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/6326e3a7-3cd9-4aa5-8ee5-99ecd5e424a9/agent/trajectory.jsonl) |
| 15 | completed | 0 | 767.76 | 0.82 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/173739bd-3a26-4739-88a7-fcf0a63956dd/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/173739bd-3a26-4739-88a7-fcf0a63956dd/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/173739bd-3a26-4739-88a7-fcf0a63956dd/agent/trajectory.jsonl) |
| 16 | completed | 1 | 843.59 | 0.80 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/ad97075f-cd62-42ca-b156-27a68c2959c6/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/ad97075f-cd62-42ca-b156-27a68c2959c6/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/ad97075f-cd62-42ca-b156-27a68c2959c6/agent/trajectory.jsonl) |
| 17 | completed | 1 | 270.58 | 1.01 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/2d12e3cd-f2cb-4cdc-8595-31c370b6f4c0/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/2d12e3cd-f2cb-4cdc-8595-31c370b6f4c0/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/2d12e3cd-f2cb-4cdc-8595-31c370b6f4c0/agent/trajectory.jsonl) |
| 18 | completed | 1 | 1179.68 | 1.05 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/48c6c97c-e655-4c55-ab71-670597d6ccf1/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/48c6c97c-e655-4c55-ab71-670597d6ccf1/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/48c6c97c-e655-4c55-ab71-670597d6ccf1/agent/trajectory.jsonl) |
| 19 | completed | 0 | 417.86 | 0.91 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/950f2e43-ab2b-44a5-a266-03f7a4d1400c/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/950f2e43-ab2b-44a5-a266-03f7a4d1400c/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/950f2e43-ab2b-44a5-a266-03f7a4d1400c/agent/trajectory.jsonl) |
| 20 | completed | 1 | 831.88 | 1.00 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/efefe09a-0f54-4e0d-b4be-56c84a721d36/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/efefe09a-0f54-4e0d-b4be-56c84a721d36/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/efefe09a-0f54-4e0d-b4be-56c84a721d36/agent/trajectory.jsonl) |
| 21 | completed | 1 | 76.37 | 0.73 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/3800e70f-73b5-4922-bf9f-e0965b505dc0/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/3800e70f-73b5-4922-bf9f-e0965b505dc0/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/3800e70f-73b5-4922-bf9f-e0965b505dc0/agent/trajectory.jsonl) |
| 22 | completed | 1 | 179.42 | 0.76 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/c9b7c946-5bc7-4b4f-9aae-c896ed54bfaf/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/c9b7c946-5bc7-4b4f-9aae-c896ed54bfaf/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/c9b7c946-5bc7-4b4f-9aae-c896ed54bfaf/agent/trajectory.jsonl) |
| 23 | completed | 1 | 355.93 | 0.74 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/29ea918f-44e9-428a-b230-b639a9d1bbbb/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/29ea918f-44e9-428a-b230-b639a9d1bbbb/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/29ea918f-44e9-428a-b230-b639a9d1bbbb/agent/trajectory.jsonl) |
| 24 | completed | 1 | 735.96 | 0.70 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/a8239cf4-d2c3-4d1a-822e-441c72bd3c80/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/a8239cf4-d2c3-4d1a-822e-441c72bd3c80/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/a8239cf4-d2c3-4d1a-822e-441c72bd3c80/agent/trajectory.jsonl) |
| 25 | completed | 1 | 596.15 | 0.77 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/14aeec65-071d-435e-b902-a99afbcc1ca8/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/14aeec65-071d-435e-b902-a99afbcc1ca8/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/14aeec65-071d-435e-b902-a99afbcc1ca8/agent/trajectory.jsonl) |
| 26 | completed | 1 | 303.08 | 0.86 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/5245a993-c216-4b15-9fc4-69c662b4c1f6/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/5245a993-c216-4b15-9fc4-69c662b4c1f6/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/5245a993-c216-4b15-9fc4-69c662b4c1f6/agent/trajectory.jsonl) |
| 27 | pending | — | — | — | — | — | — |
| 28 | cancelled | — | 627.40 | — | partial / complete | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/4726a714-da9c-4e73-af9f-fd5ce61d3104/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/4726a714-da9c-4e73-af9f-fd5ce61d3104/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/4726a714-da9c-4e73-af9f-fd5ce61d3104/agent/trajectory.jsonl) |
| 29 | pending | — | — | — | — | — | — |
| 30 | pending | — | — | — | — | — | — |
| 31 | pending | — | — | — | — | — | — |
| 32 | pending | — | — | — | — | — | — |
| 33 | pending | — | — | — | — | — | — |
| 34 | pending | — | — | — | — | — | — |
| 35 | pending | — | — | — | — | — | — |
| 36 | pending | — | — | — | — | — | — |
| 37 | pending | — | — | — | — | — | — |
| 38 | pending | — | — | — | — | — | — |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

