<!-- snapshotDigest: 34217165138c3e12f8876308b833c9bd21917ae350a9a2e5358141be96c0e2a6 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 32.56%（14/43）**

Run: a4e4dd1d-f01b-4d9a-a237-1d67d35b6283 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-20T01:58:34.711Z / 2026-11-20T10:10:47.226Z |
| 总耗时 | 8 小时 12 分 13 秒 |
| 答对 / 答错 / 解题超时 | 14 / 29 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 43 题；已保存 43 条记录；待运行 0 题。
有效评分覆盖率：43/43（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 43 |
| 计分题数 | 43 |
| 正常评分题数 | 43 |
| 答对题数 | 14 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 32.56% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 8 小时 12 分 13 秒 |
| 环境准备耗时 | 5 小时 29 分 47 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 8 分 48 秒 | 1 分 59 秒 | 35 分 42 秒 | 43 |
| 任务准备 | 0.38 毫秒 | 0.12 毫秒 | 1.21 毫秒 | 43 |
| 环境启动 | 6 秒 | 3 秒 | 12 秒 | 43 |
| 解题 | 8 分 34 秒 | 1 分 42 秒 | 35 分 31 秒 | 43 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 43 |
| 证据收集 | 1 秒 | 905.94 毫秒 | 2 秒 | 43 |
| 资源清理 | 4 秒 | 2 秒 | 12 秒 | 43 |
| 评分 | 1 秒 | 708.55 毫秒 | 2 秒 | 43 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 41e82f00-b70c-47f9-b3c8-8b44f1c6466f | 14,400 | 3600 | 2 | 2 | 7200 |
| 9927e0f7-39ab-4e6e-b24e-bb133716e740 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 102,336,614 | 1,186,595 | 103,523,209 | 43 / 43 | — |
| 运行累计 | 102,336,614 | 1,186,595 | 103,523,209 | 43 / 44 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 46 | completed | 1 | 1464.41 | 0.84 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/05fa2db5-ae40-4fa9-bd52-f31a491f8dd0/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/05fa2db5-ae40-4fa9-bd52-f31a491f8dd0/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/05fa2db5-ae40-4fa9-bd52-f31a491f8dd0/agent/trajectory.jsonl) |
| 48 | completed | 1 | 363.22 | 0.86 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/c5583c65-c835-468a-9481-35457f5ff15a/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/c5583c65-c835-468a-9481-35457f5ff15a/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/c5583c65-c835-468a-9481-35457f5ff15a/agent/trajectory.jsonl) |
| 49 | completed | 0 | 183.38 | 0.86 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/20915a70-be9c-479b-8885-1b1ce2ce4704/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/20915a70-be9c-479b-8885-1b1ce2ce4704/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/20915a70-be9c-479b-8885-1b1ce2ce4704/agent/trajectory.jsonl) |
| 50 | completed | 0 | 225.47 | 0.85 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/19449fe4-bdb8-47f3-82d8-cd787a6e7446/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/19449fe4-bdb8-47f3-82d8-cd787a6e7446/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/19449fe4-bdb8-47f3-82d8-cd787a6e7446/agent/trajectory.jsonl) |
| 51 | completed | 0 | 741.46 | 0.82 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/dd36485a-2c29-4ef5-8fa7-0c151cd0f1ef/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/dd36485a-2c29-4ef5-8fa7-0c151cd0f1ef/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/dd36485a-2c29-4ef5-8fa7-0c151cd0f1ef/agent/trajectory.jsonl) |
| 52 | completed | 0 | 344.51 | 0.96 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/1af503e3-10d5-4102-b993-ed8c24fb68c9/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/1af503e3-10d5-4102-b993-ed8c24fb68c9/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/1af503e3-10d5-4102-b993-ed8c24fb68c9/agent/trajectory.jsonl) |
| 53 | completed | 1 | 2130.70 | 1.11 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/d225cc16-18de-4e57-af90-184150b5d40b/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/d225cc16-18de-4e57-af90-184150b5d40b/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/d225cc16-18de-4e57-af90-184150b5d40b/agent/trajectory.jsonl) |
| 54 | completed | 1 | 1581.24 | 1.05 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/fa48da73-99fe-448f-9d03-3b1757a8967d/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/fa48da73-99fe-448f-9d03-3b1757a8967d/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/fa48da73-99fe-448f-9d03-3b1757a8967d/agent/trajectory.jsonl) |
| 55 | completed | 1 | 779.14 | 0.93 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/7a8a658a-c687-41ff-8727-7e44eaaf7ddf/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/7a8a658a-c687-41ff-8727-7e44eaaf7ddf/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/7a8a658a-c687-41ff-8727-7e44eaaf7ddf/agent/trajectory.jsonl) |
| 56 | completed | 0 | 713.04 | 0.92 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/638b189e-f631-400e-9be6-8d828634b343/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/638b189e-f631-400e-9be6-8d828634b343/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/638b189e-f631-400e-9be6-8d828634b343/agent/trajectory.jsonl) |
| 57 | completed | 0 | 381.36 | 0.98 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/12bc250e-ec71-449f-b1c5-470c9ab7a4ba/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/12bc250e-ec71-449f-b1c5-470c9ab7a4ba/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/12bc250e-ec71-449f-b1c5-470c9ab7a4ba/agent/trajectory.jsonl) |
| 58 | completed | 0 | 311.43 | 1.33 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/a177c66d-498d-443c-a2db-a12ed98ca7d8/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/a177c66d-498d-443c-a2db-a12ed98ca7d8/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/a177c66d-498d-443c-a2db-a12ed98ca7d8/agent/trajectory.jsonl) |
| 59 | completed | 0 | 133.13 | 0.95 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/fe4cf60a-7d3d-45f9-aa23-1ccf4e926288/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/fe4cf60a-7d3d-45f9-aa23-1ccf4e926288/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/fe4cf60a-7d3d-45f9-aa23-1ccf4e926288/agent/trajectory.jsonl) |
| 60 | completed | 1 | 203.33 | 0.87 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/f2118fc2-38c6-47cb-98eb-03042045bbd8/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/f2118fc2-38c6-47cb-98eb-03042045bbd8/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/f2118fc2-38c6-47cb-98eb-03042045bbd8/agent/trajectory.jsonl) |
| 61 | completed | 0 | 578.16 | 1.21 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/e82d16a8-205c-484e-abb5-9ef708aef834/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/e82d16a8-205c-484e-abb5-9ef708aef834/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/e82d16a8-205c-484e-abb5-9ef708aef834/agent/trajectory.jsonl) |
| 62 | completed | 0 | 149.41 | 1.61 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/fdc8c864-0d31-48ea-a091-851ea7e6e589/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/fdc8c864-0d31-48ea-a091-851ea7e6e589/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/fdc8c864-0d31-48ea-a091-851ea7e6e589/agent/trajectory.jsonl) |
| 63 | completed | 1 | 406.67 | 1.07 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/6c8cbaaa-9e46-49d1-98b7-3b087e18e928/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/6c8cbaaa-9e46-49d1-98b7-3b087e18e928/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/6c8cbaaa-9e46-49d1-98b7-3b087e18e928/agent/trajectory.jsonl) |
| 64 | completed | 1 | 134.43 | 1.62 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/81a9b4fd-5c83-48e2-b910-4d1c2fa88f61/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/81a9b4fd-5c83-48e2-b910-4d1c2fa88f61/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/81a9b4fd-5c83-48e2-b910-4d1c2fa88f61/agent/trajectory.jsonl) |
| 65 | completed | 0 | 239.39 | 1.47 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/ca448439-a6c9-4c7c-9452-abb1da2e0952/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/ca448439-a6c9-4c7c-9452-abb1da2e0952/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/ca448439-a6c9-4c7c-9452-abb1da2e0952/agent/trajectory.jsonl) |
| 66 | completed | 1 | 124.89 | 1.25 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/31c6ae8d-ac10-4724-83db-d1cf08c58175/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/31c6ae8d-ac10-4724-83db-d1cf08c58175/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/31c6ae8d-ac10-4724-83db-d1cf08c58175/agent/trajectory.jsonl) |
| 67 | completed | 1 | 325.81 | 1.15 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/74ad0c70-d243-40e6-8807-6478193cd119/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/74ad0c70-d243-40e6-8807-6478193cd119/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/74ad0c70-d243-40e6-8807-6478193cd119/agent/trajectory.jsonl) |
| 68 | completed | 1 | 363.04 | 1.23 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/bcb0d1b4-c3db-499c-a40e-330f2c82c69d/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/bcb0d1b4-c3db-499c-a40e-330f2c82c69d/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/bcb0d1b4-c3db-499c-a40e-330f2c82c69d/agent/trajectory.jsonl) |
| 69 | completed | 0 | 422.21 | 1.59 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/5047c6df-287e-4573-a0df-c1be9ae9f299/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/5047c6df-287e-4573-a0df-c1be9ae9f299/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/5047c6df-287e-4573-a0df-c1be9ae9f299/agent/trajectory.jsonl) |
| 70 | completed | 0 | 217.20 | 1.49 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/e0998bb6-1f8c-44af-aa62-53282b5b33fb/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/e0998bb6-1f8c-44af-aa62-53282b5b33fb/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/e0998bb6-1f8c-44af-aa62-53282b5b33fb/agent/trajectory.jsonl) |
| 71 | completed | 0 | 1574.95 | 1.18 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/d89b7180-e030-4bc1-ad6a-c2216ea52a9c/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/d89b7180-e030-4bc1-ad6a-c2216ea52a9c/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/d89b7180-e030-4bc1-ad6a-c2216ea52a9c/agent/trajectory.jsonl) |
| 72 | completed | 0 | 1027.90 | 1.37 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/740c044b-4320-41ab-b049-f40f9335a8b3/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/740c044b-4320-41ab-b049-f40f9335a8b3/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/740c044b-4320-41ab-b049-f40f9335a8b3/agent/trajectory.jsonl) |
| 73 | completed | 1 | 302.72 | 0.78 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/8ac694e9-3c99-4efe-ab9f-9f3cb5243c15/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/8ac694e9-3c99-4efe-ab9f-9f3cb5243c15/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/8ac694e9-3c99-4efe-ab9f-9f3cb5243c15/agent/trajectory.jsonl) |
| 74 | completed | 0 | 230.97 | 2.49 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/a1fe8d6e-6be9-4efd-8297-bbe5a8f45e32/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/a1fe8d6e-6be9-4efd-8297-bbe5a8f45e32/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/a1fe8d6e-6be9-4efd-8297-bbe5a8f45e32/agent/trajectory.jsonl) |
| 75 | completed | 0 | 375.93 | 1.63 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/3aa29086-6d6d-40f2-a396-45d8ce84f26a/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/3aa29086-6d6d-40f2-a396-45d8ce84f26a/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/3aa29086-6d6d-40f2-a396-45d8ce84f26a/agent/trajectory.jsonl) |
| 76 | completed | 0 | 101.87 | 1.55 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/d06a7e4b-1791-4a0e-8a6e-70302d32cd2d/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/d06a7e4b-1791-4a0e-8a6e-70302d32cd2d/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/d06a7e4b-1791-4a0e-8a6e-70302d32cd2d/agent/trajectory.jsonl) |
| 77 | completed | 0 | 1603.03 | 1.06 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/870faf42-5179-486e-b919-db06672cd523/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/870faf42-5179-486e-b919-db06672cd523/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/870faf42-5179-486e-b919-db06672cd523/agent/trajectory.jsonl) |
| 78 | completed | 0 | 208.20 | 0.71 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/a3fb2ecd-a331-413f-8aa0-6d40635c958b/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/a3fb2ecd-a331-413f-8aa0-6d40635c958b/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/a3fb2ecd-a331-413f-8aa0-6d40635c958b/agent/trajectory.jsonl) |
| 79 | completed | 1 | 138.49 | 1.03 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/b517565e-2d4a-4845-bb62-7f28121a29be/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/b517565e-2d4a-4845-bb62-7f28121a29be/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/b517565e-2d4a-4845-bb62-7f28121a29be/agent/trajectory.jsonl) |
| 80 | completed | 0 | 427.43 | 0.80 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/3218c872-cb78-467e-beb1-263b0239fdfa/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/3218c872-cb78-467e-beb1-263b0239fdfa/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/3218c872-cb78-467e-beb1-263b0239fdfa/agent/trajectory.jsonl) |
| 81 | completed | 0 | 155.35 | 0.81 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/e8041628-93b1-4aba-b101-e60c53829632/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/e8041628-93b1-4aba-b101-e60c53829632/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/e8041628-93b1-4aba-b101-e60c53829632/agent/trajectory.jsonl) |
| 82 | completed | 0 | 1139.86 | 0.74 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/27af93da-7b3e-4d8c-b2c2-053c33ab68ea/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/27af93da-7b3e-4d8c-b2c2-053c33ab68ea/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/27af93da-7b3e-4d8c-b2c2-053c33ab68ea/agent/trajectory.jsonl) |
| 83 | completed | 0 | 310.44 | 0.80 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/5b41f8ad-9e62-4f55-96c6-3fd6a7d49af5/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/5b41f8ad-9e62-4f55-96c6-3fd6a7d49af5/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/5b41f8ad-9e62-4f55-96c6-3fd6a7d49af5/agent/trajectory.jsonl) |
| 84 | completed | 1 | 396.84 | 0.79 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/1efe1b1a-583a-4b84-967b-e1494650c2bd/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/1efe1b1a-583a-4b84-967b-e1494650c2bd/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/1efe1b1a-583a-4b84-967b-e1494650c2bd/agent/trajectory.jsonl) |
| 85 | completed | 0 | 372.70 | 0.78 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/79fc258c-46f0-4047-80a8-96a2ad1f81d7/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/79fc258c-46f0-4047-80a8-96a2ad1f81d7/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/79fc258c-46f0-4047-80a8-96a2ad1f81d7/agent/trajectory.jsonl) |
| 86 | completed | 0 | 263.78 | 0.75 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/676ab345-7026-472e-9b3f-44fdf56251c7/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/676ab345-7026-472e-9b3f-44fdf56251c7/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/676ab345-7026-472e-9b3f-44fdf56251c7/agent/trajectory.jsonl) |
| 87 | completed | 0 | 188.39 | 0.71 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/a7e7719e-deb8-466e-a09e-d97ab7da25c6/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/a7e7719e-deb8-466e-a09e-d97ab7da25c6/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/a7e7719e-deb8-466e-a09e-d97ab7da25c6/agent/trajectory.jsonl) |
| 88 | completed | 0 | 258.84 | 0.76 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/0bade5e8-ba7d-434e-b221-0cc3affbd44e/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/0bade5e8-ba7d-434e-b221-0cc3affbd44e/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/0bade5e8-ba7d-434e-b221-0cc3affbd44e/agent/trajectory.jsonl) |
| 89 | completed | 0 | 526.80 | 0.76 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/edb6a7b0-c766-43cd-86b2-84d27c53f952/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/edb6a7b0-c766-43cd-86b2-84d27c53f952/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/edb6a7b0-c766-43cd-86b2-84d27c53f952/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

