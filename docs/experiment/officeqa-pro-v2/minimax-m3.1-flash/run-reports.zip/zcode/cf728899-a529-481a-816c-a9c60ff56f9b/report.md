<!-- snapshotDigest: 40074192fede7a203a1cb04042c4c73d86c6961f869803cb0212defa87d7b620 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 33.71%（30/89）**

Run: cf728899-a529-481a-816c-a9c60ff56f9b · Status: cancelled

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | zcode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-19T15:56:40.510Z / 2026-11-20T01:47:52.380Z |
| 总耗时 | 9 小时 51 分 12 秒 |
| 答对 / 答错 / 解题超时 | 30 / 17 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 48 条记录；待运行 43 题。
有效评分覆盖率：47/90（52.22%）。
执行失败 0；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 47 |
| 答对题数 | 30 |
| 无效评测 | 1 |
| 待运行 | 43 |
| 正确率 | 33.71% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 51 分 12 秒 |
| 环境准备耗时 | 9 小时 50 分 45 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 4 分 21 秒 | 27 秒 | 24 分 6 秒 | 48 |
| 任务准备 | 0.33 毫秒 | 0.23 毫秒 | 0.76 毫秒 | 48 |
| 环境启动 | 4 秒 | 3 秒 | 12 秒 | 48 |
| 解题 | 4 分 11 秒 | 19 秒 | 23 分 55 秒 | 48 |
| 产物传输 | 1 秒 | 991.9 毫秒 | 2 秒 | 47 |
| 证据收集 | 1 秒 | 870.82 毫秒 | 4 秒 | 48 |
| 资源清理 | 3 秒 | 2 秒 | 7 秒 | 48 |
| 评分 | 815.17 毫秒 | 683.55 毫秒 | 1 秒 | 47 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| ac393464-51b2-4a11-b26a-fe33e3f302e6 | 14,400 | 3600 | 2 | 2 | 7200 |
| 18faf20d-0bc3-4a0f-9fc5-0ac50212bfe1 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 77,630,673 | 1,052,454 | 78,683,127 | 47 / 90 | — |
| 运行累计 | 77,630,673 | 1,052,454 | 78,683,127 | 47 / 49 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 33.92 | 0.83 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/4134a26c-554e-4bbf-80a0-c54bb112e5c6/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/4134a26c-554e-4bbf-80a0-c54bb112e5c6/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/4134a26c-554e-4bbf-80a0-c54bb112e5c6/agent/trajectory.jsonl) |
| 1 | completed | 1 | 143.45 | 0.90 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/9a0cf7cc-9c29-4dd0-9d5f-f0b2e515022f/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/9a0cf7cc-9c29-4dd0-9d5f-f0b2e515022f/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/9a0cf7cc-9c29-4dd0-9d5f-f0b2e515022f/agent/trajectory.jsonl) |
| 2 | completed | 1 | 461.86 | 1.01 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/d6001e9a-6250-421b-bc89-01cc3c1a536f/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/d6001e9a-6250-421b-bc89-01cc3c1a536f/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/d6001e9a-6250-421b-bc89-01cc3c1a536f/agent/trajectory.jsonl) |
| 3 | completed | 0 | 118.44 | 0.91 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/68ce1036-9ce2-44f9-87a1-6d06f32c1553/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/68ce1036-9ce2-44f9-87a1-6d06f32c1553/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/68ce1036-9ce2-44f9-87a1-6d06f32c1553/agent/trajectory.jsonl) |
| 4 | completed | 1 | 31.82 | 0.77 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/5d43ce57-28e8-4cb0-a165-3970f7209cc0/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/5d43ce57-28e8-4cb0-a165-3970f7209cc0/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/5d43ce57-28e8-4cb0-a165-3970f7209cc0/agent/trajectory.jsonl) |
| 5 | completed | 1 | 136.63 | 0.71 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/227246ca-9c65-404a-8bf4-4378baab7a62/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/227246ca-9c65-404a-8bf4-4378baab7a62/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/227246ca-9c65-404a-8bf4-4378baab7a62/agent/trajectory.jsonl) |
| 6 | completed | 1 | 84.03 | 0.68 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/28b4632e-f8a5-496f-b40e-24278d231430/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/28b4632e-f8a5-496f-b40e-24278d231430/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/28b4632e-f8a5-496f-b40e-24278d231430/agent/trajectory.jsonl) |
| 7 | completed | 1 | 18.86 | 0.71 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/52d0c29c-41b4-46ed-bf8a-20872e604fc8/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/52d0c29c-41b4-46ed-bf8a-20872e604fc8/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/52d0c29c-41b4-46ed-bf8a-20872e604fc8/agent/trajectory.jsonl) |
| 8 | completed | 0 | 77.19 | 0.76 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/10a91c1e-857b-480c-8f4f-64d1692df715/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/10a91c1e-857b-480c-8f4f-64d1692df715/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/10a91c1e-857b-480c-8f4f-64d1692df715/agent/trajectory.jsonl) |
| 9 | completed | 1 | 45.23 | 0.68 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/833ae200-0564-4921-b19e-15106059549c/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/833ae200-0564-4921-b19e-15106059549c/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/833ae200-0564-4921-b19e-15106059549c/agent/trajectory.jsonl) |
| 10 | completed | 1 | 87.82 | 0.78 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/cc2e2d68-e545-45f6-a94f-f0ae1d6215ea/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/cc2e2d68-e545-45f6-a94f-f0ae1d6215ea/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/cc2e2d68-e545-45f6-a94f-f0ae1d6215ea/agent/trajectory.jsonl) |
| 11 | completed | 1 | 129.01 | 0.79 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/0e062bed-fe22-42e7-9ec7-d85e5aee078b/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/0e062bed-fe22-42e7-9ec7-d85e5aee078b/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/0e062bed-fe22-42e7-9ec7-d85e5aee078b/agent/trajectory.jsonl) |
| 12 | completed | 1 | 170.52 | 0.89 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/81b4a4ec-4489-4df5-8b02-d02d8292efd8/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/81b4a4ec-4489-4df5-8b02-d02d8292efd8/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/81b4a4ec-4489-4df5-8b02-d02d8292efd8/agent/trajectory.jsonl) |
| 13 | completed | 1 | 540.68 | 0.77 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/371a8c21-b4ad-4274-ac11-2afada775e2a/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/371a8c21-b4ad-4274-ac11-2afada775e2a/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/371a8c21-b4ad-4274-ac11-2afada775e2a/agent/trajectory.jsonl) |
| 14 | completed | 1 | 27.67 | 0.98 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/1a39b8ef-e76c-4ad7-a199-27231f90e90c/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/1a39b8ef-e76c-4ad7-a199-27231f90e90c/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/1a39b8ef-e76c-4ad7-a199-27231f90e90c/agent/trajectory.jsonl) |
| 15 | completed | 1 | 100.40 | 0.70 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/163f9ac7-8ed8-4d2d-a326-96b727a86a4d/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/163f9ac7-8ed8-4d2d-a326-96b727a86a4d/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/163f9ac7-8ed8-4d2d-a326-96b727a86a4d/agent/trajectory.jsonl) |
| 16 | completed | 0 | 482.84 | 0.83 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/5ba13de1-edb3-4305-95a4-7c9e2e9ef309/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/5ba13de1-edb3-4305-95a4-7c9e2e9ef309/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/5ba13de1-edb3-4305-95a4-7c9e2e9ef309/agent/trajectory.jsonl) |
| 17 | completed | 1 | 215.49 | 0.70 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/0c7e3f29-2327-4d4f-915d-17f8ac210ce9/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/0c7e3f29-2327-4d4f-915d-17f8ac210ce9/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/0c7e3f29-2327-4d4f-915d-17f8ac210ce9/agent/trajectory.jsonl) |
| 18 | completed | 1 | 135.19 | 0.72 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/0fa66ebb-5209-4ac7-bc54-5c06cc93b889/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/0fa66ebb-5209-4ac7-bc54-5c06cc93b889/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/0fa66ebb-5209-4ac7-bc54-5c06cc93b889/agent/trajectory.jsonl) |
| 19 | completed | 1 | 95.11 | 0.95 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/3fa703af-6814-4624-bfab-1179ac50ba39/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/3fa703af-6814-4624-bfab-1179ac50ba39/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/3fa703af-6814-4624-bfab-1179ac50ba39/agent/trajectory.jsonl) |
| 20 | completed | 1 | 865.50 | 0.78 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/e7c164fb-50db-45d5-a4fd-6bb9745bfe79/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/e7c164fb-50db-45d5-a4fd-6bb9745bfe79/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/e7c164fb-50db-45d5-a4fd-6bb9745bfe79/agent/trajectory.jsonl) |
| 21 | completed | 1 | 147.32 | 0.90 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/1182622a-6dd8-49ad-8327-30b61a94acfd/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/1182622a-6dd8-49ad-8327-30b61a94acfd/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/1182622a-6dd8-49ad-8327-30b61a94acfd/agent/trajectory.jsonl) |
| 22 | completed | 1 | 116.18 | 0.77 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/b4edb568-223b-4ed2-a26e-95e422a93e33/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/b4edb568-223b-4ed2-a26e-95e422a93e33/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/b4edb568-223b-4ed2-a26e-95e422a93e33/agent/trajectory.jsonl) |
| 23 | completed | 1 | 97.04 | 0.81 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/f4967228-54a1-4b54-ba68-43a9620091e9/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/f4967228-54a1-4b54-ba68-43a9620091e9/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/f4967228-54a1-4b54-ba68-43a9620091e9/agent/trajectory.jsonl) |
| 24 | completed | 0 | 105.05 | 0.75 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/65397b7d-2049-4f8b-b032-d5a1d0f389cc/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/65397b7d-2049-4f8b-b032-d5a1d0f389cc/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/65397b7d-2049-4f8b-b032-d5a1d0f389cc/agent/trajectory.jsonl) |
| 25 | completed | 0 | 172.52 | 0.79 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/495504c9-df5d-4997-9a47-6d884ce4777f/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/495504c9-df5d-4997-9a47-6d884ce4777f/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/495504c9-df5d-4997-9a47-6d884ce4777f/agent/trajectory.jsonl) |
| 26 | completed | 0 | 220.53 | 0.95 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/8620eb35-9596-44b4-a618-30fe0f34a708/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/8620eb35-9596-44b4-a618-30fe0f34a708/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/8620eb35-9596-44b4-a618-30fe0f34a708/agent/trajectory.jsonl) |
| 27 | completed | 1 | 274.49 | 1.07 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/f0c7a43e-efe1-4e61-9017-5511233c18c1/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/f0c7a43e-efe1-4e61-9017-5511233c18c1/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/f0c7a43e-efe1-4e61-9017-5511233c18c1/agent/trajectory.jsonl) |
| 28 | completed | 0 | 440.73 | 0.88 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/e38186e6-7bba-4227-9ca0-652f3f2ad3e0/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/e38186e6-7bba-4227-9ca0-652f3f2ad3e0/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/e38186e6-7bba-4227-9ca0-652f3f2ad3e0/agent/trajectory.jsonl) |
| 29 | completed | 0 | 616.91 | 0.89 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/f42e482a-6f17-4d62-82e3-bf7a772616db/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/f42e482a-6f17-4d62-82e3-bf7a772616db/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/f42e482a-6f17-4d62-82e3-bf7a772616db/agent/trajectory.jsonl) |
| 30 | completed | 0 | 168.90 | 0.88 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/1a9f49b0-1318-4d5d-ad18-64f4dbc4e5e2/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/1a9f49b0-1318-4d5d-ad18-64f4dbc4e5e2/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/1a9f49b0-1318-4d5d-ad18-64f4dbc4e5e2/agent/trajectory.jsonl) |
| 31 | completed | 0 | 25.33 | 0.95 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/5a2ac5b8-e849-4ae6-90a7-139199fbc5d9/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/5a2ac5b8-e849-4ae6-90a7-139199fbc5d9/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/5a2ac5b8-e849-4ae6-90a7-139199fbc5d9/agent/trajectory.jsonl) |
| 32 | completed | 1 | 1011.03 | 0.76 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/98928f4d-d21b-4adc-b16c-30205858902e/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/98928f4d-d21b-4adc-b16c-30205858902e/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/98928f4d-d21b-4adc-b16c-30205858902e/agent/trajectory.jsonl) |
| 33 | completed | 0 | 1435.36 | 0.90 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/bd22d9f2-6fee-41cb-af83-7c40591b8096/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/bd22d9f2-6fee-41cb-af83-7c40591b8096/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/bd22d9f2-6fee-41cb-af83-7c40591b8096/agent/trajectory.jsonl) |
| 34 | completed | 0 | 118.16 | 0.79 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/0ff56d0f-0b07-4f6e-81a5-18c8c340c43b/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/0ff56d0f-0b07-4f6e-81a5-18c8c340c43b/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/0ff56d0f-0b07-4f6e-81a5-18c8c340c43b/agent/trajectory.jsonl) |
| 35 | completed | 1 | 108.80 | 0.85 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/c91f7d2f-8faa-4813-aa91-4822efed56fb/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/c91f7d2f-8faa-4813-aa91-4822efed56fb/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/c91f7d2f-8faa-4813-aa91-4822efed56fb/agent/trajectory.jsonl) |
| 36 | completed | 0 | 807.73 | 0.73 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/8695f057-31a2-4e17-8929-c611d7fe1b0d/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/8695f057-31a2-4e17-8929-c611d7fe1b0d/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/8695f057-31a2-4e17-8929-c611d7fe1b0d/agent/trajectory.jsonl) |
| 37 | completed | 1 | 107.31 | 0.74 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/b7cdfdef-9865-48c0-9cf2-748ce2d942ad/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/b7cdfdef-9865-48c0-9cf2-748ce2d942ad/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/b7cdfdef-9865-48c0-9cf2-748ce2d942ad/agent/trajectory.jsonl) |
| 38 | completed | 0 | 267.49 | 0.73 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/94007d49-ddcc-4752-8141-07edeba77b37/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/94007d49-ddcc-4752-8141-07edeba77b37/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/94007d49-ddcc-4752-8141-07edeba77b37/agent/trajectory.jsonl) |
| 39 | completed | 1 | 180.43 | 0.75 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/eabbfbf3-f796-45a7-bacc-f807e8db0b2f/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/eabbfbf3-f796-45a7-bacc-f807e8db0b2f/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/eabbfbf3-f796-45a7-bacc-f807e8db0b2f/agent/trajectory.jsonl) |
| 40 | completed | 1 | 62.25 | 0.71 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/9b9d4ac3-ba0e-47fc-9ca1-8979c6690a05/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/9b9d4ac3-ba0e-47fc-9ca1-8979c6690a05/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/9b9d4ac3-ba0e-47fc-9ca1-8979c6690a05/agent/trajectory.jsonl) |
| 41 | completed | 0 | 178.90 | 0.87 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/2ef326b2-1002-4106-81ce-2ebff9ee431a/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/2ef326b2-1002-4106-81ce-2ebff9ee431a/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/2ef326b2-1002-4106-81ce-2ebff9ee431a/agent/trajectory.jsonl) |
| 42 | completed | 1 | 156.68 | 0.76 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/b1d4d317-a667-4608-abe8-09d10c9ede4a/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/b1d4d317-a667-4608-abe8-09d10c9ede4a/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/b1d4d317-a667-4608-abe8-09d10c9ede4a/agent/trajectory.jsonl) |
| 43 | completed | 0 | 154.71 | 0.72 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/4baa7793-87a0-4038-90a5-bd655d39992f/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/4baa7793-87a0-4038-90a5-bd655d39992f/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/4baa7793-87a0-4038-90a5-bd655d39992f/agent/trajectory.jsonl) |
| 44 | completed | 1 | 171.97 | 0.69 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/15d7c92d-f406-4ee4-b5e4-02c361a676ca/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/15d7c92d-f406-4ee4-b5e4-02c361a676ca/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/15d7c92d-f406-4ee4-b5e4-02c361a676ca/agent/trajectory.jsonl) |
| 45 | completed | 1 | 240.28 | 0.81 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/36e0292c-3f31-4732-b3af-7b2c6ceaa366/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/36e0292c-3f31-4732-b3af-7b2c6ceaa366/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/36e0292c-3f31-4732-b3af-7b2c6ceaa366/agent/trajectory.jsonl) |
| 46 | cancelled | — | 526.60 | — | partial / complete | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/69b09a0a-dc07-4d3f-baa6-04fd1da71b15/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/69b09a0a-dc07-4d3f-baa6-04fd1da71b15/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/69b09a0a-dc07-4d3f-baa6-04fd1da71b15/agent/trajectory.jsonl) |
| 47 | completed | 0 | 121.87 | 1.00 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/f4b89983-2448-4d03-96bc-50b4f2cfd2ea/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/f4b89983-2448-4d03-96bc-50b4f2cfd2ea/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/f4b89983-2448-4d03-96bc-50b4f2cfd2ea/agent/trajectory.jsonl) |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

