<!-- snapshotDigest: 7b453402b32164480a3aa2f93113bc9f5b5dbf6808f618ed77814f0180965360 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 30.34%（27/89）**

Run: f5cbe314-e449-4d9a-b86a-c24f8a485c72 · Status: cancelled

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-19T16:08:22.423Z / 2026-11-20T01:47:50.849Z |
| 总耗时 | 9 小时 39 分 28 秒 |
| 答对 / 答错 / 解题超时 | 27 / 17 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 45 条记录；待运行 46 题。
有效评分覆盖率：44/90（48.89%）。
执行失败 0；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 44 |
| 答对题数 | 27 |
| 无效评测 | 1 |
| 待运行 | 46 |
| 正确率 | 30.34% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 39 分 28 秒 |
| 环境准备耗时 | 9 小时 39 分 7 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 4 分 34 秒 | 31 秒 | 22 分 36 秒 | 45 |
| 任务准备 | 0.5 毫秒 | 0.23 毫秒 | 6.84 毫秒 | 45 |
| 环境启动 | 16 秒 | 13 秒 | 27 秒 | 45 |
| 解题 | 4 分 12 秒 | 9 秒 | 22 分 18 秒 | 45 |
| 产物传输 | 1 秒 | 797.34 毫秒 | 2 秒 | 44 |
| 证据收集 | 1 秒 | 540.84 毫秒 | 5 秒 | 45 |
| 资源清理 | 3 秒 | 2 秒 | 6 秒 | 45 |
| 评分 | 851.27 毫秒 | 574.57 毫秒 | 1 秒 | 44 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 2a2634d4-31bd-4b9b-89f1-58366159059a | 14,400 | 3600 | 2 | 2 | 7200 |
| 18129388-2071-401b-894a-bcdee9a47d09 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 91,761,060 | 906,922 | 92,667,982 | 44 / 90 | — |
| 运行累计 | 91,761,060 | 906,922 | 92,667,982 | 44 / 46 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 0 | 366.19 | 0.66 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/382903cc-f809-4a3a-af51-33ebbf0af3e7/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/382903cc-f809-4a3a-af51-33ebbf0af3e7/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/382903cc-f809-4a3a-af51-33ebbf0af3e7/agent/trajectory.jsonl) |
| 1 | completed | 1 | 88.80 | 0.90 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/b20d386f-c2df-418f-baed-3951f8693423/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/b20d386f-c2df-418f-baed-3951f8693423/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/b20d386f-c2df-418f-baed-3951f8693423/agent/trajectory.jsonl) |
| 2 | completed | 1 | 116.22 | 0.73 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/1ca34484-0baf-46d3-bddd-97610d767e35/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/1ca34484-0baf-46d3-bddd-97610d767e35/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/1ca34484-0baf-46d3-bddd-97610d767e35/agent/trajectory.jsonl) |
| 3 | completed | 1 | 129.81 | 0.74 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/f4415cc5-3ba6-4551-8a1e-a1c7d5f3dfb4/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/f4415cc5-3ba6-4551-8a1e-a1c7d5f3dfb4/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/f4415cc5-3ba6-4551-8a1e-a1c7d5f3dfb4/agent/trajectory.jsonl) |
| 4 | completed | 1 | 32.38 | 0.73 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/f8b37653-1d30-4025-a725-fe950f4a6df1/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/f8b37653-1d30-4025-a725-fe950f4a6df1/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/f8b37653-1d30-4025-a725-fe950f4a6df1/agent/trajectory.jsonl) |
| 5 | completed | 1 | 57.37 | 0.68 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/bb7e4f76-2b7e-4862-92f7-711af751b81f/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/bb7e4f76-2b7e-4862-92f7-711af751b81f/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/bb7e4f76-2b7e-4862-92f7-711af751b81f/agent/trajectory.jsonl) |
| 6 | completed | 0 | 206.89 | 0.71 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/fdd21594-c610-43c7-9089-e1b185ba2cff/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/fdd21594-c610-43c7-9089-e1b185ba2cff/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/fdd21594-c610-43c7-9089-e1b185ba2cff/agent/trajectory.jsonl) |
| 7 | completed | 1 | 50.63 | 0.90 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/cd0113a2-3d17-4a50-ad11-27adb89b6fd2/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/cd0113a2-3d17-4a50-ad11-27adb89b6fd2/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/cd0113a2-3d17-4a50-ad11-27adb89b6fd2/agent/trajectory.jsonl) |
| 8 | completed | 0 | 50.42 | 0.72 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/bcb3dce9-7e8d-4caf-a7d3-f3fbdff7bcbd/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/bcb3dce9-7e8d-4caf-a7d3-f3fbdff7bcbd/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/bcb3dce9-7e8d-4caf-a7d3-f3fbdff7bcbd/agent/trajectory.jsonl) |
| 9 | completed | 0 | 53.24 | 0.71 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/02624a20-8a58-4c0a-a2fc-7f838da7b266/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/02624a20-8a58-4c0a-a2fc-7f838da7b266/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/02624a20-8a58-4c0a-a2fc-7f838da7b266/agent/trajectory.jsonl) |
| 10 | completed | 1 | 225.51 | 0.79 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/0935b667-beb9-4748-a921-4cf493f9a897/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/0935b667-beb9-4748-a921-4cf493f9a897/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/0935b667-beb9-4748-a921-4cf493f9a897/agent/trajectory.jsonl) |
| 11 | completed | 1 | 1098.61 | 0.86 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/3ada2610-efe8-4578-ba04-7c3d4ea6bcb2/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/3ada2610-efe8-4578-ba04-7c3d4ea6bcb2/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/3ada2610-efe8-4578-ba04-7c3d4ea6bcb2/agent/trajectory.jsonl) |
| 12 | completed | 1 | 159.03 | 0.80 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/53923e9b-45fe-4fbf-8a83-6204b2c08998/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/53923e9b-45fe-4fbf-8a83-6204b2c08998/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/53923e9b-45fe-4fbf-8a83-6204b2c08998/agent/trajectory.jsonl) |
| 13 | completed | 1 | 482.96 | 1.28 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/932f299b-a32f-4382-9edd-773e7b31f2bc/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/932f299b-a32f-4382-9edd-773e7b31f2bc/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/932f299b-a32f-4382-9edd-773e7b31f2bc/agent/trajectory.jsonl) |
| 14 | completed | 1 | 23.69 | 0.73 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/41fa0493-13ac-463d-9929-b76deb56d4b9/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/41fa0493-13ac-463d-9929-b76deb56d4b9/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/41fa0493-13ac-463d-9929-b76deb56d4b9/agent/trajectory.jsonl) |
| 15 | completed | 0 | 239.33 | 0.80 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/84b6368a-946b-4ae3-8f6b-3f15b18c1e75/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/84b6368a-946b-4ae3-8f6b-3f15b18c1e75/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/84b6368a-946b-4ae3-8f6b-3f15b18c1e75/agent/trajectory.jsonl) |
| 16 | completed | 1 | 687.23 | 0.82 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/5dd38568-82dc-4042-a4c8-fa6dd9599d26/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/5dd38568-82dc-4042-a4c8-fa6dd9599d26/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/5dd38568-82dc-4042-a4c8-fa6dd9599d26/agent/trajectory.jsonl) |
| 17 | completed | 1 | 1178.74 | 1.14 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/c448da61-0d16-4f90-bc53-00ee58a77699/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/c448da61-0d16-4f90-bc53-00ee58a77699/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/c448da61-0d16-4f90-bc53-00ee58a77699/agent/trajectory.jsonl) |
| 18 | completed | 1 | 218.43 | 0.87 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/1479fc3f-2139-40a8-80a1-ebd313abb91d/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/1479fc3f-2139-40a8-80a1-ebd313abb91d/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/1479fc3f-2139-40a8-80a1-ebd313abb91d/agent/trajectory.jsonl) |
| 19 | completed | 1 | 141.52 | 0.87 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/bcac32d3-ddf6-48d6-ab16-039f817a45ce/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/bcac32d3-ddf6-48d6-ab16-039f817a45ce/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/bcac32d3-ddf6-48d6-ab16-039f817a45ce/agent/trajectory.jsonl) |
| 20 | completed | 1 | 267.01 | 0.77 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/bc1484bc-e293-45c0-9494-a46de60576b8/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/bc1484bc-e293-45c0-9494-a46de60576b8/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/bc1484bc-e293-45c0-9494-a46de60576b8/agent/trajectory.jsonl) |
| 21 | completed | 1 | 89.12 | 0.86 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/ee56f02e-4115-43ad-a62d-660291e49197/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/ee56f02e-4115-43ad-a62d-660291e49197/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/ee56f02e-4115-43ad-a62d-660291e49197/agent/trajectory.jsonl) |
| 22 | completed | 1 | 163.81 | 0.75 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/b5dd5977-f84e-4ff1-a496-5a793cdd69a4/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/b5dd5977-f84e-4ff1-a496-5a793cdd69a4/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/b5dd5977-f84e-4ff1-a496-5a793cdd69a4/agent/trajectory.jsonl) |
| 23 | completed | 1 | 95.13 | 0.71 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/993f7a36-4262-45f6-87f7-94b8ac552e2a/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/993f7a36-4262-45f6-87f7-94b8ac552e2a/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/993f7a36-4262-45f6-87f7-94b8ac552e2a/agent/trajectory.jsonl) |
| 24 | completed | 0 | 105.14 | 1.35 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/5613bb83-d26b-496b-a554-2e111353e11f/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/5613bb83-d26b-496b-a554-2e111353e11f/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/5613bb83-d26b-496b-a554-2e111353e11f/agent/trajectory.jsonl) |
| 25 | completed | 0 | 319.63 | 0.78 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/1b56f454-f616-4aa9-ab5a-e1d341f3149b/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/1b56f454-f616-4aa9-ab5a-e1d341f3149b/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/1b56f454-f616-4aa9-ab5a-e1d341f3149b/agent/trajectory.jsonl) |
| 26 | completed | 1 | 213.23 | 0.90 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/a81340ec-3a09-4676-ab48-83c356e9f21f/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/a81340ec-3a09-4676-ab48-83c356e9f21f/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/a81340ec-3a09-4676-ab48-83c356e9f21f/agent/trajectory.jsonl) |
| 27 | completed | 1 | 197.59 | 0.88 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/ed66114e-99be-443a-8706-4a5516f25e9d/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/ed66114e-99be-443a-8706-4a5516f25e9d/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/ed66114e-99be-443a-8706-4a5516f25e9d/agent/trajectory.jsonl) |
| 28 | completed | 0 | 325.34 | 0.79 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/f10e988b-6d01-4f92-8bf2-a1c870be783e/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/f10e988b-6d01-4f92-8bf2-a1c870be783e/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/f10e988b-6d01-4f92-8bf2-a1c870be783e/agent/trajectory.jsonl) |
| 29 | completed | 1 | 392.31 | 1.27 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/272ed06e-2a62-4540-8a34-7a3901339193/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/272ed06e-2a62-4540-8a34-7a3901339193/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/272ed06e-2a62-4540-8a34-7a3901339193/agent/trajectory.jsonl) |
| 30 | completed | 0 | 112.51 | 0.88 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/2c6367a1-4440-4444-98a2-c6ae2d5ad355/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/2c6367a1-4440-4444-98a2-c6ae2d5ad355/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/2c6367a1-4440-4444-98a2-c6ae2d5ad355/agent/trajectory.jsonl) |
| 31 | completed | 1 | 50.16 | 0.86 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/63c61664-664a-4020-b5dd-04b204ca9c8b/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/63c61664-664a-4020-b5dd-04b204ca9c8b/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/63c61664-664a-4020-b5dd-04b204ca9c8b/agent/trajectory.jsonl) |
| 32 | completed | 1 | 166.35 | 0.73 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/e1ae448b-cec9-45dc-8781-5aad1bb973d5/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/e1ae448b-cec9-45dc-8781-5aad1bb973d5/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/e1ae448b-cec9-45dc-8781-5aad1bb973d5/agent/trajectory.jsonl) |
| 33 | completed | 1 | 223.56 | 0.75 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/c6d1323f-3364-4545-a378-7dbf2c0ad882/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/c6d1323f-3364-4545-a378-7dbf2c0ad882/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/c6d1323f-3364-4545-a378-7dbf2c0ad882/agent/trajectory.jsonl) |
| 34 | completed | 0 | 468.06 | 0.84 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/56829fff-b9d5-43bb-a76a-9da4db7d9469/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/56829fff-b9d5-43bb-a76a-9da4db7d9469/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/56829fff-b9d5-43bb-a76a-9da4db7d9469/agent/trajectory.jsonl) |
| 35 | completed | 1 | 85.89 | 0.76 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/15e446ef-aa2f-4cd4-924d-3f470ef49f7f/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/15e446ef-aa2f-4cd4-924d-3f470ef49f7f/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/15e446ef-aa2f-4cd4-924d-3f470ef49f7f/agent/trajectory.jsonl) |
| 36 | completed | 0 | 1337.84 | 0.75 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/bbec93df-e61d-461a-b4b5-9ec7f0bbce76/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/bbec93df-e61d-461a-b4b5-9ec7f0bbce76/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/bbec93df-e61d-461a-b4b5-9ec7f0bbce76/agent/trajectory.jsonl) |
| 37 | completed | 1 | 98.89 | 0.82 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/2838d6a4-5b3c-4a68-8db0-e50e96316fd7/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/2838d6a4-5b3c-4a68-8db0-e50e96316fd7/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/2838d6a4-5b3c-4a68-8db0-e50e96316fd7/agent/trajectory.jsonl) |
| 38 | completed | 0 | 407.63 | 0.57 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/0c783480-6476-4595-9bef-fb57c7448382/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/0c783480-6476-4595-9bef-fb57c7448382/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/0c783480-6476-4595-9bef-fb57c7448382/agent/trajectory.jsonl) |
| 39 | completed | 0 | 141.67 | 1.12 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/7af5f273-a455-4d92-81ee-f6cde13682a9/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/7af5f273-a455-4d92-81ee-f6cde13682a9/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/7af5f273-a455-4d92-81ee-f6cde13682a9/agent/trajectory.jsonl) |
| 40 | completed | 0 | 83.43 | 1.26 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/174e0b33-1bc0-44cb-87b5-9c0587804da2/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/174e0b33-1bc0-44cb-87b5-9c0587804da2/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/174e0b33-1bc0-44cb-87b5-9c0587804da2/agent/trajectory.jsonl) |
| 41 | completed | 0 | 154.06 | 0.81 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/213c4cc5-c9a2-4b43-af6c-dfe34a449070/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/213c4cc5-c9a2-4b43-af6c-dfe34a449070/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/213c4cc5-c9a2-4b43-af6c-dfe34a449070/agent/trajectory.jsonl) |
| 42 | completed | 0 | 120.17 | 0.85 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/3155226f-a737-4bf5-ba38-c70415c040c5/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/3155226f-a737-4bf5-ba38-c70415c040c5/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/3155226f-a737-4bf5-ba38-c70415c040c5/agent/trajectory.jsonl) |
| 43 | completed | 0 | 91.90 | 0.92 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/3b20c396-c647-48a3-b602-d0f709310a59/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/3b20c396-c647-48a3-b602-d0f709310a59/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/3b20c396-c647-48a3-b602-d0f709310a59/agent/trajectory.jsonl) |
| 44 | pending | — | — | — | — | — | — |
| 45 | cancelled | — | 8.71 | — | partial / complete | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/08df3d51-5c44-4a5b-aea7-be70ccc2a223/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/08df3d51-5c44-4a5b-aea7-be70ccc2a223/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/08df3d51-5c44-4a5b-aea7-be70ccc2a223/agent/trajectory.jsonl) |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

