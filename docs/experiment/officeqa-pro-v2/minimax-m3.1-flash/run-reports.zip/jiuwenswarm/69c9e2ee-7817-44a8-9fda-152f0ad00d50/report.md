<!-- snapshotDigest: b1ee3fb10b2f74a9d8beac7e6efa5878c3fe6cdaf7590b27fba43406cb8fb40a -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 30.43%（14/46）**

Run: 69c9e2ee-7817-44a8-9fda-152f0ad00d50 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-20T01:57:51.014Z / 2026-11-20T10:06:45.730Z |
| 总耗时 | 8 小时 8 分 55 秒 |
| 答对 / 答错 / 解题超时 | 14 / 32 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 46 题；已保存 46 条记录；待运行 0 题。
有效评分覆盖率：46/46（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 46 |
| 计分题数 | 46 |
| 正常评分题数 | 46 |
| 答对题数 | 14 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 30.43% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 8 小时 8 分 55 秒 |
| 环境准备耗时 | 5 小时 40 分 13 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 8 分 1 秒 | 1 分 10 秒 | 40 分 25 秒 | 46 |
| 任务准备 | 0.41 毫秒 | 0.12 毫秒 | 1.55 毫秒 | 46 |
| 环境启动 | 19 秒 | 12 秒 | 37 秒 | 46 |
| 解题 | 7 分 34 秒 | 37 秒 | 40 分 3 秒 | 46 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 46 |
| 证据收集 | 1 秒 | 1 秒 | 4 秒 | 46 |
| 资源清理 | 4 秒 | 3 秒 | 19 秒 | 46 |
| 评分 | 1 秒 | 738.55 毫秒 | 4 秒 | 46 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 482b0682-00ca-44d2-b86d-bdc06629838b | 14,400 | 3600 | 2 | 2 | 7200 |
| c72262ca-24cd-4abf-8c2c-5cae4a6960d3 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 132,668,740 | 1,298,742 | 133,967,482 | 46 / 46 | — |
| 运行累计 | 132,668,740 | 1,298,742 | 133,967,482 | 46 / 48 | 2 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 44 | completed | 0 | 230.39 | 0.91 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/b799dab0-995e-4db1-8dab-fb50bd03c20f/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/b799dab0-995e-4db1-8dab-fb50bd03c20f/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/b799dab0-995e-4db1-8dab-fb50bd03c20f/agent/trajectory.jsonl) |
| 45 | completed | 1 | 354.21 | 0.83 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/982af0a4-d2b7-49a6-a4ea-9781d40a9910/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/982af0a4-d2b7-49a6-a4ea-9781d40a9910/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/982af0a4-d2b7-49a6-a4ea-9781d40a9910/agent/trajectory.jsonl) |
| 46 | completed | 0 | 1896.26 | 0.95 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/a399bf42-3bc2-48cf-9b10-a1132856b165/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/a399bf42-3bc2-48cf-9b10-a1132856b165/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/a399bf42-3bc2-48cf-9b10-a1132856b165/agent/trajectory.jsonl) |
| 47 | completed | 0 | 484.70 | 0.82 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/19009cfc-e957-4afd-acaa-711218aba847/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/19009cfc-e957-4afd-acaa-711218aba847/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/19009cfc-e957-4afd-acaa-711218aba847/agent/trajectory.jsonl) |
| 48 | completed | 1 | 229.04 | 0.85 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/f977a93c-ccda-4537-9b70-5fa87587d146/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/f977a93c-ccda-4537-9b70-5fa87587d146/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/f977a93c-ccda-4537-9b70-5fa87587d146/agent/trajectory.jsonl) |
| 49 | completed | 0 | 178.15 | 0.81 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/1c36d91f-254f-49b1-9b16-ced86f56cb89/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/1c36d91f-254f-49b1-9b16-ced86f56cb89/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/1c36d91f-254f-49b1-9b16-ced86f56cb89/agent/trajectory.jsonl) |
| 50 | completed | 0 | 612.56 | 1.00 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/f14415f4-c235-466f-acc3-5c0d5005aab8/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/f14415f4-c235-466f-acc3-5c0d5005aab8/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/f14415f4-c235-466f-acc3-5c0d5005aab8/agent/trajectory.jsonl) |
| 51 | completed | 0 | 882.50 | 0.96 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/b1e5bd53-fc6e-4f67-b673-45736812df19/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/b1e5bd53-fc6e-4f67-b673-45736812df19/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/b1e5bd53-fc6e-4f67-b673-45736812df19/agent/trajectory.jsonl) |
| 52 | completed | 0 | 84.72 | 0.79 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/456c0cdd-c120-46ee-8dca-73bf179d0503/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/456c0cdd-c120-46ee-8dca-73bf179d0503/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/456c0cdd-c120-46ee-8dca-73bf179d0503/agent/trajectory.jsonl) |
| 53 | completed | 1 | 62.19 | 0.89 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/ea579081-22af-4936-883f-85c93b31dd5a/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/ea579081-22af-4936-883f-85c93b31dd5a/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/ea579081-22af-4936-883f-85c93b31dd5a/agent/trajectory.jsonl) |
| 54 | completed | 1 | 2403.37 | 1.01 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/3b7c950e-0a0a-4379-a554-9eb9c6af7501/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/3b7c950e-0a0a-4379-a554-9eb9c6af7501/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/3b7c950e-0a0a-4379-a554-9eb9c6af7501/agent/trajectory.jsonl) |
| 55 | completed | 1 | 616.89 | 0.77 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/948826e8-3601-41c0-8332-3ba75b0de861/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/948826e8-3601-41c0-8332-3ba75b0de861/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/948826e8-3601-41c0-8332-3ba75b0de861/agent/trajectory.jsonl) |
| 56 | completed | 1 | 466.76 | 0.91 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/8e3f1a73-c45a-4060-a179-8b16b216c34c/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/8e3f1a73-c45a-4060-a179-8b16b216c34c/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/8e3f1a73-c45a-4060-a179-8b16b216c34c/agent/trajectory.jsonl) |
| 57 | completed | 0 | 613.25 | 1.13 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/fbb9b6e9-67df-4d69-8c95-0c290f382304/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/fbb9b6e9-67df-4d69-8c95-0c290f382304/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/fbb9b6e9-67df-4d69-8c95-0c290f382304/agent/trajectory.jsonl) |
| 58 | completed | 1 | 1303.24 | 1.08 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/b1eac9d9-dead-44f7-a135-c2966802d3e7/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/b1eac9d9-dead-44f7-a135-c2966802d3e7/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/b1eac9d9-dead-44f7-a135-c2966802d3e7/agent/trajectory.jsonl) |
| 59 | completed | 0 | 124.01 | 1.44 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/f85c27cf-b83c-4738-b25f-c38b0a89be7e/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/f85c27cf-b83c-4738-b25f-c38b0a89be7e/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/f85c27cf-b83c-4738-b25f-c38b0a89be7e/agent/trajectory.jsonl) |
| 60 | completed | 1 | 236.99 | 1.25 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/9771b9bf-6031-4322-b809-b0301aa87680/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/9771b9bf-6031-4322-b809-b0301aa87680/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/9771b9bf-6031-4322-b809-b0301aa87680/agent/trajectory.jsonl) |
| 61 | completed | 0 | 402.23 | 1.70 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/c2e087cb-419b-4fbb-979e-75cbe3a2780f/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/c2e087cb-419b-4fbb-979e-75cbe3a2780f/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/c2e087cb-419b-4fbb-979e-75cbe3a2780f/agent/trajectory.jsonl) |
| 62 | completed | 0 | 621.64 | 1.57 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/ada21f4a-2eb1-403a-94ca-3195d3a4c716/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/ada21f4a-2eb1-403a-94ca-3195d3a4c716/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/ada21f4a-2eb1-403a-94ca-3195d3a4c716/agent/trajectory.jsonl) |
| 63 | completed | 0 | 489.94 | 1.89 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/68193b59-60cc-4184-b288-133cfc6b1738/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/68193b59-60cc-4184-b288-133cfc6b1738/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/68193b59-60cc-4184-b288-133cfc6b1738/agent/trajectory.jsonl) |
| 64 | completed | 0 | 360.48 | 1.13 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/1156cf2b-20cd-4ea4-afb6-caea960bad3f/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/1156cf2b-20cd-4ea4-afb6-caea960bad3f/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/1156cf2b-20cd-4ea4-afb6-caea960bad3f/agent/trajectory.jsonl) |
| 65 | completed | 0 | 393.38 | 1.14 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/d77e7c9d-6d09-4a03-98db-a2b6f3b0019a/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/d77e7c9d-6d09-4a03-98db-a2b6f3b0019a/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/d77e7c9d-6d09-4a03-98db-a2b6f3b0019a/agent/trajectory.jsonl) |
| 66 | completed | 1 | 894.40 | 1.03 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/08079c75-2d8b-4814-a281-b992ad0b0552/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/08079c75-2d8b-4814-a281-b992ad0b0552/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/08079c75-2d8b-4814-a281-b992ad0b0552/agent/trajectory.jsonl) |
| 67 | completed | 1 | 675.38 | 1.13 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/a474930d-c528-4bfa-a709-131d3f2ebb1e/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/a474930d-c528-4bfa-a709-131d3f2ebb1e/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/a474930d-c528-4bfa-a709-131d3f2ebb1e/agent/trajectory.jsonl) |
| 68 | completed | 1 | 185.08 | 3.98 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/1175b9d2-0222-4464-94c7-9ccb8f3cfc55/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/1175b9d2-0222-4464-94c7-9ccb8f3cfc55/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/1175b9d2-0222-4464-94c7-9ccb8f3cfc55/agent/trajectory.jsonl) |
| 69 | completed | 0 | 214.24 | 1.26 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/93d02a05-8f42-4ef8-8cbf-1e94a07cb52f/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/93d02a05-8f42-4ef8-8cbf-1e94a07cb52f/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/93d02a05-8f42-4ef8-8cbf-1e94a07cb52f/agent/trajectory.jsonl) |
| 70 | completed | 0 | 433.61 | 0.74 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/07c8dd8f-a7bb-4263-9b5b-1b1a6ae8103f/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/07c8dd8f-a7bb-4263-9b5b-1b1a6ae8103f/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/07c8dd8f-a7bb-4263-9b5b-1b1a6ae8103f/agent/trajectory.jsonl) |
| 71 | completed | 0 | 195.17 | 1.30 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/2338e148-20d6-4479-83d0-c5e6dea42033/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/2338e148-20d6-4479-83d0-c5e6dea42033/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/2338e148-20d6-4479-83d0-c5e6dea42033/agent/trajectory.jsonl) |
| 72 | completed | 0 | 419.28 | 1.00 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/072fb512-a8dd-4367-ac28-0203c2751b4c/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/072fb512-a8dd-4367-ac28-0203c2751b4c/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/072fb512-a8dd-4367-ac28-0203c2751b4c/agent/trajectory.jsonl) |
| 73 | completed | 1 | 157.00 | 1.00 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/e80d3109-99d9-43f6-b47e-9911f4fa7e62/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/e80d3109-99d9-43f6-b47e-9911f4fa7e62/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/e80d3109-99d9-43f6-b47e-9911f4fa7e62/agent/trajectory.jsonl) |
| 74 | completed | 0 | 469.19 | 0.98 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/6fcb7005-a0d6-483a-96fe-1f2ea97bf57f/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/6fcb7005-a0d6-483a-96fe-1f2ea97bf57f/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/6fcb7005-a0d6-483a-96fe-1f2ea97bf57f/agent/trajectory.jsonl) |
| 75 | completed | 0 | 221.94 | 1.26 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/90eec20d-8c83-4272-bb4c-656a89e59613/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/90eec20d-8c83-4272-bb4c-656a89e59613/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/90eec20d-8c83-4272-bb4c-656a89e59613/agent/trajectory.jsonl) |
| 76 | completed | 0 | 37.25 | 1.14 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/7fb43015-491c-4934-845b-4c9b400b099a/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/7fb43015-491c-4934-845b-4c9b400b099a/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/7fb43015-491c-4934-845b-4c9b400b099a/agent/trajectory.jsonl) |
| 77 | completed | 0 | 600.70 | 1.27 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/2b129591-823c-4b4e-9012-8055e3e1e8db/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/2b129591-823c-4b4e-9012-8055e3e1e8db/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/2b129591-823c-4b4e-9012-8055e3e1e8db/agent/trajectory.jsonl) |
| 78 | completed | 0 | 56.21 | 1.31 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/9708c59e-26a6-4ce4-af25-2b4637fd2fdf/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/9708c59e-26a6-4ce4-af25-2b4637fd2fdf/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/9708c59e-26a6-4ce4-af25-2b4637fd2fdf/agent/trajectory.jsonl) |
| 79 | completed | 0 | 177.41 | 0.84 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/2058b07d-7cd4-48f5-914c-75939d12ba05/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/2058b07d-7cd4-48f5-914c-75939d12ba05/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/2058b07d-7cd4-48f5-914c-75939d12ba05/agent/trajectory.jsonl) |
| 80 | completed | 0 | 521.66 | 0.77 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/66d80153-7b5b-44d0-91d0-e52871a5407c/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/66d80153-7b5b-44d0-91d0-e52871a5407c/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/66d80153-7b5b-44d0-91d0-e52871a5407c/agent/trajectory.jsonl) |
| 81 | completed | 1 | 784.19 | 0.80 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/f384f098-a3b3-4a5b-af55-39fd9ebef7cc/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/f384f098-a3b3-4a5b-af55-39fd9ebef7cc/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/f384f098-a3b3-4a5b-af55-39fd9ebef7cc/agent/trajectory.jsonl) |
| 82 | completed | 0 | 237.15 | 0.81 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/d2e0df0d-15e9-4cbe-9ed2-9d4fec33186a/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/d2e0df0d-15e9-4cbe-9ed2-9d4fec33186a/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/d2e0df0d-15e9-4cbe-9ed2-9d4fec33186a/agent/trajectory.jsonl) |
| 83 | completed | 0 | 184.37 | 0.79 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/08b1f941-918c-4850-a8cd-c8bb4cbb4bcc/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/08b1f941-918c-4850-a8cd-c8bb4cbb4bcc/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/08b1f941-918c-4850-a8cd-c8bb4cbb4bcc/agent/trajectory.jsonl) |
| 84 | completed | 0 | 281.42 | 0.79 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/6d4f79c6-db45-4d86-970b-4b894ad5fbb4/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/6d4f79c6-db45-4d86-970b-4b894ad5fbb4/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/6d4f79c6-db45-4d86-970b-4b894ad5fbb4/agent/trajectory.jsonl) |
| 85 | completed | 0 | 423.08 | 0.75 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/ee2101a7-4405-424b-aacc-c180f99ea433/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/ee2101a7-4405-424b-aacc-c180f99ea433/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/ee2101a7-4405-424b-aacc-c180f99ea433/agent/trajectory.jsonl) |
| 86 | completed | 0 | 188.00 | 0.88 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/6a0c6cc0-51a9-4379-88cf-a17c5bbdb299/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/6a0c6cc0-51a9-4379-88cf-a17c5bbdb299/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/6a0c6cc0-51a9-4379-88cf-a17c5bbdb299/agent/trajectory.jsonl) |
| 87 | completed | 1 | 131.01 | 0.75 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/fb4d57b1-74b3-42d3-b1e9-8a9769a44716/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/fb4d57b1-74b3-42d3-b1e9-8a9769a44716/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/fb4d57b1-74b3-42d3-b1e9-8a9769a44716/agent/trajectory.jsonl) |
| 88 | completed | 0 | 217.97 | 0.74 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/d19ae47a-59a9-44a5-8b79-db5538bda273/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/d19ae47a-59a9-44a5-8b79-db5538bda273/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/d19ae47a-59a9-44a5-8b79-db5538bda273/agent/trajectory.jsonl) |
| 89 | completed | 0 | 148.69 | 0.76 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/8c5eaafc-1ab7-4ebf-bbb2-e2b0a0cc40e8/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/8c5eaafc-1ab7-4ebf-bbb2-e2b0a0cc40e8/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/8c5eaafc-1ab7-4ebf-bbb2-e2b0a0cc40e8/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

