<!-- snapshotDigest: 74946f2283053a15eb6231880421a3272ed75f76ea35b92eaf588c8ef099a57a -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 28.09%（25/89）**

Run: 5397a2cc-f4ad-4379-8b28-f390e8a1eefc · Status: cancelled

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-19T15:45:08.089Z / 2026-11-20T01:47:48.954Z |
| 总耗时 | 10 小时 2 分 41 秒 |
| 答对 / 答错 / 解题超时 | 25 / 16 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 42 条记录；待运行 49 题。
有效评分覆盖率：41/90（45.56%）。
执行失败 0；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 41 |
| 答对题数 | 25 |
| 无效评测 | 1 |
| 待运行 | 49 |
| 正确率 | 28.09% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 10 小时 2 分 41 秒 |
| 环境准备耗时 | 10 小时 2 分 23 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 5 分 27 秒 | 21 秒 | 35 分 47 秒 | 42 |
| 任务准备 | 0.31 毫秒 | 0.19 毫秒 | 0.63 毫秒 | 42 |
| 环境启动 | 4 秒 | 3 秒 | 11 秒 | 42 |
| 解题 | 5 分 17 秒 | 11 秒 | 35 分 34 秒 | 42 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 41 |
| 证据收集 | 1 秒 | 537.16 毫秒 | 4 秒 | 42 |
| 资源清理 | 3 秒 | 2 秒 | 5 秒 | 42 |
| 评分 | 822.83 毫秒 | 492.14 毫秒 | 1 秒 | 41 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 32d8b74f-1be3-42a6-a39d-431f30ceccd0 | 14,400 | 3600 | 2 | 2 | 7200 |
| a11c5a0e-9d5b-48fc-86f1-6f4a569647a2 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 66,322,983 | 989,572 | 67,312,555 | 41 / 90 | — |
| 运行累计 | 66,708,812 | 997,140 | 67,705,952 | 42 / 43 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 0 | 358.73 | 1.32 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/cb78934d-10a7-4132-8d50-4d201a3cc0dd/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/cb78934d-10a7-4132-8d50-4d201a3cc0dd/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/cb78934d-10a7-4132-8d50-4d201a3cc0dd/agent/trajectory.jsonl) |
| 1 | completed | 1 | 96.17 | 0.69 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/fe066d01-4cf9-4dcb-87a4-8ecc060c7d03/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/fe066d01-4cf9-4dcb-87a4-8ecc060c7d03/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/fe066d01-4cf9-4dcb-87a4-8ecc060c7d03/agent/trajectory.jsonl) |
| 2 | completed | 1 | 264.60 | 0.86 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/f1f2dc25-85a5-42b5-9802-f8ddead417a3/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/f1f2dc25-85a5-42b5-9802-f8ddead417a3/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/f1f2dc25-85a5-42b5-9802-f8ddead417a3/agent/trajectory.jsonl) |
| 3 | completed | 0 | 113.21 | 0.69 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/d95305a3-f28f-4ef6-9147-d6d3ec025286/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/d95305a3-f28f-4ef6-9147-d6d3ec025286/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/d95305a3-f28f-4ef6-9147-d6d3ec025286/agent/trajectory.jsonl) |
| 4 | completed | 1 | 90.05 | 0.84 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/27c7e3d0-607d-4879-ad58-7fbac95eb263/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/27c7e3d0-607d-4879-ad58-7fbac95eb263/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/27c7e3d0-607d-4879-ad58-7fbac95eb263/agent/trajectory.jsonl) |
| 5 | completed | 1 | 90.13 | 0.75 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/003fcd00-32c6-4754-b3f7-155c0fe1f3e1/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/003fcd00-32c6-4754-b3f7-155c0fe1f3e1/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/003fcd00-32c6-4754-b3f7-155c0fe1f3e1/agent/trajectory.jsonl) |
| 6 | completed | 1 | 50.00 | 0.79 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/26530375-adaf-4007-af57-7053226c44a6/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/26530375-adaf-4007-af57-7053226c44a6/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/26530375-adaf-4007-af57-7053226c44a6/agent/trajectory.jsonl) |
| 7 | completed | 1 | 70.36 | 0.95 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/545d8abd-a7d7-4ace-9f62-fb3ffd0c475b/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/545d8abd-a7d7-4ace-9f62-fb3ffd0c475b/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/545d8abd-a7d7-4ace-9f62-fb3ffd0c475b/agent/trajectory.jsonl) |
| 8 | completed | 0 | 1357.14 | 0.85 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/802c965b-7c29-4e6b-979c-0b638a5ec757/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/802c965b-7c29-4e6b-979c-0b638a5ec757/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/802c965b-7c29-4e6b-979c-0b638a5ec757/agent/trajectory.jsonl) |
| 9 | completed | 1 | 149.24 | 0.77 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/ab8943ec-3bdc-42a0-9b70-bd6acf1d3f85/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/ab8943ec-3bdc-42a0-9b70-bd6acf1d3f85/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/ab8943ec-3bdc-42a0-9b70-bd6acf1d3f85/agent/trajectory.jsonl) |
| 10 | completed | 1 | 112.94 | 0.76 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/d1f0c447-2673-4a84-bdf6-9c6cfff9eed0/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/d1f0c447-2673-4a84-bdf6-9c6cfff9eed0/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/d1f0c447-2673-4a84-bdf6-9c6cfff9eed0/agent/trajectory.jsonl) |
| 11 | completed | 1 | 210.46 | 0.76 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/93b4ee28-a288-41b1-b3ed-ed6449b9a00a/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/93b4ee28-a288-41b1-b3ed-ed6449b9a00a/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/93b4ee28-a288-41b1-b3ed-ed6449b9a00a/agent/trajectory.jsonl) |
| 12 | completed | 0 | 46.88 | 0.75 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/eb2e0a6b-7ad7-48ae-befa-4f418e769123/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/eb2e0a6b-7ad7-48ae-befa-4f418e769123/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/eb2e0a6b-7ad7-48ae-befa-4f418e769123/agent/trajectory.jsonl) |
| 13 | completed | 1 | 191.20 | 0.74 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/9e5a1208-5923-42f6-83fe-5cd11ef9ee6c/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/9e5a1208-5923-42f6-83fe-5cd11ef9ee6c/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/9e5a1208-5923-42f6-83fe-5cd11ef9ee6c/agent/trajectory.jsonl) |
| 14 | completed | 1 | 10.90 | 1.02 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/dec84886-2537-4e6c-90f8-f8da75b6a4ed/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/dec84886-2537-4e6c-90f8-f8da75b6a4ed/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/dec84886-2537-4e6c-90f8-f8da75b6a4ed/agent/trajectory.jsonl) |
| 15 | completed | 1 | 366.69 | 0.71 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/47508e5e-e3c5-4cd7-ae09-97de2c18d708/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/47508e5e-e3c5-4cd7-ae09-97de2c18d708/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/47508e5e-e3c5-4cd7-ae09-97de2c18d708/agent/trajectory.jsonl) |
| 16 | completed | 0 | 705.26 | 0.70 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/7a99fd97-d5d0-4b37-aebb-fd35a7956eaf/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/7a99fd97-d5d0-4b37-aebb-fd35a7956eaf/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/7a99fd97-d5d0-4b37-aebb-fd35a7956eaf/agent/trajectory.jsonl) |
| 17 | completed | 1 | 287.42 | 0.70 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/57045d1d-169b-41d7-a492-017eceec736a/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/57045d1d-169b-41d7-a492-017eceec736a/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/57045d1d-169b-41d7-a492-017eceec736a/agent/trajectory.jsonl) |
| 18 | completed | 1 | 124.41 | 0.72 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/5e28aee2-6102-40d9-ab13-6f8aca0ef12f/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/5e28aee2-6102-40d9-ab13-6f8aca0ef12f/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/5e28aee2-6102-40d9-ab13-6f8aca0ef12f/agent/trajectory.jsonl) |
| 19 | completed | 0 | 513.66 | 0.72 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/5747e7ab-ae8b-4a96-abd4-ec47d757f07e/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/5747e7ab-ae8b-4a96-abd4-ec47d757f07e/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/5747e7ab-ae8b-4a96-abd4-ec47d757f07e/agent/trajectory.jsonl) |
| 20 | completed | 0 | 2133.94 | 1.02 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/94e454e7-716d-4a38-841c-1aa12ec77b37/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/94e454e7-716d-4a38-841c-1aa12ec77b37/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/94e454e7-716d-4a38-841c-1aa12ec77b37/agent/trajectory.jsonl) |
| 21 | completed | 1 | 740.64 | 0.76 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/f70fda11-d5a2-45bd-935a-7fcbe6cbe83c/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/f70fda11-d5a2-45bd-935a-7fcbe6cbe83c/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/f70fda11-d5a2-45bd-935a-7fcbe6cbe83c/agent/trajectory.jsonl) |
| 22 | completed | 1 | 121.72 | 0.84 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/3b674977-7471-4d30-8bde-f564ee1992d9/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/3b674977-7471-4d30-8bde-f564ee1992d9/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/3b674977-7471-4d30-8bde-f564ee1992d9/agent/trajectory.jsonl) |
| 23 | completed | 1 | 76.95 | 1.34 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/2df40c08-ca1f-451e-a4cd-3d55c109fa9a/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/2df40c08-ca1f-451e-a4cd-3d55c109fa9a/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/2df40c08-ca1f-451e-a4cd-3d55c109fa9a/agent/trajectory.jsonl) |
| 24 | completed | 0 | 93.27 | 0.79 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/ffc2b87e-712f-45fa-b825-21974ea07bfb/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/ffc2b87e-712f-45fa-b825-21974ea07bfb/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/ffc2b87e-712f-45fa-b825-21974ea07bfb/agent/trajectory.jsonl) |
| 25 | completed | 1 | 121.68 | 0.88 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/acdb78e9-91b9-4c34-8e6b-ac9e8bb31df6/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/acdb78e9-91b9-4c34-8e6b-ac9e8bb31df6/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/acdb78e9-91b9-4c34-8e6b-ac9e8bb31df6/agent/trajectory.jsonl) |
| 26 | completed | 1 | 376.02 | 0.76 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/09b74385-3329-40bc-b93f-ce29213720b8/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/09b74385-3329-40bc-b93f-ce29213720b8/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/09b74385-3329-40bc-b93f-ce29213720b8/agent/trajectory.jsonl) |
| 27 | completed | 1 | 344.91 | 0.93 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/c45d90a3-5614-4725-bd81-bf6f88fee938/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/c45d90a3-5614-4725-bd81-bf6f88fee938/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/c45d90a3-5614-4725-bd81-bf6f88fee938/agent/trajectory.jsonl) |
| 28 | completed | 0 | 241.03 | 0.79 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/eb358673-dbe9-482a-8e14-e1f714955b43/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/eb358673-dbe9-482a-8e14-e1f714955b43/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/eb358673-dbe9-482a-8e14-e1f714955b43/agent/trajectory.jsonl) |
| 29 | completed | 0 | 1090.10 | 0.77 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/5bdee9ee-dff2-4022-8558-f125ce5452df/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/5bdee9ee-dff2-4022-8558-f125ce5452df/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/5bdee9ee-dff2-4022-8558-f125ce5452df/agent/trajectory.jsonl) |
| 30 | completed | 0 | 130.65 | 0.73 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/1a013e6c-4305-4d9e-b78a-399c01efed8f/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/1a013e6c-4305-4d9e-b78a-399c01efed8f/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/1a013e6c-4305-4d9e-b78a-399c01efed8f/agent/trajectory.jsonl) |
| 31 | completed | 1 | 124.72 | 0.71 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/c937ee0b-b6e1-46e0-bd4f-25c6fd0311f1/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/c937ee0b-b6e1-46e0-bd4f-25c6fd0311f1/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/c937ee0b-b6e1-46e0-bd4f-25c6fd0311f1/agent/trajectory.jsonl) |
| 32 | completed | 1 | 64.32 | 0.74 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/1ae92f90-2220-45ac-99d7-5afc543780bc/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/1ae92f90-2220-45ac-99d7-5afc543780bc/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/1ae92f90-2220-45ac-99d7-5afc543780bc/agent/trajectory.jsonl) |
| 33 | completed | 1 | 207.82 | 0.69 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/ae26abe9-99c6-4e06-817b-d0b449d1ea6b/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/ae26abe9-99c6-4e06-817b-d0b449d1ea6b/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/ae26abe9-99c6-4e06-817b-d0b449d1ea6b/agent/trajectory.jsonl) |
| 34 | completed | 0 | 1123.99 | 0.94 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/a6f75bbf-4072-479f-b1ab-0b1f0753d635/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/a6f75bbf-4072-479f-b1ab-0b1f0753d635/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/a6f75bbf-4072-479f-b1ab-0b1f0753d635/agent/trajectory.jsonl) |
| 35 | completed | 1 | 42.71 | 0.76 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/cd273dad-4259-44a3-8a1c-35087138a7a1/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/cd273dad-4259-44a3-8a1c-35087138a7a1/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/cd273dad-4259-44a3-8a1c-35087138a7a1/agent/trajectory.jsonl) |
| 36 | completed | 0 | 353.58 | 0.49 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/cf6c4de3-f20c-48a3-b88f-b516587391f2/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/cf6c4de3-f20c-48a3-b88f-b516587391f2/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/cf6c4de3-f20c-48a3-b88f-b516587391f2/agent/trajectory.jsonl) |
| 37 | completed | 1 | 87.13 | 0.94 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/006759cb-91df-498b-a554-2bfc3610e930/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/006759cb-91df-498b-a554-2bfc3610e930/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/006759cb-91df-498b-a554-2bfc3610e930/agent/trajectory.jsonl) |
| 38 | completed | 0 | 417.36 | 0.95 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/4c08f8a0-7e13-4f3b-a1df-ab3ffa508a99/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/4c08f8a0-7e13-4f3b-a1df-ab3ffa508a99/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/4c08f8a0-7e13-4f3b-a1df-ab3ffa508a99/agent/trajectory.jsonl) |
| 39 | completed | 0 | 75.99 | 0.97 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/a78db3ef-cda2-496a-9483-41615c7bcdd5/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/a78db3ef-cda2-496a-9483-41615c7bcdd5/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/a78db3ef-cda2-496a-9483-41615c7bcdd5/agent/trajectory.jsonl) |
| 40 | completed | 0 | 59.30 | 0.84 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/6095f791-37f8-4f6c-849a-46a20932131d/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/6095f791-37f8-4f6c-849a-46a20932131d/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/6095f791-37f8-4f6c-849a-46a20932131d/agent/trajectory.jsonl) |
| 41 | cancelled | — | 67.44 | — | partial / complete | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/3290c8a6-6719-49d2-9b75-116e139386fc/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/3290c8a6-6719-49d2-9b75-116e139386fc/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/3290c8a6-6719-49d2-9b75-116e139386fc/agent/trajectory.jsonl) |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

