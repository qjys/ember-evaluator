<!-- snapshotDigest: c4df1e3f98bf4572822b3f57f1b00fce00b67eb3521d916a105e918ba00dee9f -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 28.57%（14/49）**

Run: 25fe8b42-bb61-40f6-94e0-3267850501a4 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | simpleagent |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-20T01:57:42.777Z / 2026-11-20T10:03:58.372Z |
| 总耗时 | 8 小时 6 分 16 秒 |
| 答对 / 答错 / 解题超时 | 14 / 35 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 49 题；已保存 49 条记录；待运行 0 题。
有效评分覆盖率：49/49（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 49 |
| 计分题数 | 49 |
| 正常评分题数 | 49 |
| 答对题数 | 14 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 28.57% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 8 小时 6 分 16 秒 |
| 环境准备耗时 | 5 小时 27 分 4 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 7 分 39 秒 | 49 秒 | 35 分 3 秒 | 49 |
| 任务准备 | 0.35 毫秒 | 0.15 毫秒 | 1.47 毫秒 | 49 |
| 环境启动 | 5 秒 | 3 秒 | 10 秒 | 49 |
| 解题 | 7 分 26 秒 | 39 秒 | 34 分 52 秒 | 49 |
| 产物传输 | 2 秒 | 1 秒 | 3 秒 | 49 |
| 证据收集 | 1 秒 | 896.86 毫秒 | 2 秒 | 49 |
| 资源清理 | 4 秒 | 2 秒 | 17 秒 | 49 |
| 评分 | 1 秒 | 722.49 毫秒 | 2 秒 | 49 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 65523ccf-471c-44a5-ab28-527535467901 | 14,400 | 3600 | 2 | 2 | 7200 |
| d9e39938-91a6-40b0-a145-479b8add65b4 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 102,806,534 | 1,230,017 | 104,036,551 | 49 / 49 | — |
| 运行累计 | 103,252,721 | 1,243,934 | 104,496,655 | 50 / 50 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 41 | completed | 0 | 191.16 | 1.14 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/386f91af-61be-444d-9850-2b92954a6be1/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/386f91af-61be-444d-9850-2b92954a6be1/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/386f91af-61be-444d-9850-2b92954a6be1/agent/trajectory.jsonl) |
| 42 | completed | 0 | 227.33 | 1.00 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/3a1e9f2b-c384-43aa-b1c1-390dfbf6abe7/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/3a1e9f2b-c384-43aa-b1c1-390dfbf6abe7/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/3a1e9f2b-c384-43aa-b1c1-390dfbf6abe7/agent/trajectory.jsonl) |
| 43 | completed | 1 | 156.73 | 0.82 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/66aed4a0-36ef-47db-b166-a32ff1f73fc4/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/66aed4a0-36ef-47db-b166-a32ff1f73fc4/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/66aed4a0-36ef-47db-b166-a32ff1f73fc4/agent/trajectory.jsonl) |
| 44 | completed | 0 | 242.15 | 0.93 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/b43d3c64-c5f1-4864-bc1b-85c8e7c4bace/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/b43d3c64-c5f1-4864-bc1b-85c8e7c4bace/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/b43d3c64-c5f1-4864-bc1b-85c8e7c4bace/agent/trajectory.jsonl) |
| 45 | completed | 1 | 1562.57 | 0.83 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/73f029c9-e49d-4516-9d01-efdc382d3d9a/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/73f029c9-e49d-4516-9d01-efdc382d3d9a/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/73f029c9-e49d-4516-9d01-efdc382d3d9a/agent/trajectory.jsonl) |
| 46 | completed | 1 | 2092.37 | 0.85 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/3d9c95af-e30b-424a-af7f-c2fafcb7830f/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/3d9c95af-e30b-424a-af7f-c2fafcb7830f/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/3d9c95af-e30b-424a-af7f-c2fafcb7830f/agent/trajectory.jsonl) |
| 47 | completed | 0 | 38.58 | 0.92 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/50140238-4cd1-4c20-98e7-0d789fb7e162/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/50140238-4cd1-4c20-98e7-0d789fb7e162/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/50140238-4cd1-4c20-98e7-0d789fb7e162/agent/trajectory.jsonl) |
| 48 | completed | 0 | 198.40 | 0.83 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/ab559a74-15e1-4f48-9b42-33765e1f337e/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/ab559a74-15e1-4f48-9b42-33765e1f337e/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/ab559a74-15e1-4f48-9b42-33765e1f337e/agent/trajectory.jsonl) |
| 49 | completed | 0 | 102.02 | 0.86 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/a313604f-582e-4f6c-a67c-a6b430d60d20/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/a313604f-582e-4f6c-a67c-a6b430d60d20/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/a313604f-582e-4f6c-a67c-a6b430d60d20/agent/trajectory.jsonl) |
| 50 | completed | 0 | 395.61 | 1.02 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/e080681f-9da5-47ba-a34a-7367c367ed9b/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/e080681f-9da5-47ba-a34a-7367c367ed9b/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/e080681f-9da5-47ba-a34a-7367c367ed9b/agent/trajectory.jsonl) |
| 51 | completed | 0 | 929.45 | 1.19 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/28c04a5c-9b7c-4a72-9628-3d7f8fb97b01/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/28c04a5c-9b7c-4a72-9628-3d7f8fb97b01/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/28c04a5c-9b7c-4a72-9628-3d7f8fb97b01/agent/trajectory.jsonl) |
| 52 | completed | 0 | 574.33 | 1.00 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/24525072-4221-4e25-8bd3-77f4bbb34c33/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/24525072-4221-4e25-8bd3-77f4bbb34c33/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/24525072-4221-4e25-8bd3-77f4bbb34c33/agent/trajectory.jsonl) |
| 53 | completed | 1 | 65.52 | 0.97 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/43d8c9ce-4829-4b90-90d4-3735f0281eef/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/43d8c9ce-4829-4b90-90d4-3735f0281eef/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/43d8c9ce-4829-4b90-90d4-3735f0281eef/agent/trajectory.jsonl) |
| 54 | completed | 1 | 945.28 | 0.98 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/640902cc-0af5-4b84-9d2e-bfa6f68980a3/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/640902cc-0af5-4b84-9d2e-bfa6f68980a3/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/640902cc-0af5-4b84-9d2e-bfa6f68980a3/agent/trajectory.jsonl) |
| 55 | completed | 1 | 1463.13 | 1.26 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/4fdb8fbc-57df-49f5-99f6-def9a2ff838e/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/4fdb8fbc-57df-49f5-99f6-def9a2ff838e/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/4fdb8fbc-57df-49f5-99f6-def9a2ff838e/agent/trajectory.jsonl) |
| 56 | completed | 1 | 241.57 | 1.22 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/cbbeff1e-6004-4e01-b355-c15d6f39d0f9/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/cbbeff1e-6004-4e01-b355-c15d6f39d0f9/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/cbbeff1e-6004-4e01-b355-c15d6f39d0f9/agent/trajectory.jsonl) |
| 57 | completed | 0 | 459.23 | 1.00 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/507434d7-238f-429d-a740-a24f98d294df/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/507434d7-238f-429d-a740-a24f98d294df/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/507434d7-238f-429d-a740-a24f98d294df/agent/trajectory.jsonl) |
| 58 | completed | 1 | 166.66 | 1.13 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/a12db59d-774a-42be-871b-82643845301d/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/a12db59d-774a-42be-871b-82643845301d/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/a12db59d-774a-42be-871b-82643845301d/agent/trajectory.jsonl) |
| 59 | completed | 0 | 98.01 | 1.08 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/b889cf83-980f-4670-936a-2cf2fe775547/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/b889cf83-980f-4670-936a-2cf2fe775547/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/b889cf83-980f-4670-936a-2cf2fe775547/agent/trajectory.jsonl) |
| 60 | completed | 1 | 130.22 | 1.08 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/546fbe94-426b-42ac-a028-9d76f646b235/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/546fbe94-426b-42ac-a028-9d76f646b235/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/546fbe94-426b-42ac-a028-9d76f646b235/agent/trajectory.jsonl) |
| 61 | completed | 0 | 354.25 | 1.05 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/09933732-5810-4a52-aa68-df7bc9ee510e/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/09933732-5810-4a52-aa68-df7bc9ee510e/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/09933732-5810-4a52-aa68-df7bc9ee510e/agent/trajectory.jsonl) |
| 62 | completed | 0 | 342.99 | 1.11 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/e02ac695-c475-421b-8330-161328c9e8ef/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/e02ac695-c475-421b-8330-161328c9e8ef/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/e02ac695-c475-421b-8330-161328c9e8ef/agent/trajectory.jsonl) |
| 63 | completed | 1 | 198.49 | 1.33 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/6fd2528a-8bc4-447f-a8bd-f34652eeaf07/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/6fd2528a-8bc4-447f-a8bd-f34652eeaf07/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/6fd2528a-8bc4-447f-a8bd-f34652eeaf07/agent/trajectory.jsonl) |
| 64 | completed | 0 | 137.87 | 1.35 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/06a2b854-c67b-40d3-b427-fb1155b4cc50/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/06a2b854-c67b-40d3-b427-fb1155b4cc50/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/06a2b854-c67b-40d3-b427-fb1155b4cc50/agent/trajectory.jsonl) |
| 65 | completed | 0 | 75.82 | 1.15 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/1dd6a260-5b86-4313-bdd1-f75cbbc71d59/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/1dd6a260-5b86-4313-bdd1-f75cbbc71d59/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/1dd6a260-5b86-4313-bdd1-f75cbbc71d59/agent/trajectory.jsonl) |
| 66 | completed | 0 | 179.72 | 1.11 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/4cc20703-be7f-436f-95fd-81509721add4/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/4cc20703-be7f-436f-95fd-81509721add4/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/4cc20703-be7f-436f-95fd-81509721add4/agent/trajectory.jsonl) |
| 67 | completed | 1 | 140.92 | 0.98 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/30f5f4bd-e68c-4e60-9ce3-452b02a93fe0/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/30f5f4bd-e68c-4e60-9ce3-452b02a93fe0/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/30f5f4bd-e68c-4e60-9ce3-452b02a93fe0/agent/trajectory.jsonl) |
| 68 | completed | 1 | 699.46 | 1.14 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/7d16d64d-768f-45f9-a8e0-9c95e937f917/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/7d16d64d-768f-45f9-a8e0-9c95e937f917/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/7d16d64d-768f-45f9-a8e0-9c95e937f917/agent/trajectory.jsonl) |
| 69 | completed | 0 | 176.42 | 1.58 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/eb311a2b-4f12-4aee-af09-13f6e3c293fa/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/eb311a2b-4f12-4aee-af09-13f6e3c293fa/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/eb311a2b-4f12-4aee-af09-13f6e3c293fa/agent/trajectory.jsonl) |
| 70 | completed | 1 | 500.28 | 1.45 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/0f05bdd3-117d-42af-872c-12357ab87190/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/0f05bdd3-117d-42af-872c-12357ab87190/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/0f05bdd3-117d-42af-872c-12357ab87190/agent/trajectory.jsonl) |
| 71 | completed | 0 | 369.51 | 1.02 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/2f38f149-3b59-4752-bb47-a466e1c84b93/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/2f38f149-3b59-4752-bb47-a466e1c84b93/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/2f38f149-3b59-4752-bb47-a466e1c84b93/agent/trajectory.jsonl) |
| 72 | completed | 0 | 1405.90 | 1.22 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/dc386bbb-8e6e-4220-b95e-9a141f08b6b9/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/dc386bbb-8e6e-4220-b95e-9a141f08b6b9/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/dc386bbb-8e6e-4220-b95e-9a141f08b6b9/agent/trajectory.jsonl) |
| 73 | completed | 0 | 672.76 | 0.73 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/02e633ce-134f-493d-ac0c-ced06343631e/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/02e633ce-134f-493d-ac0c-ced06343631e/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/02e633ce-134f-493d-ac0c-ced06343631e/agent/trajectory.jsonl) |
| 74 | completed | 0 | 224.72 | 1.87 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/5a7e6b01-412f-43a6-b0f6-a4fdf8da3af9/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/5a7e6b01-412f-43a6-b0f6-a4fdf8da3af9/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/5a7e6b01-412f-43a6-b0f6-a4fdf8da3af9/agent/trajectory.jsonl) |
| 75 | completed | 0 | 58.37 | 1.59 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/ca351ab3-9ece-4c2c-befe-c13ad266e31b/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/ca351ab3-9ece-4c2c-befe-c13ad266e31b/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/ca351ab3-9ece-4c2c-befe-c13ad266e31b/agent/trajectory.jsonl) |
| 76 | completed | 0 | 73.88 | 2.00 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/2f59dfd9-8fbd-4bdf-8892-96da913b423b/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/2f59dfd9-8fbd-4bdf-8892-96da913b423b/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/2f59dfd9-8fbd-4bdf-8892-96da913b423b/agent/trajectory.jsonl) |
| 77 | completed | 0 | 1667.75 | 1.35 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/ef7ff6f3-6ede-48d3-bdf5-0348ab6aafeb/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/ef7ff6f3-6ede-48d3-bdf5-0348ab6aafeb/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/ef7ff6f3-6ede-48d3-bdf5-0348ab6aafeb/agent/trajectory.jsonl) |
| 78 | completed | 0 | 98.44 | 0.93 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/6caf5c17-ff5d-4be4-9757-d8cdbe7e39df/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/6caf5c17-ff5d-4be4-9757-d8cdbe7e39df/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/6caf5c17-ff5d-4be4-9757-d8cdbe7e39df/agent/trajectory.jsonl) |
| 79 | completed | 0 | 266.84 | 0.72 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d453354b-4169-4eec-95e0-154796f59972/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d453354b-4169-4eec-95e0-154796f59972/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d453354b-4169-4eec-95e0-154796f59972/agent/trajectory.jsonl) |
| 80 | completed | 0 | 584.47 | 0.75 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/e252fe18-5d16-4016-8d4d-dcfdfcb12f01/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/e252fe18-5d16-4016-8d4d-dcfdfcb12f01/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/e252fe18-5d16-4016-8d4d-dcfdfcb12f01/agent/trajectory.jsonl) |
| 81 | completed | 1 | 547.87 | 0.73 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/043a850d-cbdc-497d-9460-1cbfd09a5630/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/043a850d-cbdc-497d-9460-1cbfd09a5630/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/043a850d-cbdc-497d-9460-1cbfd09a5630/agent/trajectory.jsonl) |
| 82 | completed | 0 | 1057.48 | 0.75 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/d45e1cce-74b7-4bce-aa53-4cfa3990d125/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/d45e1cce-74b7-4bce-aa53-4cfa3990d125/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/d45e1cce-74b7-4bce-aa53-4cfa3990d125/agent/trajectory.jsonl) |
| 83 | completed | 0 | 133.08 | 0.74 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/aa353a59-9726-4e30-bdcf-efd8178433d5/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/aa353a59-9726-4e30-bdcf-efd8178433d5/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/aa353a59-9726-4e30-bdcf-efd8178433d5/agent/trajectory.jsonl) |
| 84 | completed | 0 | 299.56 | 0.81 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/5aafe82d-5c12-41df-8a70-11d8c13b884e/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/5aafe82d-5c12-41df-8a70-11d8c13b884e/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/5aafe82d-5c12-41df-8a70-11d8c13b884e/agent/trajectory.jsonl) |
| 85 | completed | 0 | 695.25 | 0.81 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/fa684485-b812-41cf-b0b5-2ee571a654a1/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/fa684485-b812-41cf-b0b5-2ee571a654a1/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/fa684485-b812-41cf-b0b5-2ee571a654a1/agent/trajectory.jsonl) |
| 86 | completed | 0 | 209.15 | 0.77 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/d546cc04-8812-4029-86ed-2c47784df8aa/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/d546cc04-8812-4029-86ed-2c47784df8aa/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/d546cc04-8812-4029-86ed-2c47784df8aa/agent/trajectory.jsonl) |
| 87 | completed | 0 | 118.74 | 0.76 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/d147c97f-61e1-48de-9ad2-f8b159b0ad36/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/d147c97f-61e1-48de-9ad2-f8b159b0ad36/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/d147c97f-61e1-48de-9ad2-f8b159b0ad36/agent/trajectory.jsonl) |
| 88 | completed | 0 | 206.44 | 0.78 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/eb001a74-7d06-4c75-8098-776bb9a2a276/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/eb001a74-7d06-4c75-8098-776bb9a2a276/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/eb001a74-7d06-4c75-8098-776bb9a2a276/agent/trajectory.jsonl) |
| 89 | completed | 0 | 74.26 | 0.78 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/9e14f2a1-d7b7-40c8-aca6-14bc7a63beae/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/9e14f2a1-d7b7-40c8-aca6-14bc7a63beae/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/9e14f2a1-d7b7-40c8-aca6-14bc7a63beae/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

