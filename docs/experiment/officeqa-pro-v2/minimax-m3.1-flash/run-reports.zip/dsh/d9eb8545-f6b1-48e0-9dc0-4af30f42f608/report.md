<!-- snapshotDigest: 21b7e4b9e5048fee15ecea9438d45900e5ec183c69aadb94ff3ac8e622f65c07 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 25.00%（11/44）**

Run: d9eb8545-f6b1-48e0-9dc0-4af30f42f608 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-20T01:57:41.775Z / 2026-11-20T11:04:28.282Z |
| 总耗时 | 9 小时 6 分 47 秒 |
| 答对 / 答错 / 解题超时 | 11 / 33 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 44 题；已保存 44 条记录；待运行 0 题。
有效评分覆盖率：44/44（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 44 |
| 计分题数 | 44 |
| 正常评分题数 | 44 |
| 答对题数 | 11 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 25.00% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 6 分 47 秒 |
| 环境准备耗时 | 6 小时 39 分 47 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 9 分 49 秒 | 52 秒 | 1 小时 24 分 36 秒 | 44 |
| 任务准备 | 0.47 毫秒 | 0.12 毫秒 | 4.53 毫秒 | 44 |
| 环境启动 | 17 秒 | 10 秒 | 40 秒 | 44 |
| 解题 | 9 分 25 秒 | 34 秒 | 1 小时 23 分 55 秒 | 44 |
| 产物传输 | 1 秒 | 1 秒 | 4 秒 | 44 |
| 证据收集 | 1 秒 | 893.91 毫秒 | 4 秒 | 44 |
| 资源清理 | 4 秒 | 2 秒 | 13 秒 | 44 |
| 评分 | 919.56 毫秒 | 715.81 毫秒 | 2 秒 | 44 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 45f7a3ae-d520-4db1-93e8-c11ea75cf44d | 14,400 | 3600 | 2 | 2 | 7200 |
| daf26100-bc59-4d93-97b1-901e81a8cd3a | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 1,211,860 | 130,086,369 | 44 / 44 | — |
| 运行累计 | — | 1,211,860 | 130,086,369 | 44 / 45 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 46 | completed | 0 | 2441.68 | 0.82 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/335048c9-b2f9-4423-ace1-3bac038be7fb/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/335048c9-b2f9-4423-ace1-3bac038be7fb/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/335048c9-b2f9-4423-ace1-3bac038be7fb/agent/trajectory.jsonl) |
| 47 | completed | 0 | 232.10 | 1.00 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/ea869829-5aaf-49c6-9ffa-1637c9950d15/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/ea869829-5aaf-49c6-9ffa-1637c9950d15/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/ea869829-5aaf-49c6-9ffa-1637c9950d15/agent/trajectory.jsonl) |
| 48 | completed | 0 | 102.54 | 0.84 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/6b44d1cb-ef0b-4742-928e-fc002e205953/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/6b44d1cb-ef0b-4742-928e-fc002e205953/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/6b44d1cb-ef0b-4742-928e-fc002e205953/agent/trajectory.jsonl) |
| 49 | completed | 0 | 189.84 | 0.87 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/885174b7-cb65-4ee6-9c5f-69038d6b53e6/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/885174b7-cb65-4ee6-9c5f-69038d6b53e6/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/885174b7-cb65-4ee6-9c5f-69038d6b53e6/agent/trajectory.jsonl) |
| 50 | completed | 0 | 206.75 | 0.99 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/116ef67b-fef7-48df-acb9-a11f5e08608a/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/116ef67b-fef7-48df-acb9-a11f5e08608a/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/116ef67b-fef7-48df-acb9-a11f5e08608a/agent/trajectory.jsonl) |
| 51 | completed | 0 | 2019.60 | 1.19 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/493b012e-4ea5-458e-a8d9-3f15d43d26ab/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/493b012e-4ea5-458e-a8d9-3f15d43d26ab/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/493b012e-4ea5-458e-a8d9-3f15d43d26ab/agent/trajectory.jsonl) |
| 52 | completed | 0 | 172.62 | 0.95 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/8afcfc3c-d9d1-4db1-9198-1cc5e98fb168/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/8afcfc3c-d9d1-4db1-9198-1cc5e98fb168/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/8afcfc3c-d9d1-4db1-9198-1cc5e98fb168/agent/trajectory.jsonl) |
| 53 | completed | 1 | 918.77 | 1.16 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/6c9f996c-d8ff-4909-a0a3-7475a74b3a2a/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/6c9f996c-d8ff-4909-a0a3-7475a74b3a2a/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/6c9f996c-d8ff-4909-a0a3-7475a74b3a2a/agent/trajectory.jsonl) |
| 54 | completed | 1 | 2767.44 | 1.27 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/f2813a7d-049b-494b-b2ab-2bbe5f0480c5/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/f2813a7d-049b-494b-b2ab-2bbe5f0480c5/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/f2813a7d-049b-494b-b2ab-2bbe5f0480c5/agent/trajectory.jsonl) |
| 55 | completed | 1 | 5035.20 | 1.88 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/300618fb-0bf8-4da9-9187-941a9a93ae38/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/300618fb-0bf8-4da9-9187-941a9a93ae38/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/300618fb-0bf8-4da9-9187-941a9a93ae38/agent/trajectory.jsonl) |
| 56 | completed | 0 | 760.93 | 0.93 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/c876eafd-8fd3-4182-b02f-1aae4319f727/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/c876eafd-8fd3-4182-b02f-1aae4319f727/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/c876eafd-8fd3-4182-b02f-1aae4319f727/agent/trajectory.jsonl) |
| 57 | completed | 0 | 188.32 | 0.92 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/2c94bf07-1a61-41c6-96aa-60e76b88268f/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/2c94bf07-1a61-41c6-96aa-60e76b88268f/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/2c94bf07-1a61-41c6-96aa-60e76b88268f/agent/trajectory.jsonl) |
| 58 | completed | 1 | 212.66 | 1.32 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/2f5ecd58-7ef3-4125-aedf-5c80e57d43aa/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/2f5ecd58-7ef3-4125-aedf-5c80e57d43aa/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/2f5ecd58-7ef3-4125-aedf-5c80e57d43aa/agent/trajectory.jsonl) |
| 59 | completed | 0 | 207.25 | 0.75 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/935b0ccf-72ec-4a10-b308-a8954268ee8d/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/935b0ccf-72ec-4a10-b308-a8954268ee8d/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/935b0ccf-72ec-4a10-b308-a8954268ee8d/agent/trajectory.jsonl) |
| 60 | completed | 1 | 207.78 | 0.97 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/afccafbd-6816-4f88-9656-5f4f6c937b31/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/afccafbd-6816-4f88-9656-5f4f6c937b31/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/afccafbd-6816-4f88-9656-5f4f6c937b31/agent/trajectory.jsonl) |
| 61 | completed | 0 | 713.85 | 1.70 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/0b366e7f-7533-4312-8ac2-3f8b11cf7506/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/0b366e7f-7533-4312-8ac2-3f8b11cf7506/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/0b366e7f-7533-4312-8ac2-3f8b11cf7506/agent/trajectory.jsonl) |
| 62 | completed | 0 | 407.12 | 0.75 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/bcf9509c-d5f0-43fd-adea-c6a71cbfa6c5/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/bcf9509c-d5f0-43fd-adea-c6a71cbfa6c5/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/bcf9509c-d5f0-43fd-adea-c6a71cbfa6c5/agent/trajectory.jsonl) |
| 63 | completed | 0 | 706.26 | 1.29 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/d2db8753-c5bd-46e2-9f12-07877ac74c21/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/d2db8753-c5bd-46e2-9f12-07877ac74c21/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/d2db8753-c5bd-46e2-9f12-07877ac74c21/agent/trajectory.jsonl) |
| 64 | completed | 1 | 141.75 | 1.15 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/7e783044-ff75-439e-9434-3110958bd854/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/7e783044-ff75-439e-9434-3110958bd854/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/7e783044-ff75-439e-9434-3110958bd854/agent/trajectory.jsonl) |
| 65 | completed | 0 | 252.41 | 0.81 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/ea8049cd-0ba4-4040-96f3-c07e8e314961/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/ea8049cd-0ba4-4040-96f3-c07e8e314961/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/ea8049cd-0ba4-4040-96f3-c07e8e314961/agent/trajectory.jsonl) |
| 66 | completed | 0 | 147.95 | 0.96 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/72a30a3b-5e47-4d82-ad99-4c7f42c60329/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/72a30a3b-5e47-4d82-ad99-4c7f42c60329/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/72a30a3b-5e47-4d82-ad99-4c7f42c60329/agent/trajectory.jsonl) |
| 67 | completed | 0 | 118.84 | 1.36 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/4ec39e2e-c614-4214-8a6c-c36019395979/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/4ec39e2e-c614-4214-8a6c-c36019395979/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/4ec39e2e-c614-4214-8a6c-c36019395979/agent/trajectory.jsonl) |
| 68 | completed | 1 | 240.53 | 0.72 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/0be328e3-e8cf-42a3-bf99-5763d0d1c803/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/0be328e3-e8cf-42a3-bf99-5763d0d1c803/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/0be328e3-e8cf-42a3-bf99-5763d0d1c803/agent/trajectory.jsonl) |
| 69 | completed | 0 | 142.74 | 0.76 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/f19a00f8-d9b4-4958-9322-cc55e8ad2934/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/f19a00f8-d9b4-4958-9322-cc55e8ad2934/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/f19a00f8-d9b4-4958-9322-cc55e8ad2934/agent/trajectory.jsonl) |
| 70 | completed | 0 | 1049.94 | 0.78 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/9aba9f89-6810-4faa-a588-f8e118c2531d/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/9aba9f89-6810-4faa-a588-f8e118c2531d/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/9aba9f89-6810-4faa-a588-f8e118c2531d/agent/trajectory.jsonl) |
| 71 | completed | 0 | 131.88 | 0.76 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/5cc17e1f-b946-4208-95fd-68e7c88b9c52/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/5cc17e1f-b946-4208-95fd-68e7c88b9c52/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/5cc17e1f-b946-4208-95fd-68e7c88b9c52/agent/trajectory.jsonl) |
| 72 | completed | 1 | 413.95 | 0.79 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/4e402464-8d96-4f32-9706-98f9558131a3/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/4e402464-8d96-4f32-9706-98f9558131a3/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/4e402464-8d96-4f32-9706-98f9558131a3/agent/trajectory.jsonl) |
| 73 | completed | 1 | 482.94 | 0.80 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/efd54db8-62fa-409f-8589-e592ed90f349/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/efd54db8-62fa-409f-8589-e592ed90f349/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/efd54db8-62fa-409f-8589-e592ed90f349/agent/trajectory.jsonl) |
| 74 | completed | 0 | 142.90 | 0.79 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/8000741e-4c4e-4898-8460-1253bb5abe2a/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/8000741e-4c4e-4898-8460-1253bb5abe2a/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/8000741e-4c4e-4898-8460-1253bb5abe2a/agent/trajectory.jsonl) |
| 75 | completed | 0 | 33.62 | 0.79 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/1e0bf571-1122-42c2-98dc-af7b89ea690d/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/1e0bf571-1122-42c2-98dc-af7b89ea690d/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/1e0bf571-1122-42c2-98dc-af7b89ea690d/agent/trajectory.jsonl) |
| 76 | completed | 0 | 70.56 | 0.76 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/ac7498b7-3b27-4f69-868e-de8f3736a40c/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/ac7498b7-3b27-4f69-868e-de8f3736a40c/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/ac7498b7-3b27-4f69-868e-de8f3736a40c/agent/trajectory.jsonl) |
| 77 | completed | 0 | 742.46 | 0.73 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/b096efb9-f85c-485d-9aae-49d7bf6a5991/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/b096efb9-f85c-485d-9aae-49d7bf6a5991/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/b096efb9-f85c-485d-9aae-49d7bf6a5991/agent/trajectory.jsonl) |
| 78 | completed | 0 | 97.31 | 0.74 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/f02458cb-79db-4bd2-b300-5fc9fcb11278/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/f02458cb-79db-4bd2-b300-5fc9fcb11278/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/f02458cb-79db-4bd2-b300-5fc9fcb11278/agent/trajectory.jsonl) |
| 79 | completed | 1 | 120.09 | 0.74 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d5a76689-8c78-40d1-9e19-a387b2b020f0/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d5a76689-8c78-40d1-9e19-a387b2b020f0/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/d5a76689-8c78-40d1-9e19-a387b2b020f0/agent/trajectory.jsonl) |
| 80 | completed | 0 | 360.17 | 0.74 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/7715bf3b-17a2-4965-9bca-1fd84264f719/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/7715bf3b-17a2-4965-9bca-1fd84264f719/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/7715bf3b-17a2-4965-9bca-1fd84264f719/agent/trajectory.jsonl) |
| 81 | completed | 0 | 159.82 | 0.72 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/de7e93fa-1dcc-48e5-abb6-02b32c432668/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/de7e93fa-1dcc-48e5-abb6-02b32c432668/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/de7e93fa-1dcc-48e5-abb6-02b32c432668/agent/trajectory.jsonl) |
| 82 | completed | 0 | 689.71 | 0.77 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/a8732e2b-b895-44c3-b08f-b832606f8e0e/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/a8732e2b-b895-44c3-b08f-b832606f8e0e/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/a8732e2b-b895-44c3-b08f-b832606f8e0e/agent/trajectory.jsonl) |
| 83 | completed | 0 | 218.02 | 0.73 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/98e846e7-23ac-4865-a2c8-b5858b0b0c02/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/98e846e7-23ac-4865-a2c8-b5858b0b0c02/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/98e846e7-23ac-4865-a2c8-b5858b0b0c02/agent/trajectory.jsonl) |
| 84 | completed | 1 | 335.05 | 0.73 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/35aa5eb9-5366-4eb7-82b6-b0129a7918f3/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/35aa5eb9-5366-4eb7-82b6-b0129a7918f3/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/35aa5eb9-5366-4eb7-82b6-b0129a7918f3/agent/trajectory.jsonl) |
| 85 | completed | 0 | 562.07 | 0.77 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/873cf317-a634-4955-9a60-c37a5bb7853f/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/873cf317-a634-4955-9a60-c37a5bb7853f/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/873cf317-a634-4955-9a60-c37a5bb7853f/agent/trajectory.jsonl) |
| 86 | completed | 0 | 294.78 | 0.75 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a20dfce1-c8d8-40cf-a193-1024a831eb3a/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a20dfce1-c8d8-40cf-a193-1024a831eb3a/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a20dfce1-c8d8-40cf-a193-1024a831eb3a/agent/trajectory.jsonl) |
| 87 | completed | 0 | 101.77 | 0.73 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/d1f2f9ef-489a-42ac-8f1f-9f75f55fb14e/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/d1f2f9ef-489a-42ac-8f1f-9f75f55fb14e/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/d1f2f9ef-489a-42ac-8f1f-9f75f55fb14e/agent/trajectory.jsonl) |
| 88 | completed | 0 | 155.37 | 0.74 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/4f1cbdf4-5ba6-4a4b-8686-5d6b2e31aa96/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/4f1cbdf4-5ba6-4a4b-8686-5d6b2e31aa96/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/4f1cbdf4-5ba6-4a4b-8686-5d6b2e31aa96/agent/trajectory.jsonl) |
| 89 | completed | 0 | 153.14 | 0.72 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/19180707-b11a-4d45-abfc-93c2ef71d4dc/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/19180707-b11a-4d45-abfc-93c2ef71d4dc/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/19180707-b11a-4d45-abfc-93c2ef71d4dc/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

