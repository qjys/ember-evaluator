<!-- snapshotDigest: de8bd4a70cac8e2295230d182cc7462ba9629baa860504d0bb53e1574d376e2e -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 32.58%（29/89）**

Run: 1c649c5f-c098-4cc5-8790-88a05b83a236 · Status: cancelled

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-19T15:46:00.664Z / 2026-11-20T01:47:51.519Z |
| 总耗时 | 10 小时 1 分 51 秒 |
| 答对 / 答错 / 解题超时 | 29 / 17 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 47 条记录；待运行 44 题。
有效评分覆盖率：46/90（51.11%）。
执行失败 0；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 46 |
| 答对题数 | 29 |
| 无效评测 | 1 |
| 待运行 | 44 |
| 正确率 | 32.58% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 10 小时 1 分 51 秒 |
| 环境准备耗时 | 10 小时 1 分 28 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 4 分 1 秒 | 1 分 1 秒 | 14 分 33 秒 | 47 |
| 任务准备 | 0.36 毫秒 | 0.2 毫秒 | 1.41 毫秒 | 47 |
| 环境启动 | 17 秒 | 11 秒 | 23 秒 | 47 |
| 解题 | 3 分 38 秒 | 35 秒 | 14 分 14 秒 | 47 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 46 |
| 证据收集 | 1 秒 | 819.37 毫秒 | 4 秒 | 47 |
| 资源清理 | 3 秒 | 2 秒 | 9 秒 | 47 |
| 评分 | 875.95 毫秒 | 681.81 毫秒 | 1 秒 | 46 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| f777c37b-ed95-4c08-8f9f-63da3b698aee | 14,400 | 3600 | 2 | 2 | 7200 |
| fbbe166f-991d-4fd9-a15a-e13ead7f197d | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | — | 959,718 | 85,308,457 | 46 / 90 | — |
| 运行累计 | — | 959,718 | 85,308,457 | 46 / 49 | 2 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 0 | 82.15 | 1.39 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/74f09b0d-6cae-46e3-b8a4-2cb5a62251a2/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/74f09b0d-6cae-46e3-b8a4-2cb5a62251a2/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/74f09b0d-6cae-46e3-b8a4-2cb5a62251a2/agent/trajectory.jsonl) |
| 1 | completed | 1 | 140.60 | 0.79 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/e14a8bce-fe1f-49fc-95ab-f2e3b868cd8b/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/e14a8bce-fe1f-49fc-95ab-f2e3b868cd8b/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/e14a8bce-fe1f-49fc-95ab-f2e3b868cd8b/agent/trajectory.jsonl) |
| 2 | completed | 1 | 129.30 | 0.95 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/b30f97a7-fb99-4f74-bd1d-be88e4c87cb2/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/b30f97a7-fb99-4f74-bd1d-be88e4c87cb2/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/b30f97a7-fb99-4f74-bd1d-be88e4c87cb2/agent/trajectory.jsonl) |
| 3 | completed | 1 | 144.56 | 0.83 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/c8c28149-37af-4523-bbb7-0cb19ebefb7f/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/c8c28149-37af-4523-bbb7-0cb19ebefb7f/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/c8c28149-37af-4523-bbb7-0cb19ebefb7f/agent/trajectory.jsonl) |
| 4 | completed | 1 | 71.08 | 0.85 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/f4eae0ee-88a0-4384-b60e-0a9f6f4867d0/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/f4eae0ee-88a0-4384-b60e-0a9f6f4867d0/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/f4eae0ee-88a0-4384-b60e-0a9f6f4867d0/agent/trajectory.jsonl) |
| 5 | completed | 1 | 114.82 | 1.03 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/22cc7c46-50de-47b2-b299-15c97661d24f/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/22cc7c46-50de-47b2-b299-15c97661d24f/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/22cc7c46-50de-47b2-b299-15c97661d24f/agent/trajectory.jsonl) |
| 6 | completed | 1 | 201.28 | 0.85 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/8fdcc85c-31cf-40d9-b9e6-8ca1e02681cc/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/8fdcc85c-31cf-40d9-b9e6-8ca1e02681cc/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/8fdcc85c-31cf-40d9-b9e6-8ca1e02681cc/agent/trajectory.jsonl) |
| 7 | completed | 1 | 64.28 | 0.91 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/2a180c1c-fd2c-409d-b99b-3a1b88ffae1c/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/2a180c1c-fd2c-409d-b99b-3a1b88ffae1c/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/2a180c1c-fd2c-409d-b99b-3a1b88ffae1c/agent/trajectory.jsonl) |
| 8 | completed | 0 | 116.71 | 1.13 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/9d8a2475-27bd-4786-8b2f-d7af6bc1f94e/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/9d8a2475-27bd-4786-8b2f-d7af6bc1f94e/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/9d8a2475-27bd-4786-8b2f-d7af6bc1f94e/agent/trajectory.jsonl) |
| 9 | completed | 1 | 34.66 | 0.93 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/5f57ddef-2a03-492a-9fe6-caf8a390f7c9/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/5f57ddef-2a03-492a-9fe6-caf8a390f7c9/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/5f57ddef-2a03-492a-9fe6-caf8a390f7c9/agent/trajectory.jsonl) |
| 10 | completed | 1 | 56.20 | 0.75 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/4e5de3ce-9b8d-4440-9ed5-bc3c08fcb9f0/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/4e5de3ce-9b8d-4440-9ed5-bc3c08fcb9f0/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/4e5de3ce-9b8d-4440-9ed5-bc3c08fcb9f0/agent/trajectory.jsonl) |
| 11 | completed | 1 | 547.12 | 0.80 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/b098aee0-2f66-45db-aff6-3a324638b48f/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/b098aee0-2f66-45db-aff6-3a324638b48f/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/b098aee0-2f66-45db-aff6-3a324638b48f/agent/trajectory.jsonl) |
| 12 | completed | 0 | 108.47 | 0.83 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/864ecf20-3e25-4929-884e-436d9a6bceb5/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/864ecf20-3e25-4929-884e-436d9a6bceb5/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/864ecf20-3e25-4929-884e-436d9a6bceb5/agent/trajectory.jsonl) |
| 13 | completed | 1 | 325.98 | 0.93 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/062295b6-ebf9-4f92-b222-6cde8efee10c/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/062295b6-ebf9-4f92-b222-6cde8efee10c/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/062295b6-ebf9-4f92-b222-6cde8efee10c/agent/trajectory.jsonl) |
| 14 | completed | 0 | 49.08 | 0.68 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/3ca211da-52af-4be7-9207-050effb546c3/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/3ca211da-52af-4be7-9207-050effb546c3/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/3ca211da-52af-4be7-9207-050effb546c3/agent/trajectory.jsonl) |
| 15 | completed | 1 | 212.72 | 0.73 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/20b0de94-bf05-45fd-9ce5-a63c202ea431/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/20b0de94-bf05-45fd-9ce5-a63c202ea431/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/20b0de94-bf05-45fd-9ce5-a63c202ea431/agent/trajectory.jsonl) |
| 16 | completed | 1 | 293.35 | 0.85 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/6df5194b-8f35-4d3f-8442-8902118e4132/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/6df5194b-8f35-4d3f-8442-8902118e4132/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/6df5194b-8f35-4d3f-8442-8902118e4132/agent/trajectory.jsonl) |
| 17 | completed | 0 | 853.84 | 0.84 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/82253781-afb0-4e36-aec4-e35b67221a29/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/82253781-afb0-4e36-aec4-e35b67221a29/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/82253781-afb0-4e36-aec4-e35b67221a29/agent/trajectory.jsonl) |
| 18 | completed | 1 | 148.87 | 0.82 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/831f034d-fa2d-4d8f-98f3-ad22cba9abec/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/831f034d-fa2d-4d8f-98f3-ad22cba9abec/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/831f034d-fa2d-4d8f-98f3-ad22cba9abec/agent/trajectory.jsonl) |
| 19 | completed | 0 | 200.83 | 0.78 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/98e6bc09-f49b-4f93-8a7b-4026d6ccb54a/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/98e6bc09-f49b-4f93-8a7b-4026d6ccb54a/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/98e6bc09-f49b-4f93-8a7b-4026d6ccb54a/agent/trajectory.jsonl) |
| 20 | completed | 1 | 188.48 | 0.72 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/4fc5b180-fcda-4631-a018-ee1e2010dbe1/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/4fc5b180-fcda-4631-a018-ee1e2010dbe1/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/4fc5b180-fcda-4631-a018-ee1e2010dbe1/agent/trajectory.jsonl) |
| 21 | completed | 1 | 88.77 | 0.72 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/7db02dfa-3cbc-4b76-b6e6-bc891110ed5c/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/7db02dfa-3cbc-4b76-b6e6-bc891110ed5c/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/7db02dfa-3cbc-4b76-b6e6-bc891110ed5c/agent/trajectory.jsonl) |
| 22 | completed | 1 | 133.71 | 0.75 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/a29ca8c2-b3d1-419b-9cec-dbce91462f8a/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/a29ca8c2-b3d1-419b-9cec-dbce91462f8a/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/a29ca8c2-b3d1-419b-9cec-dbce91462f8a/agent/trajectory.jsonl) |
| 23 | completed | 1 | 553.66 | 0.92 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/1464f512-ba78-4c82-bfca-e0ecca53df61/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/1464f512-ba78-4c82-bfca-e0ecca53df61/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/1464f512-ba78-4c82-bfca-e0ecca53df61/agent/trajectory.jsonl) |
| 24 | completed | 0 | 213.02 | 0.82 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/21af043d-981c-422d-9d5e-f9a3cfb5c6a9/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/21af043d-981c-422d-9d5e-f9a3cfb5c6a9/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/21af043d-981c-422d-9d5e-f9a3cfb5c6a9/agent/trajectory.jsonl) |
| 25 | completed | 1 | 97.26 | 0.78 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/f6680535-374b-44cd-8941-bd39831f9af8/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/f6680535-374b-44cd-8941-bd39831f9af8/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/f6680535-374b-44cd-8941-bd39831f9af8/agent/trajectory.jsonl) |
| 26 | completed | 1 | 166.63 | 0.87 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/cf6a3d16-0e69-4792-846e-11b15fe58a5a/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/cf6a3d16-0e69-4792-846e-11b15fe58a5a/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/cf6a3d16-0e69-4792-846e-11b15fe58a5a/agent/trajectory.jsonl) |
| 27 | completed | 1 | 254.20 | 1.10 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/b567018c-af6f-4ad2-b3b7-6a230d4ee4ec/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/b567018c-af6f-4ad2-b3b7-6a230d4ee4ec/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/b567018c-af6f-4ad2-b3b7-6a230d4ee4ec/agent/trajectory.jsonl) |
| 28 | completed | 0 | 189.82 | 0.86 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/232b132f-d940-467e-a38e-ef35c252ec10/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/232b132f-d940-467e-a38e-ef35c252ec10/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/232b132f-d940-467e-a38e-ef35c252ec10/agent/trajectory.jsonl) |
| 29 | completed | 1 | 431.00 | 0.86 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/dd3cd024-e954-4b89-ae90-cdd5e9693f33/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/dd3cd024-e954-4b89-ae90-cdd5e9693f33/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/dd3cd024-e954-4b89-ae90-cdd5e9693f33/agent/trajectory.jsonl) |
| 30 | completed | 0 | 52.19 | 1.08 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/a01a8903-cee6-482e-9fd5-101886abe16b/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/a01a8903-cee6-482e-9fd5-101886abe16b/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/a01a8903-cee6-482e-9fd5-101886abe16b/agent/trajectory.jsonl) |
| 31 | completed | 1 | 43.78 | 0.89 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/0c625d93-beda-42c6-9c31-97fc4d6df3a8/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/0c625d93-beda-42c6-9c31-97fc4d6df3a8/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/0c625d93-beda-42c6-9c31-97fc4d6df3a8/agent/trajectory.jsonl) |
| 32 | completed | 1 | 172.50 | 0.84 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/f4de7f69-5684-45c6-a5bf-1f7ec0722b37/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/f4de7f69-5684-45c6-a5bf-1f7ec0722b37/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/f4de7f69-5684-45c6-a5bf-1f7ec0722b37/agent/trajectory.jsonl) |
| 33 | completed | 1 | 405.97 | 0.93 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/8ce71aa2-abbe-4f8a-82d1-ff540844f05f/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/8ce71aa2-abbe-4f8a-82d1-ff540844f05f/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/8ce71aa2-abbe-4f8a-82d1-ff540844f05f/agent/trajectory.jsonl) |
| 34 | completed | 0 | 335.96 | 1.05 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/341af499-ae46-4363-b018-2e77668cb0ee/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/341af499-ae46-4363-b018-2e77668cb0ee/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/341af499-ae46-4363-b018-2e77668cb0ee/agent/trajectory.jsonl) |
| 35 | completed | 1 | 147.23 | 0.89 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/db163ec4-edb5-4a54-a07d-7a2526c74291/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/db163ec4-edb5-4a54-a07d-7a2526c74291/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/db163ec4-edb5-4a54-a07d-7a2526c74291/agent/trajectory.jsonl) |
| 36 | completed | 0 | 426.24 | 0.88 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/f8774ff9-f6af-452d-bf30-070c94b72a86/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/f8774ff9-f6af-452d-bf30-070c94b72a86/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/f8774ff9-f6af-452d-bf30-070c94b72a86/agent/trajectory.jsonl) |
| 37 | completed | 1 | 91.38 | 0.83 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/1d662dd9-88d5-4123-85aa-a26a56372cd4/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/1d662dd9-88d5-4123-85aa-a26a56372cd4/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/1d662dd9-88d5-4123-85aa-a26a56372cd4/agent/trajectory.jsonl) |
| 38 | completed | 0 | 291.48 | 1.12 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/47d9bab7-4d73-4d50-9961-552fdd8f0172/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/47d9bab7-4d73-4d50-9961-552fdd8f0172/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/47d9bab7-4d73-4d50-9961-552fdd8f0172/agent/trajectory.jsonl) |
| 39 | completed | 1 | 122.46 | 0.89 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/d119db8e-5ddd-4bf5-b78b-04039be1db31/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/d119db8e-5ddd-4bf5-b78b-04039be1db31/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/d119db8e-5ddd-4bf5-b78b-04039be1db31/agent/trajectory.jsonl) |
| 40 | completed | 0 | 82.36 | 0.90 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/cafd23d6-b54d-4e34-8973-759694c52f3c/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/cafd23d6-b54d-4e34-8973-759694c52f3c/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/cafd23d6-b54d-4e34-8973-759694c52f3c/agent/trajectory.jsonl) |
| 41 | completed | 0 | 598.55 | 0.85 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/b79a1da5-7712-4522-bf49-4832654e095b/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/b79a1da5-7712-4522-bf49-4832654e095b/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/b79a1da5-7712-4522-bf49-4832654e095b/agent/trajectory.jsonl) |
| 42 | completed | 0 | 75.86 | 0.84 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/f341945d-b078-4155-ab5c-d5a9dc78c076/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/f341945d-b078-4155-ab5c-d5a9dc78c076/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/f341945d-b078-4155-ab5c-d5a9dc78c076/agent/trajectory.jsonl) |
| 43 | completed | 1 | 226.79 | 0.76 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/e739b22a-7bd2-4cd0-b826-12347f8773d2/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/e739b22a-7bd2-4cd0-b826-12347f8773d2/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/e739b22a-7bd2-4cd0-b826-12347f8773d2/agent/trajectory.jsonl) |
| 44 | completed | 0 | 185.83 | 0.68 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/e37165ce-ed1c-415a-91d0-28d01c2e42d9/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/e37165ce-ed1c-415a-91d0-28d01c2e42d9/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/e37165ce-ed1c-415a-91d0-28d01c2e42d9/agent/trajectory.jsonl) |
| 45 | completed | 0 | 473.74 | 0.79 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/e3e9e889-1a13-48a7-917b-a22919798061/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/e3e9e889-1a13-48a7-917b-a22919798061/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/e3e9e889-1a13-48a7-917b-a22919798061/agent/trajectory.jsonl) |
| 46 | cancelled | — | 304.20 | — | partial / complete | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/fe82a51e-ad0c-44af-9729-350d47a7992b/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/fe82a51e-ad0c-44af-9729-350d47a7992b/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/fe82a51e-ad0c-44af-9729-350d47a7992b/agent/trajectory.jsonl) |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

