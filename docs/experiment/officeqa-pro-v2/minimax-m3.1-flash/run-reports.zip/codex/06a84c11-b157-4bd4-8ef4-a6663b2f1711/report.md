<!-- snapshotDigest: eb08c54e5beb3845afc2ef92eda3eb40cd09b9d62d73adc336c42df2e5fc59d7 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 32.58%（29/89）**

Run: 06a84c11-b157-4bd4-8ef4-a6663b2f1711 · Status: cancelled

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-19T15:48:40.771Z / 2026-11-20T01:47:49.110Z |
| 总耗时 | 9 小时 59 分 8 秒 |
| 答对 / 答错 / 解题超时 | 29 / 16 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 46 条记录；待运行 45 题。
有效评分覆盖率：45/90（50.00%）。
执行失败 0；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 45 |
| 答对题数 | 29 |
| 无效评测 | 1 |
| 待运行 | 45 |
| 正确率 | 32.58% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 59 分 8 秒 |
| 环境准备耗时 | 9 小时 58 分 48 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 4 分 49 秒 | 27 秒 | 33 分 26 秒 | 46 |
| 任务准备 | 0.34 毫秒 | 0.2 毫秒 | 0.82 毫秒 | 46 |
| 环境启动 | 5 秒 | 3 秒 | 8 秒 | 46 |
| 解题 | 4 分 39 秒 | 16 秒 | 33 分 11 秒 | 46 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 45 |
| 证据收集 | 1 秒 | 829.22 毫秒 | 4 秒 | 46 |
| 资源清理 | 3 秒 | 2 秒 | 5 秒 | 46 |
| 评分 | 854.84 毫秒 | 665.12 毫秒 | 1 秒 | 45 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| d2409d4e-0318-422d-8f26-db0fe9301ea7 | 14,400 | 3600 | 2 | 2 | 7200 |
| 2fd5cfcd-c0a0-4c02-a88d-459f81731e55 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 101,442,267 | 1,078,753 | 102,521,020 | 45 / 90 | — |
| 运行累计 | 101,442,267 | 1,078,753 | 102,521,020 | 45 / 47 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 184.43 | 1.49 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/338c3dfc-3153-43e8-b19e-00c4ae58ded1/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/338c3dfc-3153-43e8-b19e-00c4ae58ded1/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/338c3dfc-3153-43e8-b19e-00c4ae58ded1/agent/trajectory.jsonl) |
| 1 | completed | 1 | 164.19 | 1.10 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/2a8876dc-0319-402f-bacb-e5d6a1868f00/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/2a8876dc-0319-402f-bacb-e5d6a1868f00/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/2a8876dc-0319-402f-bacb-e5d6a1868f00/agent/trajectory.jsonl) |
| 2 | completed | 1 | 1990.51 | 0.89 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/7005cb35-c915-4b5a-8a6a-ea43b62bc02c/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/7005cb35-c915-4b5a-8a6a-ea43b62bc02c/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/7005cb35-c915-4b5a-8a6a-ea43b62bc02c/agent/trajectory.jsonl) |
| 3 | completed | 1 | 157.89 | 0.67 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/2e219542-15c5-4360-a48d-be4066318d2f/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/2e219542-15c5-4360-a48d-be4066318d2f/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/2e219542-15c5-4360-a48d-be4066318d2f/agent/trajectory.jsonl) |
| 4 | completed | 1 | 31.09 | 0.88 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/27e47427-ef03-46ab-86e8-1d90a68be0c5/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/27e47427-ef03-46ab-86e8-1d90a68be0c5/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/27e47427-ef03-46ab-86e8-1d90a68be0c5/agent/trajectory.jsonl) |
| 5 | completed | 1 | 165.85 | 0.91 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/5d105c30-a61c-4136-9fa1-1508ee4d2a8d/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/5d105c30-a61c-4136-9fa1-1508ee4d2a8d/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/5d105c30-a61c-4136-9fa1-1508ee4d2a8d/agent/trajectory.jsonl) |
| 6 | completed | 1 | 147.35 | 0.86 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/795883db-ad50-48cd-bb2a-87154cdaab35/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/795883db-ad50-48cd-bb2a-87154cdaab35/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/795883db-ad50-48cd-bb2a-87154cdaab35/agent/trajectory.jsonl) |
| 7 | completed | 1 | 46.90 | 0.92 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/5b2f977e-05c6-45cf-8156-cf8d82d5dc2d/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/5b2f977e-05c6-45cf-8156-cf8d82d5dc2d/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/5b2f977e-05c6-45cf-8156-cf8d82d5dc2d/agent/trajectory.jsonl) |
| 8 | completed | 0 | 44.97 | 0.79 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/b9b2ad3d-fddd-4551-b0b2-8fdac09b683e/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/b9b2ad3d-fddd-4551-b0b2-8fdac09b683e/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/b9b2ad3d-fddd-4551-b0b2-8fdac09b683e/agent/trajectory.jsonl) |
| 9 | completed | 1 | 19.86 | 0.77 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/4ad2a926-cbc8-4021-863f-cffa49828342/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/4ad2a926-cbc8-4021-863f-cffa49828342/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/4ad2a926-cbc8-4021-863f-cffa49828342/agent/trajectory.jsonl) |
| 10 | completed | 1 | 51.65 | 0.83 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/6e8353eb-7e92-4f0f-baac-0b10c6670227/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/6e8353eb-7e92-4f0f-baac-0b10c6670227/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/6e8353eb-7e92-4f0f-baac-0b10c6670227/agent/trajectory.jsonl) |
| 11 | completed | 1 | 810.63 | 0.75 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/a02510ae-ad97-4946-b087-a4c845492eb5/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/a02510ae-ad97-4946-b087-a4c845492eb5/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/a02510ae-ad97-4946-b087-a4c845492eb5/agent/trajectory.jsonl) |
| 12 | completed | 1 | 71.12 | 0.83 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/c787eadf-d8cb-4dd3-8eaa-f14f221aee96/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/c787eadf-d8cb-4dd3-8eaa-f14f221aee96/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/c787eadf-d8cb-4dd3-8eaa-f14f221aee96/agent/trajectory.jsonl) |
| 13 | completed | 1 | 312.03 | 0.69 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/063a253c-4c9f-407f-9ceb-90fd39fc5b26/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/063a253c-4c9f-407f-9ceb-90fd39fc5b26/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/063a253c-4c9f-407f-9ceb-90fd39fc5b26/agent/trajectory.jsonl) |
| 14 | completed | 0 | 39.65 | 0.72 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/fd44af16-516f-43f5-ad62-adc06a3bc7d7/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/fd44af16-516f-43f5-ad62-adc06a3bc7d7/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/fd44af16-516f-43f5-ad62-adc06a3bc7d7/agent/trajectory.jsonl) |
| 15 | completed | 0 | 1012.12 | 0.88 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/baa61854-4ba1-4a6b-ae11-defe06b754d1/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/baa61854-4ba1-4a6b-ae11-defe06b754d1/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/baa61854-4ba1-4a6b-ae11-defe06b754d1/agent/trajectory.jsonl) |
| 16 | completed | 1 | 246.74 | 0.78 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/26cb567b-b13a-478c-ac9f-bd3ef99b3c78/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/26cb567b-b13a-478c-ac9f-bd3ef99b3c78/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/26cb567b-b13a-478c-ac9f-bd3ef99b3c78/agent/trajectory.jsonl) |
| 17 | completed | 1 | 149.63 | 0.84 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/d822e34e-deae-490c-901f-658af9de8675/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/d822e34e-deae-490c-901f-658af9de8675/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/d822e34e-deae-490c-901f-658af9de8675/agent/trajectory.jsonl) |
| 18 | completed | 1 | 123.16 | 0.79 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/451a45b6-f0ca-4f96-acb8-f83e955358c5/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/451a45b6-f0ca-4f96-acb8-f83e955358c5/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/451a45b6-f0ca-4f96-acb8-f83e955358c5/agent/trajectory.jsonl) |
| 19 | completed | 1 | 85.91 | 1.00 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/e3d9fa70-4950-4c2b-888d-d7cdba517001/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/e3d9fa70-4950-4c2b-888d-d7cdba517001/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/e3d9fa70-4950-4c2b-888d-d7cdba517001/agent/trajectory.jsonl) |
| 20 | completed | 0 | 411.63 | 0.84 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/eb2430a4-cd87-4108-9b0f-1a212b1693dd/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/eb2430a4-cd87-4108-9b0f-1a212b1693dd/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/eb2430a4-cd87-4108-9b0f-1a212b1693dd/agent/trajectory.jsonl) |
| 21 | completed | 1 | 103.37 | 0.93 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/af9d9ddf-976f-42b7-a512-258ac0b7afce/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/af9d9ddf-976f-42b7-a512-258ac0b7afce/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/af9d9ddf-976f-42b7-a512-258ac0b7afce/agent/trajectory.jsonl) |
| 22 | completed | 1 | 231.86 | 0.93 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/f53482e9-740c-4dd7-9142-23fa5de831b7/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/f53482e9-740c-4dd7-9142-23fa5de831b7/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/f53482e9-740c-4dd7-9142-23fa5de831b7/agent/trajectory.jsonl) |
| 23 | completed | 0 | 581.94 | 0.91 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/e0ed8177-9520-45c8-8017-8104aedd1a0b/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/e0ed8177-9520-45c8-8017-8104aedd1a0b/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/e0ed8177-9520-45c8-8017-8104aedd1a0b/agent/trajectory.jsonl) |
| 24 | completed | 1 | 100.68 | 0.83 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/b64ea90e-8e15-42c2-a210-8d2aa36d4203/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/b64ea90e-8e15-42c2-a210-8d2aa36d4203/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/b64ea90e-8e15-42c2-a210-8d2aa36d4203/agent/trajectory.jsonl) |
| 25 | completed | 1 | 572.84 | 0.78 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/d6a39a7e-d054-48f8-9bb6-96a1d417f843/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/d6a39a7e-d054-48f8-9bb6-96a1d417f843/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/d6a39a7e-d054-48f8-9bb6-96a1d417f843/agent/trajectory.jsonl) |
| 26 | completed | 1 | 107.51 | 0.88 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/33b32cc5-f449-4507-a036-3bb36b3cf1f6/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/33b32cc5-f449-4507-a036-3bb36b3cf1f6/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/33b32cc5-f449-4507-a036-3bb36b3cf1f6/agent/trajectory.jsonl) |
| 27 | completed | 1 | 407.57 | 0.83 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/ea159ce0-b525-48a2-a90a-22264fbec9cd/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/ea159ce0-b525-48a2-a90a-22264fbec9cd/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/ea159ce0-b525-48a2-a90a-22264fbec9cd/agent/trajectory.jsonl) |
| 28 | completed | 0 | 321.76 | 1.10 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/4900a1bf-d75c-4973-b9b0-54201ecbead9/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/4900a1bf-d75c-4973-b9b0-54201ecbead9/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/4900a1bf-d75c-4973-b9b0-54201ecbead9/agent/trajectory.jsonl) |
| 29 | completed | 0 | 515.53 | 0.96 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/4a057b16-4235-44c4-8c74-3ce8739966cf/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/4a057b16-4235-44c4-8c74-3ce8739966cf/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/4a057b16-4235-44c4-8c74-3ce8739966cf/agent/trajectory.jsonl) |
| 30 | completed | 0 | 156.21 | 0.86 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/57b30821-7163-4fac-b441-f9a1c569b2f2/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/57b30821-7163-4fac-b441-f9a1c569b2f2/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/57b30821-7163-4fac-b441-f9a1c569b2f2/agent/trajectory.jsonl) |
| 31 | completed | 1 | 16.39 | 0.82 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/dff6b629-25f5-447c-8a46-678605a88741/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/dff6b629-25f5-447c-8a46-678605a88741/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/dff6b629-25f5-447c-8a46-678605a88741/agent/trajectory.jsonl) |
| 32 | completed | 1 | 316.09 | 0.76 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/bc1fa1bb-b007-4742-8b90-5d9449d6a10c/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/bc1fa1bb-b007-4742-8b90-5d9449d6a10c/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/bc1fa1bb-b007-4742-8b90-5d9449d6a10c/agent/trajectory.jsonl) |
| 33 | completed | 1 | 341.28 | 0.72 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/37e2f3ea-2b3c-4ce8-bdfa-e22ce7756e33/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/37e2f3ea-2b3c-4ce8-bdfa-e22ce7756e33/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/37e2f3ea-2b3c-4ce8-bdfa-e22ce7756e33/agent/trajectory.jsonl) |
| 34 | completed | 0 | 394.47 | 0.71 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/b294d6db-dae7-46ea-a0fe-101d481e0c5c/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/b294d6db-dae7-46ea-a0fe-101d481e0c5c/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/b294d6db-dae7-46ea-a0fe-101d481e0c5c/agent/trajectory.jsonl) |
| 35 | completed | 1 | 137.41 | 0.75 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/42a643d8-d681-4c28-8fb3-f36d3cfc0f91/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/42a643d8-d681-4c28-8fb3-f36d3cfc0f91/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/42a643d8-d681-4c28-8fb3-f36d3cfc0f91/agent/trajectory.jsonl) |
| 36 | completed | 0 | 606.05 | 0.76 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/ab8d6e21-f49f-40f7-98d2-7b2afb8d2891/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/ab8d6e21-f49f-40f7-98d2-7b2afb8d2891/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/ab8d6e21-f49f-40f7-98d2-7b2afb8d2891/agent/trajectory.jsonl) |
| 37 | completed | 1 | 158.84 | 0.69 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/9c887cba-3de8-49f2-ba5b-679ac34b6eec/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/9c887cba-3de8-49f2-ba5b-679ac34b6eec/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/9c887cba-3de8-49f2-ba5b-679ac34b6eec/agent/trajectory.jsonl) |
| 38 | completed | 0 | 495.27 | 0.93 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/6ef8801f-be3b-4b06-b33a-ac82a3193e45/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/6ef8801f-be3b-4b06-b33a-ac82a3193e45/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/6ef8801f-be3b-4b06-b33a-ac82a3193e45/agent/trajectory.jsonl) |
| 39 | completed | 1 | 107.79 | 0.75 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/18138f3e-fe78-4ddc-942f-f9345672b540/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/18138f3e-fe78-4ddc-942f-f9345672b540/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/18138f3e-fe78-4ddc-942f-f9345672b540/agent/trajectory.jsonl) |
| 40 | completed | 0 | 44.28 | 0.71 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/934bf622-5558-4094-b073-df27fb412450/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/934bf622-5558-4094-b073-df27fb412450/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/934bf622-5558-4094-b073-df27fb412450/agent/trajectory.jsonl) |
| 41 | completed | 0 | 117.76 | 0.72 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/dbd4127c-92ba-4159-add8-1a34dd522aa7/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/dbd4127c-92ba-4159-add8-1a34dd522aa7/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/dbd4127c-92ba-4159-add8-1a34dd522aa7/agent/trajectory.jsonl) |
| 42 | completed | 0 | 64.27 | 0.90 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/188f18e6-6551-4035-b518-9a22ca69093c/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/188f18e6-6551-4035-b518-9a22ca69093c/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/188f18e6-6551-4035-b518-9a22ca69093c/agent/trajectory.jsonl) |
| 43 | completed | 0 | 244.86 | 1.02 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/2aa330ee-59b4-43ce-80c3-777913a98208/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/2aa330ee-59b4-43ce-80c3-777913a98208/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/2aa330ee-59b4-43ce-80c3-777913a98208/agent/trajectory.jsonl) |
| 44 | completed | 0 | 266.31 | 0.97 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/2e562ac6-15a1-4f1d-a9ff-a5de7793b81b/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/2e562ac6-15a1-4f1d-a9ff-a5de7793b81b/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/2e562ac6-15a1-4f1d-a9ff-a5de7793b81b/agent/trajectory.jsonl) |
| 45 | pending | — | — | — | — | — | — |
| 46 | cancelled | — | 149.96 | — | partial / complete | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/5f0afa9f-dfe1-46ff-91d9-31b16b3982eb/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/5f0afa9f-dfe1-46ff-91d9-31b16b3982eb/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/5f0afa9f-dfe1-46ff-91d9-31b16b3982eb/agent/trajectory.jsonl) |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

