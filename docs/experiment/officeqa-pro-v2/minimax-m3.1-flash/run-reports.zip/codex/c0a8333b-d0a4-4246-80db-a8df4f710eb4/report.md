<!-- snapshotDigest: 5156d6aa901186c2927c9f0bcdcafd6c83a9b13a6a576ed5303a712870664fba -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 31.82%（14/44）**

Run: c0a8333b-d0a4-4246-80db-a8df4f710eb4 · Status: error

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | codex |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-20T01:58:10.100Z / 2026-11-20T11:49:46.891Z |
| 总耗时 | 9 小时 51 分 37 秒 |
| 答对 / 答错 / 解题超时 | 14 / 30 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 45 题；已保存 45 条记录；待运行 0 题。
有效评分覆盖率：44/45（97.78%）。
执行失败 1；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 45 |
| 计分题数 | 44 |
| 正常评分题数 | 44 |
| 答对题数 | 14 |
| 无效评测 | 1 |
| 待运行 | 0 |
| 正确率 | 31.82% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 51 分 37 秒 |
| 环境准备耗时 | 7 小时 29 分 31 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 10 分 7 秒 | 57 秒 | 51 分 43 秒 | 45 |
| 任务准备 | 0.34 毫秒 | 0.15 毫秒 | 0.78 毫秒 | 45 |
| 环境启动 | 5 秒 | 3 秒 | 11 秒 | 45 |
| 解题 | 9 分 55 秒 | 48 秒 | 51 分 33 秒 | 45 |
| 产物传输 | 1 秒 | 1 秒 | 3 秒 | 44 |
| 证据收集 | 1 秒 | 887.64 毫秒 | 2 秒 | 45 |
| 资源清理 | 3 秒 | 2 秒 | 9 秒 | 45 |
| 评分 | 932.33 毫秒 | 712.7 毫秒 | 2 秒 | 44 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 8ad81f2e-6359-44c6-9c27-d06c429ca720 | 14,400 | 3600 | 2 | 2 | 7200 |
| 9c3fcc76-c34c-41cc-95bd-1aa90a6bdd1d | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 119,673,131 | 1,372,340 | 121,045,471 | 44 / 45 | — |
| 运行累计 | 119,673,131 | 1,372,340 | 121,045,471 | 44 / 46 | 2 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 45 | completed | 0 | 2446.86 | 0.81 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/76041fda-3bd1-4e2d-bdb5-b89d254a43d5/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/76041fda-3bd1-4e2d-bdb5-b89d254a43d5/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/76041fda-3bd1-4e2d-bdb5-b89d254a43d5/agent/trajectory.jsonl) |
| 46 | completed | 1 | 2032.23 | 0.92 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/5e211daf-5767-4b42-b9a4-82ad3aa99b5c/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/5e211daf-5767-4b42-b9a4-82ad3aa99b5c/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/5e211daf-5767-4b42-b9a4-82ad3aa99b5c/agent/trajectory.jsonl) |
| 47 | completed | 0 | 64.55 | 0.88 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/a75fe235-a4e7-4618-8caf-af9ef35674ed/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/a75fe235-a4e7-4618-8caf-af9ef35674ed/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/a75fe235-a4e7-4618-8caf-af9ef35674ed/agent/trajectory.jsonl) |
| 48 | completed | 1 | 119.23 | 0.85 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/2d150f7a-bde8-4fe4-b034-5a9881bdabd4/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/2d150f7a-bde8-4fe4-b034-5a9881bdabd4/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/2d150f7a-bde8-4fe4-b034-5a9881bdabd4/agent/trajectory.jsonl) |
| 49 | completed | 0 | 110.30 | 0.86 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/ea277672-62b8-4707-a638-56a44216493a/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/ea277672-62b8-4707-a638-56a44216493a/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/ea277672-62b8-4707-a638-56a44216493a/agent/trajectory.jsonl) |
| 50 | completed | 0 | 618.22 | 0.93 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/360ff3a2-dfb3-4e64-afd5-9c20d46b6b09/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/360ff3a2-dfb3-4e64-afd5-9c20d46b6b09/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/360ff3a2-dfb3-4e64-afd5-9c20d46b6b09/agent/trajectory.jsonl) |
| 51 | completed | 0 | 830.63 | 0.82 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/98c2d0f1-4f86-4ec4-8eb9-2d62cd177a5e/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/98c2d0f1-4f86-4ec4-8eb9-2d62cd177a5e/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/98c2d0f1-4f86-4ec4-8eb9-2d62cd177a5e/agent/trajectory.jsonl) |
| 52 | completed | 0 | 89.31 | 0.90 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/88eba44b-cf26-455d-91b3-b69cffa91622/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/88eba44b-cf26-455d-91b3-b69cffa91622/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/88eba44b-cf26-455d-91b3-b69cffa91622/agent/trajectory.jsonl) |
| 53 | completed | 1 | 1075.04 | 0.91 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/39f56acc-113c-4adf-b965-77bde8f78033/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/39f56acc-113c-4adf-b965-77bde8f78033/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/39f56acc-113c-4adf-b965-77bde8f78033/agent/trajectory.jsonl) |
| 54 | completed | 1 | 1590.35 | 0.99 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/3cd1adad-dd93-4b8e-b9a3-17bed22e6649/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/3cd1adad-dd93-4b8e-b9a3-17bed22e6649/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/3cd1adad-dd93-4b8e-b9a3-17bed22e6649/agent/trajectory.jsonl) |
| 55 | completed | 1 | 123.81 | 1.39 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/56ffd8bc-5232-476c-b479-ee8b751bdf14/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/56ffd8bc-5232-476c-b479-ee8b751bdf14/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/56ffd8bc-5232-476c-b479-ee8b751bdf14/agent/trajectory.jsonl) |
| 56 | completed | 1 | 584.54 | 1.20 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/d37ca034-0b3c-4395-a444-f9c81c461143/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/d37ca034-0b3c-4395-a444-f9c81c461143/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/d37ca034-0b3c-4395-a444-f9c81c461143/agent/trajectory.jsonl) |
| 57 | completed | 0 | 180.34 | 1.12 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/aba8acef-437d-4e82-b36c-4a1566058a38/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/aba8acef-437d-4e82-b36c-4a1566058a38/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/aba8acef-437d-4e82-b36c-4a1566058a38/agent/trajectory.jsonl) |
| 58 | completed | 1 | 2310.86 | 1.07 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/0029662d-3c07-4864-b02b-67190ad24003/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/0029662d-3c07-4864-b02b-67190ad24003/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/0029662d-3c07-4864-b02b-67190ad24003/agent/trajectory.jsonl) |
| 59 | completed | 0 | 387.47 | 1.34 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/a90fabb5-6fc5-4ef5-bc49-30d431fec4a9/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/a90fabb5-6fc5-4ef5-bc49-30d431fec4a9/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/a90fabb5-6fc5-4ef5-bc49-30d431fec4a9/agent/trajectory.jsonl) |
| 60 | completed | 1 | 417.22 | 1.53 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/a3afdb94-15b7-4f46-9e13-3627c84c7620/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/a3afdb94-15b7-4f46-9e13-3627c84c7620/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/a3afdb94-15b7-4f46-9e13-3627c84c7620/agent/trajectory.jsonl) |
| 61 | completed | 0 | 987.53 | 1.02 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/ec5e1143-e52a-4277-b715-7987c588d095/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/ec5e1143-e52a-4277-b715-7987c588d095/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/ec5e1143-e52a-4277-b715-7987c588d095/agent/trajectory.jsonl) |
| 62 | completed | 0 | 1273.56 | 1.76 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/2cabdce4-0dba-4d5f-8d9e-eed9d8bfdbc3/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/2cabdce4-0dba-4d5f-8d9e-eed9d8bfdbc3/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/2cabdce4-0dba-4d5f-8d9e-eed9d8bfdbc3/agent/trajectory.jsonl) |
| 63 | completed | 1 | 335.08 | 0.90 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/02f0ac35-2123-47ab-9d53-5e16a8fc60bd/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/02f0ac35-2123-47ab-9d53-5e16a8fc60bd/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/02f0ac35-2123-47ab-9d53-5e16a8fc60bd/agent/trajectory.jsonl) |
| 64 | completed | 1 | 395.02 | 1.73 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/2b0e0516-53fe-4208-adf4-7cd02877e97e/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/2b0e0516-53fe-4208-adf4-7cd02877e97e/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/2b0e0516-53fe-4208-adf4-7cd02877e97e/agent/trajectory.jsonl) |
| 65 | completed | 0 | 646.75 | 0.86 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/173ba2a1-ef6f-4b38-a90a-05c767a00140/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/173ba2a1-ef6f-4b38-a90a-05c767a00140/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/173ba2a1-ef6f-4b38-a90a-05c767a00140/agent/trajectory.jsonl) |
| 66 | completed | 1 | 431.80 | 0.87 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/86bc8fc5-c593-4b8d-a3eb-e292b6b0ba34/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/86bc8fc5-c593-4b8d-a3eb-e292b6b0ba34/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/86bc8fc5-c593-4b8d-a3eb-e292b6b0ba34/agent/trajectory.jsonl) |
| 67 | invalid | — | 3093.49 | — | partial / complete | SOLVER\_RESULT\_INCOMPLETE; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/9d99d1e0-3f23-47d3-b079-3cab624ee299/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/9d99d1e0-3f23-47d3-b079-3cab624ee299/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/9d99d1e0-3f23-47d3-b079-3cab624ee299/agent/trajectory.jsonl) |
| 68 | completed | 1 | 275.64 | 0.96 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/904f5f1e-8065-4f3d-8b09-29ce2e2dbacc/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/904f5f1e-8065-4f3d-8b09-29ce2e2dbacc/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/904f5f1e-8065-4f3d-8b09-29ce2e2dbacc/agent/trajectory.jsonl) |
| 69 | completed | 0 | 154.26 | 0.73 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/463f25f7-ed1d-48e0-961a-75f6c587d146/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/463f25f7-ed1d-48e0-961a-75f6c587d146/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/463f25f7-ed1d-48e0-961a-75f6c587d146/agent/trajectory.jsonl) |
| 70 | completed | 0 | 245.42 | 0.75 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/d0ceddbd-45c7-4fb0-88ac-3295a417ceae/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/d0ceddbd-45c7-4fb0-88ac-3295a417ceae/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/d0ceddbd-45c7-4fb0-88ac-3295a417ceae/agent/trajectory.jsonl) |
| 71 | completed | 0 | 85.28 | 0.79 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/ef5e5423-a961-4b7e-ba82-f5697ec057d6/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/ef5e5423-a961-4b7e-ba82-f5697ec057d6/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/ef5e5423-a961-4b7e-ba82-f5697ec057d6/agent/trajectory.jsonl) |
| 72 | completed | 0 | 912.50 | 0.76 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/2b9c65f0-01b8-41fd-b81d-68d5e0269a78/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/2b9c65f0-01b8-41fd-b81d-68d5e0269a78/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/2b9c65f0-01b8-41fd-b81d-68d5e0269a78/agent/trajectory.jsonl) |
| 73 | completed | 1 | 233.41 | 1.09 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/e2cbaab3-52ba-4bfa-9155-dd8b3dda0689/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/e2cbaab3-52ba-4bfa-9155-dd8b3dda0689/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/e2cbaab3-52ba-4bfa-9155-dd8b3dda0689/agent/trajectory.jsonl) |
| 74 | completed | 0 | 135.46 | 0.74 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/0ec7331e-4df5-4406-b344-415d5b562827/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/0ec7331e-4df5-4406-b344-415d5b562827/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/0ec7331e-4df5-4406-b344-415d5b562827/agent/trajectory.jsonl) |
| 75 | completed | 0 | 48.00 | 0.76 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/5b598dd3-a787-4613-bc2d-7d5a36b890de/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/5b598dd3-a787-4613-bc2d-7d5a36b890de/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/5b598dd3-a787-4613-bc2d-7d5a36b890de/agent/trajectory.jsonl) |
| 76 | completed | 0 | 48.18 | 0.73 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/65488e4d-e801-4149-abeb-b206f80c2e35/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/65488e4d-e801-4149-abeb-b206f80c2e35/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/65488e4d-e801-4149-abeb-b206f80c2e35/agent/trajectory.jsonl) |
| 77 | completed | 0 | 1556.17 | 0.74 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/9c042705-f7e2-47fb-9610-40cd0b60a779/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/9c042705-f7e2-47fb-9610-40cd0b60a779/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/9c042705-f7e2-47fb-9610-40cd0b60a779/agent/trajectory.jsonl) |
| 78 | completed | 0 | 70.05 | 0.74 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/f7f9a5e7-8b68-4f52-a2a8-4475d7d0a939/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/f7f9a5e7-8b68-4f52-a2a8-4475d7d0a939/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/f7f9a5e7-8b68-4f52-a2a8-4475d7d0a939/agent/trajectory.jsonl) |
| 79 | completed | 1 | 83.86 | 0.71 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/b850fdc9-c03c-43ba-9811-887ffa0c40ef/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/b850fdc9-c03c-43ba-9811-887ffa0c40ef/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/b850fdc9-c03c-43ba-9811-887ffa0c40ef/agent/trajectory.jsonl) |
| 80 | completed | 0 | 472.24 | 0.82 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/2de98a30-e315-46b7-9de2-978b0d6ab463/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/2de98a30-e315-46b7-9de2-978b0d6ab463/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/2de98a30-e315-46b7-9de2-978b0d6ab463/agent/trajectory.jsonl) |
| 81 | completed | 0 | 356.79 | 0.75 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/eb62b63c-ccea-40c9-9c9d-f9754d93f888/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/eb62b63c-ccea-40c9-9c9d-f9754d93f888/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/eb62b63c-ccea-40c9-9c9d-f9754d93f888/agent/trajectory.jsonl) |
| 82 | completed | 0 | 179.66 | 0.75 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/b10adc6b-3b6d-4b5b-afe0-3b389eb47d1c/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/b10adc6b-3b6d-4b5b-afe0-3b389eb47d1c/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/b10adc6b-3b6d-4b5b-afe0-3b389eb47d1c/agent/trajectory.jsonl) |
| 83 | completed | 0 | 148.42 | 0.78 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/4d4bf081-f808-45ba-b305-5769d63a80f7/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/4d4bf081-f808-45ba-b305-5769d63a80f7/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/4d4bf081-f808-45ba-b305-5769d63a80f7/agent/trajectory.jsonl) |
| 84 | completed | 0 | 230.61 | 0.82 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/816c6b7c-e61b-4639-9b29-c2111bef7f58/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/816c6b7c-e61b-4639-9b29-c2111bef7f58/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/816c6b7c-e61b-4639-9b29-c2111bef7f58/agent/trajectory.jsonl) |
| 85 | completed | 0 | 536.26 | 0.79 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/e5b43c01-1e1f-42cb-aca1-556440a4534e/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/e5b43c01-1e1f-42cb-aca1-556440a4534e/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/e5b43c01-1e1f-42cb-aca1-556440a4534e/agent/trajectory.jsonl) |
| 86 | completed | 0 | 282.70 | 0.81 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/ca2d88bb-e33f-4ea6-8590-a06a8949378d/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/ca2d88bb-e33f-4ea6-8590-a06a8949378d/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/ca2d88bb-e33f-4ea6-8590-a06a8949378d/agent/trajectory.jsonl) |
| 87 | completed | 0 | 135.80 | 0.75 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/66a75bee-beaa-48ae-8bc8-98a544085437/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/66a75bee-beaa-48ae-8bc8-98a544085437/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/66a75bee-beaa-48ae-8bc8-98a544085437/agent/trajectory.jsonl) |
| 88 | completed | 0 | 232.28 | 0.78 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/2c8ae8fb-d2d1-46c7-89dc-9b58e304894e/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/2c8ae8fb-d2d1-46c7-89dc-9b58e304894e/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/2c8ae8fb-d2d1-46c7-89dc-9b58e304894e/agent/trajectory.jsonl) |
| 89 | completed | 0 | 228.46 | 0.77 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/51f1fc63-4fbd-45ee-b022-1031543d67c0/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/51f1fc63-4fbd-45ee-b022-1031543d67c0/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/51f1fc63-4fbd-45ee-b022-1031543d67c0/agent/trajectory.jsonl) |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | SOLVER_RESULT_INCOMPLETE | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

