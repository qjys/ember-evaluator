<!-- snapshotDigest: 29ea59ca2254ce3f43de07c3b909d211f13d3bb3d434124607173e599b4b1134 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 24.72%（22/89）**

Run: 75a6b2c5-0d45-4dc4-892b-c0fe27f85d32 · Status: cancelled

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | claudecode |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-19T15:49:25.741Z / 2026-11-20T01:47:50.851Z |
| 总耗时 | 9 小时 58 分 25 秒 |
| 答对 / 答错 / 解题超时 | 22 / 15 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 38 条记录；待运行 53 题。
有效评分覆盖率：37/90（41.11%）。
执行失败 0；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 37 |
| 答对题数 | 22 |
| 无效评测 | 1 |
| 待运行 | 53 |
| 正确率 | 24.72% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 58 分 25 秒 |
| 环境准备耗时 | 9 小时 58 分 2 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 5 分 51 秒 | 34 秒 | 59 分 41 秒 | 38 |
| 任务准备 | 0.35 毫秒 | 0.18 毫秒 | 0.71 毫秒 | 38 |
| 环境启动 | 5 秒 | 3 秒 | 9 秒 | 38 |
| 解题 | 5 分 39 秒 | 20 秒 | 59 分 31 秒 | 38 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 37 |
| 证据收集 | 1 秒 | 885.39 毫秒 | 4 秒 | 38 |
| 资源清理 | 3 秒 | 2 秒 | 22 秒 | 38 |
| 评分 | 866.52 毫秒 | 662.14 毫秒 | 1 秒 | 37 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| f7e94783-5cad-4a51-bb12-57824404b87e | 14,400 | 3600 | 2 | 2 | 7200 |
| 397cb984-8cba-46d5-acc8-e4f49b60c60b | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 72,318,062 | 960,652 | 73,278,714 | 37 / 90 | — |
| 运行累计 | 72,318,062 | 960,652 | 73,278,714 | 37 / 39 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 0 | 24.78 | 0.85 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/11a89747-c946-4a7e-b776-9a083fb84163/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/11a89747-c946-4a7e-b776-9a083fb84163/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/11a89747-c946-4a7e-b776-9a083fb84163/agent/trajectory.jsonl) |
| 1 | completed | 1 | 174.65 | 0.85 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/7dfa874d-eb05-4349-a949-1a8ff7ae9ced/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/7dfa874d-eb05-4349-a949-1a8ff7ae9ced/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/7dfa874d-eb05-4349-a949-1a8ff7ae9ced/agent/trajectory.jsonl) |
| 2 | completed | 1 | 63.10 | 1.03 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/f345be1e-6a57-4e30-979f-94595c0d133a/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/f345be1e-6a57-4e30-979f-94595c0d133a/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/f345be1e-6a57-4e30-979f-94595c0d133a/agent/trajectory.jsonl) |
| 3 | completed | 1 | 77.66 | 1.12 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/7cbc68d9-4aff-43a8-9bc3-a796bbfa7b72/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/7cbc68d9-4aff-43a8-9bc3-a796bbfa7b72/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/7cbc68d9-4aff-43a8-9bc3-a796bbfa7b72/agent/trajectory.jsonl) |
| 4 | completed | 1 | 20.19 | 1.06 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/d2111390-128c-4928-9199-b7c626e8eee9/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/d2111390-128c-4928-9199-b7c626e8eee9/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/d2111390-128c-4928-9199-b7c626e8eee9/agent/trajectory.jsonl) |
| 5 | completed | 1 | 119.65 | 0.66 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/b004e2d3-0bb3-47e4-b56c-6e34c40f1ba9/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/b004e2d3-0bb3-47e4-b56c-6e34c40f1ba9/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/b004e2d3-0bb3-47e4-b56c-6e34c40f1ba9/agent/trajectory.jsonl) |
| 6 | completed | 0 | 164.21 | 0.71 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/01a347d3-fcb5-49e8-97b6-d1a71c5b9b78/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/01a347d3-fcb5-49e8-97b6-d1a71c5b9b78/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/01a347d3-fcb5-49e8-97b6-d1a71c5b9b78/agent/trajectory.jsonl) |
| 7 | completed | 1 | 128.90 | 0.84 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/622b4d45-5eaa-4351-a8d1-04a0d54bf0b6/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/622b4d45-5eaa-4351-a8d1-04a0d54bf0b6/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/622b4d45-5eaa-4351-a8d1-04a0d54bf0b6/agent/trajectory.jsonl) |
| 8 | completed | 0 | 85.41 | 0.81 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/567a2013-7a54-4f14-972b-74d20a446b34/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/567a2013-7a54-4f14-972b-74d20a446b34/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/567a2013-7a54-4f14-972b-74d20a446b34/agent/trajectory.jsonl) |
| 9 | completed | 1 | 51.48 | 1.20 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/961131ad-2227-4e73-b43c-7b479f12fc4b/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/961131ad-2227-4e73-b43c-7b479f12fc4b/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/961131ad-2227-4e73-b43c-7b479f12fc4b/agent/trajectory.jsonl) |
| 10 | completed | 1 | 95.24 | 0.77 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/8894e09e-a569-4eb0-830e-030d6491ece1/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/8894e09e-a569-4eb0-830e-030d6491ece1/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/8894e09e-a569-4eb0-830e-030d6491ece1/agent/trajectory.jsonl) |
| 11 | completed | 1 | 208.98 | 0.79 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/e4a2f420-1caf-4546-bbee-f4b13e811a9e/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/e4a2f420-1caf-4546-bbee-f4b13e811a9e/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/e4a2f420-1caf-4546-bbee-f4b13e811a9e/agent/trajectory.jsonl) |
| 12 | completed | 1 | 111.06 | 0.72 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/7910aa49-5c40-4d01-83b4-7607e208226a/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/7910aa49-5c40-4d01-83b4-7607e208226a/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/7910aa49-5c40-4d01-83b4-7607e208226a/agent/trajectory.jsonl) |
| 13 | completed | 0 | 142.91 | 0.75 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/7891b59c-0080-4b3e-9e15-6ba833872989/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/7891b59c-0080-4b3e-9e15-6ba833872989/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/7891b59c-0080-4b3e-9e15-6ba833872989/agent/trajectory.jsonl) |
| 14 | completed | 1 | 48.65 | 0.68 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/c05e655d-c5e4-4c35-844a-3a02549f28f7/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/c05e655d-c5e4-4c35-844a-3a02549f28f7/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/c05e655d-c5e4-4c35-844a-3a02549f28f7/agent/trajectory.jsonl) |
| 15 | completed | 1 | 3571.25 | 0.90 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/287ba939-6c27-4820-bafc-6fc7cf5766e3/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/287ba939-6c27-4820-bafc-6fc7cf5766e3/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/287ba939-6c27-4820-bafc-6fc7cf5766e3/agent/trajectory.jsonl) |
| 16 | completed | 1 | 584.92 | 0.73 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/3da0dd54-f25f-4346-978f-2ccc1af72811/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/3da0dd54-f25f-4346-978f-2ccc1af72811/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/3da0dd54-f25f-4346-978f-2ccc1af72811/agent/trajectory.jsonl) |
| 17 | completed | 0 | 1437.51 | 0.92 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/b7be0d6f-1e42-43d6-b629-eee18683e8d6/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/b7be0d6f-1e42-43d6-b629-eee18683e8d6/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/b7be0d6f-1e42-43d6-b629-eee18683e8d6/agent/trajectory.jsonl) |
| 18 | completed | 0 | 1079.95 | 0.83 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/3349da09-6c31-4e10-b08d-d626a2143dd6/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/3349da09-6c31-4e10-b08d-d626a2143dd6/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/3349da09-6c31-4e10-b08d-d626a2143dd6/agent/trajectory.jsonl) |
| 19 | completed | 0 | 263.32 | 0.80 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/dbe938ed-ee86-4165-9c5f-7d446a374b0a/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/dbe938ed-ee86-4165-9c5f-7d446a374b0a/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/dbe938ed-ee86-4165-9c5f-7d446a374b0a/agent/trajectory.jsonl) |
| 20 | completed | 1 | 723.58 | 0.77 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/92539cd0-19c3-4752-83a0-d669a2997938/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/92539cd0-19c3-4752-83a0-d669a2997938/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/92539cd0-19c3-4752-83a0-d669a2997938/agent/trajectory.jsonl) |
| 21 | completed | 1 | 122.50 | 1.24 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/b42c94a7-798c-44ad-bfde-9bc1666d8ee6/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/b42c94a7-798c-44ad-bfde-9bc1666d8ee6/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/b42c94a7-798c-44ad-bfde-9bc1666d8ee6/agent/trajectory.jsonl) |
| 22 | completed | 1 | 88.22 | 1.06 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/34a43499-7cd6-413b-b2b6-424d166f70f2/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/34a43499-7cd6-413b-b2b6-424d166f70f2/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/34a43499-7cd6-413b-b2b6-424d166f70f2/agent/trajectory.jsonl) |
| 23 | completed | 1 | 84.47 | 0.87 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/bfce26e9-dfcf-4d54-a326-92c0428c9eb6/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/bfce26e9-dfcf-4d54-a326-92c0428c9eb6/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/bfce26e9-dfcf-4d54-a326-92c0428c9eb6/agent/trajectory.jsonl) |
| 24 | completed | 0 | 62.96 | 0.79 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/fbecc843-6047-4237-a45f-f5957c59829d/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/fbecc843-6047-4237-a45f-f5957c59829d/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/fbecc843-6047-4237-a45f-f5957c59829d/agent/trajectory.jsonl) |
| 25 | completed | 1 | 150.94 | 0.75 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/5b057eda-5ab7-4693-b5a3-2ce15285105c/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/5b057eda-5ab7-4693-b5a3-2ce15285105c/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/5b057eda-5ab7-4693-b5a3-2ce15285105c/agent/trajectory.jsonl) |
| 26 | completed | 0 | 89.95 | 0.74 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/900f1a92-1bf1-4019-b594-d55e7480cea4/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/900f1a92-1bf1-4019-b594-d55e7480cea4/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/900f1a92-1bf1-4019-b594-d55e7480cea4/agent/trajectory.jsonl) |
| 27 | completed | 1 | 196.84 | 0.73 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/64f7bee8-18eb-4022-b586-db9d16a1d6c6/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/64f7bee8-18eb-4022-b586-db9d16a1d6c6/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/64f7bee8-18eb-4022-b586-db9d16a1d6c6/agent/trajectory.jsonl) |
| 28 | completed | 0 | 109.51 | 0.76 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/5431bf43-aef3-4838-b719-4a093bf4695e/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/5431bf43-aef3-4838-b719-4a093bf4695e/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/5431bf43-aef3-4838-b719-4a093bf4695e/agent/trajectory.jsonl) |
| 29 | completed | 0 | 1578.82 | 0.71 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/d03bc620-87b4-444d-b293-d12086efc4ea/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/d03bc620-87b4-444d-b293-d12086efc4ea/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/d03bc620-87b4-444d-b293-d12086efc4ea/agent/trajectory.jsonl) |
| 30 | completed | 0 | 128.70 | 0.73 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/b0c53af2-0c6c-46e0-970a-2d1d9b2b81fa/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/b0c53af2-0c6c-46e0-970a-2d1d9b2b81fa/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/b0c53af2-0c6c-46e0-970a-2d1d9b2b81fa/agent/trajectory.jsonl) |
| 31 | completed | 0 | 39.20 | 0.94 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/d03b83bf-fd04-4eb0-8a51-dc1d74de8b5d/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/d03b83bf-fd04-4eb0-8a51-dc1d74de8b5d/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/d03b83bf-fd04-4eb0-8a51-dc1d74de8b5d/agent/trajectory.jsonl) |
| 32 | completed | 1 | 38.49 | 0.98 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/02566a74-4136-4499-9b4f-368343d6e5ba/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/02566a74-4136-4499-9b4f-368343d6e5ba/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/02566a74-4136-4499-9b4f-368343d6e5ba/agent/trajectory.jsonl) |
| 33 | completed | 1 | 250.97 | 0.81 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/e716d092-f076-48df-b0ea-a2fb60b237d7/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/e716d092-f076-48df-b0ea-a2fb60b237d7/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/e716d092-f076-48df-b0ea-a2fb60b237d7/agent/trajectory.jsonl) |
| 34 | completed | 0 | 90.12 | 0.95 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/95807832-5028-4b99-9287-e4a5ededc9ea/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/95807832-5028-4b99-9287-e4a5ededc9ea/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/95807832-5028-4b99-9287-e4a5ededc9ea/agent/trajectory.jsonl) |
| 35 | completed | 1 | 115.72 | 1.02 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/5e5328b0-92c1-4df5-80c3-4a49bb71e040/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/5e5328b0-92c1-4df5-80c3-4a49bb71e040/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/5e5328b0-92c1-4df5-80c3-4a49bb71e040/agent/trajectory.jsonl) |
| 36 | completed | 0 | 195.50 | 1.17 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/74940a97-310d-4752-9ac7-0c8d0b9280f3/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/74940a97-310d-4752-9ac7-0c8d0b9280f3/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/74940a97-310d-4752-9ac7-0c8d0b9280f3/agent/trajectory.jsonl) |
| 37 | pending | — | — | — | — | — | — |
| 38 | cancelled | — | 371.65 | — | partial / complete | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/e5cc5e65-f1a9-40f3-b44b-c2b7bc61557e/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/e5cc5e65-f1a9-40f3-b44b-c2b7bc61557e/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/e5cc5e65-f1a9-40f3-b44b-c2b7bc61557e/agent/trajectory.jsonl) |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

