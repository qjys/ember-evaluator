<!-- snapshotDigest: 839587d90659e30c93b5e0cea55f329dac65bf7a7292c87c6f844369fd1bb037 -->
<!-- revision: 1 -->
# Evaluator report

评测已完成。

**正确率 33.33%（15/45）**

Run: 1e0692a4-d2b0-400d-86be-e06f13884dd2 · Status: completed

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-20T01:59:37.387Z / 2026-11-20T10:14:43.154Z |
| 总耗时 | 8 小时 15 分 6 秒 |
| 答对 / 答错 / 解题超时 | 15 / 30 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 0 / 0 |

已选择 45 题；已保存 45 条记录；待运行 0 题。
有效评分覆盖率：45/45（100.00%）。
执行失败 0；超时 0；取消 0；不支持 0。
Agent 解题超时 0（计 0 分）；无效 0。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 45 |
| 计分题数 | 45 |
| 正常评分题数 | 45 |
| 答对题数 | 15 |
| 无效评测 | 0 |
| 待运行 | 0 |
| 正确率 | 33.33% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 8 小时 15 分 6 秒 |
| 环境准备耗时 | 5 小时 27 分 49 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 8 分 23 秒 | 55 秒 | 52 分 17 秒 | 45 |
| 任务准备 | 0.42 毫秒 | 0.12 毫秒 | 3.21 毫秒 | 45 |
| 环境启动 | 7 秒 | 4 秒 | 15 秒 | 45 |
| 解题 | 8 分 9 秒 | 42 秒 | 51 分 51 秒 | 45 |
| 产物传输 | 1 秒 | 1 秒 | 3 秒 | 45 |
| 证据收集 | 1 秒 | 927.12 毫秒 | 3 秒 | 45 |
| 资源清理 | 3 秒 | 2 秒 | 6 秒 | 45 |
| 评分 | 1 秒 | 720.22 毫秒 | 3 秒 | 45 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| f78b5b00-f583-4f48-bbe7-64b8d4c95db9 | 14,400 | 3600 | 2 | 2 | 7200 |
| 4733a778-0935-4e8e-861b-007822ae92aa | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 98,082,615 | 1,340,286 | 99,422,901 | 45 / 45 | — |
| 运行累计 | 98,654,272 | 1,348,243 | 100,002,515 | 46 / 46 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 45 | completed | 1 | 2077.33 | 0.88 | complete / complete | — | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/0e69e76d-0dac-4843-9fe8-52e5d5dade17/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/0e69e76d-0dac-4843-9fe8-52e5d5dade17/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/0e69e76d-0dac-4843-9fe8-52e5d5dade17/agent/trajectory.jsonl) |
| 46 | completed | 0 | 182.05 | 1.14 | complete / complete | — | [result](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/585b55c7-976c-4af5-868f-f766561b49b8/result.json) · [文件清单](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/585b55c7-976c-4af5-868f-f766561b49b8/files.json) · [轨迹](tasks/25fc0e7096fc653718202dc30b0c580b8ab87eac11a700cba03a7c021bc35b0c/attempts/585b55c7-976c-4af5-868f-f766561b49b8/agent/trajectory.jsonl) |
| 47 | completed | 0 | 71.58 | 0.86 | complete / complete | — | [result](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/ae73463a-4d62-4af7-aabc-cb40b375284f/result.json) · [文件清单](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/ae73463a-4d62-4af7-aabc-cb40b375284f/files.json) · [轨迹](tasks/31489056e0916d59fe3add79e63f095af3ffb81604691f21cad442a85c7be617/attempts/ae73463a-4d62-4af7-aabc-cb40b375284f/agent/trajectory.jsonl) |
| 48 | completed | 0 | 353.07 | 0.84 | complete / complete | — | [result](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/d7e11340-3147-4c60-bd5b-6088170b69b7/result.json) · [文件清单](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/d7e11340-3147-4c60-bd5b-6088170b69b7/files.json) · [轨迹](tasks/98010bd9270f9b100b6214a21754fd33bdc8d41b2bc9f9dd16ff54d3c34ffd71/attempts/d7e11340-3147-4c60-bd5b-6088170b69b7/agent/trajectory.jsonl) |
| 49 | completed | 0 | 140.93 | 1.16 | complete / complete | — | [result](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/73425f06-468b-4ab6-a5b9-a37cd400ca3d/result.json) · [文件清单](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/73425f06-468b-4ab6-a5b9-a37cd400ca3d/files.json) · [轨迹](tasks/0e17daca5f3e175f448bacace3bc0da47d0655a74c8dd0dc497a3afbdad95f1f/attempts/73425f06-468b-4ab6-a5b9-a37cd400ca3d/agent/trajectory.jsonl) |
| 50 | completed | 0 | 526.97 | 0.80 | complete / complete | — | [result](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/39722b2b-2724-42f1-abb9-ed778228ff28/result.json) · [文件清单](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/39722b2b-2724-42f1-abb9-ed778228ff28/files.json) · [轨迹](tasks/1a6562590ef19d1045d06c4055742d38288e9e6dcd71ccde5cee80f1d5a774eb/attempts/39722b2b-2724-42f1-abb9-ed778228ff28/agent/trajectory.jsonl) |
| 51 | completed | 0 | 596.65 | 1.66 | complete / complete | — | [result](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/aee032aa-defe-4e46-9f55-d4d999d329f6/result.json) · [文件清单](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/aee032aa-defe-4e46-9f55-d4d999d329f6/files.json) · [轨迹](tasks/031b4af5197ec30a926f48cf40e11a7dbc470048a21e4003b7a3c07c5dab1baa/attempts/aee032aa-defe-4e46-9f55-d4d999d329f6/agent/trajectory.jsonl) |
| 52 | completed | 0 | 165.82 | 0.83 | complete / complete | — | [result](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/cc6c6597-6413-4d40-9627-6e31f1837c87/result.json) · [文件清单](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/cc6c6597-6413-4d40-9627-6e31f1837c87/files.json) · [轨迹](tasks/41cfc0d1f2d127b04555b7246d84019b4d27710a3f3aff6e7764375b1e06e05d/attempts/cc6c6597-6413-4d40-9627-6e31f1837c87/agent/trajectory.jsonl) |
| 53 | completed | 1 | 1731.01 | 0.92 | complete / complete | — | [result](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/852af942-37d8-4163-8c91-805dc1caa697/result.json) · [文件清单](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/852af942-37d8-4163-8c91-805dc1caa697/files.json) · [轨迹](tasks/2858dcd1057d3eae7f7d5f782167e24b61153c01551450a628cee722509f6529/attempts/852af942-37d8-4163-8c91-805dc1caa697/agent/trajectory.jsonl) |
| 54 | completed | 1 | 1050.78 | 1.00 | complete / complete | — | [result](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/374bbdb1-0639-4478-86ca-551b4401bbbb/result.json) · [文件清单](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/374bbdb1-0639-4478-86ca-551b4401bbbb/files.json) · [轨迹](tasks/2fca346db656187102ce806ac732e06a62df0dbb2829e511a770556d398e1a6e/attempts/374bbdb1-0639-4478-86ca-551b4401bbbb/agent/trajectory.jsonl) |
| 55 | completed | 1 | 112.23 | 0.88 | complete / complete | — | [result](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/039f3c62-a95f-47b9-8811-de655dc61683/result.json) · [文件清单](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/039f3c62-a95f-47b9-8811-de655dc61683/files.json) · [轨迹](tasks/02d20bbd7e394ad5999a4cebabac9619732c343a4cac99470c03e23ba2bdc2bc/attempts/039f3c62-a95f-47b9-8811-de655dc61683/agent/trajectory.jsonl) |
| 56 | completed | 1 | 269.51 | 0.95 | complete / complete | — | [result](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/aa8959ca-e434-4eff-9478-bde63d8ec049/result.json) · [文件清单](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/aa8959ca-e434-4eff-9478-bde63d8ec049/files.json) · [轨迹](tasks/7688b6ef52555962d008fff894223582c484517cea7da49ee67800adc7fc8866/attempts/aa8959ca-e434-4eff-9478-bde63d8ec049/agent/trajectory.jsonl) |
| 57 | completed | 0 | 941.25 | 1.02 | complete / complete | — | [result](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/a775cd77-dd1e-4240-b59a-8108bedd0768/result.json) · [文件清单](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/a775cd77-dd1e-4240-b59a-8108bedd0768/files.json) · [轨迹](tasks/c837649cce43f2729138e72cc315207057ac82599a59be72765a477f22d14a54/attempts/a775cd77-dd1e-4240-b59a-8108bedd0768/agent/trajectory.jsonl) |
| 58 | completed | 1 | 206.80 | 0.92 | complete / complete | — | [result](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/34066d14-7333-4131-8b1a-90948a5cc265/result.json) · [文件清单](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/34066d14-7333-4131-8b1a-90948a5cc265/files.json) · [轨迹](tasks/6208ef0f7750c111548cf90b6ea1d0d0a66f6bff40dbef07cb45ec436263c7d6/attempts/34066d14-7333-4131-8b1a-90948a5cc265/agent/trajectory.jsonl) |
| 59 | completed | 0 | 211.54 | 1.01 | complete / complete | — | [result](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/aab82752-6125-44c2-b800-5042c5453b2a/result.json) · [文件清单](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/aab82752-6125-44c2-b800-5042c5453b2a/files.json) · [轨迹](tasks/3e1e967e9b793e908f8eae83c74dba9bcccce6a5535b4b462bd9994537bfe15c/attempts/aab82752-6125-44c2-b800-5042c5453b2a/agent/trajectory.jsonl) |
| 60 | completed | 0 | 175.05 | 1.13 | complete / complete | — | [result](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/08e411bc-c38e-4b9f-ac51-cf0153cbf09e/result.json) · [文件清单](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/08e411bc-c38e-4b9f-ac51-cf0153cbf09e/files.json) · [轨迹](tasks/39fa9ec190eee7b6f4dff1100d6343e10918d044c75eac8f9e9a2596173f80c9/attempts/08e411bc-c38e-4b9f-ac51-cf0153cbf09e/agent/trajectory.jsonl) |
| 61 | completed | 0 | 244.88 | 1.12 | complete / complete | — | [result](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/ab0caf3a-74eb-4030-873d-84d139e4f225/result.json) · [文件清单](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/ab0caf3a-74eb-4030-873d-84d139e4f225/files.json) · [轨迹](tasks/d029fa3a95e174a19934857f535eb9427d967218a36ea014b70ad704bc6c8d1c/attempts/ab0caf3a-74eb-4030-873d-84d139e4f225/agent/trajectory.jsonl) |
| 62 | completed | 0 | 214.53 | 0.98 | complete / complete | — | [result](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/f2a13800-9250-4958-b611-f3ba3916357d/result.json) · [文件清单](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/f2a13800-9250-4958-b611-f3ba3916357d/files.json) · [轨迹](tasks/81b8a03f97e8787c53fe1a86bda042b6f0de9b0ec9c09357e107c99ba4d6948a/attempts/f2a13800-9250-4958-b611-f3ba3916357d/agent/trajectory.jsonl) |
| 63 | completed | 0 | 205.64 | 1.05 | complete / complete | — | [result](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/45c684d9-d873-4dd8-893a-8d6dcc7e2d8e/result.json) · [文件清单](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/45c684d9-d873-4dd8-893a-8d6dcc7e2d8e/files.json) · [轨迹](tasks/da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c/attempts/45c684d9-d873-4dd8-893a-8d6dcc7e2d8e/agent/trajectory.jsonl) |
| 64 | completed | 1 | 41.61 | 0.96 | complete / complete | — | [result](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/e174cf3e-525e-4430-8b62-f1a27d0bae81/result.json) · [文件清单](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/e174cf3e-525e-4430-8b62-f1a27d0bae81/files.json) · [轨迹](tasks/a68b412c4282555f15546cf6e1fc42893b7e07f271557ceb021821098dd66c1b/attempts/e174cf3e-525e-4430-8b62-f1a27d0bae81/agent/trajectory.jsonl) |
| 65 | completed | 0 | 290.52 | 0.94 | complete / complete | — | [result](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/cca52433-5b54-4854-9f6e-06f36fd6f895/result.json) · [文件清单](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/cca52433-5b54-4854-9f6e-06f36fd6f895/files.json) · [轨迹](tasks/108c995b953c8a35561103e2014cf828eb654a99e310f87fab94c2f4b7d2a04f/attempts/cca52433-5b54-4854-9f6e-06f36fd6f895/agent/trajectory.jsonl) |
| 66 | completed | 0 | 52.61 | 1.14 | complete / complete | — | [result](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/e896c608-e1f6-4d0c-8616-bae7d935cf59/result.json) · [文件清单](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/e896c608-e1f6-4d0c-8616-bae7d935cf59/files.json) · [轨迹](tasks/3ada92f28b4ceda38562ebf047c6ff05400d4c572352a1142eedfef67d21e662/attempts/e896c608-e1f6-4d0c-8616-bae7d935cf59/agent/trajectory.jsonl) |
| 67 | completed | 0 | 143.99 | 1.26 | complete / complete | — | [result](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/d7685005-cfa5-4b38-be0a-8d76a43ae9b8/result.json) · [文件清单](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/d7685005-cfa5-4b38-be0a-8d76a43ae9b8/files.json) · [轨迹](tasks/49d180ecf56132819571bf39d9b7b342522a2ac6d23c1418d3338251bfe469c8/attempts/d7685005-cfa5-4b38-be0a-8d76a43ae9b8/agent/trajectory.jsonl) |
| 68 | completed | 1 | 153.90 | 1.17 | complete / complete | — | [result](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/66b9b1ae-b4d3-409c-afbb-08add093aaf7/result.json) · [文件清单](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/66b9b1ae-b4d3-409c-afbb-08add093aaf7/files.json) · [轨迹](tasks/a21855da08cb102d1d217c53dc5824a3a795c1c1a44e971bf01ab9da3a2acbbf/attempts/66b9b1ae-b4d3-409c-afbb-08add093aaf7/agent/trajectory.jsonl) |
| 69 | completed | 0 | 113.71 | 1.37 | complete / complete | — | [result](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/07d8c734-3e83-42c1-a6c0-24407b0e5ca8/result.json) · [文件清单](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/07d8c734-3e83-42c1-a6c0-24407b0e5ca8/files.json) · [轨迹](tasks/c75cb66ae28d8ebc6eded002c28a8ba0d06d3a78c6b5cbf9b2ade051f0775ac4/attempts/07d8c734-3e83-42c1-a6c0-24407b0e5ca8/agent/trajectory.jsonl) |
| 70 | completed | 0 | 188.05 | 0.99 | complete / complete | — | [result](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/42d62159-2b0b-478c-b741-8d6009f3d749/result.json) · [文件清单](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/42d62159-2b0b-478c-b741-8d6009f3d749/files.json) · [轨迹](tasks/ff5a1ae012afa5d4c889c50ad427aaf545d31a4fac04ffc1c4d03d403ba4250a/attempts/42d62159-2b0b-478c-b741-8d6009f3d749/agent/trajectory.jsonl) |
| 71 | completed | 0 | 200.99 | 1.59 | complete / complete | — | [result](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/f217737b-0760-4f54-914b-a795c282830e/result.json) · [文件清单](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/f217737b-0760-4f54-914b-a795c282830e/files.json) · [轨迹](tasks/7f2253d7e228b22a08bda1f09c516f6fead81df6536eb02fa991a34bb38d9be8/attempts/f217737b-0760-4f54-914b-a795c282830e/agent/trajectory.jsonl) |
| 72 | completed | 1 | 1656.49 | 1.14 | complete / complete | — | [result](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/1386f114-a6b9-4449-887c-bbccc4efda5f/result.json) · [文件清单](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/1386f114-a6b9-4449-887c-bbccc4efda5f/files.json) · [轨迹](tasks/8722616204217eddb39e7df969e0698aed8e599ba62ed2de1ce49b03ade0fede/attempts/1386f114-a6b9-4449-887c-bbccc4efda5f/agent/trajectory.jsonl) |
| 73 | completed | 1 | 1034.56 | 0.86 | complete / complete | — | [result](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/ff51e80f-9220-4936-9c8b-435ab2481d98/result.json) · [文件清单](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/ff51e80f-9220-4936-9c8b-435ab2481d98/files.json) · [轨迹](tasks/96061e92f58e4bdcdee73df36183fe3ac64747c81c26f6c83aada8d2aabb1864/attempts/ff51e80f-9220-4936-9c8b-435ab2481d98/agent/trajectory.jsonl) |
| 74 | completed | 0 | 522.84 | 1.42 | complete / complete | — | [result](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/4e220627-f16e-42ee-a5fd-70fd307058a8/result.json) · [文件清单](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/4e220627-f16e-42ee-a5fd-70fd307058a8/files.json) · [轨迹](tasks/eb624dbe56eb6620ae62080c10a273cab73ae8eca98ab17b731446a31c79393a/attempts/4e220627-f16e-42ee-a5fd-70fd307058a8/agent/trajectory.jsonl) |
| 75 | completed | 0 | 529.76 | 1.31 | complete / complete | — | [result](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/a544969d-5009-4d92-a14a-7070981feebd/result.json) · [文件清单](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/a544969d-5009-4d92-a14a-7070981feebd/files.json) · [轨迹](tasks/f369cb89fc627e668987007d121ed1eacdc01db9e28f8bb26f358b7d8c4f08ac/attempts/a544969d-5009-4d92-a14a-7070981feebd/agent/trajectory.jsonl) |
| 76 | completed | 0 | 136.74 | 3.13 | complete / complete | — | [result](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/e798100f-9cc5-4164-9ffb-aaa4f3f13282/result.json) · [文件清单](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/e798100f-9cc5-4164-9ffb-aaa4f3f13282/files.json) · [轨迹](tasks/f74efabef12ea619e30b79bddef89cffa9dda494761681ca862cff2871a85980/attempts/e798100f-9cc5-4164-9ffb-aaa4f3f13282/agent/trajectory.jsonl) |
| 77 | completed | 0 | 3111.29 | 1.37 | complete / complete | — | [result](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/cf315ada-8c87-4ca5-a17a-47ddfe808f2c/result.json) · [文件清单](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/cf315ada-8c87-4ca5-a17a-47ddfe808f2c/files.json) · [轨迹](tasks/a88a7902cb4ef697ba0b6759c50e8c10297ff58f942243de19b984841bfe1f73/attempts/cf315ada-8c87-4ca5-a17a-47ddfe808f2c/agent/trajectory.jsonl) |
| 78 | completed | 1 | 79.64 | 1.09 | complete / complete | — | [result](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/977c1599-a170-4e04-9c4b-0050d4ac33d6/result.json) · [文件清单](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/977c1599-a170-4e04-9c4b-0050d4ac33d6/files.json) · [轨迹](tasks/349c41201b62db851192665c504b350ff98c6b45fb62a8a2161f78b6534d8de9/attempts/977c1599-a170-4e04-9c4b-0050d4ac33d6/agent/trajectory.jsonl) |
| 79 | completed | 1 | 136.16 | 0.72 | complete / complete | — | [result](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/5ba1a9f3-6944-49a0-af11-6969b57d77a4/result.json) · [文件清单](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/5ba1a9f3-6944-49a0-af11-6969b57d77a4/files.json) · [轨迹](tasks/98a3ab7c340e8a033e7b37b6ef9428751581760af67bbab2b9e05d4964a8874a/attempts/5ba1a9f3-6944-49a0-af11-6969b57d77a4/agent/trajectory.jsonl) |
| 80 | completed | 0 | 794.62 | 0.77 | complete / complete | — | [result](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/d8191dac-cb71-4f58-8af2-bb39483346a7/result.json) · [文件清单](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/d8191dac-cb71-4f58-8af2-bb39483346a7/files.json) · [轨迹](tasks/48449a14a4ff7d79bb7a1b6f3d488eba397c36ef25634c111b49baf362511afc/attempts/d8191dac-cb71-4f58-8af2-bb39483346a7/agent/trajectory.jsonl) |
| 81 | completed | 1 | 524.71 | 0.79 | complete / complete | — | [result](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/168beb45-bda5-43e1-8b0b-499992e103d3/result.json) · [文件清单](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/168beb45-bda5-43e1-8b0b-499992e103d3/files.json) · [轨迹](tasks/5316ca1c5ddca8e6ceccfce58f3b8540e540ee22f6180fb89492904051b3d531/attempts/168beb45-bda5-43e1-8b0b-499992e103d3/agent/trajectory.jsonl) |
| 82 | completed | 0 | 865.63 | 0.73 | complete / complete | — | [result](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/3dbb901a-3ca7-4b6b-a252-f4e72841e65e/result.json) · [文件清单](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/3dbb901a-3ca7-4b6b-a252-f4e72841e65e/files.json) · [轨迹](tasks/a46e37632fa6ca51a13fe39a567b3c23b28c2f47d8af6be9bd63e030e214ba38/attempts/3dbb901a-3ca7-4b6b-a252-f4e72841e65e/agent/trajectory.jsonl) |
| 83 | completed | 0 | 52.92 | 0.79 | complete / complete | — | [result](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/68b8dbd7-d722-4938-85fb-3a716a678d45/result.json) · [文件清单](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/68b8dbd7-d722-4938-85fb-3a716a678d45/files.json) · [轨迹](tasks/bbb965ab0c80d6538cf2184babad2a564a010376712012bd07b0af92dcd3097d/attempts/68b8dbd7-d722-4938-85fb-3a716a678d45/agent/trajectory.jsonl) |
| 84 | completed | 1 | 455.91 | 0.75 | complete / complete | — | [result](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/3e27bd46-99f0-4998-83cc-4b5ac39f5f89/result.json) · [文件清单](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/3e27bd46-99f0-4998-83cc-4b5ac39f5f89/files.json) · [轨迹](tasks/44c8031cb036a7350d8b9b8603af662a4b9cdbd2f96e8d5de5af435c9c35da69/attempts/3e27bd46-99f0-4998-83cc-4b5ac39f5f89/agent/trajectory.jsonl) |
| 85 | completed | 0 | 328.45 | 0.76 | complete / complete | — | [result](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/405aef61-e007-41ee-a935-08dbdf7482d5/result.json) · [文件清单](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/405aef61-e007-41ee-a935-08dbdf7482d5/files.json) · [轨迹](tasks/b4944c6ff08dc6f43da2e9c824669b7d927dd1fa976fadc7b456881f51bf5ccc/attempts/405aef61-e007-41ee-a935-08dbdf7482d5/agent/trajectory.jsonl) |
| 86 | completed | 0 | 309.94 | 0.79 | complete / complete | — | [result](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a6eccc4b-2ff2-4748-8c35-02f4eccecc72/result.json) · [文件清单](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a6eccc4b-2ff2-4748-8c35-02f4eccecc72/files.json) · [轨迹](tasks/434c9b5ae514646bbd91b50032ca579efec8f22bf0b4aac12e65997c418e0dd6/attempts/a6eccc4b-2ff2-4748-8c35-02f4eccecc72/agent/trajectory.jsonl) |
| 87 | completed | 1 | 115.24 | 0.75 | complete / complete | — | [result](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/89138735-5985-40da-8537-3a2f600e91ce/result.json) · [文件清单](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/89138735-5985-40da-8537-3a2f600e91ce/files.json) · [轨迹](tasks/bdd2d3af3a5a1213497d4f1f7bfcda898274fe9cb5401bbc0190885664708fc2/attempts/89138735-5985-40da-8537-3a2f600e91ce/agent/trajectory.jsonl) |
| 88 | completed | 0 | 513.89 | 0.78 | complete / complete | — | [result](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/35581da3-a647-4e84-ab45-f111a611141e/result.json) · [文件清单](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/35581da3-a647-4e84-ab45-f111a611141e/files.json) · [轨迹](tasks/8b940be7fb78aaa6b6567dd7a3987996947460df1c668e698eb92ca77e425349/attempts/35581da3-a647-4e84-ab45-f111a611141e/agent/trajectory.jsonl) |
| 89 | completed | 0 | 164.69 | 0.77 | complete / complete | — | [result](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/38b7b660-263d-41e0-9d78-ac60791bc1df/result.json) · [文件清单](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/38b7b660-263d-41e0-9d78-ac60791bc1df/files.json) · [轨迹](tasks/cd70bea023f752a0564abb6ed08d42c1440f2e33e29914e55e0be1595e24f45a/attempts/38b7b660-263d-41e0-9d78-ac60791bc1df/agent/trajectory.jsonl) |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

