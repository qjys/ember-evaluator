<!-- snapshotDigest: 7219f40545355b3dc5debd26fc5a766ee384f31e9d70f0c60b06684b7d7ee171 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 25.84%（23/89）**

Run: 97c056a9-4400-4c9b-ad88-3be9e84c3e61 · Status: cancelled

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | agentbundle |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-19T15:56:50.651Z / 2026-11-20T01:47:49.782Z |
| 总耗时 | 9 小时 50 分 59 秒 |
| 答对 / 答错 / 解题超时 | 23 / 22 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 46 条记录；待运行 45 题。
有效评分覆盖率：45/90（50.00%）。
执行失败 0；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 45 |
| 答对题数 | 23 |
| 无效评测 | 1 |
| 待运行 | 45 |
| 正确率 | 25.84% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 50 分 59 秒 |
| 环境准备耗时 | 9 小时 50 分 36 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 4 分 29 秒 | 32 秒 | 19 分 34 秒 | 46 |
| 任务准备 | 0.34 毫秒 | 0.21 毫秒 | 0.6 毫秒 | 46 |
| 环境启动 | 5 秒 | 4 秒 | 10 秒 | 46 |
| 解题 | 4 分 18 秒 | 23 秒 | 19 分 23 秒 | 46 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 45 |
| 证据收集 | 1 秒 | 858.5 毫秒 | 4 秒 | 46 |
| 资源清理 | 3 秒 | 2 秒 | 6 秒 | 46 |
| 评分 | 845.53 毫秒 | 682.99 毫秒 | 1 秒 | 45 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 4dc4983d-a2f6-417e-8661-e9a6e2630554 | 14,400 | 3600 | 2 | 2 | 7200 |
| afd9a731-1f46-470f-8b4b-0e2c1b9a6e25 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 72,927,426 | 946,678 | 73,874,104 | 45 / 90 | — |
| 运行累计 | 73,563,951 | 962,668 | 74,526,619 | 46 / 47 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 0 | 463.47 | 0.76 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/300462cb-c5fe-4660-a6b3-266e5b3a9d9b/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/300462cb-c5fe-4660-a6b3-266e5b3a9d9b/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/300462cb-c5fe-4660-a6b3-266e5b3a9d9b/agent/trajectory.jsonl) |
| 1 | completed | 0 | 1163.08 | 0.75 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/171cc953-2fe5-4014-a5b1-db641934aa59/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/171cc953-2fe5-4014-a5b1-db641934aa59/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/171cc953-2fe5-4014-a5b1-db641934aa59/agent/trajectory.jsonl) |
| 2 | completed | 1 | 103.47 | 0.74 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/0a2d591b-0b16-49e9-a7b1-21c3541d83ee/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/0a2d591b-0b16-49e9-a7b1-21c3541d83ee/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/0a2d591b-0b16-49e9-a7b1-21c3541d83ee/agent/trajectory.jsonl) |
| 3 | completed | 1 | 50.78 | 0.85 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/b405fc1e-5193-4334-a0c5-e2af4353226d/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/b405fc1e-5193-4334-a0c5-e2af4353226d/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/b405fc1e-5193-4334-a0c5-e2af4353226d/agent/trajectory.jsonl) |
| 4 | completed | 1 | 23.77 | 0.78 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/16695b87-ab4f-45ad-9ba9-2494c340e739/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/16695b87-ab4f-45ad-9ba9-2494c340e739/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/16695b87-ab4f-45ad-9ba9-2494c340e739/agent/trajectory.jsonl) |
| 5 | completed | 0 | 57.60 | 0.68 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/fac2a994-5a8d-4385-8d18-871ab823e486/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/fac2a994-5a8d-4385-8d18-871ab823e486/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/fac2a994-5a8d-4385-8d18-871ab823e486/agent/trajectory.jsonl) |
| 6 | completed | 0 | 102.51 | 0.89 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/a02b9ea4-8369-4ed8-ab44-2a2c4ded2ad1/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/a02b9ea4-8369-4ed8-ab44-2a2c4ded2ad1/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/a02b9ea4-8369-4ed8-ab44-2a2c4ded2ad1/agent/trajectory.jsonl) |
| 7 | completed | 1 | 42.59 | 0.70 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/9a37e3c7-6bb8-4502-8ead-562f07a453a8/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/9a37e3c7-6bb8-4502-8ead-562f07a453a8/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/9a37e3c7-6bb8-4502-8ead-562f07a453a8/agent/trajectory.jsonl) |
| 8 | completed | 0 | 42.75 | 0.76 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/1da8c6f7-f280-44cf-a9a3-d688ba6fdf2b/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/1da8c6f7-f280-44cf-a9a3-d688ba6fdf2b/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/1da8c6f7-f280-44cf-a9a3-d688ba6fdf2b/agent/trajectory.jsonl) |
| 9 | completed | 0 | 48.12 | 0.93 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/956454fd-5ff3-4401-ab9a-ac70bc36fa99/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/956454fd-5ff3-4401-ab9a-ac70bc36fa99/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/956454fd-5ff3-4401-ab9a-ac70bc36fa99/agent/trajectory.jsonl) |
| 10 | completed | 1 | 115.38 | 0.74 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/ca2d1a07-db17-4650-976c-3e70ea3bd9f1/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/ca2d1a07-db17-4650-976c-3e70ea3bd9f1/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/ca2d1a07-db17-4650-976c-3e70ea3bd9f1/agent/trajectory.jsonl) |
| 11 | completed | 1 | 117.94 | 0.74 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/bb0dacdc-f00d-4c69-9430-7e40c4ab13bd/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/bb0dacdc-f00d-4c69-9430-7e40c4ab13bd/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/bb0dacdc-f00d-4c69-9430-7e40c4ab13bd/agent/trajectory.jsonl) |
| 12 | completed | 0 | 55.47 | 0.78 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/539830d8-2644-452d-93b2-3ce85c3604d1/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/539830d8-2644-452d-93b2-3ce85c3604d1/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/539830d8-2644-452d-93b2-3ce85c3604d1/agent/trajectory.jsonl) |
| 13 | completed | 1 | 212.44 | 0.74 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/8b39188e-7042-4899-90c5-7ab7330f6ff6/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/8b39188e-7042-4899-90c5-7ab7330f6ff6/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/8b39188e-7042-4899-90c5-7ab7330f6ff6/agent/trajectory.jsonl) |
| 14 | completed | 1 | 22.54 | 0.74 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/948c26d0-dc2f-4a5c-9261-b84297e6ae43/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/948c26d0-dc2f-4a5c-9261-b84297e6ae43/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/948c26d0-dc2f-4a5c-9261-b84297e6ae43/agent/trajectory.jsonl) |
| 15 | completed | 1 | 688.76 | 0.95 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/d8b91c2d-56c9-4bd3-8b8a-50e1945d5fa4/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/d8b91c2d-56c9-4bd3-8b8a-50e1945d5fa4/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/d8b91c2d-56c9-4bd3-8b8a-50e1945d5fa4/agent/trajectory.jsonl) |
| 16 | completed | 0 | 829.04 | 0.82 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/d42431b0-f8a3-4b3e-ae28-7c665b3f8a4e/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/d42431b0-f8a3-4b3e-ae28-7c665b3f8a4e/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/d42431b0-f8a3-4b3e-ae28-7c665b3f8a4e/agent/trajectory.jsonl) |
| 17 | completed | 1 | 157.34 | 0.98 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/61efe3de-6046-4c4e-947d-a6b3703194dc/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/61efe3de-6046-4c4e-947d-a6b3703194dc/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/61efe3de-6046-4c4e-947d-a6b3703194dc/agent/trajectory.jsonl) |
| 18 | completed | 1 | 281.83 | 0.75 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/96daa873-09b0-4204-96a1-8f98000a581f/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/96daa873-09b0-4204-96a1-8f98000a581f/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/96daa873-09b0-4204-96a1-8f98000a581f/agent/trajectory.jsonl) |
| 19 | completed | 1 | 236.29 | 0.79 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/731458c8-57bc-49fb-8ed0-cae93f9cab0a/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/731458c8-57bc-49fb-8ed0-cae93f9cab0a/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/731458c8-57bc-49fb-8ed0-cae93f9cab0a/agent/trajectory.jsonl) |
| 20 | completed | 0 | 821.42 | 1.23 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/69254793-dbc5-475e-ba13-a499585756dc/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/69254793-dbc5-475e-ba13-a499585756dc/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/69254793-dbc5-475e-ba13-a499585756dc/agent/trajectory.jsonl) |
| 21 | completed | 1 | 113.69 | 0.90 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/c2b98344-1909-431b-907b-5db7e19b3f06/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/c2b98344-1909-431b-907b-5db7e19b3f06/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/c2b98344-1909-431b-907b-5db7e19b3f06/agent/trajectory.jsonl) |
| 22 | completed | 1 | 107.24 | 0.87 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/26064f46-f197-4bde-ad30-731cb1f53515/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/26064f46-f197-4bde-ad30-731cb1f53515/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/26064f46-f197-4bde-ad30-731cb1f53515/agent/trajectory.jsonl) |
| 23 | completed | 1 | 49.71 | 0.82 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/3bc50f02-bbc7-4eed-963b-5d58fd0c1318/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/3bc50f02-bbc7-4eed-963b-5d58fd0c1318/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/3bc50f02-bbc7-4eed-963b-5d58fd0c1318/agent/trajectory.jsonl) |
| 24 | completed | 0 | 43.88 | 0.88 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/f840afee-6d06-4b84-b081-f900e3750e28/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/f840afee-6d06-4b84-b081-f900e3750e28/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/f840afee-6d06-4b84-b081-f900e3750e28/agent/trajectory.jsonl) |
| 25 | completed | 1 | 72.93 | 1.49 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/c4929c18-278e-49b6-bbcd-3e80540ac5b8/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/c4929c18-278e-49b6-bbcd-3e80540ac5b8/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/c4929c18-278e-49b6-bbcd-3e80540ac5b8/agent/trajectory.jsonl) |
| 26 | completed | 1 | 167.45 | 0.87 | complete / complete | — | [result](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/23eb504d-7cbe-4122-995c-a292ce5aa56b/result.json) · [文件清单](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/23eb504d-7cbe-4122-995c-a292ce5aa56b/files.json) · [轨迹](tasks/5f9c4ab08cac7457e9111a30e4664920607ea2c115a1433d7be98e97e64244ca/attempts/23eb504d-7cbe-4122-995c-a292ce5aa56b/agent/trajectory.jsonl) |
| 27 | completed | 1 | 347.59 | 1.03 | complete / complete | — | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/8943c51f-783c-47f5-86d1-1af0e993fd66/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/8943c51f-783c-47f5-86d1-1af0e993fd66/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/8943c51f-783c-47f5-86d1-1af0e993fd66/agent/trajectory.jsonl) |
| 28 | completed | 0 | 161.68 | 1.08 | complete / complete | — | [result](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/4b0cea71-783c-4072-8820-cee122f634a9/result.json) · [文件清单](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/4b0cea71-783c-4072-8820-cee122f634a9/files.json) · [轨迹](tasks/59e19706d51d39f66711c2653cd7eb1291c94d9b55eb14bda74ce4dc636d015a/attempts/4b0cea71-783c-4072-8820-cee122f634a9/agent/trajectory.jsonl) |
| 29 | completed | 0 | 454.08 | 0.88 | complete / complete | — | [result](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/56f6c1bb-1ebe-4ac9-81f3-afdee11bea36/result.json) · [文件清单](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/56f6c1bb-1ebe-4ac9-81f3-afdee11bea36/files.json) · [轨迹](tasks/35135aaa6cc23891b40cb3f378c53a17a1127210ce60e125ccf03efcfdaec458/attempts/56f6c1bb-1ebe-4ac9-81f3-afdee11bea36/agent/trajectory.jsonl) |
| 30 | completed | 0 | 251.79 | 0.87 | complete / complete | — | [result](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/88735b35-bed5-4ee8-bfbc-057a4a70e8ac/result.json) · [文件清单](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/88735b35-bed5-4ee8-bfbc-057a4a70e8ac/files.json) · [轨迹](tasks/624b60c58c9d8bfb6ff1886c2fd605d2adeb6ea4da576068201b6c6958ce93f4/attempts/88735b35-bed5-4ee8-bfbc-057a4a70e8ac/agent/trajectory.jsonl) |
| 31 | completed | 0 | 536.43 | 1.01 | complete / complete | — | [result](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/9c32a7db-774a-4cea-9804-c5d29c048a7f/result.json) · [文件清单](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/9c32a7db-774a-4cea-9804-c5d29c048a7f/files.json) · [轨迹](tasks/eb1e33e8a81b697b75855af6bfcdbcbf7cbbde9f94962ceaec1ed8af21f5a50f/attempts/9c32a7db-774a-4cea-9804-c5d29c048a7f/agent/trajectory.jsonl) |
| 32 | completed | 1 | 62.56 | 0.77 | complete / complete | — | [result](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/85897ae8-5f00-4bf5-a5c9-bef39ef30208/result.json) · [文件清单](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/85897ae8-5f00-4bf5-a5c9-bef39ef30208/files.json) · [轨迹](tasks/e29c9c180c6279b0b02abd6a1801c7c04082cf486ec027aa13515e4f3884bb6b/attempts/85897ae8-5f00-4bf5-a5c9-bef39ef30208/agent/trajectory.jsonl) |
| 33 | completed | 1 | 498.40 | 0.99 | complete / complete | — | [result](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/e964c472-892b-4df3-9e05-6675c846442a/result.json) · [文件清单](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/e964c472-892b-4df3-9e05-6675c846442a/files.json) · [轨迹](tasks/c6f3ac57944a531490cd39902d0f777715fd005efac9a30622d5f5205e7f6894/attempts/e964c472-892b-4df3-9e05-6675c846442a/agent/trajectory.jsonl) |
| 34 | completed | 0 | 186.37 | 0.83 | complete / complete | — | [result](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/63834aa5-6b28-4a3f-82cd-8413f7644b03/result.json) · [文件清单](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/63834aa5-6b28-4a3f-82cd-8413f7644b03/files.json) · [轨迹](tasks/86e50149658661312a9e0b35558d84f6c6d3da797f552a9657fe0558ca40cdef/attempts/63834aa5-6b28-4a3f-82cd-8413f7644b03/agent/trajectory.jsonl) |
| 35 | completed | 1 | 43.63 | 0.93 | complete / complete | — | [result](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/2c382eac-7a74-4514-8b5a-2d626e82389a/result.json) · [文件清单](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/2c382eac-7a74-4514-8b5a-2d626e82389a/files.json) · [轨迹](tasks/9f14025af0065b30e47e23ebb3b491d39ae8ed17d33739e5ff3827ffb3634953/attempts/2c382eac-7a74-4514-8b5a-2d626e82389a/agent/trajectory.jsonl) |
| 36 | completed | 0 | 571.68 | 0.74 | complete / complete | — | [result](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/54996074-ec6f-48ad-9109-097de45003ee/result.json) · [文件清单](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/54996074-ec6f-48ad-9109-097de45003ee/files.json) · [轨迹](tasks/76a50887d8f1c2e9301755428990ad81479ee21c25b43215cf524541e0503269/attempts/54996074-ec6f-48ad-9109-097de45003ee/agent/trajectory.jsonl) |
| 37 | completed | 1 | 61.28 | 0.76 | complete / complete | — | [result](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/d7a41b4b-a261-4565-bb3e-e33055256351/result.json) · [文件清单](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/d7a41b4b-a261-4565-bb3e-e33055256351/files.json) · [轨迹](tasks/7a61b53701befdae0eeeffaecc73f14e20b537bb0f8b91ad7c2936dc63562b25/attempts/d7a41b4b-a261-4565-bb3e-e33055256351/agent/trajectory.jsonl) |
| 38 | completed | 0 | 1135.52 | 0.73 | complete / complete | — | [result](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/157385b2-66f9-478e-a0e3-070e35030f74/result.json) · [文件清单](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/157385b2-66f9-478e-a0e3-070e35030f74/files.json) · [轨迹](tasks/aea92132c4cbeb263e6ac2bf6c183b5d81737f179f21efdc5863739672f0f470/attempts/157385b2-66f9-478e-a0e3-070e35030f74/agent/trajectory.jsonl) |
| 39 | completed | 0 | 109.81 | 0.74 | complete / complete | — | [result](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/ca119e42-4817-4aba-bc93-e0643054843a/result.json) · [文件清单](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/ca119e42-4817-4aba-bc93-e0643054843a/files.json) · [轨迹](tasks/0b918943df0962bc7a1824c0555a389347b4febdc7cf9d1254406d80ce44e3f9/attempts/ca119e42-4817-4aba-bc93-e0643054843a/agent/trajectory.jsonl) |
| 40 | completed | 0 | 78.85 | 0.72 | complete / complete | — | [result](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/a5387824-c069-4272-a627-80bfe5828646/result.json) · [文件清单](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/a5387824-c069-4272-a627-80bfe5828646/files.json) · [轨迹](tasks/d59eced1ded07f84c145592f65bdf854358e009c5cd705f5215bf18697fed103/attempts/a5387824-c069-4272-a627-80bfe5828646/agent/trajectory.jsonl) |
| 41 | completed | 1 | 271.90 | 0.81 | complete / complete | — | [result](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/a0a34a78-b269-4ad1-91fc-0401f33b5867/result.json) · [文件清单](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/a0a34a78-b269-4ad1-91fc-0401f33b5867/files.json) · [轨迹](tasks/3d914f9348c9cc0ff8a79716700b9fcd4d2f3e711608004eb8f138bcba7f14d9/attempts/a0a34a78-b269-4ad1-91fc-0401f33b5867/agent/trajectory.jsonl) |
| 42 | completed | 0 | 70.44 | 0.72 | complete / complete | — | [result](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/2847ffe2-c0f6-45f9-8f63-2031f7a6ad8d/result.json) · [文件清单](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/2847ffe2-c0f6-45f9-8f63-2031f7a6ad8d/files.json) · [轨迹](tasks/73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049/attempts/2847ffe2-c0f6-45f9-8f63-2031f7a6ad8d/agent/trajectory.jsonl) |
| 43 | completed | 0 | 99.62 | 0.73 | complete / complete | — | [result](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/f20f1be9-6134-4423-ba36-547d94e4b0c7/result.json) · [文件清单](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/f20f1be9-6134-4423-ba36-547d94e4b0c7/files.json) · [轨迹](tasks/44cb730c420480a0477b505ae68af508fb90f96cf0ec54c6ad16949dd427f13a/attempts/f20f1be9-6134-4423-ba36-547d94e4b0c7/agent/trajectory.jsonl) |
| 44 | completed | 0 | 91.02 | 0.82 | complete / complete | — | [result](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/f0c52cd6-788e-4b40-b3b2-1de864e32a87/result.json) · [文件清单](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/f0c52cd6-788e-4b40-b3b2-1de864e32a87/files.json) · [轨迹](tasks/71ee45a3c0db9a9865f7313dd3372cf60dca6479d46261f3542eb9346e4a04d6/attempts/f0c52cd6-788e-4b40-b3b2-1de864e32a87/agent/trajectory.jsonl) |
| 45 | cancelled | — | 642.63 | — | partial / complete | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/3b0cb90a-9f92-484f-93bf-1451f439b933/result.json) · [文件清单](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/3b0cb90a-9f92-484f-93bf-1451f439b933/files.json) · [轨迹](tasks/811786ad1ae74adfdd20dd0372abaaebc6246e343aebd01da0bfc4c02bf0106c/attempts/3b0cb90a-9f92-484f-93bf-1451f439b933/agent/trajectory.jsonl) |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

