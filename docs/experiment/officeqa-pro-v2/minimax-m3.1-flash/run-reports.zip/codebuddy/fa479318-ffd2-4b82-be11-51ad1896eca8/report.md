<!-- snapshotDigest: 08be494a3ac13d69ba0a4b8eab4579ff6153d4ab6f9860789c3f744fecfd4559 -->
<!-- revision: 1 -->
# Evaluator report

**未完成：本报告包含部分运行结果。**

**正确率 22.47%（20/89）**

Run: fa479318-ffd2-4b82-be11-51ad1896eca8 · Status: cancelled

## 运行概况

| 项目 | 结果 |
| --- | --- |
| Benchmark | officeqa-pro-v2 |
| 模型 | MiniMax-M3.1-Flash |
| Agent Harness | codebuddy |
| 环境 / 调度器 | docker / local |
| 开始 / 结束（UTC） | 2026-11-19T15:55:14.579Z / 2026-11-20T01:47:50.166Z |
| 总耗时 | 9 小时 52 分 36 秒 |
| 答对 / 答错 / 解题超时 | 20 / 6 / 0 |
| 清理未确认 | 0 |
| 轨迹不完整 / 产物不完整 | 1 / 0 |

已选择 90 题；已保存 27 条记录；待运行 64 题。
有效评分覆盖率：26/90（28.89%）。
执行失败 0；超时 0；取消 1；不支持 0。
Agent 解题超时 0（计 0 分）；无效 1。

## Metrics

### 评分

| 指标 | 结果 |
| --- | --- |
| 选定题数 | 90 |
| 计分题数 | 89 |
| 正常评分题数 | 26 |
| 答对题数 | 20 |
| 无效评测 | 1 |
| 待运行 | 64 |
| 正确率 | 22.47% |

### 耗时

| 指标 | 结果 |
| --- | --- |
| 整批运行 | 9 小时 52 分 36 秒 |
| 环境准备耗时 | 9 小时 52 分 11 秒 |

| 阶段 | 平均用时 | 最短用时 | 最长用时 | 任务数 |
| --- | --- | --- | --- | --- |
| 单题执行 | 6 分 8 秒 | 49 秒 | 30 分 16 秒 | 27 |
| 任务准备 | 0.35 毫秒 | 0.23 毫秒 | 0.86 毫秒 | 27 |
| 环境启动 | 5 秒 | 4 秒 | 8 秒 | 27 |
| 解题 | 5 分 58 秒 | 40 秒 | 30 分 6 秒 | 27 |
| 产物传输 | 1 秒 | 1 秒 | 2 秒 | 26 |
| 证据收集 | 1 秒 | 884.17 毫秒 | 5 秒 | 27 |
| 资源清理 | 3 秒 | 2 秒 | 12 秒 | 27 |
| 评分 | 827.51 毫秒 | 704.56 毫秒 | 1 秒 | 26 |

| 准备轮次 | 整轮上限（秒） | 环境基础时限（秒） | 准备并发 | 放宽系数 | 实际环境时限（秒） |
| --- | --- | --- | --- | --- | --- |
| 104894fb-9766-4c51-ad98-92b13464911e | 14,400 | 3600 | 2 | 2 | 7200 |
| 27515180-0d74-4360-b80b-5860e0c6cb39 | 14,400 | 3600 | 2 | 2 | 7200 |

### 模型用量

| 范围 | 输入 token | 输出 token | 总 token | 覆盖记录 | 不完整记录 |
| --- | --- | --- | --- | --- | --- |
| 最终结果 | 53,241,032 | 936,478 | 54,177,510 | 26 / 90 | — |
| 运行累计 | 53,241,032 | 936,478 | 54,177,510 | 26 / 28 | 1 |

## Tasks

| 任务 | 状态 | 评分 | 解题用时（秒） | 验证用时（秒） | 轨迹 / 产物 | 错误 | 证据 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | completed | 1 | 265.29 | 0.99 | complete / complete | — | [result](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/df834988-ebfb-4ea5-93f3-71a2879d162a/result.json) · [文件清单](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/df834988-ebfb-4ea5-93f3-71a2879d162a/files.json) · [轨迹](tasks/5feceb66ffc86f38d952786c6d696c79c2dbc239dd4e91b46729d73a27fb57e9/attempts/df834988-ebfb-4ea5-93f3-71a2879d162a/agent/trajectory.jsonl) |
| 1 | completed | 1 | 186.42 | 0.81 | complete / complete | — | [result](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/6653a5b2-5bdf-419d-a4cd-aa02b4a96768/result.json) · [文件清单](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/6653a5b2-5bdf-419d-a4cd-aa02b4a96768/files.json) · [轨迹](tasks/6b86b273ff34fce19d6b804eff5a3f5747ada4eaa22f1d49c01e52ddb7875b4b/attempts/6653a5b2-5bdf-419d-a4cd-aa02b4a96768/agent/trajectory.jsonl) |
| 2 | completed | 1 | 211.55 | 1.21 | complete / complete | — | [result](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/92060661-eeb5-4760-b47b-a7be84e0a8b1/result.json) · [文件清单](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/92060661-eeb5-4760-b47b-a7be84e0a8b1/files.json) · [轨迹](tasks/d4735e3a265e16eee03f59718b9b5d03019c07d8b6c51f90da3a666eec13ab35/attempts/92060661-eeb5-4760-b47b-a7be84e0a8b1/agent/trajectory.jsonl) |
| 3 | completed | 0 | 158.12 | 0.96 | complete / complete | — | [result](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/c6796786-6f9c-4b11-8ec6-437e53b90624/result.json) · [文件清单](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/c6796786-6f9c-4b11-8ec6-437e53b90624/files.json) · [轨迹](tasks/4e07408562bedb8b60ce05c1decfe3ad16b72230967de01f640b7e4729b49fce/attempts/c6796786-6f9c-4b11-8ec6-437e53b90624/agent/trajectory.jsonl) |
| 4 | completed | 1 | 43.22 | 0.76 | complete / complete | — | [result](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/1b726a45-5eff-41b9-a8e4-114c80ffe6d7/result.json) · [文件清单](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/1b726a45-5eff-41b9-a8e4-114c80ffe6d7/files.json) · [轨迹](tasks/4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a/attempts/1b726a45-5eff-41b9-a8e4-114c80ffe6d7/agent/trajectory.jsonl) |
| 5 | completed | 1 | 86.07 | 0.71 | complete / complete | — | [result](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/847084cc-26e8-4c9b-8cb2-b22ff72a0463/result.json) · [文件清单](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/847084cc-26e8-4c9b-8cb2-b22ff72a0463/files.json) · [轨迹](tasks/ef2d127de37b942baad06145e54b0c619a1f22327b2ebbcfbec78f5564afe39d/attempts/847084cc-26e8-4c9b-8cb2-b22ff72a0463/agent/trajectory.jsonl) |
| 6 | completed | 0 | 269.36 | 0.72 | complete / complete | — | [result](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/16c130f8-c9a1-4f7e-9307-9c3afbdb3485/result.json) · [文件清单](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/16c130f8-c9a1-4f7e-9307-9c3afbdb3485/files.json) · [轨迹](tasks/e7f6c011776e8db7cd330b54174fd76f7d0216b612387a5ffcfb81e6f0919683/attempts/16c130f8-c9a1-4f7e-9307-9c3afbdb3485/agent/trajectory.jsonl) |
| 7 | completed | 1 | 54.89 | 0.72 | complete / complete | — | [result](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/9cf9c4ca-f614-40d5-98fc-a881cb060869/result.json) · [文件清单](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/9cf9c4ca-f614-40d5-98fc-a881cb060869/files.json) · [轨迹](tasks/7902699be42c8a8e46fbbb4501726517e86b22c56a189f7625a6da49081b2451/attempts/9cf9c4ca-f614-40d5-98fc-a881cb060869/agent/trajectory.jsonl) |
| 8 | completed | 0 | 104.90 | 0.76 | complete / complete | — | [result](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/508abec5-a83c-4f3e-b552-8fb15dc037c2/result.json) · [文件清单](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/508abec5-a83c-4f3e-b552-8fb15dc037c2/files.json) · [轨迹](tasks/2c624232cdd221771294dfbb310aca000a0df6ac8b66b696d90ef06fdefb64a3/attempts/508abec5-a83c-4f3e-b552-8fb15dc037c2/agent/trajectory.jsonl) |
| 9 | completed | 1 | 39.54 | 0.76 | complete / complete | — | [result](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/77cfe68d-2744-40d3-9a59-8b9b04e4dcdf/result.json) · [文件清单](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/77cfe68d-2744-40d3-9a59-8b9b04e4dcdf/files.json) · [轨迹](tasks/19581e27de7ced00ff1ce50b2047e7a567c76b1cbaebabe5ef03f7c3017bb5b7/attempts/77cfe68d-2744-40d3-9a59-8b9b04e4dcdf/agent/trajectory.jsonl) |
| 10 | completed | 0 | 211.09 | 0.86 | complete / complete | — | [result](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/e851dfaa-5aec-4b5d-836e-35eb1ee126f7/result.json) · [文件清单](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/e851dfaa-5aec-4b5d-836e-35eb1ee126f7/files.json) · [轨迹](tasks/4a44dc15364204a80fe80e9039455cc1608281820fe2b24f1e5233ade6af1dd5/attempts/e851dfaa-5aec-4b5d-836e-35eb1ee126f7/agent/trajectory.jsonl) |
| 11 | completed | 1 | 1805.67 | 0.89 | complete / complete | — | [result](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/33d8fc1e-1881-408a-ad79-304a4e4c26d2/result.json) · [文件清单](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/33d8fc1e-1881-408a-ad79-304a4e4c26d2/files.json) · [轨迹](tasks/4fc82b26aecb47d2868c4efbe3581732a3e7cbcc6c2efb32062c08170a05eeb8/attempts/33d8fc1e-1881-408a-ad79-304a4e4c26d2/agent/trajectory.jsonl) |
| 12 | completed | 1 | 74.96 | 0.70 | complete / complete | — | [result](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/c65c4715-d2f9-41af-90b1-9b0789478704/result.json) · [文件清单](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/c65c4715-d2f9-41af-90b1-9b0789478704/files.json) · [轨迹](tasks/6b51d431df5d7f141cbececcf79edf3dd861c3b4069f0b11661a3eefacbba918/attempts/c65c4715-d2f9-41af-90b1-9b0789478704/agent/trajectory.jsonl) |
| 13 | completed | 1 | 1353.43 | 0.75 | complete / complete | — | [result](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/e2966d27-69b8-41cd-85ef-b2aca81c4102/result.json) · [文件清单](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/e2966d27-69b8-41cd-85ef-b2aca81c4102/files.json) · [轨迹](tasks/3fdba35f04dc8c462986c992bcf875546257113072a909c162f7e470e581e278/attempts/e2966d27-69b8-41cd-85ef-b2aca81c4102/agent/trajectory.jsonl) |
| 14 | completed | 1 | 48.59 | 0.71 | complete / complete | — | [result](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/e16b9677-f685-446e-8c98-e2e5334bd632/result.json) · [文件清单](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/e16b9677-f685-446e-8c98-e2e5334bd632/files.json) · [轨迹](tasks/8527a891e224136950ff32ca212b45bc93f69fbb801c3b1ebedac52775f99e61/attempts/e16b9677-f685-446e-8c98-e2e5334bd632/agent/trajectory.jsonl) |
| 15 | completed | 1 | 557.57 | 0.81 | complete / complete | — | [result](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/a2c1b510-d3f3-44fd-8347-557651357af4/result.json) · [文件清单](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/a2c1b510-d3f3-44fd-8347-557651357af4/files.json) · [轨迹](tasks/e629fa6598d732768f7c726b4b621285f9c3b85303900aa912017db7617d8bdb/attempts/a2c1b510-d3f3-44fd-8347-557651357af4/agent/trajectory.jsonl) |
| 16 | completed | 1 | 1276.20 | 0.83 | complete / complete | — | [result](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/4d181b32-b2eb-4496-ab26-a59ed3821657/result.json) · [文件清单](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/4d181b32-b2eb-4496-ab26-a59ed3821657/files.json) · [轨迹](tasks/b17ef6d19c7a5b1ee83b907c595526dcb1eb06db8227d650d5dda0a9f4ce8cd9/attempts/4d181b32-b2eb-4496-ab26-a59ed3821657/agent/trajectory.jsonl) |
| 17 | completed | 0 | 271.06 | 0.79 | complete / complete | — | [result](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/dede9009-13fb-4f4d-babf-54d808f494cd/result.json) · [文件清单](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/dede9009-13fb-4f4d-babf-54d808f494cd/files.json) · [轨迹](tasks/4523540f1504cd17100c4835e85b7eefd49911580f8efff0599a8f283be6b9e3/attempts/dede9009-13fb-4f4d-babf-54d808f494cd/agent/trajectory.jsonl) |
| 18 | completed | 1 | 225.26 | 0.79 | complete / complete | — | [result](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/37e45ff9-134a-4253-8a7f-c8f4d69bb748/result.json) · [文件清单](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/37e45ff9-134a-4253-8a7f-c8f4d69bb748/files.json) · [轨迹](tasks/4ec9599fc203d176a301536c2e091a19bc852759b255bd6818810a42c5fed14a/attempts/37e45ff9-134a-4253-8a7f-c8f4d69bb748/agent/trajectory.jsonl) |
| 19 | completed | 0 | 455.78 | 0.90 | complete / complete | — | [result](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/8a8b215d-6aa3-47c0-898b-9da0cdba0364/result.json) · [文件清单](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/8a8b215d-6aa3-47c0-898b-9da0cdba0364/files.json) · [轨迹](tasks/9400f1b21cb527d7fa3d3eabba93557a18ebe7a2ca4e471cfe5e4c5b4ca7f767/attempts/8a8b215d-6aa3-47c0-898b-9da0cdba0364/agent/trajectory.jsonl) |
| 20 | completed | 1 | 353.30 | 0.82 | complete / complete | — | [result](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/ff2180d5-b987-4367-8065-14538e94ec9d/result.json) · [文件清单](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/ff2180d5-b987-4367-8065-14538e94ec9d/files.json) · [轨迹](tasks/f5ca38f748a1d6eaf726b8a42fb575c3c71f1864a8143301782de13da2d9202b/attempts/ff2180d5-b987-4367-8065-14538e94ec9d/agent/trajectory.jsonl) |
| 21 | completed | 1 | 142.25 | 0.72 | complete / complete | — | [result](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/554f7154-6dcd-4824-8d01-cc3def75a7bb/result.json) · [文件清单](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/554f7154-6dcd-4824-8d01-cc3def75a7bb/files.json) · [轨迹](tasks/6f4b6612125fb3a0daecd2799dfd6c9c299424fd920f9b308110a2c1fbd8f443/attempts/554f7154-6dcd-4824-8d01-cc3def75a7bb/agent/trajectory.jsonl) |
| 22 | completed | 1 | 166.87 | 0.73 | complete / complete | — | [result](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/5acfe1c7-168f-4ca9-b316-283a4cc943d1/result.json) · [文件清单](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/5acfe1c7-168f-4ca9-b316-283a4cc943d1/files.json) · [轨迹](tasks/785f3ec7eb32f30b90cd0fcf3657d388b5ff4297f2f9716ff66e9b69c05ddd09/attempts/5acfe1c7-168f-4ca9-b316-283a4cc943d1/agent/trajectory.jsonl) |
| 23 | completed | 1 | 125.86 | 0.97 | complete / complete | — | [result](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/b19a3804-daf4-4c82-b31d-41ce73103df0/result.json) · [文件清单](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/b19a3804-daf4-4c82-b31d-41ce73103df0/files.json) · [轨迹](tasks/535fa30d7e25dd8a49f1536779734ec8286108d115da5045d77f3b4185d8f790/attempts/b19a3804-daf4-4c82-b31d-41ce73103df0/agent/trajectory.jsonl) |
| 24 | completed | 1 | 215.05 | 0.86 | complete / complete | — | [result](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/ee1e2699-adb9-4125-91c4-1843220b4eca/result.json) · [文件清单](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/ee1e2699-adb9-4125-91c4-1843220b4eca/files.json) · [轨迹](tasks/c2356069e9d1e79ca924378153cfbbfb4d4416b1f99d41a2940bfdb66c5319db/attempts/ee1e2699-adb9-4125-91c4-1843220b4eca/agent/trajectory.jsonl) |
| 25 | completed | 1 | 370.88 | 0.98 | complete / complete | — | [result](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/c33da637-69f2-41f2-8314-e8097fa13d20/result.json) · [文件清单](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/c33da637-69f2-41f2-8314-e8097fa13d20/files.json) · [轨迹](tasks/b7a56873cd771f2c446d369b649430b65a756ba278ff97ec81bb6f55b2e73569/attempts/c33da637-69f2-41f2-8314-e8097fa13d20/agent/trajectory.jsonl) |
| 26 | pending | — | — | — | — | — | — |
| 27 | cancelled | — | 580.59 | — | partial / complete | RUN\_CANCELLED; ARTIFACT\_COLLECTION\_INCOMPLETE | [result](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/5ac5d6f9-9853-47b2-be8c-8c6ae08d06ac/result.json) · [文件清单](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/5ac5d6f9-9853-47b2-be8c-8c6ae08d06ac/files.json) · [轨迹](tasks/670671cd97404156226e507973f2ab8330d3022ca96e0c93bdbdb320c41adcaf/attempts/5ac5d6f9-9853-47b2-be8c-8c6ae08d06ac/agent/trajectory.jsonl) |
| 28 | pending | — | — | — | — | — | — |
| 29 | pending | — | — | — | — | — | — |
| 30 | pending | — | — | — | — | — | — |
| 31 | pending | — | — | — | — | — | — |
| 32 | pending | — | — | — | — | — | — |
| 33 | pending | — | — | — | — | — | — |
| 34 | pending | — | — | — | — | — | — |
| 35 | pending | — | — | — | — | — | — |
| 36 | pending | — | — | — | — | — | — |
| 37 | pending | — | — | — | — | — | — |
| 38 | pending | — | — | — | — | — | — |
| 39 | pending | — | — | — | — | — | — |
| 40 | pending | — | — | — | — | — | — |
| 41 | pending | — | — | — | — | — | — |
| 42 | pending | — | — | — | — | — | — |
| 43 | pending | — | — | — | — | — | — |
| 44 | pending | — | — | — | — | — | — |
| 45 | pending | — | — | — | — | — | — |
| 46 | pending | — | — | — | — | — | — |
| 47 | pending | — | — | — | — | — | — |
| 48 | pending | — | — | — | — | — | — |
| 49 | pending | — | — | — | — | — | — |
| 50 | pending | — | — | — | — | — | — |
| 51 | pending | — | — | — | — | — | — |
| 52 | pending | — | — | — | — | — | — |
| 53 | pending | — | — | — | — | — | — |
| 54 | pending | — | — | — | — | — | — |
| 55 | pending | — | — | — | — | — | — |
| 56 | pending | — | — | — | — | — | — |
| 57 | pending | — | — | — | — | — | — |
| 58 | pending | — | — | — | — | — | — |
| 59 | pending | — | — | — | — | — | — |
| 60 | pending | — | — | — | — | — | — |
| 61 | pending | — | — | — | — | — | — |
| 62 | pending | — | — | — | — | — | — |
| 63 | pending | — | — | — | — | — | — |
| 64 | pending | — | — | — | — | — | — |
| 65 | pending | — | — | — | — | — | — |
| 66 | pending | — | — | — | — | — | — |
| 67 | pending | — | — | — | — | — | — |
| 68 | pending | — | — | — | — | — | — |
| 69 | pending | — | — | — | — | — | — |
| 70 | pending | — | — | — | — | — | — |
| 71 | pending | — | — | — | — | — | — |
| 72 | pending | — | — | — | — | — | — |
| 73 | pending | — | — | — | — | — | — |
| 74 | pending | — | — | — | — | — | — |
| 75 | pending | — | — | — | — | — | — |
| 76 | pending | — | — | — | — | — | — |
| 77 | pending | — | — | — | — | — | — |
| 78 | pending | — | — | — | — | — | — |
| 79 | pending | — | — | — | — | — | — |
| 80 | pending | — | — | — | — | — | — |
| 81 | pending | — | — | — | — | — | — |
| 82 | pending | — | — | — | — | — | — |
| 83 | pending | — | — | — | — | — | — |
| 84 | pending | — | — | — | — | — | — |
| 85 | pending | — | — | — | — | — | — |
| 86 | pending | — | — | — | — | — | — |
| 87 | pending | — | — | — | — | — | — |
| 88 | pending | — | — | — | — | — | — |
| 89 | pending | — | — | — | — | — | — |

## 错误分类与处理

异常任务 1；错误记录 2（主流程 1；证据收集 1；资源清理 0）。

| 阶段 | 错误码 | 涉及任务数 | 记录数 |
| --- | --- | --- | --- |
| solve | RUN_CANCELLED | 1 | 1 |
| collect | ARTIFACT_COLLECTION_INCOMPLETE | 1 | 1 |

## 运行文件

[指标 JSON](metrics.json) · [运行清单](manifest.json) · [保存配置](config.yaml)

数据来源：huggingface-snapshot:databricks/officeqa-pro-v2 @ 65a2b315780417bc50d7bfe6e5bdb904e63fda65

